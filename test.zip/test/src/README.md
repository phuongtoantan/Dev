# Writing libraries
## Guide: https://www.jenkins.io/doc/book/pipeline/shared-libraries/#writing-libraries
