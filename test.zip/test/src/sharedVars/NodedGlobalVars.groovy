// Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.
package sharedVars

class NodedGlobalVars {
    def GenericVars = new GenericVars()

    // Noded RPM's ARTIFACTORY paths
    static String NODED_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + "mobile-phoenix-rpm-candidate-rr/noded/"
    
    static String NODED_TMP_IMAGE_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/noded-tmp'
    static String NODED_MAIN_IMAGE_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/noded'
    static String NODED_PR_IMAGE_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/noded-pr'

    static String NODED_RPM_MAIN_PATH = NodedGlobalVars.NODED_RPM_PATH
    static String NODED_RPM_TMP_PATH = "mobile-phoenix-rpm-pr-rr"+ '/noded-tmp' + '/noded'
}