// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package sharedVars

class CUGlobalVars {
    def GenericVars = new GenericVars()
    
    // Artifactory
    static String SEM_VERSION = 'CU_2.1.0.0'
    static String TMP_SEM_VERSION = 'CU_TMP_2.1.0.0'
    static String SEM_VERSION_PR = 'v0.2.1'
    static String DOCKER_IMAGE_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/cu-images'
    static String DOCKER_IMAGE_PROD_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/cu-images-prod'
    static String ARTIFACT_PATH = GenericVars.RAN_GENERIC_REPO + '/rpm/cups'
    static String ARTITACTORY_CUSTOM_IMAGE_URL = "phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/dev-image"
    static String RAN_GENERIC_REPO_URL = GenericVars.ARTITACTORY_BASE_URL + GenericVars.RAN_GENERIC_REPO
    static String CUCP_DPDK_IMG_FULL_URL = GenericVars.ARTITACTORY_DOCKER_BASE_URL + '/cu-images-prod/rhel8/dpdk/cp/cucp-dpdk'
    static String CUUP_DPDK_IMG_FULL_URL = GenericVars.ARTITACTORY_DOCKER_BASE_URL + '/cu-images-prod/rhel8/dpdk/up/cuup-dpdk'
    static String CU_UBI_IMAGE = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/cu_ubi'
}