// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package sharedVars

class SMSGlobalVars {
    def GenericVars = new GenericVars()

    // SMS RPM's Artifactory paths
    static String SMS_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + "mobile-phoenix-rpm-candidate-rr/noded/"
    static String GREEN_LOAD_RPM_ARTIFACT_PATH = GenericVars.ARTITACTORY_BASE_URL + "mobile-phoenix-rpm-green_load/latest/"
    
    static String SMS_TMP_IMAGE_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/sms-tmp'
    static String SMS_MAIN_IMAGE_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/sms'
    static String SMS_PR_IMAGE_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/sms-pr'

    static String SMS_RPM_MAIN_PATH = SMSGlobalVars.SMS_RPM_PATH
    static String SMS_RPM_TMP_PATH = "mobile-phoenix-rpm-pr-rr"+ '/sms-tmp' + '/sms'
}
