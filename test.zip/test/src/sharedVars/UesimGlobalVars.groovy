// Copyright (c) 2022-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

package sharedVars

class UesimGlobalVars {
    //Main-redhat8
    static String UESIM_DPDK_IMG_FULL_URL = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker/artifactory/platform/uesim-images/rhel8/main/dpdk/uesim'
    static String UESIM_MAIN_IMAGE_DPDK_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker/artifactory/platform/uesim-images/rhel8/main/dpdk/uesim'
    static String UESIM_IMAGE_DEV_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker/artifactory/platform/dev-image/uesim-image'
    static String UESIM_MAIN_BINARY_PATH = 'mobile-phoenix-ran-generic/bin/uesim/rhel8/main/dpdk'
    static String UESIM_DEV_BINARY_PATH = 'mobile-phoenix-ran-generic/bin/uesim/dev'

    // Local Paths
    static String UESIM_DPDK_IMG_FULL_URL_LOCAL_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/uesim-images/rhel8/main/dpdk/uesim'
    static String UESIM_MAIN_IMAGE_DPDK_LOCAL_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/uesim-images/rhel8/main/dpdk/uesim'
    static String UESIM_IMAGE_DEV_LOCAL_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/dev-image/uesim-image'
    static String UESIM_MAIN_BINARY_LOCAL_PATH = 'mobile-phoenix-ran-generic-local/bin/uesim/rhel8/main/dpdk'
    static String UESIM_DEV_BINARY_LOCAL_PATH = 'mobile-phoenix-ran-generic-local/bin/uesim/dev'
}