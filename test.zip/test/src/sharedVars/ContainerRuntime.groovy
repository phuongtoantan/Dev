// Copyright © 2023-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
package sharedVars

/*
 * Valid Container runtimes
 * @see https://docs.groovy-lang.org/latest/html/documentation/#_string_to_enum_coercion
 */
public class ContainerRuntime {
    enum RuntimeType {
        podman,
        docker
    }

    static getRuntimeType() {
        return RuntimeType
    } 
}
