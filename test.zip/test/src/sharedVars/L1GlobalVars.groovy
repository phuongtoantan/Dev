// Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
package sharedVars
import java.net.URLEncoder
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


public class L1GlobalVars {
    static String L1_TARGET_FUSION = "fusion"
    static String L1_TARGET_REMOTE = "remote"
    static String L1_PR_BUILD_DIR = "PR_build"
    static Boolean ENABLE_DEBUG_PRINT = true

    static int debugPrintStackLine(Boolean enable = false) {
        int lineNumber = Thread.currentThread().getStackTrace()[2].getLineNumber(); 
        String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        if (enable) {
            def l1common = new jenkins.L1CoreCommon()
            l1common.print_jenkins_console("**DEBUG LOG**: Method Name ${methodName} - Line ${lineNumber} ")
        }


    }    
    static int debugPrintText(Boolean enable = false, String text = "") {
        if (enable) {
            def l1common = new jenkins.L1CoreCommon()
            l1common.print_jenkins_console("**DEBUG LOG**: ${text}")
        }
    }     

    // static String L1_CORE_PIPELINE_BUILD = "L1CorePipelineBuild"
    // static String L1_PLATFORM_APPS_PIPELINE_BUILD = "L1PlatformAppsPipelineBuild"
    

    static String VERSION_JSON_FILE = "version.json"

    def Target createTarget(String targetType, String soc, String oran, String subchannel) { 
        if (targetType == L1_TARGET_FUSION) {
            print "Fusion target!\n"
            return new FusionMpltdTarget(soc,  oran,  subchannel)
        }
        else {
            print "Remote target!\n"
            return new RemoteMpltdTarget(soc,  oran,  subchannel)
        }
    }
    public class Target {
        // static String TOPIC = 'phoenix-jenkins-events'
        // static String TESTCATEGORY = 'Sanity'
        // static String DEFAULT_L1_AUTOMATION_BRANCH = 'main'
        // static String ARTIFACTORY_COMPONENT_PATH = 'L1/firmware_f105'
        // static String SUBC_30 = "SUBC_30"
        // static String NON_ORAN = "NON_ORAN"
        // static String SUBC_15 = "SUBC_15"
        // static String ORAN = "ORAN"        
        //build_${BOARD_SO}_${SUBC_30}_${ORAN}_fusionMPLTD.tar.gz
        public String soc;
        public String subchannel;
        public String oran;
        public String artifactoryComponentPath;
        public String testCategory;
        public String packageName;
        public String hostPackageName;
        Target(String soc, String oran, String subchannel) { 
            this.soc = soc
            this.oran = oran
            this.subchannel = subchannel
            this.artifactoryComponentPath = "" 
            this.packageName = "build_oran_mhab.tar.gz"
            this.hostPackageName = "mpltd_img_pkg.tgz"
        } 

        public String getArtifactoryComponentPath () {
            return artifactoryComponentPath
        }
        public String getPackageNameTagGz () {
            return packageName
        }

        public String getHostPackageName () {
            return hostPackageName
        }

        public String getHostPackageNameWithoutExt () {
            return this.hostPackageName.replaceFirst(~/\..+$/, '')
        }

        public String getPackageNameWithoutExt () {
            return this.packageName.replaceFirst(~/\..+$/, '')
        }
    }

    public class FusionMpltdTarget extends Target{
        FusionMpltdTarget (String soc, String oran, String subchannel) {             
            super(soc,  oran, subchannel)

            this.packageName = String.format("build_%s_%s_%s_fusionMPLTD.tar.gz", soc, subchannel, oran)
            this.artifactoryComponentPath = 'L1/firmware_f105'
        } 
    }

    class RemoteMpltdTarget extends Target{
        public RemoteMpltdTarget (String soc, String oran, String subchannel) {             
            super(soc,  oran, subchannel)
            this.packageName = String.format("build_%s_%s_%s_remoteMPLTD.tar.gz", soc, subchannel, oran)
            this.artifactoryComponentPath = 'L1/firmware_f105'
        } 
    }

    public class L1PlatformImage{
        public String imageLabel;
        public String imageType;
        public String packageName;
        public String l1platformImagePath;
        public String l1platformImageBuildScript;
        public String buildOutputDir;
        public String artifactoryComponentPath;
        public String qtestClassName = "";
        public String qtestMappingEntry = "";
        public String blackduck_tools_mapping_label = "";
        public List<String> releaseCandidateAppBranches = []

        L1PlatformImage (String imageType, String imageLabel, String packageName = "", String l1platformImagePath= "", 
                    String l1platformImageBuildScript= "",String buildOutputDir= "", String artifactoryComponentPath= "", List<String> releaseCandidateAppBranches = []) {
            this.imageLabel = imageLabel
            this.imageType = imageType
            this.packageName = packageName
            this.l1platformImagePath = l1platformImagePath
            this.l1platformImageBuildScript = l1platformImageBuildScript
            this.buildOutputDir = buildOutputDir
            this.artifactoryComponentPath = artifactoryComponentPath
            this.releaseCandidateAppBranches = releaseCandidateAppBranches
        };

        public String getTarNameWithVersion(String version='0.0.0.0-0'){
            return "${this.getPackageNameWithoutExtValue()}-${version}.tar.gz"
        };


        // Add a Value to all getters, as it keeps calling them in an infinite loop, under the hood caller the getter itself.
        public String getImageTypeValue() { return this.imageType; }
        public String getL1platformImageBuildScriptValue() { print "REMOVE LOG l1platformImageBuildScript ${this.l1platformImageBuildScript}"; return this.l1platformImageBuildScript;}
        public String getBuildOutputDirValue(){return this.buildOutputDir; }
        public String getPackageNameTarGzValue(){return this.packageName;}
        public String getPackageNameWithoutExtValue(){ return this.packageName.replaceFirst(~/\..+$/, ''); }
    }


    public class L1PlatformMtfImage extends L1PlatformImage{

        L1PlatformMtfImage ()
        {
            super(L1GlobalVars.L1_MANUFACTURING_IMAGE, "Manufacturing Image")
  
            this.packageName = "L1_Platform_mtf.tar.gz"
            // Pathing inside L1-Platform repo
            this.l1platformImagePath = "ci/image_mtf/"
            this.l1platformImageBuildScript = "${l1platformImagePath}build.sh"
            this.buildOutputDir = "output_ci_image_mfg"
            this.artifactoryComponentPath = ""
            this.qtestClassName = "L1PlatformManufacturingTests"
            this.blackduck_tools_mapping_label = "Platform_manufacturing"
            this.qtestMappingEntry = "qTestL1PlatformManufacturingTestMapping"
            this.releaseCandidateAppBranches = [L1GlobalVars.L1_PLATFORM_APP_MAIN_MANUFACTURING_BRANCH]
            
            
        }
    }

    public class L1PlatformDvtImage extends L1PlatformImage{
        L1PlatformDvtImage ()
        {
            super(L1GlobalVars.L1_DVT_DEFAULT_IMAGE, "Dvt Image")

            this.packageName = "L1_Platform_dvt.tar.gz"
            // Pathing inside L1-Platform repo
            this.blackduck_tools_mapping_label = "Platform_dvt"
            this.l1platformImagePath =  "ci/image_dvt/"
            this.l1platformImageBuildScript = "${l1platformImagePath}build.sh"
            this.buildOutputDir =  "output_ci_image_dvt"
            this.artifactoryComponentPath = ""
            this.qtestClassName = "L1PlatformDvtTests"
            this.qtestMappingEntry = "qTestL1PlatformDvtTestMapping"
            
        }

    }

    public class L1PlatformFdfImage extends L1PlatformImage{
        L1PlatformFdfImage ()
        {
            super(L1GlobalVars.L1_FACTORY_DEFAULT_IMAGE, "Factory Default Image")
            this.packageName = "L1_Platform_fdf.tar.gz"
            // Pathing inside L1-Platform repo
            this.blackduck_tools_mapping_label = "Platform_factory_default"
            this.l1platformImagePath = "ci/image_fdf/"
            this.l1platformImageBuildScript = "${l1platformImagePath}build.sh"
            this.buildOutputDir = "output_ci_image_fdf"
            this.artifactoryComponentPath = ""
            this.qtestClassName = "L1PlatformFactoryDefaultTests"
            this.qtestMappingEntry = "qTestL1PlatformFactoryDefaultTestMapping"
            this.releaseCandidateAppBranches = [L1GlobalVars.L1_PLATFORM_APP_MAIN_FDF_BRANCH]
            
        }
        
    }

    public class L1RegulatoryImage extends L1PlatformImage{

        L1RegulatoryImage ()
        {
            super(L1GlobalVars.L1_REGULATORY_IMAGE, "Regulatory Image")
            this.packageName = "L1_Platform_Regulatory.tar.gz"
            // Pathing inside L1-Platform repo
            this.blackduck_tools_mapping_label = null //"Platform_aurora_fdf"
            this.l1platformImagePath = "ci/image_regulatory/"
            this.l1platformImageBuildScript = "${l1platformImagePath}build.sh -f \${MERCURY_ACCOUNT} "
            this.buildOutputDir = "output_ci_image_regulatory" //"output_ci_image_fdf"
            this.artifactoryComponentPath = null //""
            this.qtestClassName = null //"L1PlatformAuroraTests"
            this.qtestMappingEntry = "qTestL1PlatformRegulatoryTestMapping"
            this.releaseCandidateAppBranches = [L1GlobalVars.L1_PLATFORM_APP_MAIN_REGULATORY_BRANCH]
            

        }
    }
    public class L1AuroraImage extends L1PlatformImage{

        public L1AuroraImage(String imageType) {
            super(null,null)
            this.updateImageType(imageType)
            this.packageName = "L1_Platform_${imageType.replaceAll('-', '_')}.tar.gz"
            // Pathing inside L1-Platform repo
            this.blackduck_tools_mapping_label = "Platform_aurora"
            this.l1platformImagePath = "ci/image_aurora/"
            this.l1platformImageBuildScript = "${l1platformImagePath}build.sh"
            this.buildOutputDir = "output_ci_image_aurora"
            this.artifactoryComponentPath = ""
            this.qtestClassName = "L1PlatformAuroraTests"
            this.qtestMappingEntry = "qTestL1PlatformAuroraTestMapping"
            this.releaseCandidateAppBranches = [L1GlobalVars.L1_PLATFORM_APP_MAIN_AURORA_BRANCH]
        }

        @NonCPS
        private updateImageType(String imageType) {
            this.imageType = imageType
            if (imageType == L1GlobalVars.L1_AURORA_IMAGE) {
                this.imageLabel = "Aurora Image"
            }
            if (imageType == L1GlobalVars.L1_AURORA_DEV_IMAGE) {
                this.imageLabel = "Aurora Dev Image"
            }
        }
    }

    public class L1PlatformDellRANImage extends L1PlatformImage{

        L1PlatformDellRANImage ()
        {
            super(L1GlobalVars.L1_DELL_RAN_IMAGE, "Dell RAN Image")
            this.packageName = "output_ci_image_dell_ran.tar.gz"
            // Pathing inside L1-Platform repo
            this.blackduck_tools_mapping_label = "Platform_dell_ran_image"
            this.l1platformImagePath = "ci/image_dell_ran/"
            this.l1platformImageBuildScript = "${l1platformImagePath}build.sh"
            this.buildOutputDir = "output_ci_image_eng"
            this.artifactoryComponentPath = ""
            this.qtestClassName = "L1PlatformDellRanImageTests"
            this.qtestMappingEntry = "qTestL1PlatformDellRanImageTestMapping"
            this.releaseCandidateAppBranches = [L1_PLATFORM_APP_F105_BRANCH]
            

        }
    }
    public class L1PlatformDellRANRPM extends L1PlatformImage{
        
        L1PlatformDellRANRPM ()
        {
            super(L1GlobalVars.L1_DELL_RAN_RPM, "Dell RAN Image RPM")
            this.packageName = "firmware.tar.gz"
            // Pathing inside L1-Platform repo
            this.blackduck_tools_mapping_label = "Platform_dell_firmware"
            this.l1platformImagePath = "ci/image_dell_ran_rpm/"
            this.l1platformImageBuildScript = "${l1platformImagePath}build.sh"
            this.buildOutputDir = "output_ci_image_eng_rpm"
            this.artifactoryComponentPath = ""
            this.qtestClassName = "L1PlatformDellFirmwareTests"
            this.qtestMappingEntry = "qTestL1PlatformDellFirmwareTestMapping"
            
        }        
    }

    static String L1_DEFERRED_VERSION_VALUE = ""
    static String L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R3 = "R3"
    static String L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2 = "R2"
    static String L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2_1 = "R2.1"
    static String L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R1 = "R1"
    static String L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE = L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R3
    static String L1_CURRENT_VERSION_MAJOR_MINOR = "3.0"
    static String ARTIFACTORY_COMPONENT_PATH_L1_DRIVER = 'L1/L1_driver'
    static String RPM_PR_PATH = 'mobile-phoenix-rpm-pr'
    static String RPM_CANDIDATE_PATH = 'mobile-phoenix-rpm-candidate'

    // Default value used for last successful build in pipeline
    static String PIPELINE_LAST_SUCCESSFUL_BUILD_NUM_DEFAULT = '0'

    static String ARTIFACTORY_URL = "${GenericVars.ARTITACTORY_BASE_URL}"
    static String ARTIFACTORY_API_URL = "${ARTIFACTORY_URL}api"

    // Deprecated
    //static String ARTIFACTORY_COMPONENT_PATH_L1_PLATFORM = 'L1/L1_Platform'
    //static String ARTIFACTORY_COMPONENT_PATH_L1_CORE = 'L1/L1_Core'

    // L1 Branch names    
    static String L1_FIRMWARE_IMAGES_MAIN_BRANCH = "main"

    static String L1_CORE_MAIN_BRANCH           = "main"
    static String L1_CORE_MAIN_F105_BRANCH      = "main"
    static String L1_CORE_MAIN_95O_BRANCH       = "main_95O"
    static String L1_CORE_MAIN_BRANCH_R_1_0     = "R1.0"
    static String L1_CORE_MAIN_BRANCH_R_2_0     = "${L1_CORE_MAIN_95O_BRANCH}"
    static String L1_CORE_MAIN_BRANCH_R_3_0     = "${L1_CORE_MAIN_F105_BRANCH}"

    static String [] L1_CORE_LIST_OF_MAIN_BRANCHES = [L1_CORE_MAIN_BRANCH_R_1_0, L1_CORE_MAIN_BRANCH, L1_CORE_MAIN_F105_BRANCH, L1_CORE_MAIN_95O_BRANCH]

    static String L1_PLATFORM_MAIN_BRANCH_R_1_0 = "R1.0"
    static String L1_PLATFORM_MAIN_BRANCH       = "main"
    static String L1_PLATFORM_MAIN_95O_BRANCH   = "main_95O"
    static String L1_PLATFORM_APP_MAIN_BRANCH   = "main"
    static String L1_PLATFORM_APP_MAIN_MANUFACTURING_BRANCH   = "main_manufacturing"
    static String L1_PLATFORM_APP_MAIN_FDF_BRANCH   = "main_fdf"
    static String L1_PLATFORM_APP_MAIN_AURORA_BRANCH   = "main_aurora"
    static String L1_PLATFORM_APP_MAIN_REGULATORY_BRANCH   = "main_regulatory"

    static String [] L1_PLATFORM_APP_LIST_OF_MAIN_BRANCHES = [L1_PLATFORM_MAIN_BRANCH_R_1_0, L1_PLATFORM_MAIN_BRANCH, L1_PLATFORM_MAIN_95O_BRANCH, L1_PLATFORM_APP_MAIN_BRANCH , L1_PLATFORM_APP_MAIN_MANUFACTURING_BRANCH, L1_PLATFORM_APP_MAIN_FDF_BRANCH, L1_PLATFORM_APP_MAIN_AURORA_BRANCH]
     

    static String L1_PLATFORM_MAIN_BRANCH_R_2_0 = "${L1_PLATFORM_MAIN_BRANCH}"
    static String L1_FIRMWARE_IMAGES_MAIN = "main"
    static String L1_FIRMWARE_IMAGES_DELL_RAN_BRANCH = "main_dell_ran"
    static String L1_FIRMWARE_IMAGES_FDF_BRANCH = "main_fdf"
    static String L1_FIRMWARE_IMAGES_MTF_BRANCH = "main_mtf"
    static String L1_FIRMWARE_IMAGES_AURORA_BRANCH = "main_aurora"
    static String L1_FIRMWARE_IMAGES_MPLTD_BRANCH = "main_mpltd"
    static String L1_FIRMWARE_IMAGES_BRANCH_R_2_0 = "${L1_FIRMWARE_IMAGES_MAIN}"


    static String L1_PLATFORM_DEV_BRANCH        = "dev"
    static String L1_PLATFORM_APP_F105_BRANCH   = "main"
    static String L1_PLATFORM_MAIN_BRANCH_R_3_0 = "${L1_PLATFORM_DEV_BRANCH}"

    static String L1_AUTOMATION_MAIN_BRANCH = "main"
    static String L1_AUTOMATION_DEV_BRANCH = "dev"

    // Coverity 
    static String COVERITY_SERVER = 'https://isg-coverity3.cec.lab.emc.com'
    
    // L1 Pipeline names
    static String L1_FIRMWARE_IMAGES_ARTIFACTORY_NAME           = "L1-Firmware-Images"
    static String L1_DELL_RAN_MULTIARCH_ARTIFACTORY_NAME        = "DellRanMultiArch"
    static String L1_PLATFORM_MARVELL_SDK_ARTIFACTORY_NAME      = "L1-Marvell-SDKs"
    static String L1_PLATFORM_MARVELL_BPHY_ARTIFACTORY_NAME      = "L1-Marvell-Bphy"
    static String L1_PLATFORM_MARVELL_DRIVERS_ARTIFACTORY_NAME  = "L1-Marvell-drivers"
    static String L1_PLATFORM_APPS_ARTIFACTORY_NAME             = "L1-Platform-Apps"
    static String L1_PLATFORM_HOST_DRIVERS_ARTIFACTORY_NAME     = "L1-Marvell-drivers"
    static String L1_PLATFORM_HOST_TOOLS_ARTIFACTORY_NAME       = "L1-Host-Tools"
    static String L1_CORE_ARTIFACTORY_NAME                      = "L1_Core"
    static String L1_CUSTOMER_SUPPORT_ARTIFACTORY_NAME          = "L1-customer-support"

    static String L1_FIRMWARE_IMAGES_NAME    = "${L1_PLATFORM_FOLDER_NAME}/${L1_FIRMWARE_IMAGES_ARTIFACTORY_NAME}"
    static String L1_DELL_RAN_MULTIARCH_NAME = "${L1_DELL_RAN_MULTIARCH_ARTIFACTORY_NAME}"
    static String L1_DELL_PACK_NAME          = "${L1_PLATFORM_FOLDER_NAME}/L1-Dell-Pack"
    // L1 Firmware Images multibranch
    static String L1_FIRMWARE_IMAGES_MULTIBRANCH_ARTIFACTORY_NAME   = "L1-Firmware-Images-MultiBranch"
    static String L1_FIRMWARE_IMAGES_MULTIBRANCH_NAME = "${L1_PLATFORM_FOLDER_NAME}/${L1_FIRMWARE_IMAGES_MULTIBRANCH_ARTIFACTORY_NAME}"

    static String L1_PLATFORM_FOLDER_NAME = "L1_Platform_Pipelines"
    static String L1_PLATFORM_MARVELL_SDK_NAME      = "${L1_PLATFORM_FOLDER_NAME}/${L1_PLATFORM_MARVELL_SDK_ARTIFACTORY_NAME}"
    static String L1_PLATFORM_MARVELL_BPHY_NAME      = "${L1_PLATFORM_FOLDER_NAME}/${L1_PLATFORM_MARVELL_BPHY_ARTIFACTORY_NAME}"
    static String L1_PLATFORM_MARVELL_DRIVERS_NAME  = "${L1_PLATFORM_FOLDER_NAME}/${L1_PLATFORM_MARVELL_DRIVERS_ARTIFACTORY_NAME}"
    static String L1_PLATFORM_APPS_NAME             = "${L1_PLATFORM_FOLDER_NAME}/${L1_PLATFORM_APPS_ARTIFACTORY_NAME}"
    static String L1_PLATFORM_HOST_DRIVERS_NAME     = "${L1_PLATFORM_FOLDER_NAME}/${L1_PLATFORM_HOST_DRIVERS_ARTIFACTORY_NAME}"
    static String L1_PLATFORM_HOST_TOOLS_NAME       = "${L1_PLATFORM_FOLDER_NAME}/${L1_PLATFORM_HOST_TOOLS_ARTIFACTORY_NAME}"
    static String L1_CORE_NAME                      = "L1_App_DPDK"
    static String L1_CUSTOMER_SUPPORT_NAME          = "${L1_CUSTOMER_SUPPORT_ARTIFACTORY_NAME}"

    static String L1_SECURITY_FOLDER_NAME                       = "Security"
    static String L1_PLATFORM_COVERITY_ARTIFACTORY_NAME         = "L1-Platform-Coverity"
    static String L1_PLATFORM_COVERITY_PR_ARTIFACTORY_NAME      = "L1-Platform-Coverity-PR"
    static String L1_CORE_COVERITY_ARTIFACTORY_NAME             = "L1-Core-Coverity"
    static String L1_CORE_COVERITY_PR_ARTIFACTORY_NAME          = "L1-Core-Coverity-PR"
    static String L1_PLATFORM_COVERITY_PIPELINE_NAME            = "${L1_SECURITY_FOLDER_NAME}/${L1_PLATFORM_COVERITY_ARTIFACTORY_NAME}"
    static String L1_PLATFORM_COVERITY_PR_PIPELINE_NAME         = "${L1_SECURITY_FOLDER_NAME}/${L1_PLATFORM_COVERITY_PR_ARTIFACTORY_NAME}"
    static String L1_CORE_COVERITY_PIPELINE_NAME                = "${L1_SECURITY_FOLDER_NAME}/${L1_CORE_COVERITY_ARTIFACTORY_NAME}"
    static String L1_CORE_COVERITY_PR_PIPELINE_NAME             = "${L1_SECURITY_FOLDER_NAME}/${L1_CORE_COVERITY_PR_ARTIFACTORY_NAME}"


    static String L1_PLATFORM_MARVELL_DRIVERS_GIT_REPO = "eos2git.cec.lab.emc.com/Mobile-Phoenix/l1-marvell-drivers"
    static String L1_CORE_GIT_REPO = "eos2git.cec.lab.emc.com/Mobile-Phoenix/L1-Core"


    //Deprecated
    // static String L1_MARVELL_DRIVERS_NAME = "${L1_PLATFORM_FOLDER_NAME}/L1-Marvell-drivers"
    // static String L1_MARVELL_SDK_NAME = "${L1_PLATFORM_FOLDER_NAME}/L1-Marvell-SDKs"
    // static String L1_MARVELL_SDK_SIGNED_NAME = "${L1_PLATFORM_FOLDER_NAME}/L1-Marvell-SDKs-signed"


    static String ARTIFACT_PATH_L1_RAN_GENERIC_REPO ="${GenericVars.RAN_GENERIC_REPO}/${L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE}/bin/L1"
    
    // Hack required for F105
    static String ARTIFACT_PATH_L1_RAN_GENERIC_REPO_R2 ="${GenericVars.RAN_GENERIC_REPO}/${L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2}/bin/L1"
    static String ARTIFACT_PATH_L1_RAN_GENERIC_REPO_R3 ="${GenericVars.RAN_GENERIC_REPO}/${L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R3}/bin/L1"

    @NonCPS
    static def String getL1GenericRepoPathForArtifactoryVersion (String artifactoryFolder, String version){ return "${GenericVars.RAN_GENERIC_REPO}/${version}/bin/L1${artifactoryFolder}" }
    static def String getL1RPMRepoPathForArtifactoryVersion (String artifactoryFolder, String version){ return "${GenericVars.RPM_PR_PATH}/${version}/bin/L1${artifactoryFolder}" }
    static def String getL1RPMCandidateRepoPathForArtifactoryVersion (String artifactoryFolder, String version){ return "${GenericVars.RPM_CANDIDATE_PATH}/${version}/bin/L1${artifactoryFolder}" }
        

    // 5gran_pack
    static String ARTIFACT_PATH_L1_PACK = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/5GRAN_pack"

    // main/master branch
    static String ARTIFACT_PATH_L1_PACK_RPM_MAIN = "${GenericVars.RPM_CANDIDATE_PATH}/${L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE}/L1/5GRAN_pack"
    static String ARTIFACT_PATH_L1_PACK_FIRMWARE_RPM_MAIN = "${ARTIFACT_PATH_L1_PACK_RPM_MAIN}/firmware"

    // PR branches
    static String ARTIFACT_PATH_L1_PACK_RPM_PR = "${GenericVars.RPM_PR_PATH}/${L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE}/L1/5GRAN_pack"
    static String ARTIFACT_PATH_L1_PACK_FIRMWARE_RPM_PR = "${ARTIFACT_PATH_L1_PACK_RPM_PR}/firmware"

    // MultiArch
    static String ARTIFACT_PATH_MULTIARCH_PATH = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/DellRanMultiArch"
    static String ARTIFACT_PATH_MULTIARCH_PATH_R2 = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO_R2}/DellRanMultiArch"

    static String ARTIFACT_PATH_MULTIARCH_RPM_MAIN = "${GenericVars.RPM_CANDIDATE_PATH}/${L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE}/L1/DellRanMultiArch"
    static String ARTIFACT_PATH_MULTIARCH_FIRMWARE_RPM_MAIN = "${ARTIFACT_PATH_MULTIARCH_RPM_MAIN}/firmware"

    static String ARTIFACT_PATH_MULTIARCH_RPM_MAIN_R2 = "${GenericVars.RPM_CANDIDATE_PATH}/${L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2}/L1/DellRanMultiArch"
    static String ARTIFACT_PATH_MULTIARCH_FIRMWARE_RPM_MAIN_R2 = "${ARTIFACT_PATH_MULTIARCH_RPM_MAIN_R2}/firmware"

    static String ARTIFACT_PATH_MULTIARCH_RPM_PR = "${GenericVars.RPM_PR_PATH}/${L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE}/L1/DellRanMultiArch"
    static String ARTIFACT_PATH_MULTIARCH_FIRMWARE_RPM_PR = "${ARTIFACT_PATH_MULTIARCH_RPM_PR}/firmware"

    static String ARTIFACT_PATH_MULTIARCH_RPM_PR_R2 = "${GenericVars.RPM_PR_PATH}/${L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2}/L1/DellRanMultiArch"
    static String ARTIFACT_PATH_MULTIARCH_FIRMWARE_RPM_PR_R2 = "${ARTIFACT_PATH_MULTIARCH_RPM_PR_R2}/firmware"


    // L1-Platform
    static String ARTIFACT_PATH_L1_PLATFORM = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_Platform"
    static String ARTIFACT_PATH_L1_PLATFORM_R2 = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO_R2}/L1_Platform"

    // L1-Core
    static String ARTIFACT_PATH_L1_CORE = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_Core"
    static String ARTIFACT_PATH_L1_CORE_R2 = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO_R2}/L1_Core"
    static String ARTIFACT_PATH_L1_CORE_R3 = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO_R3}/L1_Core"
    static String TV_FILE = "tvFile.csv"
    static String L1_CORE_UNIT_TESTS_LOCK_NAME ="L1-Core-unit-tests-lock"
    
    // Customer support tool pipeline
    static String L1_CUSTOMER_SUPPORT_PIPELINE_NAME = "L1-customer-support"
    static String ARTIFACT_PATH_L1_CUSTOMER_SUPPORT = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1-Customer_Support"
    static String ARTIFACT_PATH_L1_CUSTOMER_SUPPORT_R2 = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO_R2}/L1-Customer_Support"
    static String L1_CUSTOMER_SUPPORT_MAIN_BRANCH           = "main"
    static String L1_CUSTOMER_SUPPORT_MAIN_BRANCH_R_2_0     = "${L1_CUSTOMER_SUPPORT_MAIN_BRANCH}"

    // TODO: Add a Class for each card type
    static String L1_CORE_SYSTEM_TEST_DIR = "./system_test"
    static String L1_CORE_BUILD_DIR = "./build"
    static String PATH_L1_CORE_MAIN_TOOL_BUILD = "Tool/Build/"
    static String PATH_L1_CORE_MAIN_TOOL = "Tool/"
    static String PATH_L1_CORE_MAIN_BUILD = "Build/"
    static String PATH_L1_CORE_F105_TOOL_BUILD = "tool/build/"
    static String PATH_L1_CORE_F105_TOOL = "tool/"
    static String PATH_L1_CORE_F105_BUILD = "build/"

    // L1-Platform-Coverity-PR
    static String ARTIFACT_PATH_L1_PLATFORM_COV_PR = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_Platform_Cov_PR"

    // L1-Platform-SDK-Sign
    static String ARTIFACT_PATH_L1_PLATFORM_SDK_SIGN = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_platform_sdk_sign"

    // L1-Platform-Apps
    static String ARTIFACT_PATH_L1_PLATFORM_APPS = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1-Platform-Apps"
    static String ARTIFACT_PATH_L1_PLATFORM_APPS_R2 = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO_R2}/L1-Platform-Apps"
    
    static String ARTIFACT_PATH_L1_FIRMWARE_IMAGES = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1-Firmware-Images"
    static String ARTIFACT_PATH_L1_FIRMWARE_IMAGES_R2 = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO_R2}/L1-Firmware-Images"
    
    // L1-PLatform Image Names
    static String L1_MANUFACTURING_IMAGE = 'mtf'
    static String L1_FACTORY_DEFAULT_IMAGE = 'fdf'
    static String L1_DVT_DEFAULT_IMAGE = 'dvt'
    static String L1_AURORA_IMAGE = 'aurora'
    static String L1_AURORA_DEV_IMAGE = 'aurora-dev'
    static String L1_REGULATORY_IMAGE = 'regulatory'

    static String L1_DELL_RAN_IMAGE = 'dell_ran'
    static String L1_DELL_RAN_RPM = 'dell_ran_rpm'

    // L1-Transport-Build
    static String ARTIFACT_PATH_L1_TRANSPORT_BUILD = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_transport_build"

    // L1-Core-On-Demand
    static String ARTIFACT_PATH_L1_CORE_ON_DEMAND = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_Core_On_Demand"
    
    // L1-Analyzers-On-Demand
    static String ARTIFACT_PATH_L1_ANALYZERS_ON_DEMAND = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1-Analyzers-On-Demand"

    // L1-Core-Nightly
    static String ARTIFACT_PATH_L1_CORE_NIGHTLY = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_Core_Nightly"

    // L1-Automation
    static String ARTIFACT_PATH_L1_AUTOMATION = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_Automation"

    // L1-pcieBuildRoot
    static String ARTIFACT_PATH_L1_PCIEBUILDROOT = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_pciebuildroot"

    // L1-FlexRAN
    static String ARTIFACT_PATH_L1_FLEXRAN = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_FlexRAN"

    // L1-2103_FlexRAN
    static String ARTIFACT_PATH_L1_2103_FLEXRAN = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_2103_FlexRAN"

    // L1-app-ODP_DPDK
    static String ARTIFACT_PATH_L1_APP_ODP_DPDK = "${ARTIFACT_PATH_L1_RAN_GENERIC_REPO}/L1_Marvell_pure"

    // L1 Timeout durations
    static Integer L1_PROMOTE_TIMEOUT_MINUTES = 50
    static Integer L1_SANITY_STAGE_SHORT_TIMEOUT_MINUTES = 50
    static Integer L1_REMOTE_SANITY_STAGE_SHORT_TIMEOUT_MINUTES =  120
    static Integer L1_SANITY_STAGE_LONG_TIMEOUT_MINUTES = 150
    static Integer L1_SANITY_PIPELINE_TIMEOUT_MINUTES = 150
    static Integer L1_REGRESSION_STAGE_SHORT_TIMEOUT_MINUTES = 180
    static Integer L1_REGRESSION_STAGE_LONG_TIMEOUT_MINUTES = 900
    static Integer L1_REGRESSION_NIGHTLY_PIPELINE_TIMEOUT_MINUTES = 24 * 60
    static Integer L1_REGRESSION_PIPELINE_TIMEOUT_MINUTES = 48 * 60

    // Credential names
    static String GIT_ACCOUNT_NAME_1 = "mp-github-app"
    static String GIT_ACCOUNT_NAME_2 = "github-checks-updater"
    static String GIT_ACCOUNT_L1_MAIN = "${GIT_ACCOUNT_NAME_2}"

    public class L1Pipeline{
        public String pipelineName
        public String branch

        public L1Pipeline(String pipelineName, String branch) { 
                    this.pipelineName = pipelineName
                    this.branch = branch
                    
        } 

        public String getPipelineNameBranch(){
             return "${pipelineName}/${branch}"
        }
    }

    public class L1PipelineBuild extends L1Pipeline{
        
        public String downloadPath
        public String [] artifacts
        public String nonRpmArtifactBasePath
        public String rpmArtifactBasePath
        public String rpmCandidateArtifactBasePath
        public String buildNumber
        public String targetBranch
        //public String target_release
        public String version
        public String buildInfoName
        public String artifactoryName    // Pipeline Name
        public Boolean isPRBranch
        protected context

        public L1PipelineBuild (context, String artifactoryName, String pipelineName, String branch, String buildNumber, String targetBranch, String version, String artifactsSpaceSeparated)
        {
            super (pipelineName, branch)
            //this.version = version
            this.context = context
            this.artifactoryName = artifactoryName
            this.downloadPath = "./"
            this.artifacts = artifactsSpaceSeparated.split()
            this.buildNumber = buildNumber
            this.targetBranch = targetBranch
            // A PR branch is a branch that has a different targetBranch vs. branch
            // This can be overriden by subclasses
            if (this.targetBranch.equals(this.branch)) {
                // sharedVars.L1GlobalVars.debugPrintText(ENABLE_DEBUG_PRINT, "Main Branch pipeline")
                this.isPRBranch = false
            }
            else {
                // sharedVars.L1GlobalVars.debugPrintText(ENABLE_DEBUG_PRINT, "PR Branch pipeline")
                this.isPRBranch = true
            }
            // https://github.com/cloudbees/groovy-cps/pull/83/files
            updateArtifactoryBasePaths (version)
        }
        @NonCPS
        public String toString()
        {
            return ReflectionToStringBuilder.toString(this, ToStringStyle.SHORT_PREFIX_STYLE);
        }

       /**
        * Standard formating for Artifactory Build Name
        * {this.version}-{buildNameWithOutFolders}-{this.branch}
        * @return buildName to be found in https://phm.artifactory.cec.lab.emc.com/ui/builds/
        */
        @NonCPS
        String setBuildInfoName() {
        
            def List buildNameTokens = "${this.pipelineName}".tokenize('/')
            def String buildNameWithOutFolders = buildNameTokens[buildNameTokens.size()-1]
        
            def String buildInfoName = "${this.version}-${buildNameWithOutFolders}"
            def String buildBranchName = "${this.branch}"
        
            this.buildInfoName = "${buildInfoName}-${buildBranchName}"
        }

        @NonCPS
        protected void updateArtifactoryBasePaths (String version) {
            this.version = version
            this.nonRpmArtifactBasePath = getGenericRepoPathForArtifactoryVersion (this.artifactoryName, version)
            this.rpmArtifactBasePath = getRpmRepoPathForArtifactoryVersion (this.artifactoryName, version)
            this.rpmCandidateArtifactBasePath = getRpmCandidateRepoPathForArtifactoryVersion (this.artifactoryName, version)
            setBuildInfoName()
        }

        public void setDownloadPath (String downloadPath){
            this.downloadPath = downloadPath
        }

        public void getDownloadPath (){
            return downloadPath
        }

        @NonCPS
        protected String getGenericRepoPathForArtifactoryVersion (String artifactoryFolder, String version)
        { 
            return "${GenericVars.RAN_GENERIC_REPO}/${version}/bin/L1/${artifactoryFolder}" 
        }

        @NonCPS
        protected String getRpmRepoPathForArtifactoryVersion (String artifactoryFolder, String version)
        { 
            return "${GenericVars.RPM_PR_PATH}/${version}/L1/${artifactoryFolder}"
        }

        @NonCPS
        protected String getRpmCandidateRepoPathForArtifactoryVersion (String artifactoryFolder, String version)
        { 
            return "${GenericVars.RPM_CANDIDATE_PATH}/${version}/L1/${artifactoryFolder}" 
        }

        public String getRpmArtifactPath(){
            def String artifactPath = "${rpmArtifactBasePath}/${branch}/${buildNumber}"
            if (isPRpipeline()) {
                artifactPath = "${rpmArtifactBasePath}/${L1GlobalVars.L1_PR_BUILD_DIR}/${branch}/${buildNumber}"
            }
                
            print "Artifact (rpm) path ${artifactPath}" 
            return artifactPath
        }

        public String getNonRpmArtifactPath(){
            def String artifactPath = "${nonRpmArtifactBasePath}/${branch}/${buildNumber}"
            if (isPRpipeline()) {
                artifactPath = "${nonRpmArtifactBasePath}/${L1GlobalVars.L1_PR_BUILD_DIR}/${branch}/${buildNumber}"
            }
                

            print "Artifact (non-rpm) path ${artifactPath}" 
            return artifactPath
        }

        public String getNonRpmArtifactPathPattern(int artifactIndex = 0){
            def String artifactPattern = "${getNonRpmArtifactPath()}/*/${artifacts[artifactIndex]}"

            print "Artifact pattern ${artifactPattern}" 
            return artifactPattern
        }
        public isPRpipeline(){
            return this.isPRBranch
        }
    }

    public class L1PlatformImages {
        public List<L1PlatformImage> imageTypes =new ArrayList<L1PlatformImage>();

        L1PlatformImages() {
            //imageTypes = []
        }

        public addImageType(String image_name){
            if (image_name == L1GlobalVars.L1_MANUFACTURING_IMAGE){
                imageTypes.add(new L1PlatformMtfImage())
            }
            else if (image_name == L1GlobalVars.L1_FACTORY_DEFAULT_IMAGE){
                imageTypes.add(new L1PlatformFdfImage())
            }
            else if (image_name == L1GlobalVars.L1_DELL_RAN_IMAGE){
                    imageTypes.add(new L1PlatformDellRANImage())
            }
            else if (image_name == L1GlobalVars.L1_DELL_RAN_RPM){
                imageTypes.add(new L1PlatformDellRANRPM())
            }
            else if (image_name == L1GlobalVars.L1_AURORA_IMAGE){
                imageTypes.add(new L1AuroraImage(L1GlobalVars.L1_AURORA_IMAGE))
            }
            else if (image_name == L1GlobalVars.L1_AURORA_DEV_IMAGE){
                imageTypes.add(new L1AuroraImage(L1GlobalVars.L1_AURORA_DEV_IMAGE))
            }
            else if (image_name == L1GlobalVars.L1_REGULATORY_IMAGE){
                imageTypes.add(new L1RegulatoryImage())
            }

        }
        // Comma separated image list to add
        public addImageTypesString(String image_name_list){
            def image_type_list = image_name_list.split(',')
            for (image_type in image_type_list){
                this.addImageType(image_type.trim())
            }
        }

        public String getImageNamesString(String delimiter = ", "){
            def image_name_string = []
            //List<String> image_name_string = Arrays.asList();
            for (image_type in this.imageTypes){
                image_name_string.add(image_type.imageType)
            }
            return image_name_string.join(delimiter)
        }
    }

    public class L1PlatformAppsPipelineBuild extends L1PipelineBuild {
        // String image_name = L1GlobalVars.L1_FACTORY_DEFAULT_IMAGE
        public L1PlatformImages platformImages = new L1PlatformImages()
        //public List<L1PlatformImage> imageTypes = []

        L1PlatformAppsPipelineBuild (context, String branch, String buildNumber, String targetBranch, String version, String artifactsSpaceSeparated = "apps.tar.gz")
        {
            super (context, L1GlobalVars.L1_PLATFORM_APPS_ARTIFACTORY_NAME, L1GlobalVars.L1_PLATFORM_APPS_NAME,  
                    branch, buildNumber, targetBranch, version, artifactsSpaceSeparated)

            // Using release to branch mapping
            if (version == L1GlobalVars.L1_DEFERRED_VERSION_VALUE) 
            {
                if (targetBranch == L1_PLATFORM_MAIN_BRANCH_R_2_0 ||
                    targetBranch == L1_PLATFORM_APP_MAIN_MANUFACTURING_BRANCH ||
                    targetBranch == L1_PLATFORM_APP_F105_BRANCH)
                {
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2

                    //this.target_release = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2
                }
                else 
                {
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE
                    //this.target_release = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE
                }                
            }
            updateArtifactoryBasePaths (version)

            print "Created an instance of L1PlatformAppsPipelineBuild()\n"
        }

        public int runUnitTests(String release_candidate) {
            context.sh script:  """
                        export RELEASE_CANDIDATE=${release_candidate}
                        ./ci/unit_test/build.sh
                        ls -la;
                        #touch workspace.tar.gz
                        #tar -czf workspace.tar.gz --exclude=workspace.tar.gz .
                    """
            // To be used in future
            return 0
        }
        public int buildApps(String release_candidate) {
            context.sh script:  """
                        export RELEASE_CANDIDATE=${release_candidate}

                        ./ci/apps/build.sh
                        ls -lAh output_ci_apps/
                    """
            // To be used in future
            return 0
        }
    }

    public class L1MultiArchPipelineBuild extends L1PipelineBuild {
        public L1PlatformImages platformImages= new L1PlatformImages()
        //public List<L1PlatformImage> imageTypes = []

        L1MultiArchPipelineBuild(context, String branch, String buildNumber, String targetBranch, String version, String artifactsSpaceSeparated = "")
        {
            super (context, L1GlobalVars.L1_DELL_RAN_MULTIARCH_ARTIFACTORY_NAME, L1GlobalVars.L1_DELL_RAN_MULTIARCH_NAME, branch, buildNumber, targetBranch, version, artifactsSpaceSeparated)
            //imageTypes = []
            //this.nonRpmArtifactBasePath = L1GlobalVars.getL1GenericRepoPathForArtifactoryVersion (version)
            //this.rpmArtifactPath = L1GlobalVars.ARTIFACT_PATH_MULTIARCH_FIRMWARE_RPM_PR_R2

            print "Created an instance of L1MultiArchPipelineBuild()\n${toString()}\n"
        }

        public buildImages(String release_candidate, String apps95o_path, String apps105_path, String sdk_build_folder, String MERCURY_ACCOUNT)
        {

            for (image in platformImages.imageTypes)
            {
                def build_script = image.getL1platformImageBuildScriptValue()
                def output_dir = image.getBuildOutputDirValue()
                def package_filename = image.getPackageNameTarGzValue()
                def package_name = image.getPackageNameWithoutExtValue()

                def build_args = ""
                if(image.getImageTypeValue() == sharedVars.L1GlobalVars.L1_DELL_RAN_IMAGE){
                    build_args = "-a ${apps95o_path} -A ${apps105_path} -s ${sdk_build_folder} -f $MERCURY_ACCOUNT \
                        Build/5GNR_L1_95o_ORAN_MHAB_scs30k.tgz build/5GNR_L1_105_ORAN_scs30k_ran-nic_fusionMPLTD.tgz "
                }
                else {
                    build_args = ""
                }
                def l1platformcommon = new jenkins.L1PlatformCommon()
                l1platformcommon.build_image_from_pipeline(build_script, output_dir, package_filename, package_name, release_candidate, build_args)
            }
        }
    }

    public class L1MarvellSDKPipelineBuild extends L1PipelineBuild {
        public String default_config_yaml_path=".target_socs.yaml"
        
        L1MarvellSDKPipelineBuild(context, String branch, String buildNumber, String targetBranch, String version, String artifactsSpaceSeparated = "")
        {
            super (context, L1GlobalVars.L1_PLATFORM_MARVELL_SDK_ARTIFACTORY_NAME, L1GlobalVars.L1_PLATFORM_MARVELL_SDK_NAME, branch, buildNumber, targetBranch, version, artifactsSpaceSeparated)
            
            // Using release to branch mapping
            if (version == L1GlobalVars.L1_DEFERRED_VERSION_VALUE)  {
                version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2
            }
            updateArtifactoryBasePaths(version)
            print "Created an instance of L1MarvellSDKPipelineBuild()\n"
        
        }

        private build_marvell_sdk(String build_cmd, String output_folder, String output_filename, String l1_marvell_sdk_dir="l1-marvell-sdk"){
            return context.sh (returnStatus: true,
                script: """
                    pwd;ls -la
                    cd ${l1_marvell_sdk_dir}
                    ls -la
                    ${build_cmd}
                    ls -la
                    echo "Done SDK Build"
                    tar -czvf ${context.env.WORKSPACE}/${output_filename}.tar.gz ${output_folder}/
                """)
        }

        private build_marvell_sdk_from_config(String target_yaml, String artifactory_path, String output_filename, Boolean upload_build=true, Map sdk_buildInfoMap){
            def configSDK = context.readYaml file: target_yaml
            def Utils = new common.Utils()
            for (target in configSDK['targets']) {
                context.stage("Build ${target.name}") {
                    def Exit_code = build_marvell_sdk("${target.script}", "${target.output}", "${output_filename}", "./")
                    if (Exit_code == 0 && upload_build) {
                        context.retry(3) {
                            Utils.uploadArtifact(
                                ["${output_filename}.tar.gz"],
                                "${artifactory_path}/",
                                sdk_buildInfoMap
                            ) 
                        }
                    }
                    else
                    {
                        error("Build Failed with Exit Code ${Exit_code}")
                    }
                } 
            }
        }

        public get_sdk_image_name(String target_yaml_path)
        {
            def l1common = new jenkins.L1CoreCommon()
            l1common.get_sdk_image_name(target_yaml_path, this.buildNumber)
        }

        public get_sdk_build_folder(String target_yaml_path, Integer target_index)
        {
            def l1common = new jenkins.L1CoreCommon()
            l1common.get_sdk_build_folder(target_yaml_path, target_index)
        }

        public build_SDKs(String target_yaml_path, Map sdk_buildInfoMap)
        {
            this.build_marvell_sdk_from_config(target_yaml_path, this.getNonRpmArtifactPath(), this.get_sdk_image_name(target_yaml_path), true, sdk_buildInfoMap)
        }

        @NonCPS
        public isReleaseCandidateBranch(String branch){
            if (branch.startsWithAny("rel/sdk-")){
                return true
            }else{
                return false
            }
        }
    }

    public class L1MarvellBphyPipelineBuild extends L1PipelineBuild {
        public String default_config_yaml_path=".bphy_config.yaml"
        public String build_phy_script = "./ci/build_bphy/build.sh"
        public String build_opk_script = "./ci/build_opk/build.sh"
        public String build_phy_output_path = "./output_bphy_app/"
        public String build_phy_output_package = "cnf105_dpdk_bphy_dell_pkg.tgz"
        public String build_opk_output_package = "cnf105_dpdk_bphy_dell_pkg.tgz"
        
        L1MarvellBphyPipelineBuild(context, String branch, String buildNumber, String targetBranch, String version, String artifactsSpaceSeparated = "")
        {
            super (context, L1GlobalVars.L1_PLATFORM_MARVELL_BPHY_ARTIFACTORY_NAME, L1GlobalVars.L1_PLATFORM_MARVELL_BPHY_NAME, branch, buildNumber, targetBranch, version, artifactsSpaceSeparated)
            
            // Using release to branch mapping
            if (version == L1GlobalVars.L1_DEFERRED_VERSION_VALUE)  {
                version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2
            }
            updateArtifactoryBasePaths(version)
            print "Created an instance of L1MarvellBphyPipelineBuild\n"
        
        }

        public build_bphy(String tool_chain_root)
        {
            def cmd_options = "-s ${tool_chain_root}"

            context.sh script:  """
                    pwd;ls -la
                    ${build_phy_script} ${cmd_options}
                    echo "Done Building Bphy"
                """
            context.stash includes: "${build_phy_output_path}${build_phy_output_package}", name: "${build_phy_output_package}"
        }

        public build_opk()
        {
            def cmd_options = "-d ${build_phy_output_path}${build_phy_output_package}"

            context.sh script:  """
                    pwd;ls -la
                    ${build_opk_script} ${cmd_options}
                    echo "Done Building Opk"
                """
            context.stash includes: "${build_phy_output_path}${build_opk_output_package}", name: "${build_opk_output_package}"
        }

        public upload_artifacts () 
        {
            def Utils = new common.Utils()
            Utils.uploadArtifact(
                            ["${build_phy_output_path}${build_phy_output_package}", "${build_phy_output_path}${build_opk_output_package}"],
                            "${artifactory_path}/",
                            ['buildName':"${buildInfoName}",'buildNumber':"${BUILD_ID}"]
                        ) 
        }

        @NonCPS
        public isReleaseCandidateBranch(String branch){
            if (branch.startsWithAny("rel/sdk-")){
                return true
            }else{
                return false
            }
        }
    }


    public class L1FirmwareImagesMultiBranchPipelineBuild extends L1PipelineBuild {
        public L1PlatformImages platformImages = new L1PlatformImages()
        L1FirmwareImagesMultiBranchPipelineBuild(context, String branch, String buildNumber, String targetBranch, String version, String artifactsSpaceSeparated = "")
        {
            super (context, L1GlobalVars.L1_FIRMWARE_IMAGES_MULTIBRANCH_ARTIFACTORY_NAME, L1GlobalVars.L1_FIRMWARE_IMAGES_MULTIBRANCH_NAME, branch, buildNumber, targetBranch, version, artifactsSpaceSeparated)
            
            if (version == L1GlobalVars.L1_DEFERRED_VERSION_VALUE)  {
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2
            } else {
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE
            }
            updateArtifactoryBasePaths (version)
        }
        @NonCPS
        public isReleaseCandidateBranch(List<String> releaseCandidateAppBranches, String target_app_branch){
            if(releaseCandidateAppBranches.contains(target_app_branch)){
                return true
            }else{
                return false
            }
        }
    }

    public class L1FirmwareImagesPipelineBuild extends L1PipelineBuild {
        public L1PlatformImages platformImages = new L1PlatformImages()

        //public final List<L1PlatformImage> imageTypes_to_scan_in_blackduck = [L1PlatformFdfImage.blackduck_tools_mapping_label, L1AuroraImage.blackduck_tools_mapping_label, L1PlatformDellRANImage.blackduck_tools_mapping_label]

        //List<L1PlatformImage> imageTypes = []
    
        L1FirmwareImagesPipelineBuild (context, String branch, String buildNumber, String targetBranch, String version, String artifactsSpaceSeparated = "")
        {
            super (context, L1GlobalVars.L1_FIRMWARE_IMAGES_ARTIFACTORY_NAME, L1GlobalVars.L1_FIRMWARE_IMAGES_NAME, branch, buildNumber, targetBranch, version, artifactsSpaceSeparated)
            print "Create an instance of L1FirmwareImagesPipelineBuild()\n"
            // imageTypes = []
            // Using release to branch mapping
            if (version == L1GlobalVars.L1_DEFERRED_VERSION_VALUE)  {
                if (targetBranch == L1_FIRMWARE_IMAGES_BRANCH_R_2_0)
                {
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2
                }
                else 
                {
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE
                }
            }
            updateArtifactoryBasePaths (version)
        }

        @NonCPS
        public isReleaseCandidateBranch(List<String> releaseCandidateAppBranches, String target_app_branch){
            if(releaseCandidateAppBranches.contains(target_app_branch)){
                return true
            }else{
                return false
            }
        }
    }

    public class L1PlatformDriversPipelineBuild extends L1PipelineBuild {

        public String driverType = "rpm"
        public String artifactSpecificVersion = "0.0.0"  // TODO: improve this code
        //private context 
        L1PlatformDriversPipelineBuild (context, String branch, 
                                        String buildNumber,
                                        String targetBranch,
                                        String version,
                                        String artifactsSpaceSeparated = ""){

            super (context, L1GlobalVars.L1_PLATFORM_HOST_DRIVERS_ARTIFACTORY_NAME, L1GlobalVars.L1_PLATFORM_HOST_DRIVERS_NAME, 
                    branch, buildNumber, targetBranch, version, artifactsSpaceSeparated)
            //this.context = context
            //sharedVars.L1GlobalVars.debugPrintText(ENABLE_DEBUG_PRINT, "Create an instance of L1PlatformDriversPipelineBuild\n" )
        }

        public driverPipelineSettings (String driverType, String artifactSpecificVersion) {
            /*
                driverType          :   String      :   package type for the drivers
                                                        current supported types
                                                        - rpm
                                                        - deb            
                artifactSpecificVersion             :   String      :   RPM Release version for the drivers
                                                        e.g. 2.4.112302 for release 2 based on sdk 11.23.02
            */

            sharedVars.L1GlobalVars.debugPrintText(ENABLE_DEBUG_PRINT, "driverType  = ${driverType}\n artifactSpecificVersion = ${artifactSpecificVersion}" )
            this.driverType = driverType
            this.artifactSpecificVersion = artifactSpecificVersion

        }

        @NonCPS
        public isReleaseCandidateBranch(){
            if (this.branch.startsWithAny("rel/sdk-")){
                return true
            } else {
                return false
            }
        }
        def stash_drivers(String package_tar_name, String stash_name){
            context.sh script: """
                ls -ltr
                rm ${package_tar_name} || :
                pwd
                tar -czf ${package_tar_name} ${getBuildOutputPath ()}
            """
            context.stash includes: "${package_tar_name}", name: "${stash_name}"
        }

        public getBuildOutputPath ()
        {

            if (this.driverType.equals ('rpm')){
                return "output_ci_host_drivers_rpm/"            
            } else if (this.driverType.equals ('deb')){
                return "output_ci_host_drivers_deb/"
            }
        }

        public getHostDriverBuildScriptPath ()
        {
            if (this.driverType.equals ('rpm')){
                return "host_drivers_rpm"            
            } else if (this.driverType.equals ('deb')){
                return "host_drivers_deb"
            }    
        }

        public getHostDriverPackagePrefix ()
        {
            if (this.driverType.equals ('rpm')){
                return "host-drivers-rpm"            
            } else if (this.driverType.equals ('deb')){
                return "host-drivers-deb"
            }    
        }

        public create_project_version_file(){
            String project_version = this.artifactSpecificVersion
            context.sh script: """
                echo ${project_version} > .project_version
            """
            context.sh script: """
                echo '7777'
            """
        }

        public build_and_upload_drivers (Map buildInfo = [:]){

            def Utils = new common.Utils()
            String project_version = this.artifactSpecificVersion
            String driversArtifactsPath = getRpmArtifactPath ()
            Boolean releaseCandidate = !isPRpipeline()

            context.sh script: """
                RELEASE_CANDIDATE=${releaseCandidate} ./ci/${getHostDriverBuildScriptPath()}/build.sh -v ${project_version}
            """

            if (isPRpipeline ()) {
                Utils.uploadArtifact(["${getBuildOutputPath()}/*"], "${driversArtifactsPath}/${getBuildOutputPath()}") 
            }
            else {
                Utils.uploadArtifact(["${getBuildOutputPath()}/*"], "${driversArtifactsPath}/${getBuildOutputPath()}", buildInfo) 
            }
        }
    }

    public class L1CorePipelineBuild extends L1PipelineBuild {
        public String test_vectors_path = "test_vectors/"
        public String oran_build_path = "oran_build/"
        public String sbom_path = "sbom/"
        L1CorePipelineBuild (context, String branch, String buildNumber, String targetBranch, String version, String artifactsSpaceSeparated ="build_oran_mhab.tar.gz")
        {
            super (context, L1GlobalVars.L1_CORE_ARTIFACTORY_NAME, L1GlobalVars.L1_CORE_NAME, branch, buildNumber, targetBranch, version, artifactsSpaceSeparated)
            //if (branch == L1_CORE_MAIN_F105_BRANCH)

            // Using release to branch mapping
            if (version == L1GlobalVars.L1_DEFERRED_VERSION_VALUE) 
            {
                if (targetBranch == L1_CORE_MAIN_F105_BRANCH)
                {
                    // L1-Core main is an R2 artifact
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2
                }
                else 
                {
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2
                }
            }
            updateArtifactoryBasePaths (version)
            

            print "Create an instance of L1CorePipelineBuild()\n${toString()}\n"
            

        }

        @NonCPS
        public isReleaseCandidateBranch(){
            if (this.branch == L1_CORE_MAIN_BRANCH){
                return true
            } else {
                return false
            }
        }
    }

    public class L1CustomerSupportPipelineBuild extends L1PipelineBuild {
        L1CustomerSupportPipelineBuild (context, String branch, String buildNumber, String targetBranch, String version, String artifactsSpaceSeparated ="")
        {
            super (context, L1GlobalVars.L1_CUSTOMER_SUPPORT_ARTIFACTORY_NAME, L1GlobalVars.L1_CUSTOMER_SUPPORT_NAME, 
                branch, buildNumber, targetBranch, version, artifactsSpaceSeparated)

            // Using release to branch mapping
            if (version == L1GlobalVars.L1_DEFERRED_VERSION_VALUE) 
            {
                if (targetBranch == L1_CUSTOMER_SUPPORT_MAIN_BRANCH_R_2_0)
                {
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_FOR_R2
                }
                else 
                {
                    version = L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE
                }                
            }
            updateArtifactoryBasePaths (version)
            print "Created an instance of L1CustomerSupportPipelineBuild()\n"
        }
    }

    def L1PipelineBuild createL1PipelineBuild ( context, 
                                                String pipelineName ,
                                                String branch,
                                                String buildNumber, 
                                                String targetBranch,
                                                String versionPath=L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE, 
                                                String artifactsSpaceSeparated = "") { 
        def Utils = new common.Utils();

        // Added fix to URL encode the branch name 
        // This is how Jenkins reads branch names.
        def String pipelineBranchLink = "${pipelineName}/${URLEncoder.encode(branch, "UTF-8")}"
        
        if (buildNumber == PIPELINE_LAST_SUCCESSFUL_BUILD_NUM_DEFAULT)
        {
            def lastSuccessfulBuild = ""
            if (Utils.isMultiBranchPipeline(pipelineName)){
                lastSuccessfulBuild = Utils.getLastSuccessfulBuildID("${pipelineBranchLink}");
            } else {
                lastSuccessfulBuild = Utils.getLastSuccessfulBuildID("${pipelineName}");
            }

            if (lastSuccessfulBuild != "") {
                buildNumber = lastSuccessfulBuild;
                print "Set last successful build for ${buildNumber}."
            } 
        }
        sharedVars.L1GlobalVars.debugPrintText(ENABLE_DEBUG_PRINT, "pipelineName  = ${pipelineName}\n branch = ${branch}\n buildNumber, = ${buildNumber}\n targetBranch = ${targetBranch}\n versionPath, = ${versionPath}\n artifactsSpaceSeparated = ${artifactsSpaceSeparated}\n" )

        if (pipelineName == L1GlobalVars.L1_CORE_NAME) {
            return new L1CorePipelineBuild(context, branch, buildNumber, targetBranch, versionPath, artifactsSpaceSeparated)
        }
        else if (pipelineName == L1GlobalVars.L1_PLATFORM_APPS_NAME) 
        {
            return new L1PlatformAppsPipelineBuild(context, branch, buildNumber, targetBranch, versionPath, artifactsSpaceSeparated)
        }
        else if (pipelineName == L1GlobalVars.L1_PLATFORM_HOST_DRIVERS_NAME) 
        {
            return new L1PlatformDriversPipelineBuild(context, branch, buildNumber, targetBranch, versionPath, artifactsSpaceSeparated)
        }
        else if (pipelineName == L1GlobalVars.L1_FIRMWARE_IMAGES_NAME) 
        {
            return new L1FirmwareImagesPipelineBuild(context, branch, buildNumber, targetBranch, versionPath, artifactsSpaceSeparated)
        }
        else if (pipelineName == L1GlobalVars.L1_FIRMWARE_IMAGES_MULTIBRANCH_NAME) 
        {
            return new L1FirmwareImagesMultiBranchPipelineBuild(context, branch, buildNumber, targetBranch, versionPath, artifactsSpaceSeparated)
        }
        else if (pipelineName == L1GlobalVars.L1_CUSTOMER_SUPPORT_PIPELINE_NAME) 
        {
            return new L1CustomerSupportPipelineBuild(context, branch, buildNumber, targetBranch, versionPath, artifactsSpaceSeparated)
        }
        else if (pipelineName == L1GlobalVars.L1_DELL_RAN_MULTIARCH_NAME) 
        {
            return new L1MultiArchPipelineBuild(context, branch, buildNumber, targetBranch, versionPath, artifactsSpaceSeparated)
        }
        else if (pipelineName == L1GlobalVars.L1_PLATFORM_MARVELL_SDK_NAME) 
        {
            return new L1MarvellSDKPipelineBuild(context, branch, buildNumber, targetBranch, versionPath, artifactsSpaceSeparated)
        }
        else if (pipelineName == L1GlobalVars.L1_PLATFORM_MARVELL_BPHY_NAME) 
        {
            return new L1MarvellBphyPipelineBuild(context, branch, buildNumber, targetBranch, versionPath, artifactsSpaceSeparated)
        }        
        else {

            print "Error Pipeline Not Found!\n"
        }

    }


}

