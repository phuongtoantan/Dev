// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package sharedVars

class RDCGlobalVars {
    def GenericVars = new GenericVars()
    
    static String RDC_IMAGE_URL_PATH = "phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/mobile-phoenix-rdc-docker"
}
