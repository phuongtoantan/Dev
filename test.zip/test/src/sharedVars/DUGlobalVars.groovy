// Copyright (c) 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
package sharedVars

class DUGlobalVars {
    //General
    static String DU_MAIN_BIN_BASE_PATH = 'mobile-phoenix-ran-generic-local/bin/du/main/'
    static String DU_PR_BRANCH_BIN_BASE_PATH = 'mobile-phoenix-ran-generic-local/du/pr/artifact/du-builds'
    static String DU_UBI_IMAGE = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/du_ubi'
    static String DU_UT_GBI_IMAGE = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/du_ut_gbi'
    static String DU_TESTSIM_GBI_IMAGE = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/du_testsim_gbi'
    static String DU_CT_GBI_IMAGE = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/du_ct_gbi'
    static String DU_MASTER_BRANCH = 'master'
    // URL for DU image
    static String DU_DPDK_IMG_FULL_URL = "${GenericVars.ARTITACTORY_DOCKER_BASE_URL}/du-images/du-rhel8-prd/du_dpdk"
    // DU_DEV Main & PR: artifact files
    static def getDuDevArtifactURL(String branch, String build_number) {
        String DU_DEV_ARTIFACT_MAIN_PATH = 'mobile-phoenix-ran-generic-local/du/main/artifact/du_dev'
        String DU_DEV_ARTIFACT_PR_PATH = 'mobile-phoenix-ran-generic-local/du/pr/artifact/du_dev'
        String ARTIFACT_URL = (branch == 'main' || branch == DU_MASTER_BRANCH)  ? DU_DEV_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_DEV_ARTIFACT_PR_PATH  + '/' + branch + '/'
        return ARTIFACT_URL
    }
    // DU_DEV Main & PR - BUILD_MINERVA-05 stage: dpdk mvl du binary file (du_build_mvl.tar.gz) and env file (env_vars_du.txt)
    static def getDuDevDpdkMvlBinURL(String branch, String build_number) {
        String DU_DEV_DPDK_MVL_BIN_MAIN_PATH = 'mobile-phoenix-ran-generic-local/bin/du/main/marvell_rhel8/' + build_number + '/'
        String DU_DEV_DPDK_MVL_BIN_PR_PATH = 'mobile-phoenix-ran-generic-local/bin/du/' + branch + '/marvell_rhel8/' + build_number + '/'
        String ARTIFACT_URL = (branch == 'main' || branch == DU_MASTER_BRANCH)  ? DU_DEV_DPDK_MVL_BIN_MAIN_PATH :
                            DU_DEV_DPDK_MVL_BIN_PR_PATH
        return ARTIFACT_URL
    }
    // DU_DEV Main & PR - BUILD_MINERVA-05 stage: dpdk mvl du RPM file (du_marvell-*.rpm)
    static def getDuDevDpdkMvlRpmURL(String branch, String build_number) {
        String DU_DEV_DPDK_MVL_RPM_MAIN_PATH = 'mobile-phoenix-rpm-pr-rr/du/main/' + build_number + '/05/'
        String DU_DEV_DPDK_MVL_RPM_PR_PATH = 'mobile-phoenix-rpm-pr-rr/du/' + branch + '/' + build_number + '/05/'
        String ARTIFACT_URL = (branch == 'main' || branch == DU_MASTER_BRANCH)  ? DU_DEV_DPDK_MVL_RPM_MAIN_PATH :
                            DU_DEV_DPDK_MVL_RPM_PR_PATH
        return ARTIFACT_URL
    }
    // DU_DEV Main - BUILD_PAL_NO_DPDK_RUN_CT stage: no-dpdk pal du container image (du_no_dpdk:<tag>)
    // And DU-BUILD-ALL - 01-DPDK stage: dpdk pal du container image (du_dpdk: <tag>)
    // And DU-BUILD-ALL - BUILD_MINERVA-05 stage: dpdk mvl du container image
    static String DU_IMAGE_MAIN_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/mobile-phoenix-platform-docker/du-images/du-rhel8-prd'
    static String DU_IMAGE_TMP_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/mobile-phoenix-platform-docker/du-images/du-rhel8-tmp'
    // DU_DEV Main & PR - BUILD_PAL_NO_DPDK_RUN_CT stage: no-dpdk pal du binary file
    static def getDuDevNoDpdkPalBinURL(String branch, String build_number) {
        String DU_DEV_NO_DPDK_PAL_BIN_MAIN_PATH = 'mobile-phoenix-ran-generic-local/bin/du/main/no_dpdk_rhel8/' + build_number + '/'
        String DU_DEV_NO_DPDK_PAL_BIN_PR_PATH = 'mobile-phoenix-ran-generic-local/bin/du/' + branch + '/no_dpdk_rhel8/' + build_number + '/'
        String ARTIFACT_URL = (branch == 'main')  ? DU_DEV_NO_DPDK_PAL_BIN_MAIN_PATH :
                            DU_DEV_NO_DPDK_PAL_BIN_PR_PATH
        return ARTIFACT_URL
    }
    // DU_DEV Main & PR - BUILD_PAL_NO_DPDK_RUN_CT stage: no-dpdk pal du RPM file
    static def getDuDevNoDpdkPalRpmURL(String branch, String build_number) {
        String DU_DEV_NO_DPDK_PAL_RPM_MAIN_PATH = 'mobile-phoenix-rpm-pr-rr/du/main/' + build_number + '/02/'
        String DU_DEV_NO_DPDK_PAL_RPM_PR_PATH = 'mobile-phoenix-rpm-pr-rr/du/' + branch + '/' + build_number + '/02/'
        String ARTIFACT_URL = (branch == 'main')  ? DU_DEV_NO_DPDK_PAL_RPM_MAIN_PATH :
                            DU_DEV_NO_DPDK_PAL_RPM_PR_PATH
        return ARTIFACT_URL
    }
    // DU_DEV Main - BUILD_MINERVA_NO_DPDK_RUN_TEST_SIM stage: push TestSim container image from Build stage to Artifactory then pull it to Test stage
    static String DU_TESTSIM_IMAGE_MAIN_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/du-images/main/run-du-test-sim/05-mvl'
    // DU_DEV PR - BUILD_MINERVA_NO_DPDK_RUN_TEST_SIM stage: push TestSim container image from Build stage to Artifactory then pull it to Test stage
    static String DU_TESTSIM_IMAGE_PR_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/du-images/pr/run-du-test-sim/05-mvl'
    // DU-BUILD-ALL - 01-DPDK stage: dpdk pal du binary file
    static def getDuBuildAllDpdkPalBinURL(String branch, String build_number) {
        String DU_BUILD_ALL_DPDK_PAL_BIN_PATH = DU_MAIN_BIN_BASE_PATH + build_number + '/01/'
        return DU_BUILD_ALL_DPDK_PAL_BIN_PATH
    }
    // DU-BUILD-ALL - 01-DPDK stage: dpdk pal du RPM file
    static def getDuBuildAllDpdkPalRpmURL(String branch, String build_number) {
        String DU_BUILD_ALL_DPDK_PAL_RPM_PATH = 'mobile-phoenix-rpm-candidate-rr/du/' + build_number + '/01/'
        return DU_BUILD_ALL_DPDK_PAL_RPM_PATH
    }
    // DU-BUILD-ALL - 01-DPDK stage: temporary dpdk pal du RPM file
    static def getTmpDuBuildAllDpdkPalRpmURL(String branch, String build_number) {
        String TMP_DU_BUILD_ALL_DPDK_PAL_RPM_PATH = 'mobile-phoenix-rpm-pr-rr/du/main/' + build_number + '/01/'
        return TMP_DU_BUILD_ALL_DPDK_PAL_RPM_PATH
    }
    // DU-BUILD-ALL - 02-NO_DPDK stage: no-dpdk pal du binary file
    static def getDuBuildAllNoDpdkPalBinURL(String branch, String build_number) {
        String DU_BUILD_ALL_NO_DPDK_PAL_BIN_PATH = DU_MAIN_BIN_BASE_PATH + build_number + '/02/'
        return DU_BUILD_ALL_NO_DPDK_PAL_BIN_PATH
    }
    // DU-BUILD-ALL - 02-NO_DPDK stage: no-dpdk pal du RPM file
    static def getDuBuildAllNoDpdkPalRpmURL(String branch, String build_number) {
        String DU_BUILD_ALL_NO_DPDK_PAL_RPM_PATH = 'mobile-phoenix-rpm-candidate-rr/du/' + build_number + '/02/'
        return DU_BUILD_ALL_NO_DPDK_PAL_RPM_PATH
    }
    // DU-BUILD-ALL - 02-NO_DPDK stage: temporary no-dpdk pal du RPM file
    static def getTmpDuBuildAllNoDpdkPalRpmURL(String branch, String build_number) {
        String TMP_DU_BUILD_ALL_NO_DPDK_PAL_RPM_PATH = 'mobile-phoenix-rpm-pr-rr/du/main/' + build_number + '/02/'
        return TMP_DU_BUILD_ALL_NO_DPDK_PAL_RPM_PATH
    }
    // DU-BUILD-ALL - BUILD_MINERVA-05 stage: dpdk mvl du binary file
    static def getDuBuildAllDpdkMvlBinURL(String branch, String build_number) {
        String DU_BUILD_ALL_DPDK_MVL_BIN_PATH = DU_MAIN_BIN_BASE_PATH + build_number + '/05/'
        return DU_BUILD_ALL_DPDK_MVL_BIN_PATH
    }
    // DU-BUILD-ALL - BUILD_MINERVA-05 stage: dpdk mvl du RPM file
    static def getDuBuildAllDpdkMvlRpmURL(String branch, String build_number) {
        String DU_BUILD_ALL_DPDK_MVL_RPM_PATH = 'mobile-phoenix-rpm-candidate-rr/du/' + build_number + '/05/'
        return DU_BUILD_ALL_DPDK_MVL_RPM_PATH
    }
    // DU-BUILD-ALL - BUILD_MINERVA-05 stage: temporary dpdk mvl du RPM file
    static def getTmpDuBuildAllDpdkMvlRpmURL(String branch, String build_number) {
        String TMP_DU_BUILD_ALL_DPDK_MVL_RPM_PATH = 'mobile-phoenix-rpm-pr-rr/du/main/' + build_number + '/05/'
        return TMP_DU_BUILD_ALL_DPDK_MVL_RPM_PATH
    }
    // Mainstream - 06-MINERVA-NO_DPDK stage: no_dpdk mvl du binary file
    static def getDuMainstreamNoDpdkMvlBinURL(String branch, String build_number) {
        String DU_MAINSTREAM_NO_DPDK_MVL_BIN_PATH = DU_MAIN_BIN_BASE_PATH + build_number + '/06/'
        return DU_MAINSTREAM_NO_DPDK_MVL_BIN_PATH
    }
    // Mainstream - 06-MINERVA-NO_DPDK stage: no_dpdk mvl du RPM file
    static def getDuMainstreamNoDpdkMvlRpmURL(String branch, String build_number) {
        String DU_MAINSTREAM_NO_DPDK_MVL_RPM_PATH = 'mobile-phoenix-rpm-candidate-rr/du/' + build_number + '/06/'
        return DU_MAINSTREAM_NO_DPDK_MVL_RPM_PATH
    }
    // Mainstream - 06-MINERVA-NO_DPDK stage: temporary no_dpdk mvl du RPM file
    static def getTmpDuMainstreamNoDpdkMvlRpmURL(String branch, String build_number) {
        String TMP_DU_MAINSTREAM_NO_DPDK_MVL_RPM_PATH = 'mobile-phoenix-rpm-pr-rr/du/main/' + build_number + '/06/'
        return TMP_DU_MAINSTREAM_NO_DPDK_MVL_RPM_PATH
    }
    // Mainstream - 01 DPDK PAL RPM file
    static def getDuMainstreamDpdkPalRpmURL(String branch, String build_number) {
        String DU_MAINSTREAM_DPDK_PAL_RPM_PATH = 'mobile-phoenix-rpm-candidate-rr/du/' + build_number + '/01/'
        return DU_MAINSTREAM_DPDK_PAL_RPM_PATH
    }
    // Mainstream - 01 DPDK PAL RPM temporary file
    static def getTmpDuMainstreamDpdkPalRpmURL(String branch, String build_number) {
        String TMP_DU_MAINSTREAM_DPDK_PAL_RPM_PATH = 'mobile-phoenix-rpm-pr-rr/du/main/' + build_number + '/01/'
        return TMP_DU_MAINSTREAM_DPDK_PAL_RPM_PATH
    }
    // Mainstream - 02 NO_DPDK PAL RPM file
    static def getDuMainstreamNoDpdkPalRpmURL(String branch, String build_number) {
        String DU_MAINSTREAM_NO_DPDK_PAL_RPM_PATH = 'mobile-phoenix-rpm-candidate-rr/du/' + build_number + '/02/'
        return DU_MAINSTREAM_NO_DPDK_PAL_RPM_PATH
    }
    // Mainstream - 02 NO_DPDK PAL RPM temporary file
    static def getTmpDuMainstreamNoDpdkPalRpmURL(String branch, String build_number) {
        String TMP_DU_MAINSTREAM_NO_DPDK_PAL_RPM_PATH = 'mobile-phoenix-rpm-pr-rr/du/main/' + build_number + '/02/'
        return TMP_DU_MAINSTREAM_NO_DPDK_PAL_RPM_PATH
    }
    // Mainstream - 05 DPDK MVL RPM file
    static def getDuMainstreamDpdkMvlRpmURL(String branch, String build_number) {
        String DU_MAINSTREAM_DPDK_MVL_RPM_PATH = 'mobile-phoenix-rpm-candidate-rr/du/' + build_number + '/05/'
        return DU_MAINSTREAM_DPDK_MVL_RPM_PATH
    }
    // Mainstream - 05 DPDK MVL RPM temporary file
    static def getTmpDuMainstreamDpdkMvlRpmURL(String branch, String build_number) {
        String TMP_DU_MAINSTREAM_DPDK_MVL_RPM_PATH = 'mobile-phoenix-rpm-pr-rr/du/main/' + build_number + '/05/'
        return TMP_DU_MAINSTREAM_DPDK_MVL_RPM_PATH
    }
    // DU-Custom-Build - DU-Custom-Build stage: du variants container image
    static String DU_CUSTOM_BUILD_IMAGE_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/dev-image/du'
    // DU-Builds Main & PR: Artifact
    static def getDuBuildArtifactURL(String branch, String build_number) {
        String DU_BUILD_ARTIFACT_MAIN_PATH = 'mobile-phoenix-ran-generic-local/du/main/artifact/du-builds'
        String DU_BUILD_ARTIFACT_PR_PATH = 'mobile-phoenix-ran-generic-local/du/pr/artifact/du-builds'
        String ARTIFACT_URL = (branch == 'main' || branch == DU_MASTER_BRANCH || branch.startsWith("du_2.1.0.0"))  ? DU_BUILD_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_BUILD_ARTIFACT_PR_PATH  + '/' + branch + '/'
        return ARTIFACT_URL
    }
    // DU_CT Main & PR: Artifact
    static def getDuCtArtifactURL(String branch, String build_number) {
        String DU_CT_ARTIFACT_MAIN_PATH = 'mobile-phoenix-ran-generic-local/du/main/artifact/du_ct'
        String DU_CT_ARTIFACT_PR_PATH = 'mobile-phoenix-ran-generic-local/du/pr/artifact/du_ct'
        String ARTIFACT_URL = (branch == 'main' || branch == DU_MASTER_BRANCH)  ? DU_CT_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_CT_ARTIFACT_PR_PATH  + '/' + branch + '/'
        return ARTIFACT_URL
    }
    // DU-TEST-SIM Main & PR: Artifact
    static def getDuTestSimArtifactURL(String branch, String build_number) {
        String DU_TESTSIM_ARTIFACT_MAIN_PATH = 'mobile-phoenix-ran-generic-local/du/main/artifact/du_test_sim'
        String DU_TESTSIM_ARTIFACT_PR_PATH = 'mobile-phoenix-ran-generic-local/du/pr/artifact/du_test_sim'
        String ARTIFACT_URL = (branch == 'main' || branch == DU_MASTER_BRANCH)  ? DU_TESTSIM_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_TESTSIM_ARTIFACT_PR_PATH  + '/' + branch + '/'
        return ARTIFACT_URL
    }
    // DU_UT Main & PR: Artifact
    static def getDuUtArtifactURL(String branch, String build_number) {
        String DU_UT_ARTIFACT_MAIN_PATH = 'mobile-phoenix-ran-generic-local/du/main/artifact/du_ut'
        String DU_UT_ARTIFACT_PR_PATH = 'mobile-phoenix-ran-generic-local/du/pr/artifact/du_ut'
        String ARTIFACT_URL = (branch == 'main' || branch == DU_MASTER_BRANCH || branch.startsWith("du_2.1.0.0"))  ? DU_UT_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_UT_ARTIFACT_PR_PATH  + '/' + branch + '/'
        return ARTIFACT_URL
    }
    // DU-TESTSIM-NIGHTLY: Artifact
    static def getDuTestSimNightlyArtifactURL(String branch, String build_number) {
        String DU_TESTSIM_NIGHTLY_ARTIFACT_MAIN_PATH = 'mobile-phoenix-ran-generic-local/du/main/artifact/du_testsim_nightly'
        String DU_TESTSIM_NIGHTLY_ARTIFACT_PR_PATH = 'mobile-phoenix-ran-generic-local/du/pr/artifact/du_testsim_nightly'
        String ARTIFACT_URL = (branch == 'main' || branch == DU_MASTER_BRANCH)  ? DU_TESTSIM_NIGHTLY_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_TESTSIM_NIGHTLY_ARTIFACT_PR_PATH  + '/' + branch + '/'
        return ARTIFACT_URL
    }    
}
