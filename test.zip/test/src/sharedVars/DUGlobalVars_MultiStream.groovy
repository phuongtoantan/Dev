// Copyright (c) 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
package sharedVars


class DUGlobalVars_MultiStream {
    // DU-Builds Main & PR: Artifact
    def getDuBuildArtifactURL(Map streamMetadata, String branch, String build_number, String variant='') {
        String DU_BUILD_ARTIFACT_MAIN_PATH = "${streamMetadata.components.du.du_build_artifact_main_path}"
        String DU_BUILD_ARTIFACT_PR_PATH = "${streamMetadata.components.du.du_build_artifact_path}"
        String ARTIFACT_URL = (branch == streamMetadata.stream_branch || branch.startsWith(streamMetadata.components.du.sem_version.toLowerCase()))  ? DU_BUILD_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_BUILD_ARTIFACT_PR_PATH  + '/' + branch + '/'
        ARTIFACT_URL += variant ? variant + '/' : ''
        return ARTIFACT_URL
    }
    def getDuRPMArtifactURL(Map streamMetadata, String branch, String build_number, String variant='') {
        String DU_RPM_ARTIFACT_MAIN_PATH = "${streamMetadata.components.du.rpm_candidate_path_main}"
        String DU_RPM_ARTIFACT_PR_PATH = "${streamMetadata.components.du.rpm_artifact_path_pr}"
        String SEM_VERSION = "${streamMetadata.components.du.sem_version}"
        String ARTIFACT_URL = (branch == streamMetadata.stream_branch || branch.startsWith(SEM_VERSION.toLowerCase()))  ? DU_RPM_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_RPM_ARTIFACT_PR_PATH  + '/' + branch + '/'
        ARTIFACT_URL += variant ? variant + '/' : ''
        return ARTIFACT_URL
    }
    def getDuTmpRpmArtifactURL(Map streamMetadata, String build_number, String variant='') {
        String DU_RPM_ARTIFACT_PR_PATH = "${streamMetadata.components.du.rpm_artifact_path_pr}"
        String ARTIFACT_URL = DU_RPM_ARTIFACT_PR_PATH  + '/main/' + build_number + '/'
        ARTIFACT_URL += variant ? variant + '/' : ''
        return ARTIFACT_URL
    }
    // DU_UT Main & PR: Artifact
    static def getDuUtArtifactURL(Map streamMetadata, String branch, String build_number) {
        String DU_UT_ARTIFACT_MAIN_PATH = "${streamMetadata.components.du.du_ut_artifact_main_path}"
        String DU_UT_ARTIFACT_PR_PATH = "${streamMetadata.components.du.du_ut_artifact_pr_path}"
        String ARTIFACT_URL = (branch == streamMetadata.stream_branch || branch.startsWith(streamMetadata.components.du.sem_version.toLowerCase()))  ? DU_UT_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_UT_ARTIFACT_PR_PATH  + '/' + branch + '/'
        return ARTIFACT_URL
    }
    // DU-TEST-SIM Main & PR: Artifact
    static def getDuTestSimArtifactURL(Map streamMetadata, String branch, String build_number) {
        String DU_TESTSIM_ARTIFACT_MAIN_PATH = "${streamMetadata.components.du.du_testsim_artifact_main_path}"
        String DU_TESTSIM_ARTIFACT_PR_PATH = "${streamMetadata.components.du.du_testsim_artifact_pr_path}"
        String ARTIFACT_URL = (branch == streamMetadata.stream_branch)  ? DU_TESTSIM_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_TESTSIM_ARTIFACT_PR_PATH  + '/' + branch + '/'
        return ARTIFACT_URL
    }
    // DU-TEST-SIM Main & PR: Artifact
    static def getDuTestSimNightlyArtifactURL(Map streamMetadata, String branch, String build_number) {
        String DU_TESTSIM_NIGHTLY_ARTIFACT_MAIN_PATH = "${streamMetadata.components.du.du_testsim_nightly_artifact_main_path}"
        String DU_TESTSIM_NIGHTLY_ARTIFACT_PR_PATH = "${streamMetadata.components.du.du_testsim_nightly_artifact_pr_path}"
        String ARTIFACT_URL = (branch == streamMetadata.stream_branch)  ? DU_TESTSIM_NIGHTLY_ARTIFACT_MAIN_PATH + '/' + build_number + '/' :
                            DU_TESTSIM_NIGHTLY_ARTIFACT_PR_PATH  + '/' + branch + '/'
        return ARTIFACT_URL
    }
}
