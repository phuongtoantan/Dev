// Copyright (c) 2023-2024 Dell Inc. or its subsidiaries. All rights reserved.

package sharedVars

class RadioswGlobalVars {

    static String RADIOSW_ARTIFACT_PATH = 'mobile-phoenix-ran-generic-local/bin/radio/radiosw'
    static String RADIOSW_MAINSTREAM_ARTIFACT_PATH = 'mobile-phoenix-ran-generic/bin/radio/mainstream/radiosw'
    static String RU_CL2_ARTIFACT_PATH = 'mobile-phoenix-ran-generic-local/bin/radio/ru_cl2'
    static String RU_AUTO_TEST_HWU_ARTIFACT_PATH = 'mobile-phoenix-ran-generic/bin/radio/ru_auto_test_hwu'
    static String RU_CL1_ARTIFACT_PROMOTE_PATH   = 'mobile-phoenix-ran-generic-local/RU/Jenkins/CL1'
    static String RU_CL2_ARTIFACT_PROMOTE_PATH   = 'mobile-phoenix-ran-generic-local/RU/Jenkins/CL2'
    static String RU_CL3_ARTIFACT_PROMOTE_PATH   = 'mobile-phoenix-ran-generic-local/RU/Jenkins/CL3'
    static String RU_CL4_ARTIFACT_PROMOTE_PATH   = 'mobile-phoenix-ran-generic-local/RU/Jenkins/CL4'
    static String RADIOSW_YOCTO_ARTIFACT_PATH = 'mobile-phoenix-ran-generic/RU/Jenkins/radiosw-yocto'
    static String RU_SW_SLOT_IMAGE_BUILDER_ARTIFACT_PATH = 'mobile-phoenix-ran-generic/RU/Jenkins/ru-sw-slot-image-builder'
    static String RU_SW_SLOT_TESTER_ARTIFACT_PATH = 'mobile-phoenix-ran-generic/RU/Jenkins/ru-sw-slot-tester'
    static String RU_AUTO_TEST_SUBMODULE_PATH = 'radiosw-src/extern/RU-Auto-Test'
    static String RU_LATEST_ARM_SDK_ART_URL = 'https://phm.artifactory.cec.lab.emc.com:443/artifactory/mobile-phoenix-ran-generic-local/RU/Releases/SDK/latest/sdk_latest.tar.gz'
}
