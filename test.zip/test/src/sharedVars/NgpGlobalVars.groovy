// Copyright (c) 2023-2024 Dell Inc. or its subsidiaries. All rights reserved.

package sharedVars

class NgpGlobalVars {
    static String PODMAN_IMAGE_NAME_NGP_MAIN_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/ngp'
    static String ARTIFACTORY_REPO = 'phm.artifactory.cec.lab.emc.com/artifactory/mobile-phoenix-rpm-pr-rr'

    //PR DEV NODPDK
    static String PODMAN_IMAGE_NAME_CUCP_NODPDK_PR_DEV_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/dev/cu/cp/no-dpdk'
    static String PODMAN_IMAGE_NAME_CUUP_NODPDK_PR_DEV_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/dev/cu/up/no-dpdk'
    static String PODMAN_IMAGE_NAME_DU_NODPDK_PR_DEV_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/dev/du/no-dpdk'

    //PR PROD DPDK
    static String PODMAN_IMAGE_NAME_CUCP_DPDK_PR_PROD_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/prod/cu/cp/dpdk'
    static String PODMAN_IMAGE_NAME_CUUP_DPDK_PR_PROD_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/prod/cu/up/dpdk'
    static String PODMAN_IMAGE_NAME_DU_DPDK_PR_PROD_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/prod/du/dpdk'

    // PR PROD NODPDK
    static String PODMAN_IMAGE_NAME_CUCP_PR_PROD_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/prod/cu/cp/no-dpdk'
    static String PODMAN_IMAGE_NAME_CUUP_PR_PROD_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/prod/cu/up/no-dpdk'
    static String PODMAN_IMAGE_NAME_DU_PR_PROD_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/prod/du/no-dpdk'

    //Main NODPDK Dev
    static String PODMAN_IMAGE_NAME_CUCP_MAIN_DEV_NODPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/cu/cp/no-dpdk'
    static String PODMAN_IMAGE_NAME_CUUP_MAIN_DEV_NODPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/cu/up/no-dpdk'
    static String PODMAN_IMAGE_NAME_DU_MAIN_DEV_NODPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/du/no-dpdk'

    //Main NODPDK Prod
    static String PODMAN_IMAGE_NAME_CUCP_MAIN_PROD_NODPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/prod/cu/cp/no-dpdk'
    static String PODMAN_IMAGE_NAME_CUUP_MAIN_PROD_NODPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/prod/cu/up/no-dpdk'
    static String PODMAN_IMAGE_NAME_DU_MAIN_PROD_NODPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/prod/du/no-dpdk'

    //Main DPDK Dev
    static String PODMAN_IMAGE_NAME_CUCP_MAIN_DEV_DPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/cu/cp/dpdk'
    static String PODMAN_IMAGE_NAME_CUUP_MAIN_DEV_DPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/cu/up/dpdk'
    static String PODMAN_IMAGE_NAME_DU_MAIN_DEV_DPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/du/dpdk'

    //Main DPDK Prod
    static String PODMAN_IMAGE_NAME_CUCP_MAIN_PROD_DPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/prod/cu/cp/dpdk'
    static String PODMAN_IMAGE_NAME_CUUP_MAIN_PROD_DPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/prod/cu/up/dpdk'
    static String PODMAN_IMAGE_NAME_DU_MAIN_PROD_DPDK_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/prod/du/dpdk'

    //RPMs NODPDK
    static String ARTIFACT_PATH_CUCP_MAIN_DEV_NODPDK = 'mobile-phoenix-rpm-pr-rr/gNB_ngp/dev/CU/CP/NODPDK'
    static String ARTIFACT_PATH_CUUP_MAIN_DEV_NODPDK = 'mobile-phoenix-rpm-pr-rr/gNB_ngp/dev/CU/UP/NODPDK' 
    static String ARTIFACT_PATH_DU_MAIN_DEV_NODPDK = 'mobile-phoenix-rpm-pr-rr/gNB_ngp/dev/DU/NODPDK'

    //RPMs DPDK
    static String ARTIFACT_PATH_CUCP_MAIN_DEV_DPDK = 'mobile-phoenix-rpm-pr-rr/gNB_ngp/dev/CU/CP/DPDK'
    static String ARTIFACT_PATH_CUUP_MAIN_DEV_DPDK = 'mobile-phoenix-rpm-pr-rr/gNB_ngp/dev/CU/UP/DPDK' 
    static String ARTIFACT_PATH_DU_MAIN_DEV_DPDK = 'mobile-phoenix-rpm-pr-rr/gNB_ngp/dev/DU/DPDK'

    // UT Main
    static String PODMAN_IMAGE_PATH_DUUT_MAIN_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/du/ut'
    static String PODMAN_IMAGE_PATH_CUUT_MAIN_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/cu/ut'
    static String PODMAN_IMAGE_PATH_NGP_UT_MAIN_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/main/dev/ngp/ut'

    // UT PR
    static String PODMAN_IMAGE_PATH_DUUT_PR_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/dev/du/ut'
    static String PODMAN_IMAGE_PATH_NGP_UT_PR_RHEL8 = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gnb-ngp/pr/dev/ngp/ut'


    // UT reports
    static String NGP_UT_ARTIFACT_PATH = 'mobile-phoenix-rpm-pr-rr/gNB_ngp/artifacts/NGP-UT'
    static String NGP_CUDU_UT_ARTIFACT_PATH = 'mobile-phoenix-rpm-pr-rr/gNB_ngp/artifacts/NGP-CU-DU-UT'

    // CT reports
    static String NGP_CT_ARTIFACT_PATH = 'mobile-phoenix-rpm-pr-rr/gNB_ngp/artifacts/NGP-CT'
    
    // Base image for UT
    static String NGP_UT_IMAGE_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/ngp_ut'

    // Base image for CT

    static String NGP_CT_IMAGE_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/ngp_ct'
    // Base image for Perftest
    static String NGP_PERFTEST_IMAGE_PATH = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/ngp_perftest'
}
