// Copyright (c) 2023-2024 Dell Inc. or its subsidiaries. All rights reserved.
package sharedVars

class TransportGlobalVars {
    def GenericVars = new GenericVars()

    // Transport RPM's Artifactory paths
    static String TRANSPORT_RPM_PATH = "mobile-phoenix-rpm-candidate/R2/du/transport/main"
    static String KEA_SERVER_RPM_ARTIFACT_PATH = "mobile-phoenix-rpm-candidate/R2/du/transport/main/kea_server_latest/"
    static String GREEN_LOAD_RPM_ARTIFACT_PATH = GenericVars.ARTITACTORY_BASE_URL + "mobile-phoenix-rpm-green_load/latest/"
    static String FH_MANAGER_PR_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + "mobile-phoenix-rpm-pr/R2/du/transport/"


    
    static String TRANSPORT_TMP_IMAGE_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/transport-tmp'
    static String TRANSPORT_MAIN_IMAGE_BASE_URL = GenericVars.DOCKER_IMAGE_BASE_URL + '/transport'
    static String FH_MANAGER_TMP_IMAGE_PATH = TransportGlobalVars.TRANSPORT_TMP_IMAGE_BASE_URL + '/fh_manager'
    static String FH_MANAGER_IMAGE_PATH = TransportGlobalVars.TRANSPORT_MAIN_IMAGE_BASE_URL + '/fh_manager'


    static String FH_MANAGER_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + TransportGlobalVars.TRANSPORT_RPM_PATH + '/fh_manager'
    static String FH_MANAGER_RPM_TMP_PATH = "mobile-phoenix-rpm-pr-rr"+ '/transport-tmp' + '/fh_manager'

    static String NETFILTER_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + TransportGlobalVars.TRANSPORT_RPM_PATH + '/netfilter'
    static String NETFILTER_RPM_TMP_PATH = "mobile-phoenix-rpm-pr-rr"+ '/transport-tmp' + '/netfilter'

    static String KEA_DHCP_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + TransportGlobalVars.TRANSPORT_RPM_PATH + '/kea_dhcp'
    static String KEA_DHCP_RPM_TMP_PATH = "mobile-phoenix-rpm-pr-rr"+ '/transport-tmp' + '/kea_dhcp'

    static String DELL_KEA_SERVER_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + TransportGlobalVars.TRANSPORT_RPM_PATH + '/kea_server'
    static String DELL_KEA_SERVER_RPM_TMP_PATH = "mobile-phoenix-rpm-pr-rr"+ '/transport-tmp' + '/kea_server'

    static String DELL_KEA_SERVER_DEVEL_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + TransportGlobalVars.TRANSPORT_RPM_PATH + '/kea_server'
    static String DELL_KEA_SERVER_DEVEL_RPM_TMP_PATH = "mobile-phoenix-rpm-pr-rr"+ '/transport-tmp' + '/kea_server'

    static String DELL_KEA_SERVER_HOOKS_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + TransportGlobalVars.TRANSPORT_RPM_PATH + '/kea_server'
    static String DELL_KEA_SERVER_HOOKS_RPM_TMP_PATH = "mobile-phoenix-rpm-pr-rr"+ '/transport-tmp' + '/kea_server'

    static String DELL_KEA_SERVER_LIBS_RPM_PATH = GenericVars.ARTITACTORY_BASE_URL + TransportGlobalVars.TRANSPORT_RPM_PATH + '/kea_server'
    static String DELL_KEA_SERVER_LIBS_RPM_TMP_PATH = "mobile-phoenix-rpm-pr-rr"+ '/transport-tmp' + '/kea_server'

    static String NetFilter_Results_XML = "mobile-phoenix-rpm-pr-rr/transport/xml_reports"
}
