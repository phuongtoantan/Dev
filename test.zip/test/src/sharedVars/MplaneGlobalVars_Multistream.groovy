// Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

package sharedVars

class MplaneGlobalVars_Multistream {
    def getMplaneRPMBasePath(Map streamMetadata, String component, String branch, Boolean is_candidate=false, Boolean green_load=false) {
        String RPM_MAIN_PATH = "${streamMetadata.components.mplane.artifact_path_main}"
        String RPM_GREEN_LOAD_PATH = "${streamMetadata.rpm_green_load_path}"
        String RPM_PR_PATH = "${streamMetadata.components.mplane.rpm_artifact_path_pr}"
        component = component == '' ? '' : '/'  + component
        String RPM_PATH = (is_candidate || branch == streamMetadata.stream_branch)  ? RPM_MAIN_PATH + component :
                            green_load == true ? RPM_GREEN_LOAD_PATH + component :
                            RPM_PR_PATH  + component + '/' + branch
        return RPM_PATH
    }

    def getMplaneLogPath(Map streamMetadata, String branch) {
        String MPLANE_LOG_PATH = "${streamMetadata.components.mplane.artifact_path_log}"
        String ARTIFACT_PATH = (branch == streamMetadata.stream_branch)  ? MPLANE_LOG_PATH + '/' + branch :
                            MPLANE_LOG_PATH +'/' + 'PR' + '/' + branch
        return ARTIFACT_PATH
    }

}