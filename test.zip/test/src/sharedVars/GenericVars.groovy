// Copyright (c) 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

package sharedVars

class GenericVars {
    // Artifactory
    static String GBI_PODMAN_IMAGE = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gbi'
    //The Username of user that API key is used to access Artifactory
    static String ARTIFACTORY_SVC_USER = 'svc_npmphran'

    // Docker registry
    static String DEFAULT_ARTIFACTORY_DOCKER_REGISTRY = 'phm.artifactory.cec.lab.emc.com'
    static String LOCAL_PLATFORM_DOCKER_REGISTRY = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local'
    static String PLATFORM_DOCKER_REGISTRY = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker'

    static String DEPLOYER_PODMAN_IMAGE = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/deployer'
    static String ARTITACTORY_BASE_URL = 'https://phm.artifactory.cec.lab.emc.com/artifactory/'
    static String ARTITACTORY_DOCKER_BASE_URL = "${ARTITACTORY_BASE_URL}" + 'mobile-phoenix-platform-docker/artifactory/mobile-phoenix-platform-docker'
    static String RPM_PR_PATH = 'mobile-phoenix-rpm-pr-rr'
    static String RPM_CANDIDATE_PATH = 'mobile-phoenix-rpm-candidate'
    static String RPM_PR_LOCAL_PATH = 'mobile-phoenix-rpm-pr-rr'
    static String RPM_CANDIDATE_LOCAL_PATH = 'mobile-phoenix-rpm-candidate-rr'
    static String RPM_GREEN_LOAD_PATH = 'mobile-phoenix-rpm-green_load'
    static String RAN_GENERIC_REPO = 'mobile-phoenix-ran-generic-local'
    static String DOCKER_IMAGE_BASE_URL = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/mobile-phoenix-platform-docker'
    static String DOCKER_IMAGE_BASE_PATH = 'mobile-phoenix-platform-docker-local/artifactory/mobile-phoenix-platform-docker'
    static String RELEASE_VERSION = '2.1.0.0'

    // DEPRECATED - use RPM_CANDIDATE_PATH
    static String RPM_CANDITATE_PATH = 'mobile-phoenix-rpm-candidate'
    // DEPRECATED - use RPM_CANDIDATE_LOCAL_PATH
    static String RPM_CANDITATE_LOCAL_PATH = 'mobile-phoenix-rpm-candidate-rr'

    // Github
    static GITHUB_HTTP_URL = "https://eos2git.cec.lab.emc.com"
    static GITHUB_OWNER = "Mobile-Phoenix"
    static GITHUB_API_BASE_URL = "$GITHUB_HTTP_URL/api/v3/repos/$GITHUB_OWNER"

    // Jenkins
    static String JENKINS_SCRIPT_PATH = 'jenkins/jobs/scripts/shell'

    // Custom functions
    static def getComponentRPMBasePath(String component, String branch, Boolean is_candidate=false, Boolean green_load=false) {
        component = component == '' ? '' : '/'  + component
        String RPM_PATH = (is_candidate || branch == 'main')  ? RPM_CANDIDATE_PATH + component :
                            green_load == true ? RPM_GREEN_LOAD_PATH + component :
                            RPM_PR_PATH  + component + '/' + branch
        
        return RPM_PATH
    }

    static def getComponentRPMBasePathWithVersion(String version, String component, String branch, String build_id = 0, Boolean is_candidate=false, Boolean green_load=false, Boolean include_branch=false) {
        component = component == '' ? '' : '/'  + component
        String RPM_PATH = (is_candidate || branch == 'main' || branch == 'main' || branch == 'R1.0' || branch == 'main_R1') ? 
                            RPM_CANDIDATE_PATH + '/' + version + '/' + component + (include_branch ? '/' + branch +  '/' + build_id : ''):
                            green_load == true ? RPM_GREEN_LOAD_PATH + '/' + version + '/' +  component + (include_branch ? '/' + branch +  '/' + build_id : ''):
                            RPM_PR_PATH + '/' + version + '/' +  component + '/PR_build/' + branch +  '/' + build_id
        return RPM_PATH
    }

    static def getComponentRPMBaseURL(String component, String branch, Boolean is_candidate=false, Boolean green_load=false) {
        component = component == '' ? '' : '/'  + component
        String BASE_URL = ARTITACTORY_BASE_URL
        BASE_URL += (is_candidate || branch == 'main')  ? RPM_CANDIDATE_PATH + component :
                    green_load == true ? RPM_GREEN_LOAD_PATH + component :
                    RPM_PR_PATH  + component + '/' + branch
        
        return BASE_URL
    }
}