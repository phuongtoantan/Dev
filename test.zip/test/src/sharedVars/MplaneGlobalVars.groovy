// Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

package sharedVars

class MplaneGlobalVars {
    def GenericVars = new GenericVars()

    static String MPLANE_IMG_FULL_URL = "${GenericVars.DOCKER_IMAGE_BASE_URL}" + '/mplane-images-prod/rhel8/mplane'
    static String PODMAN_IMAGE_NAME_MPLANE_PRO_MAIN_RHEL8 = "${GenericVars.DOCKER_IMAGE_BASE_URL}" + '/mplane-images-prod/rhel8/mplane'
    static String PODMAN_IMAGE_NAME_MPLANE_NON_PRO_MAIN_RHEL8 = "${GenericVars.DOCKER_IMAGE_BASE_URL}" + '/mplane-images-non-prod/rhel8/mplane'

    static String PODMAN_IMAGE_NAME_NGP_MPLANE_PR_DEV_RHEL8 = "${GenericVars.DOCKER_IMAGE_BASE_URL}" + 'artifactory/platform/gnb-ngp/pr/dev/mplane'
    static String ARTIFACT_PATH_NGP_MPLANE_PR_DEV_RHEL8 = 'mobile-phoenix-platform-gen/gNB_ngp/dev/MPLANE'

    def getMplaneLogPath(String branch) {
        String MPLANE_LOG_PATH = "mobile-phoenix-ran-generic-local/MPLANE/artifact"
        String ARTIFACT_PATH = (branch == 'main')  ? MPLANE_LOG_PATH + '/' + 'main' :
                            MPLANE_LOG_PATH +'/' + 'PR' + '/' + branch
        return ARTIFACT_PATH
    }

    
}