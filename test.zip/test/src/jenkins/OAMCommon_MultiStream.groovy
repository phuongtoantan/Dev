// Copyright © 2023-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

package jenkins

def CleanWs() {
    cleanWs(cleanWhenNotBuilt: true,
            deleteDirs: true,
            disableDeferredWipeout: true,
            notFailBuild: true)
}

/**
 * This function trigger OAM Component Test.
 * @param ctopts. Default is an empty list
 */
def OamComponentTest( String... ctopts) {
    sh """
        pwd
        ./oam-dev-tools/devenv/scripts/pipeline.sh component-test --init -n ${JOB_NAME.replaceAll("[ -/]","_")}_component_test_${BUILD_ID} --oam-sim-src oam-node-simulator --test-src gNB_OAM_TEST
        ./oam-dev-tools/devenv/scripts/pipeline.sh component-test --component-test ${ctopts?.join(' ')} || true
        pwd
    """
}

/**
 * This function trigger OAM Stress Test.
 * @param ctopts. Default is an empty list
 */
def OamStressTest( String... ctopts) {
    sh """
        pwd
        ./oam-dev-tools/devenv/scripts/pipeline.sh component-test --init -n ${JOB_NAME.replaceAll("[ -/]","_")}_stress_test_${BUILD_ID} --oam-sim-src oam-node-simulator --test-src gNB_OAM_TEST
        ./oam-dev-tools/devenv/scripts/pipeline.sh component-test --stress-test ${ctopts?.join(' ')} || true
        pwd
    """
}

def OamCheckoutSrc(
      streamMetadata = [:],
      String OAM_DEV_TOOLS_BRANCH= '',
      String PR_REPO= 'gNB_OAM',
      String PR_BRANCH= '',
      String PR_TARGET= '',
      String NODE_CONTROLLER_BRANCH= '',
      String NGP_BRANCH= '',
      String OAM_BRANCH= '',
      String YANG_MODEL_BRANCH= '',
      String DU_BRANCH= '',
      String OAM_TEST_BRANCH= '',
      String OAM_NODE_SIMULATOR_BRANCH= '',
      String API_BRANCH= '',
      String CU_BRANCH= ''
    ) {
    //Checkout the appropriate branches for the oam-node-simulator submodules
    sh label: "Checkout repos...", script: """
      git clone -b ${streamMetadata.components.oam.dev_tools_branch} git@eos2git.cec.lab.emc.com:Mobile-Phoenix/oam-dev-tools.git oam-dev-tools
      git clone -b ${streamMetadata.components.oam.test_branch} git@eos2git.cec.lab.emc.com:Mobile-Phoenix/gNB_OAM_TEST.git gNB_OAM_TEST
      git clone -b ${streamMetadata.components.oam.node_simulator_branch} git@eos2git.cec.lab.emc.com:Mobile-Phoenix/oam-node-simulator.git oam-node-simulator
    """
    retry (3) {
      timeout(time: 3, unit: 'MINUTES') {
        sh """
          cd  ${WORKSPACE}/oam-dev-tools
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${OAM_DEV_TOOLS_BRANCH} || git checkout ${streamMetadata.components.oam.dev_tools_branch}
          cd  ${WORKSPACE}/gNB_OAM_TEST
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${OAM_TEST_BRANCH} || git checkout ${streamMetadata.components.oam.test_branch}
          cd  ${WORKSPACE}/oam-node-simulator
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${OAM_NODE_SIMULATOR_BRANCH} || git checkout ${streamMetadata.components.oam.node_simulator_branch}
          git submodule update --init --remote --jobs 8
          cd  ${WORKSPACE}/oam-node-simulator/gNB_OAM
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${OAM_BRANCH}
          cd  ${WORKSPACE}/oam-node-simulator/gNB_ngp
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${NGP_BRANCH}
          cd  ${WORKSPACE}/oam-node-simulator/yang_model
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${YANG_MODEL_BRANCH}
          cd  ${WORKSPACE}/oam-node-simulator/gNB_API
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${API_BRANCH}
          cd  ${WORKSPACE}/oam-node-simulator/gNB_node_controller
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${NODE_CONTROLLER_BRANCH}
          cd  ${WORKSPACE}/oam-node-simulator/gNB_CU
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${CU_BRANCH}
          cd  ${WORKSPACE}/oam-node-simulator/gNB_DU
          git checkout ${PR_BRANCH} || git checkout ${PR_TARGET} || git checkout ${DU_BRANCH}
        """
      }
    } // End of retry
}

/**
 * This function create container image, which can be used to deploy setup for simulator test or configuration mapping test
 * @param TEST_TYPE Default is 'sim-test', another possible value is 'cfgtest'
*/
def OamBuilderImg(String TEST_TYPE="sim-test") {
  // Clean up.  There may be stray images from previous aborted jenkins jobs.
  sh "${CNT_BUILDER} image prune --force"
  sh "${CNT_BUILDER} network prune --force"
  sh "${CNT_BUILDER} image rm robot --force || true"
  // Create OAM Test Bed for simulator
  sh "./oam-dev-tools/devenv/scripts/pipeline.sh ${TEST_TYPE} --init -n ${JOB_NAME.replaceAll("[ -/]","_")}_${TEST_TYPE.replaceAll("[ -/]","_")}_${BUILD_ID} --oam-sim-src oam-node-simulator --test-src gNB_OAM_TEST"
  // Login builder registry
  sh "./oam-dev-tools/devenv/scripts/registry-login.sh -u ${DOCKER_CREDS_USR} -p ${DOCKER_CREDS_PSW} -r ${REGISTRY}"
  //Build gnb-oam-builder image
  sh "./oam-dev-tools/devenv/scripts/pipeline.sh ${TEST_TYPE} --builder-image"
}

def getSubmoduleHash(String gitDir="oam-node-simulator") {
  def hashMap =[:]
  def output = ""
  try {
    output = sh(returnStdout: true,
                script:"""
                  cd ${gitDir} &&
                  git submodule foreach --quiet 'echo \${name}' | xargs -I{} bash -c 'cd {}; echo {}:\$(git rev-parse --short HEAD)'
                """
              ).trim()
  }
  catch (Exception error) {
    println "Failed to collect submodule commit hashes"
  }
  hashMap = output.split('\n').collectEntries { line -> line.split(':') as List }
  return hashMap
}

/**
 * This function leverages incredibuild to build OAM artifacts ($WORKSPACE/oam-node-simulator/target) which can be used for simulator test
 * @param SHARED_LIB_BRANCH The mp-jenkins-shared-lib branch for build script build_oam_ib.sh
 * @param PLATFORM_BRANCH The gNB_platform branch for buildah_oam.dockerfile which is used to build OAM simulator artifacts
 * @param BRANCH The cross-dependency branches to be checked out to build OAM simulator artifacts
 * @param OAM_NODE_SIMULATOR_BRANCH The explicit oam-node-simulator branch to be checked out to build OAM simulator artifacts
 * @param API_BRANCH The explicit gNB_API submodule branche to be checked out to build OAM simulator artifacts
 * @param DU_BRANCH The explicit gNB_DU submodule branche to be checked out to build OAM simulator artifacts
 * @param CU_BRANCH The explicit gNB_CU submodule branche to be checked out to build OAM simulator artifacts
 * @param NGP_BRANCH The explicit gNB_ngp submodule branche to be checked out to build OAM simulator artifacts
 * @param OAM_BRANCH The explicit gNB_OAM submodule branche to be checked out to build OAM simulator artifacts
 * @param YANG_MODEL_BRANCH The explicit yang_model submodule branche to be checked out to build OAM simulator artifacts
 * @param NODE_CONTROLLER_BRANCH The explicit gNB_node_controller submodule branche to be checked out to build OAM simulator artifacts
 * @param TMP_IMAGE_TAG The temporary container image tag of builder image
 */
def OamSimBuild(
  streamMetadata = [:],
  String SHARED_LIB_BRANCH='',
  String PLATFORM_BRANCH='',
  String OAM_NODE_SIMULATOR_BRANCH='',
  String BRANCH='',
  String API_BRANCH='',
  String DU_BRANCH='',
  String CU_BRANCH='',
  String NGP_BRANCH='',
  String OAM_BRANCH='',
  String YANG_MODEL_BRANCH='',
  String NODE_CONTROLLER_BRANCH='',
  String TMP_IMAGE_TAG=''
) {
  def Podman = new common.Podman()
  def SCRIPT_PATH = 'jenkins/jobs/scripts/shell'
  // Pull gbi image and oam_ubi image
  timeout(20) {
    waitUntil(initialRecurrencePeriod: 15000) {
      try {
        script {
          Podman.loginArtifactoryDockerRegistry()
        }
        sh "podman pull $GBI_IMAGE"
        sh "podman pull $OAM_UBI_IMAGE"
        return true
      }
      catch (exception) {
        return false
      }
    }
  } //end of timeout
  // Implictly assign cross-dependancy BRANCH to PLATFORM_BRANCH and/or SHARE_LIB_BRANCH if not explicitly defined. Fail over to 'main'
  PLATFORM_BRANCH = "${PLATFORM_BRANCH ?: BRANCH ?: streamMetadata.components.platform.branch}"
  SHARED_LIB_BRANCH = "${SHARED_LIB_BRANCH ?: BRANCH ?: 'main'}"
  // Assign 'main' to PLATFORM_BRANCH and/or SHARED_LIB_BRANCH if the none of branch names exists
  PLATFORM_BRANCH   = sh(script: "git ls-remote --heads git@eos2git.cec.lab.emc.com:Mobile-Phoenix/gNB_Platform.git ${PLATFORM_BRANCH} | grep ${PLATFORM_BRANCH} > /dev/null && echo ${PLATFORM_BRANCH} || echo ${streamMetadata.components.platform.branch}",
                        returnStdout:true).trim()
  SHARED_LIB_BRANCH = sh(script: "git ls-remote --heads git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git ${SHARED_LIB_BRANCH} | grep ${SHARED_LIB_BRANCH} > /dev/null && echo ${SHARED_LIB_BRANCH} || echo main",
                        returnStdout:true).trim()
  println 'Cloning gNB_platform and mp-jenkins-shared-lib repos...'
  sh "git clone --branch $PLATFORM_BRANCH --single-branch https://$GIT_ACCOUNT@eos2git.cec.lab.emc.com/Mobile-Phoenix/gNB_platform.git"
  sh "git clone --branch $SHARED_LIB_BRANCH --single-branch git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git build_scripts"
  println "Building OAM..."
  sh """
    cd $WORKSPACE/build_scripts/$SCRIPT_PATH && \
    sh build_oam_ib.sh -w ${WORKSPACE} \
      ${OAM_NODE_SIMULATOR_BRANCH ? "-s $OAM_NODE_SIMULATOR_BRANCH" : ""} \
      ${BRANCH ? "-b $BRANCH" : ""} \
      ${API_BRANCH ? "-i $API_BRANCH" : ""} \
      ${DU_BRANCH ? "-d $DU_BRANCH" : ""} \
      ${CU_BRANCH ? "-c $CU_BRANCH" : ""} \
      ${NGP_BRANCH ? "-n $NGP_BRANCH" : ""} \
      ${OAM_BRANCH ? "-o $OAM_BRANCH" : ""} \
      ${YANG_MODEL_BRANCH ? "-y $YANG_MODEL_BRANCH" : ""} \
      ${NODE_CONTROLLER_BRANCH ? "-N $NODE_CONTROLLER_BRANCH" : ""} \
      -C ${OAM_CONTAINER_NAME} \
      -t ${TMP_IMAGE_TAG}
  """
  sh 'podman images'    
  sh ''' podman run -id --name oam_env_$TMP_IMAGE_TAG oam_env:$TMP_IMAGE_TAG
         podman exec oam_env_$TMP_IMAGE_TAG ls -alh /
         podman cp oam_env_$TMP_IMAGE_TAG:/usr/sbin/netconfd-pro ./oam-node-simulator/
         podman cp oam_env_$TMP_IMAGE_TAG:/usr/sbin/netconf-subsystem-pro ./oam-node-simulator/
         podman cp oam_env_$TMP_IMAGE_TAG:/usr/lib64/. ./oam-node-simulator/
     '''
  sh 'ls -ltr $WORKSPACE/oam-node-simulator/'  
    
  println "Cleaning up builder image and container"
  cleanUpImage([image: "oam_env:${TMP_IMAGE_TAG}"], 'podman')
  cleanUpImage([container: "${OAM_CONTAINER_NAME}_${TMP_IMAGE_TAG}"], 'podman')
}
