
// Copyright © 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.

package jenkins
import hudson.model.Slave
import jenkins.model.Jenkins
import hudson.slaves.DumbSlave

/** 
    Reference: 
    * https://stackoverflow.com/questions/30327219/mark-jenkins-node-temporarily-as-offline-by-using-the-jenkins-rest-api
    * https://javadoc.jenkins.io/hudson/model/Computer.html
*/

// Input array of labels. E.g: [label1, label2, ...]
def getTargetAgents(targetAgentLabels) {
    def targetAgents = [:]
    def allAgents = Jenkins.instance.slaves
    for (int i = 0; i < allAgents.size(); i++) {
        try {
            Slave agent = allAgents[i]
            def agentLabels = agent.getLabelString().split(" ")

            // Only check online agent
            if (agent.getComputer().isOnline()) {
                agentLabels.each { agentLabel ->
                    if(targetAgentLabels.contains(agentLabel)){
                        agentName = agent.getNodeName()
                        if (!targetAgents.containsKey("$agentName")) {
                            targetAgents."$agentName" = agentLabel
                        }
                    }
                }
            }
        } catch (error) {
            println error
        }
    }
    return targetAgents
}

def isProcessRunning (agentIP, processName){
    def status = false
    script {
        node('jenkins-cleanup-agent') {
            script{
                sh """
                    if ! type rsync >/dev/null; then
                        sudo dnf install -y rsync
                    fi
                """
                withCredentials([usernamePassword(credentialsId: 'jenkins-agent-default', passwordVariable: 'password', usernameVariable: 'username')]) {
                    status = sh(returnStatus: true,
                        script: """
                            sshpass -p $password ssh -o StrictHostKeyChecking=no $username@${agentIP} "ps -cax |grep $processName >/dev/null"
                        """) == 0
                }
            }
        }
    }
    return status
}

def waitUntilProcessCompleted (agentIP, processName, waitTimeInMinutes=3)
{
    script {
        println "Waiting for $processName process completed..."
        while (true) {
            def status = isProcessRunning(agentIP, processName)
            if (status == false)
            {
                println "No $processName is running"
                break
            }
            sleep(time: waitTimeInMinutes, unit: "MINUTES")
        }
    }
}

def waitUntilIdle(agentName, waitTimeInMinutes=10) {
    def workComputer = jenkins.model.Jenkins.instance.getNode(agentName).computer

    println "Waiting for agent idle..."
    while (true) {
        if (workComputer.isIdle()) {
            println "Agent '$agentName' is idle..."
            break
        }
        sleep(time: waitTimeInMinutes, unit: "MINUTES")
    }
}

def markOffline(agentName, offlineReason = "") {
    def workComputer = jenkins.model.Jenkins.instance.getNode(agentName).computer
    if (workComputer) {
        println "Found agent '${agentName}'. Setting agent as temporarity offline..."
        workComputer.setTemporarilyOffline(true, new hudson.slaves.OfflineCause.ByCLI(offlineReason))
        println('Waiting for agent offline...')
        workComputer.waitUntilOffline()
        println('Agent is offline')
    } else {
        throw new Exception("Unable to get agent with name: $agentName")
    }
}

def bringUpOnline(agentName) {
    def workComputer = jenkins.model.Jenkins.instance.getNode(agentName).computer
    if (workComputer) {
        println ("Found agent ${agentName}. Bringing agent back to online...")
        workComputer.setTemporarilyOffline(false,null)
        println('Waiting for agent online...')
        workComputer.waitUntilOnline()
        println('Agent is connected and online')
    } else {
        throw new Exception("Unable to get agent with name: $agentName")
    }
}

def getPercentageDiskSpace(String hostIP, String username, String password) {
    node ('jenkins-cleanup-agent') {
        try {
            def percentage
            String dfOutput = sh(
                returnStdout: true,
                script: "sshpass -p ${password} ssh -o ConnectTimeout=60 -o StrictHostKeyChecking=no -tt ${username}@${hostIP} df -h"
            )
            // Split the dfOutput into lines
            def lines = dfOutput.split('\n')

            // Search for the line containing a percentage value for root '/'
            def desiredLine = lines.find { line -> line =~ /(\d+%)\s+\/$/ }

            // Extract the percentage value from the desired line
            def matcher = (desiredLine =~ /(\d+)%/)
            if (matcher.find()) {
                percentage_full = matcher.group(0)
                percentage = percentage_full.split("%")[0] // Don't include % character
                percentage = Float.parseFloat(percentage)
                println "Percentage: $percentage"
            } else {
                println "No percentage value found."
            }
            return percentage
        } catch (error) {
            println error
            return null
        }
    }
}

def getAgentIP(agentName) {
    def workComputer = jenkins.model.Jenkins.instance.getNode(agentName).computer
    def agentIP = workComputer.launcher.host
    if (!agentIP) {
        throw new Exception("Error when get node IP")
    }
    return agentIP
}


/**
 * Executes an Ansible playbook on a target virtual machine (VM) specified by its IP address.
 * This function performs the following steps:
 *
 * 1. Creates an Ansible inventory file for the pipeline, specifying connection details and credentials.
 * 2. Adds the target VM to the inventory list.
 * 3. Runs the Ansible playbook on the target VM using the provided playbook name and optional extra variables.
 *
 * @param targetVMIP The IP address of the target virtual machine where the Ansible playbook will be executed.
 * @param ansiblePlaybookPath The path to the directory containing the Ansible playbook.
 * @param ansiblePlaybookName The name of the Ansible playbook to be executed.
 * @param extraVars (Optional) Additional variables to pass to the Ansible playbook command as extra parameters.
 * @param enableDebugMode (Optional) If set to true, enables debugging mode for the Ansible playbook execution, providing verbose output for troubleshooting.
 */

def executeAnsiblePlaybook(targetVMIP, ansiblePlaybookPath, ansiblePlaybookName, extraVars="", enableDebugMode=false) {
    def targetVMIPCvt = targetVMIP.replace('.', '_')
    def generatedInventoryFile = "inventory_pipeline_${targetVMIPCvt}.init"
    def TestLine = new component.TestLine()

    withCredentials([usernamePassword(credentialsId: 'jenkins-agent-default', usernameVariable: 'svc_jenkins_user', passwordVariable: 'svc_jenkins_passsword')]) {
        // SSH init
        println "Init SSH key connection to target VM"
        script {
            TestLine.initSshToRemoteVM(svc_jenkins_user, svc_jenkins_passsword, targetVMIP)
        }

        println "Create ansible inventory file for pipeline"
        sh """
            cd $ansiblePlaybookPath
            ls -la
            echo "Create and add new VM to inventory pipeline list"
            touch $generatedInventoryFile
            echo "[all:vars]" >> $generatedInventoryFile
            echo "ansible_connection=ssh" >> $generatedInventoryFile
            echo "ansible_user=$svc_jenkins_user" >> $generatedInventoryFile
            echo "ansible_ssh_pass=$svc_jenkins_passsword" >> $generatedInventoryFile
            echo "ansible_become_pass=$svc_jenkins_passsword" >> $generatedInventoryFile
            echo "[host-$targetVMIP]" >> $generatedInventoryFile
            echo "$targetVMIP" >> $generatedInventoryFile
            cat $generatedInventoryFile
        """

        println "Run ansible playbook on target VM"
        VERBOSE_MODE="-v" // Normal mode
        if (enableDebugMode) {
            VERBOSE_MODE="-vvvv" // Extra debug mode
        }

        sh """
            cd $ansiblePlaybookPath
            ansible-playbook $VERBOSE_MODE $ansiblePlaybookName -i $generatedInventoryFile $extraVars
            rm $generatedInventoryFile
        """
    }
}

/**
 * Retrieves the label(s) associated with a Jenkins agent (node) by its name.
 *
 * @param agentName The name of the Jenkins agent for which labels are to be retrieved.
 * @return A String representing the label(s) associated with the agent.
 *         If the agent is found and is of type DumbSlave, the function returns the label string.
 *         If the agent is not found or is not a DumbSlave, an empty string is returned.
 */

def getAgentLabels(agentName) {
    // Get the computer (node) for the specified agent name
    def computer = Jenkins.instance.getComputer(agentName)

    if (computer != null && computer.node instanceof DumbSlave) {
        return computer.node.getLabelString()
    }

    // Return an empty string if the agent was not found or is not a DumbSlave
    return ''
}



return this
