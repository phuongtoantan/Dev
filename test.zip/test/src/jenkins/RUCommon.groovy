// Copyright (c) 2022-2024 Dell Inc. or its subsidiaries. All rights reserved.
package jenkins

def PrintAgentInfo() {
    sh(script: 'hostname; ifconfig', returnStdout: false)
}

def CleanWs() {
    cleanWs(cleanWhenNotBuilt: true,
            deleteDirs: true,
            disableDeferredWipeout: true,
            notFailBuild: true)
}

def CloneRadioswSrc() {
    sh '''
        pwd
        git clone -b ${PIPELINE_BRANCH} https://$GIT_ACCOUNT@eos2git.cec.lab.emc.com/Mobile-Phoenix/radiosw-src.git radiosw-src
        cd radiosw-src
        git submodule update --init --recursive
        pwd
    '''
}

def CloneRadioswSrcWithCommit(String radiosw_src_tag) {
    sh """
        pwd
        git clone -b ${PIPELINE_BRANCH} https://$GIT_ACCOUNT@eos2git.cec.lab.emc.com/Mobile-Phoenix/radiosw-src.git radiosw-src
        cd radiosw-src
        git checkout $radiosw_src_tag
        git submodule update --init --recursive
        pwd
    """
}

/*
 * Function to be used on a lab PC agent. This clones the radiosw-src repo.
 */
def CloneRadioswSrcLabPc(String radiosw_branch) {
    sh (
        script: """
            pwd
            git clone -b ${radiosw_branch} git@eos2git.cec.lab.emc.com:Mobile-Phoenix/radiosw-src.git radiosw-src
            cd radiosw-src
            git submodule update --init --recursive
            pwd
        """,
        label: "Clone radiosw-src on a lab PC"
    )
}

/*
 * Function to be used on a lab PC agent. This clones the radiosw-src repo and checks out a specific commit.
 */
def CloneRadioswSrcLabPcWithCommit(String radiosw_commit) {
    sh (
        script: """
            pwd
            ls
            rm -rf radiosw-src
            git clone -b main git@eos2git.cec.lab.emc.com:Mobile-Phoenix/radiosw-src.git radiosw-src
            cd radiosw-src
            git checkout ${radiosw_commit}
            git submodule update --init --recursive
            pwd
        """,
        label: "Clone radiosw-src on a lab PC (and checkout a specific commit)"
    )
}

def MakeAndSourcePythonVenv() {
    sh '''
        python3 -m venv ${WORKSPACE}/radiosw-py-venv
        . ${WORKSPACE}/radiosw-py-venv/bin/activate
    '''
}

String installSDKFromUrl(String sdkUrl) {
    String workspaceSDKDir = "${WORKSPACE}/sdk"
    try {
        sh(script: """
            set -e
            cd ${WORKSPACE}/radiosw-src
            wget -q -O ./sdk.sh ${sdkUrl}
            chmod +x ./sdk.sh
            WORKSPACE_SDK=${workspaceSDKDir}
            printf "\$WORKSPACE_SDK\n\n\n" | ./sdk.sh
        """, label: 'Install Albus SDK')
    } catch (Exception e) {
        error("Albus SDK Installation Failed: " + e.toString())
    }

    try {
        // Run the first command
        def sdkGitInfo = sh(script: "grep -oP '(?<=export SDK_GIT_INFO=).*' ${workspaceSDKDir}/radiosw-dev-environment-setup-armv8a-dell-linux", returnStdout: true, label: "Obtaining SDK Git Version Info").trim()
        currentBuild.description += "\nARM SDK GIT INFO: ${sdkGitInfo}"

        // Run the second command
        def jenkinsBuildId = sh(script: "grep -oP '(?<=export JENKINS_BUILD_ID=).*' ${workspaceSDKDir}/radiosw-dev-environment-setup-armv8a-dell-linux", returnStdout: true, label: "Obtaining SDK Build ID").trim()
        currentBuild.description += "\nARM SDK BUILD NUM: ${jenkinsBuildId}"
    } catch (Exception e) {
        error("Failed to obtain SDK Version Info")
    }

    return workspaceSDKDir
}

void Build(String build_platform, String workspaceSDKDir) {
    println("Building: ${build_platform}")
    try {
        sh(script: """        
            set -e
            cd ${WORKSPACE}/radiosw-src

            . ${workspaceSDKDir}/radiosw-dev-environment-setup-armv8a-dell-linux
            grep SDK_GIT_INFO ${workspaceSDKDir}/radiosw-dev-environment-setup-armv8a-dell-linux
            grep JENKINS_BUILD_ID ${workspaceSDKDir}/radiosw-dev-environment-setup-armv8a-dell-linux

            mkdir build_${build_platform}
            cd build_${build_platform}
            cmake -DCMAKE_BUILD_TYPE=RelWithDebInfo -DRADIO_SW_BUILD_DEMOS=OFF -DRADIO_SW_BUILD_TESTS=OFF ..
            make -j4
            cpack
            bash ${WORKSPACE}/radiosw-src/scripts/seperate_debug_symbols.sh
            mv radiosw-0.0.100-Linux.tar.gz ${PROD_VERSION}_${CommitID}_${build_platform}.tar.gz
        """, label: 'Build Albus RadioSW-Src')
    } catch (Exception e) {
        error("App Build Failed: " + e.toString())
    }
}

/*
 * Temporary function to be used on a lab PC agent.
 * This updates the production DB to diable the factory boot feature..
 */
def ModifyProductionDb(String ip_address) {
    println "Modify the production DB"
    sh (
        script: """#!/bin/bash
            ssh -o ServerAliveInterval=2 root@${ip_address} 'if grep -q "NAME /if-rsrc/enable-factory-boot TAGS RU_2_0_1 TYPE Boolean VALUE false END" /etc/radiosw/Production.rudb; then echo "Production DB already modified"; else sed -i "/TAG-LIST-END/ a\\\nNAME /if-rsrc/enable-factory-boot TAGS RU_2_0_1 TYPE Boolean VALUE false END" /etc/radiosw/Production.rudb; fi'
            ssh -o ServerAliveInterval=2 root@${ip_address} "cat /etc/radiosw/Production.rudb"
        """,
        label: "Modifying the production DB (temporary)"
    )
}

/*
 * Function to setup a python virtual environment.
 */
def SetUpPythonVirtualEnvironment()
{
    // WORKSPACE is an environment variable
    sh (
        script: """#!/bin/bash
            python3 -m venv ${WORKSPACE}/radiosw-py-venv
        """,
        label: "Setting up Python Virtual Environment"
    )
}

/*
 * Function to setup the test environment. This involves copying over the test files
 * from the repo to the submodule and installing the requirements from the submodule.
 * This function has a dependency that the radiosw-src repo was already cloned.
 */
def SetUpTestEnvironment()
{
    // WORKSPACE is an environment variable
    sh (
        script: """#!/bin/bash
            mv ${WORKSPACE}/radiosw-src/robot/CL1/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/TestSuite/Regression/CL1/
            mv ${WORKSPACE}/radiosw-src/robot/CL2/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/TestSuite/Regression/CL2/
            mv ${WORKSPACE}/radiosw-src/robot/CL3/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/TestSuite/Regression/CL3/
            mv ${WORKSPACE}/radiosw-src/robot/CL4/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/TestSuite/Regression/CL4/
            mv ${WORKSPACE}/radiosw-src/robot/framework/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/framework/Resources/

            . ${WORKSPACE}/radiosw-py-venv/bin/activate
            python3 -m pip install --upgrade pip
            pip install -r ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/requirements.txt
        """,
        label: "Setting up Test Environment"
    )
}

/*
 * Function to checkout a specific RU-Auto-Test branch within the submodule.
 * This is used by the RU-Auto-Test pipeline.
 * This function has a dependency that the radiosw-src repo was already cloned.
 */
def CheckoutCustomTestBranch(String branch)
{
    // WORKSPACE is an environment variables
    sh (
        script: """#!/bin/bash
            echo "Using RU-Auto-Test branch ${branch}"
            cd ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}
            git checkout ${branch}
            git status
        """,
        label: "Checking out custom test branch"
    )
}

/*
 * Function to download the RU SW application.
 * This function works for CL1 and RU-Auto-Test currently.
 */
def DownloadRuSwApp(String build_id, String prod_version, String build_platform, String commit_id)
{
    // ARTIFACTORY_URL, ARTIFACT_PATH, and PIPELINE_BRANCH_PATH are environment variables
    sh (
        script: """#!/bin/bash
            wget ${ARTIFACTORY_URL}/${ARTIFACT_PATH}/${PIPELINE_BRANCH_PATH}/${build_id}/${build_platform}/${prod_version}_${commit_id}_${build_platform}.tar.gz
            chmod 777 ${prod_version}_${commit_id}_${build_platform}.tar.gz
        """,
        label: "Download RU SW App from artifactory"
    )
}

/*
 * Function to download the RU SW application from a lower pipeline.
 * This function works for CL2, CL3, and CL4 currently.
 */
def DownloadRuSwAppFromLowerPipeline(String build_platform)
{
    // ARTIFACT is an environment variable
    sh (
        script: """#!/bin/bash
            wget -r -nd --no-parent -A 'radiosw-*.tar.gz' https://phm.artifactory.cec.lab.emc.com/${ARTIFACT}/${build_platform}/
            chmod 777 radiosw-*.tar.gz
            mv radiosw-*.tar.gz radiosw.tar.gz
        """,
        label: "Download RU SW App from artifactory (from lower pipeline level)"
    )
}

/*
 * Function to retrieve the commit ID from the build artifact.
 */
def GetCommitIdFromBuildArtifact()
{
    // ARTIFACT is an environment variable
    def commit_id = sh(
        returnStdout: true,
        script: '''#!/bin/bash
            wget -r -nd --no-parent -A 'radiosw-*.tar.gz' https://phm.artifactory.cec.lab.emc.com/${ARTIFACT}/Albus/
            COMMIT_ID=$(ls radiosw-*.tar.gz | cut -d'_' -f2)
            echo \$COMMIT_ID
            rm radiosw-*.tar.gz
        '''
    ).trim()

    println "Commit ID: $commit_id"

    return commit_id
}

/*
 * Function to rename the build artifact for the current pipeline.
 * This function has a dependency on the build artifact being downloaded.
 * This function works for CL2, CL3, and CL4 currently.
 */
def PrepAppForUploadInCurrentPipeline(String prod_version, String build_platform, String commit_id, String pipeline_tag)
{
    sh (
        script: """#!/bin/bash
            mv radiosw.tar.gz ${prod_version}_${commit_id}_${pipeline_tag}_${build_platform}.tar.gz
        """,
        label: "Rename RU SW App to prepare for upload to current pipeline in artifactory"
    )
}

def SetUpRuForTest() {
    sh (
        script: """#!/bin/bash
            . ${WORKSPACE}/radiosw-py-venv/bin/activate
            cd ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}
            python -m robot -t "RU SW HW Status" -i Albus --variable RADIO_SSH:${SSH_SERV} --variable RADIO_NETCONF:${SSH_SERV} --log setup_log TestSuite/Jenkins/
        """,
        label: "Check RU status & attempt to restore if needed"
    )
}

/*
 * Function to install the application via radioswins
 * This function has a dependency on the build artifact being downloaded & radiosw-src being cloned.
 * This function works for CL1 and RU-Auto-Test currently.
 */
def InstallRuSwAppViaRadioswins(String prod_version, String build_platform, String commit_id)
{
    sh (
        script: """#!/bin/bash
            . ${WORKSPACE}/radiosw-py-venv/bin/activate
            python3 -m pip install --upgrade pip
            pip install ${WORKSPACE}/radiosw-src/scripts/radioswins
            cd ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}
            python -m robot -t "RU SW App Installation" -i Albus --variable RADIO_SSH:${SSH_SERV} --variable RADIO_NETCONF:${SSH_SERV} --variable RU_APP_INSTALL_PACKAGE_PATH:${WORKSPACE}/${prod_version}_${commit_id}_${build_platform}.tar.gz --variable INSTALL_DIRECTORY:${WORKSPACE} --variable WORKSPACE:${WORKSPACE} --log installation_log TestSuite/Jenkins/
        """,
        label: "Install RU SW App via radioswins"
    )
}

/*
 * Function to install the application via radioswins
 * This function has a dependency on the build artifact being downloaded & radiosw-src being cloned.
 * This function works for CL2, CL3, and CL4 currently (due to the difference in package name)
 */
def InstallRuSwAppViaRadioswinsGeneric(String ip_address)
{
    // CL2, CL3, CL4 will soon differ anyway in the installation
    // Using a different function that can be swapped out later
    // WORKSPACE is an environment variable
    sh (
        script: """#!/bin/bash
            . ${WORKSPACE}/radiosw-py-venv/bin/activate
            python3 -m pip install --upgrade pip
            pip install ${WORKSPACE}/radiosw-src/scripts/radioswins
            cd ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}
            python -m robot -t "RU SW App Installation" -i Albus --variable RADIO_SSH:${SSH_SERV} --variable RADIO_NETCONF:${SSH_SERV} --variable RU_APP_INSTALL_PACKAGE_PATH:${WORKSPACE}/radiosw.tar.gz --variable INSTALL_DIRECTORY:${WORKSPACE} --variable WORKSPACE:${WORKSPACE} --log installation_log TestSuite/Jenkins/
        """,
        label: "Install RU SW App via radioswins"
    )
}

/*
 * Function to set up GDB on the board
 */
def SetUpGDB(String ip_address)
{
    sh (
        script: """#!/bin/bash
            wget -nv https://phm.artifactory.cec.lab.emc.com/artifactory/mobile-phoenix-ran-generic/RU/RU_Leto/gdb 2>&1
            if [ -f ./gdb ]
            then
                chmod 770 ./gdb
                scp gdb root@${ip_address}:/usr/bin/gdb | tee ssh_log.txt
            else
                echo "GDB binary missing in artifactory"
            fi
        """,
        label: "Set up GDB on the RU"
    )
}

/*
 * Function to run tests on target.
 * This function has a dependency on the build artifact being downloaded & radiosw-src being cloned.
 */
def RunTestsOnTarget(String build_id, String cl_tc_tags, String hw)
{
    // WORKSPACE is an environment variable
    // SSH_SERV is an environment variable that is set in Jenkins UI
    sh (
        script: """#!/bin/bash
            . ${WORKSPACE}/radiosw-py-venv/bin/activate

            cd ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}
            # Check the RU-Auto-Test + radiosw-src framework before running tests on target
            ./ru_sw_framework_check.sh

            echo Running on: ${SSH_SERV}
            python3 -m robot --listener framework/helpers/RuSwTestListener.py --variable RADIO_SSH:${SSH_SERV} --variable RADIO_NETCONF:${SSH_SERV} --variable BUILD_NUMBER:${build_id} ${cl_tc_tags} -x xunitreport --log ${hw}log --report ${hw}report --output ${hw}output TestSuite/Regression/
        """,
        label: "Run Tests on Target"
    )
}

/*
 * Function to power cycle the HW (as part of the E01 status stage)
 */
def PowerCycleHW(String ip_address) {
    sh """#!/bin/bash
        set -ex

        # Attempt to ping the board
        if ping -c 1 ${ip_address} &> /dev/null; then
            echo "Ping to ${ip_address} was successful"

            # Attempt to SSH & reboot the board
            ssh -o ServerAliveInterval=2 root@${ip_address} "reboot" | tee ssh_log.txt

            # Below error messages are expected, or the SSH command returned no error
            if [ \$? -eq 0 ] || grep -qE "client_loop: send disconnect: Broken pipe|Connection to ${ip_address} closed"; then
                # Wait for board to come back up
                sleep 90

                # Attempt to ping the board after the reboot
                for ((i=1; i<=5; i++)); do
                    if ping -c 1 -W 60 "${ip_address}" > /dev/null; then
                        echo "Ping to ${ip_address} was successful"
                        exit 0
                    else
                        echo "Ping to ${ip_address} failed. Retrying..."
                    fi
                    sleep 1
                done

                echo "Ping to ${ip_address} failed after 5 retries"

            # SSH command returned an unexpected error
            else
                echo "SSH to ${ip_address} failed. No reboot was done"
            fi
        else
            echo "Ping to ${ip_address} failed"
        fi

        # If the script gets here, that means either the initial ping failed,
        # or the SSH reboot failed, or the second ping failed. Power cycle the board via the PDU
        echo "Rebooting hardware through PDU"
        git clone git@eos2git.cec.lab.emc.com:Mobile-Phoenix/RU-Auto-Test.git
        pwd
        ls -ltr
        cd ${WORKSPACE}/RU-Auto-Test
        if wget "${ARTIFACTORY_URL}/mobile-phoenix-ran-generic-local/RU/reboots/${SSH_SERV}_reboots.log"; then
            echo  "Download successful"
        else
            echo "Download failed, ${SSH_SERV}_reboots.log is not available "
            touch ${SSH_SERV}_reboots.log
        fi
        python3 -m venv ${WORKSPACE}/radiosw-py-venv
        . ${WORKSPACE}/radiosw-py-venv/bin/activate
        pip install -r ${WORKSPACE}/RU-Auto-Test/requirements.txt
        python3 -m robot --variable RADIO_SSH:${SSH_SERV} -x xunitreport --log PowerCyclelog --report PowerCyclereport -i Power_Cycle --output PowerCycleoutput TestSuite/Jenkins/
    """


    rtUpload(
            serverId: 'Artifactory-RR-PHM',
            spec: '''
            {
            "files": [{
                "pattern": "*_reboots.log",
                "target": "mobile-phoenix-ran-generic-local/RU/reboots/"
                }]
            }
        '''
    )
}

/*
 * Function to check if the RU is pingable
 */
def CheckRuConnection(String ip_address) {
    sh (
        script: """#!/bin/bash
            set -ex
            for ((i=1; i<=5; i++)); do
                if ping -c 1 -W 60 "${ip_address}" > /dev/null; then
                    echo "Ping to ${ip_address} was successful"
                    exit 0
                else
                    echo "Ping to ${ip_address} failed. Retrying..."
                fi
            done
            echo "Ping to ${ip_address} failed after 5 retries"
            exit 1
        """,
        label: "Checking RU Connection via Ping command"
    )
}

/*
 * This function is used by the mainstream pipeline
 * Consider updating that function call with the new functionality
 */
def RunOnTargetWithTag(String prod_version, String build_platform, String ip_address, String cli_tc_tags, String hw) {
    sh """
        # Move CL1 Tests from radiosw-src to RU-Auto-Test
        mv ${WORKSPACE}/radiosw-src/robot/CL1/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/TestSuite/Regression/CL1/
        mv ${WORKSPACE}/radiosw-src/robot/CL2/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/TestSuite/Regression/CL2/
        mv ${WORKSPACE}/radiosw-src/robot/CL3/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/TestSuite/Regression/CL3/
        mv ${WORKSPACE}/radiosw-src/robot/CL4/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/TestSuite/Regression/CL4/
        mv ${WORKSPACE}/radiosw-src/robot/framework/* ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/framework/Resources/
        wget ${ARTIFACTORY_URL}/${ARTIFACT_PATH}/${PIPELINE_BRANCH}/${prod_version}/${build_platform}/${prod_version}_${CommitID}_${build_platform}.tar.gz
        chmod 777 ${prod_version}_${CommitID}_${build_platform}.tar.gz
        python3 -m venv ${WORKSPACE}/radiosw-py-venv
        . ${WORKSPACE}/radiosw-py-venv/bin/activate
        python3 -m pip install --upgrade pip
        ls -ltr
        pip install ${WORKSPACE}/radiosw-src/scripts/radioswins
        python3 -m radioswins --uninstall -r --host root@${ip_address} --radioswins-workdir $PWD
        python3 -m venv ${WORKSPACE}/radiosw-py-venv
        . ${WORKSPACE}/radiosw-py-venv/bin/activate
        python3 -m radioswins --pkg ${prod_version}_${CommitID}_${build_platform}.tar.gz --populate --radioswins-workdir $PWD
        python3 -m radioswins --pkg ${prod_version}_${CommitID}_${build_platform}.tar.gz -r --host root@${ip_address} --radioswins-workdir $PWD
        ssh -o ServerAliveInterval=2 root@${ip_address} "reboot" | tee ssh_log.txt
        if [ \$? -eq 0 ] || grep -qE "client_loop: send disconnect: Broken pipe|Connection to ${ip_address} closed"; then
            sleep 90
        else
            echo "SSH reboot failed. Exiting tests"
            exit 1
        fi
        cd ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}
        pwd
        pip install -r ${WORKSPACE}/${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}/requirements.txt
        echo Running on: ${SSH_SERV}
        python3 -m robot --listener framework/helpers/RuSwTestListener.py --variable RADIO_SSH:${SSH_SERV} --variable RADIO_NETCONF:${SSH_SERV} ${cli_tc_tags} -x xunitreport --log ${hw}log --report ${hw}report --output ${hw}output TestSuite/Regression/
    """
}

/*
 * This function is used by the RU-Auto-Test repo as a submission check on PRs.
 */
def CheckFramework() {
    sh '''
        # Prep environment
        rm -rf RU-Auto-Test radiosw-py-venv
        git clone -b ${ghprbSourceBranch} git@eos2git.cec.lab.emc.com:Mobile-Phoenix/RU-Auto-Test.git RU-Auto-Test
        python3 -m venv "\$WORKSPACE"/radiosw-py-venv
        . "\$WORKSPACE"/radiosw-py-venv/bin/activate
        pip install -r "\$WORKSPACE"/RU-Auto-Test/requirements.txt
        cd \$WORKSPACE/RU-Auto-Test
        pwd
        ls -ltr
        # Check the framework
        ./ru_sw_framework_check.sh
    '''
}

/*
 * This function is used to check the TE logs if there were any known Jira tickets flagged.
 * It auto comments on any Jira tickets with a link to the build.
 * This depends on the RunTestsOnTarget function running and producing a TE log file
 * This function does not work on lab PCs and must be run on Jenkins PCs (due to the curl command)
 */
def CheckForKnownIssues(String platform) {
    sh "wget $ARTIFACTORY_URL/$ARTIFACT_PATH/$PIPELINE_BRANCH_PATH/$BUILD_ID/$platform/telogs.txt"
    withCredentials([usernamePassword(credentialsId: 'svc_acc_npmpticketcheck', passwordVariable: 'Jira_Password', usernameVariable: 'Jira_User')]){
        sh (
            script: '''#!/bin/bash
                file_path="telogs.txt"
                regex_pattern="\\[RUSW-[0123456789]+\\]"
                if [ -e "$file_path" ]; then
                    echo "TE log exists; parsing for known issues"
                    known_issues=$(grep -oE "$regex_pattern" "$file_path")
                    if [ -n "$known_issues" ]; then
                        IFS=$'\n'
                        for known_issue in $known_issues; do
                            known_issue="${known_issue//\\]/}"
                            known_issue="${known_issue//\\[/}"
                            echo "Known issue found: $known_issue"
                            curl D -u $Jira_User:$Jira_Password -X POST --data '{"body":"Issue occurred in '"$BUILD_URL"'"}' -H "Content-Type: application/json" https://jira.cec.lab.emc.com/rest/api/2/issue/$known_issue/comment
                        done
                    else
                        echo "No known issues found."
                    fi
                else
                    echo "TE log does not exist; nothing to parse"
                fi
            ''',
            label: "Checking for known issues in RU SW"
        )
    }
}

/*
 * This function retrieves the commit lineup and sets it as the description in artifactory.
 * This function is dependent on radiosw-src being cloned.
 */
def SetBuildAndTestLineup(){
    println "Getting Build & Test Lineup Information"

    radiosw_commit = sh(returnStdout: true, script: "cd radiosw-src; git rev-parse --short=8 HEAD").trim()
    ru_auto_test_commit = sh(returnStdout: true, script: "cd ${sharedVars.RadioswGlobalVars.RU_AUTO_TEST_SUBMODULE_PATH}; git rev-parse --short=8 HEAD").trim()

    currentBuild.description = """
        <b>Source code + test commit lineup:</b><br><br>
        <b>radiosw-src:</b> ${radiosw_commit}<br>
        <b>RU-Auto-Test:</b> ${ru_auto_test_commit}
    """
}

/*
 * This function is used to report a lost RU connection issue (after CheckRuConnection)
 * It auto comments on the associated Jira ticket with a link to the build.
 * This function does not work on lab PCs and must be run on Jenkins PCs (due to the curl command)
 */
def ReportLostConnectionIssue() {
    withCredentials([usernamePassword(credentialsId: 'svc_acc_npmpticketcheck', passwordVariable: 'Jira_Password', usernameVariable: 'Jira_User')]){
        sh (
            script: '''#!/bin/bash
                curl D -u $Jira_User:$Jira_Password -X POST --data '{"body":"Issue occurred in '"$BUILD_URL"'"}' -H "Content-Type: application/json" https://jira.cec.lab.emc.com/rest/api/2/issue/RUSW-7379/comment
            ''',
            label: "Reporting lost connection issue in the pipeline"
        )
    }
}

def AddLineInRemoteFile(String file_path, String string, String remote_host)
{
    sh """
        #!/bin/bash

        # Function to check if string exists in file on remote host
        check_string() {
            ssh "root@${remote_host}" "grep -q \"${string}\" \"${file_path}\""
        }

        # Function to add string to file on remote host
        add_string() {
            ssh "root@${remote_host}" "echo \"${string}\" >> \"${file_path}\""
        }

        # Check if string exists in file
        if check_string; then
            echo "String already exists in the file on the remote host."
            exit 0
        else
            add_string
            echo "String added to the file on the remote host."
            exit 0
        fi
    """
}

def ReplaceLineInRemoteFile(String file_path, String string_to_replace, String string, String remote_host)
{
    sh """
        #!/bin/bash

        # Function to check if string exists in file on remote host
        check_replace_string() {
            ssh "root@${remote_host}" 'grep -q "${string_to_replace}" \"${file_path}\"'
        }

        check_string() {
            ssh "root@${remote_host}" "grep -q \"${string}\" \"${file_path}\""
        }

        # Function to replace string to file on remote host
        replace_string() {
             ssh "root@${remote_host}" 'sed -i "s~${string_to_replace}~${string}~g" \"${file_path}\"'
        }

        # Check if string exists in file
        if check_string; then
            echo "String already exists in the file on the remote host."
            exit 0
        elif check_replace_string; then
            replace_string
            echo "String replaced on the remote host."
            exit 0
        else
            echo "String not already present and string to replace not found".
            exit 1
        fi
    """
}
