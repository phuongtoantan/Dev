package jenkins
import groovy.transform.Field


def get_host_drivers_artifactory_path(String sdkBranch, String driverType='rpm', String versionPath='', Boolean isCandidate=false){
    /*
        build the drivers with the supported releases

        sdkBranch       :   String  :   sdk branch for the drivers
                                        e.g.    rel/sdk-11.23.02
        driverType      :   String  :   package type for the drivers
                                        current supported types
                                        - rpm
                                        - deb
        versionPath     :   String  :   Dell release version path
                                        e.g.    R2 for release 2.0
        isCandidate     :   Boolean :   set to true for release candidates.
    */
    def GenericVars = new sharedVars.GenericVars()
    def L1GlobalVars = new sharedVars.L1GlobalVars()
    def driversArtifactsPath = GenericVars.getComponentRPMBasePathWithVersion(versionPath,
                L1GlobalVars.ARTIFACTORY_COMPONENT_PATH_L1_DRIVER, sdkBranch , "${BUILD_ID}", isCandidate, false, true)
    
    if (driverType == 'rpm'){
        return "${driversArtifactsPath}/output_ci_host_drivers_rpm/"
    }else if (driverType == 'deb'){
        return "${driversArtifactsPath}/output_ci_host_drivers_deb/"
    }
}

def read_supported_releases(String filename){
    // Read the supported releases file inside the drivers repo,
    // the function returns an array with the supported release versions.
    // The supported release file will have one release per line
    // all lines beginning with # are ignored.
    def fileContents = readFile(filename)
    def lines = fileContents.split('\n')
    def supportedReleases = []

    for (line in lines) 
    {
        if (line.startsWith('#')) continue
        supportedReleases<< "${line}"
    }

    return supportedReleases
}

def build_and_upload_drivers (Boolean releaseCandidate = false,
                              String driverType='rpm',
                              String versionPath='R2',
                              String version = '0.0.0'){
    /*
        build the drivers with the supported releases

        releaseCandidate    :   Boolean     :   set to true for release candidates.
        driverType          :   String      :   package type for the drivers
                                                current supported types
                                                - rpm
                                                - deb
        versionPath         :   String      :   Dell release version path
                                                e.g.    R2 for release 2.0 
        version             :   String      :   RPM Release version for the drivers
                                                e.g. 2.4.112302 for release 2 based on sdk 11.23.02
    */
    def Utils = new common.Utils()
    def driversArtifactsPath = get_host_drivers_artifactory_path("${BRANCH_NAME}", driverType, versionPath, releaseCandidate)
    sh """
        echo ${version} > .project_version
    """
    if (driverType == 'rpm'){
        sh """
            RELEASE_CANDIDATE=${releaseCandidate} ./ci/host_drivers_rpm/build.sh
            ./scripts/version-json-gen.py -n host-drivers-rpm -v ${version} -o output_ci_host_drivers_rpm/version.json
        """
        Utils.uploadArtifact(["output_ci_host_drivers_rpm/*"], "${driversArtifactsPath}") 
    }else if (driverType == 'deb'){
        sh """
            RELEASE_CANDIDATE=${releaseCandidate} ./ci/host_drivers_deb/build.sh
            ./scripts/version-json-gen.py -n host-drivers-deb -v ${version} -o output_ci_host_drivers_deb/version.json
        """
        Utils.uploadArtifact(["output_ci_host_drivers_deb/*"], "${driversArtifactsPath}") 
    }
}

def build_manufacturing_image (){
	echo "Building Manufacturing image"
	sh """
		./ci/image_dvt/build.sh
	"""
}


def docker_set_env_vars_on_docker_users(String optargs=''){
	return 'DOCKER_UID=$(id -u) DOCKER_GID=$(id -g) ' + optargs
}

def run_robot_tests(String optargs){
	/*
		optargs:string			optargs should be a string which sets the ENV variables the following are required
								'SETUP_IP=<setup op> ROBOT_TAGS=<robot tags>'
	*/
	String env_vars = docker_set_env_vars_on_docker_users(optargs)
	sh """
			ls -la
			cd ./system_test
			pwd; ls -la
			mkdir -p reports
			mkdir -p libraries
			mkdir -p outputs
			echo '        user: "\${DOCKER_UID}:\${DOCKER_GID}"' >> docker-compose.yml
			 ${env_vars} docker-compose up --build --force-recreate
			if [ -s "reports/output.xml" ]
			then
				rebot -d reports -x xunitreport.xml reports/output.xml
			else
				echo "Error: Robot output file not found"
			fi
		"""
}
