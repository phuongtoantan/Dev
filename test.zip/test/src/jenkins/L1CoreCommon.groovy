// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package jenkins
import groovy.transform.Field
import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7' )

@Field String ARTIFACTORY_COMPONENT_PATH_L1_FIRMWARE = 'L1/L1_firmware'
@Field String L1_REPOSITORY_TAG_PLACLEHOLDER_PREFIX = 'V2-PH-'
@Field String DEFAULT_L1_AUTOMATION_BRANCH = 'main'

// To use this in pipeline files (vars/*.groovy files)
// def common = new jenkins.L1CoreCommon()
// Run functions in this file within a script block
// script{
//     common.fapigen_test()
// }

def L1GlobalVars = new sharedVars.L1GlobalVars()


def print_skip_stages (String [] skipped_stages){
    println ("Print skipped stages:")
    for (String stage :  skipped_stages)
        println (stage)
    println ("Done printing skipped stages.")
}

def skip_stage (String [] skipped_stages, String stage_name, boolean condition = true){
    println ("Check to skip ${stage_name}")
    if (condition && skipped_stages.contains(stage_name)) {
        println ("Skipping Stage ${stage_name}")
        return true
    }
        
    return false
}

def blackduckProjectVersion (String sub_project){
    def L1GlobalVars = new sharedVars.L1GlobalVars()
    return L1GlobalVars.L1_CURRENT_VERSION_MAJOR_MINOR_PATH_CODE + "_" + sub_project
}

def generateRepositoryPlaceHolderTag(String buildNumber) {
    String REPO_TAG="${L1_REPOSITORY_TAG_PLACLEHOLDER_PREFIX}" + buildNumber
    return REPO_TAG
}

def generateRepositoryTag(String versionNumber, String buildNumber) {
    String REPO_TAG="v" + versionNumber + "-" + buildNumber
    return REPO_TAG
}

def checkout(String workspaceStr = "./", String l1_automation_branch="main", String mp_jenkins_shared_lib_branch="main",
             String config_file="mp-jenkins-shared-lib/jenkins/jobs/scripts/configs/L1-Core/config_105.yaml", 
             String tools_mapping="mp-jenkins-shared-lib/jenkins/jobs/scripts/configs/L1-Core/tools_mapping.yaml"){
    // git clone mp-jenkins-shared-lib and l1-automation git repos
    // Copy config files to l1-automation
    // l1_automation_branch and mp_jenkins_shared_lib_branch can be git branches or tags
    sh """
        mkdir -p ${workspaceStr}
        cd ${workspaceStr}
        git clone -b ${l1_automation_branch} https://${GIT_ACCOUNT}@eos2git.cec.lab.emc.com/Mobile-Phoenix/L1-Automation.git;
        git clone -b ${mp_jenkins_shared_lib_branch} https://${GIT_ACCOUNT}@eos2git.cec.lab.emc.com/Mobile-Phoenix/mp-jenkins-shared-lib.git;
        pwd;
        cp ${config_file} L1-Automation/config/config.yaml;
        cp mp-jenkins-shared-lib/jenkins/jobs/scripts/configs/L1-Core/config_setups.yaml L1-Automation/config/config_setups.yaml;
    """
}

def checkout_repo(String workspaceStr = "./", String branch, String repo, String options="", String dir=""){
    // branch argument can be git branches or tags
    sh """
        mkdir -p ${workspaceStr}
        cd ${workspaceStr}
        pwd;
        git clone --depth=1 -b ${branch} ${options} ${repo} ${dir}
    """
}

def checkout_l1_core(String workspaceStr = "./", String branch="main_F105"){
    // branch argument can be git branches or tags
    repo = "https://${GIT_ACCOUNT}@eos2git.cec.lab.emc.com/Mobile-Phoenix/L1-Core.git"
    checkout_repo (workspaceStr, branch, repo, "--recursive ", ".")
}

def checkout_l1_automation(String workspaceStr = "./", String branch="main"){
    // branch argument can be git branches or tags
    repo = "https://${GIT_ACCOUNT}@eos2git.cec.lab.emc.com/Mobile-Phoenix/L1-Automation.git"
    checkout_repo (workspaceStr, branch, repo)
}

def checkout_l1_platform(String workspaceStr = "./", String branch=L1GlobalVars.L1_PLATFORM_MAIN_BRANCH){
    // branch argument can be git branches or tags
    repo = "https://${GIT_ACCOUNT}@eos2git.cec.lab.emc.com/Mobile-Phoenix/L1-platform.git"
    checkout_repo (workspaceStr, branch, repo, "--recursive ", ".")
}

def checkout_l1_firmware_images(String workspaceStr = "./", String branch=L1GlobalVars.L1_FIRMWARE_IMAGES_MAIN_BRANCH){
    // branch argument can be git branches or tags
    repo = "https://${GIT_ACCOUNT}@eos2git.cec.lab.emc.com/Mobile-Phoenix/L1-firmware-images.git"
    checkout_repo (workspaceStr, branch, repo, "--recursive ", ".")
}

def checkout_l1_mp_jenkins(String workspaceStr = "./", String branch="L1_main_R3"){
    // branch argument can be git branches or tags
    // Leaving debug lines in - we can print if the encoded value 
    String hashed = "${GIT_ACCOUNT}"
    String encoded = hashed.bytes.encodeBase64().toString()

    repo = "https://${GIT_ACCOUNT}@eos2git.cec.lab.emc.com/Mobile-Phoenix/mp-jenkins-shared-lib.git"
    checkout_repo (workspaceStr, branch, repo)
}

def checkout_l1_marvell_sdk(String workspaceStr = "./", String branch="main"){
    // branch argument can be git branches or tags
    repo = "https://${GIT_ACCOUNT}@eos2git.cec.lab.emc.com/Mobile-Phoenix/l1-marvell-sdk.git"
    checkout_repo (workspaceStr, branch, repo)
}

def checkout_l1_marvell_drivers(String workspaceStr = "./", String branch="main"){
    // branch argument can be git branches or tags
    repo = "https://${GIT_ACCOUNT}@eos2git.cec.lab.emc.com/Mobile-Phoenix/l1-marvell-drivers.git"
    checkout_repo (workspaceStr, branch, repo)
}

def configure_l1_automation(String workspaceStr = "./", 
        String config_file="mp-jenkins-shared-lib/jenkins/jobs/scripts/configs/L1-Core/config_105.yaml", 
        String tools_mapping="mp-jenkins-shared-lib/jenkins/jobs/scripts/configs/L1-Core/tools_mapping.yaml", 
        config_dest_path="L1-Automation/config/"){
    sh """
        mkdir -p ${workspaceStr}
        cd ${workspaceStr}
        cp ${config_file} ${config_dest_path}config.yaml;
        cp ${tools_mapping} ${config_dest_path}tools_mapping.yaml;

        cp mp-jenkins-shared-lib/jenkins/jobs/scripts/configs/L1-Core/config_setups.yaml ${config_dest_path}config_setups.yaml;
    """
}

def push_git_tag(String repo_name, String release_candidate){
    //  repo: String with github hostname and path to git project repo 
    //      Ex: eos2git.cec.lab.emc.com/Mobile-Phoenix/l1-marvell-drivers
    //  release_candidate: String that is set to an env var used by scripts/project-version-gen for version tweak
    
    if (release_candidate.length() < 1) {
        println "PR build - No Tagging Required"
        return 
    }
    println "Release Candidate - Tag the build"

    sh """
        pwd 
        export RELEASE_CANDIDATE=${release_candidate}
        echo "RELEASE_CANDIDATE=\${RELEASE_CANDIDATE}"
        export PROD_VERSION=`scripts/project-version-gen`
        echo "PROD_VERSION=\${PROD_VERSION}"
        export REPO_TAG="\${PROD_VERSION}-${BUILD_NUMBER}"
        echo "REPO_TAG=\${REPO_TAG}"
        TAG_EXISTS=\$(git tag --list \${REPO_TAG} | tail -n 1) 
        if ! [ -z "\${TAG_EXISTS}" ]; then
            echo "WARNING: Tag \${REPO_TAG} exists! Deleting existing tag and creating a new tag"
            git tag -d \${REPO_TAG}
            git push --delete \${REPO_TAG}
        fi
        git tag \${REPO_TAG}
        git push https://${GIT_ACCOUNT}@${repo_name} \${REPO_TAG}
        echo "Created & Pushed Tag name \${REPO_TAG}"
    """
}

def push_git_tag_with_name(String repo_name, String tag_name){
    sh """
        TAG_EXISTS=\$(git tag --list ${tag_name} | tail -n 1) 
        if ! [ -z "\${TAG_EXISTS}" ]; then
            echo "WARNING: Tag ${tag_name} exists!"
        else
            git tag ${tag_name}
            git push https://${GIT_ACCOUNT}@${repo_name} ${tag_name}
        fi
    """
}

def get_git_commit_id(){
    String git_commit_id = sh (
                            script: """
                                        git log -1 | grep ^commit | cut -d " " -f 2
                                    """,
                            returnStdout: true
                        ).trim()
    return git_commit_id
}

def generate_git_tag(String release_candidate){
    //  repo: String with github hostname and path to git project repo 
    //      Ex: eos2git.cec.lab.emc.com/Mobile-Phoenix/l1-marvell-drivers
    //  release_candidate: String that is set to an env var used by scripts/project-version-gen for version tweak
    String git_tag = sh (

                            script: """
                                        #pwd 
                                        export RELEASE_CANDIDATE=${release_candidate}
                                        #echo "RELEASE_CANDIDATE=\${RELEASE_CANDIDATE}"
                                        export PROD_VERSION=`scripts/project-version-gen`
                                        #echo "PROD_VERSION=\${PROD_VERSION}"
                                        export REPO_TAG="\${PROD_VERSION}-${BUILD_NUMBER}"
                                        echo "\${REPO_TAG}"
                                    """,
                            returnStdout: true
                        ).trim()
    return git_tag
}

def load_config(String config_file = "L1-Automation/config/config.yaml"){
    println "Loading contents of yaml config file: ${config_file}"
    def config = readYaml file: config_file
    return config
}

def load_releases_mapping(String releases_mapping_path){
    println "Loading releases mapping file: ${releases_mapping_path}"
    def releases_mapping_file = readYaml file: releases_mapping_path
    return releases_mapping_file
}

def load_tools_mapping(String tools_mapping_path){
    println "Loading tools mapping file: ${tools_mapping_path}"
    def tools_mapping_file = readYaml file: tools_mapping_path
    return tools_mapping_file
}

def build_l1_source(String sdk_path, String buildFlavor="ALL", String so="95o", String sc="SUBC_30", 
        String m="ORAN_MHAB", String board="vdu-pci", String packageName="build_oran_mhab.tar.gz", 
        String buildScriptPath="Source_code/Tool/Build/", String buildOutputPath="Build", String otherOptions="", String release_candidate=""){
    def L1GlobalVars = new sharedVars.L1GlobalVars()
    sh """
        git status;
        pwd

        cd ${buildScriptPath}
        rm -rf ${buildOutputPath}
        export RELEASE_CANDIDATE=${release_candidate}
        ./build_5GNR_apps.sh -d ${sdk_path}/host/aarch64-buildroot-linux-gnu/sysroot/ -t \
        ${sdk_path}/host/bin/ -f ${buildFlavor} -so ${so} -sc ${sc} -m ${m} -bo cleanall -b ${board} ${otherOptions} -logger 1
        touch l1-core-commit-id.txt
        git rev-parse HEAD >> l1-core-commit-id.txt || :
        cd ../ ;
        pwd
        ls -ltr;
        echo 'archive build artifacts'
        pwd
        cp ../../${L1GlobalVars.VERSION_JSON_FILE} ${buildOutputPath} || :
        cd ../../
        mkdir build_test
        pwd
        ls -ltr;
        cd ${buildScriptPath}
        pwd
        ls -ltr
        cp -r ./${buildOutputPath}/../*.tgz  ../../../build_test || :
        cd ../../../
        pwd
        ls -ltr
        ls -ltr build_test
        mv build_test build
        # L1-core repo requires these files to be in a build directory
        tar -czvf ${packageName} build
    """
}

def build_l1_source_logutils(String sdk_path, String arguments= "-f HOST_LOGUTILS -so 95o -sc SUBC_30 -m ORAN_MHAB -bo cleanall -b vdu-pci", 
    String logger_package="logger_oran_mhab.tar.gz", String toolBuildPath="Tool/Build/" ){
    sh """
        git status;
        pwd;
        ls -la
        ls -la Source_code
        cd Source_code/${toolBuildPath};
        ./build_5GNR_apps.sh -d ${sdk_path}/host/aarch64-buildroot-linux-gnu/sysroot/ -t ${sdk_path}/host/bin/ ${arguments}
        cd ../ ;
        ls -ltr;
        echo 'archive build artifacts'
        tar -czvf ${logger_package} Build/Logger*
        mv ${logger_package} ../../
    """
}

def build_minerva_firmware(String sdk_path){

    sh """
      pwd
      cd ./Source_code/tool/build
      ./build_5GNR_apps.sh -d ${sdk_path}/host/aarch64-buildroot-linux-gnu/sysroot/ -t ${sdk_path}/host/bin/ \
        -f ALL -so 105 -sc SUBC_30 -m ORAN -bo cleanall -b ran-nic -cti 1 -rb disable -logger 1 -rpm
      ls -laht
    """

}

def build_l1_remote_mpltd(String sdk_path, String buildFlavor="ALL", String so="95o", String sc="SUBC_30", 
        String m="ORAN_MHAB", String board="vdu-pci", String packageName="build_oran_mhab.tar.gz", 
        String buildScriptPath="Source_code/Tool/Build/", String buildOutputPath="Build", String otherOptions=""){
    sh """
        git status;
        pwd

        cd ${buildScriptPath}
        rm -rf ${buildOutputPath} 
        ./build_5GNR_apps.sh -hs ${sdk_path}/host -f ${buildFlavor} -so ${so} -sc ${sc} -m ${m} \
        -bo cleanall -b ${board} -t ${sdk_path}/host/bin/ ${otherOptions}
        touch l1-core-commit-id.txt
        git rev-parse HEAD >> l1-core-commit-id.txt || :
        cd ../ ;
        ls -ltr;
        echo 'archive build artifacts'
        pwd
        tar -czvf ${packageName} ${buildOutputPath}
        mv ${packageName} ../../
    """
}

def get_5gran_pack_last_successful_buildid_started_by_L1_App_DPDK_main(){
    def Utils = new common.Utils()
    def L1GlobalVars = new sharedVars.L1GlobalVars()
    def l1_core_branch = L1GlobalVars.L1_CORE_MAIN_BRANCH
    def mainCoreBuildId = Utils.getLastSuccessfulBuildID("L1_App_DPDK/${l1_core_branch}")
    def job5granPack = Utils.getLastSuccessfulBuild('5gran_pack')
    def PACK_BUILD_NUMBER = job5granPack.number.toInteger()
    def job5granPackParameters = job5granPack.getAction(hudson.model.ParametersAction)
    while (job5granPackParameters.getParameter('L1_CORE_PR').value != l1_core_branch 
            || job5granPackParameters.getParameter('L1_PLATFORM_PR').value != L1GlobalVars.L1_PLATFORM_MAIN_BRANCH
            || job5granPackParameters.getParameter('L1_CORE_BUILD_NUMBER').value != mainCoreBuildId
            || job5granPack.getBuildStatusIconClassName() != 'icon-blue') {
        PACK_BUILD_NUMBER = PACK_BUILD_NUMBER - 1
        if (PACK_BUILD_NUMBER <= 0) {
            throw new Exception("No 5gran_pack buildId found for L1_App_DPDK/${l1_core_branch} #${mainCoreBuildId}")
        }
        job5granPack = Jenkins.instance.getItemByFullName('5gran_pack')
                        .getBuildByNumber(PACK_BUILD_NUMBER)
        job5granPackParameters = job5granPack.getAction(hudson.model.ParametersAction)
    }
    println "5gran pack last successful Build started from L1_App_DPDK/${l1_core_branch}: ${PACK_BUILD_NUMBER}"
    return PACK_BUILD_NUMBER
}

def get_5gran_pack_last_successful_buildid_started_by_L1_Platform_master(){
    // Return 5Gran_pack pipeline buildID number, started by L1 Platform master
    def Utils = new common.Utils()
    def job5granPack = Utils.getLastSuccessfulBuild('5gran_pack')
    def PACK_BUILD_NUMBER = job5granPack.number.toInteger()
    def job5granPackParameters = job5granPack.getAction(hudson.model.ParametersAction)
    while (job5granPackParameters.getParameter('L1_PLATFORM_PR').value != L1GlobalVars.L1_PLATFORM_MAIN_BRANCH) {
        PACK_BUILD_NUMBER = PACK_BUILD_NUMBER - 1
        if (PACK_BUILD_NUMBER <= 0) {
            throw new Exception("No 5gran_pack buildId found for L1_Platform")
        }
        job5granPack = Jenkins.instance.getItemByFullName('5gran_pack')
                        .getBuildByNumber(PACK_BUILD_NUMBER)
        job5granPackParameters = job5granPack.getAction(hudson.model.ParametersAction)
    }
    println "5gran pack last successful Build started from L1_Platform/${L1GlobalVars.L1_PLATFORM_MAIN_BRANCH}: ${PACK_BUILD_NUMBER}"
    return PACK_BUILD_NUMBER
}

def unit_tests(){
    def L1GlobalVars = new sharedVars.L1GlobalVars()
    lock(L1GlobalVars.L1_CORE_UNIT_TESTS_LOCK_NAME){
        sh '''
            rm -rf build
            mkdir build
            cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
            cmake --build build
            cd build
            ./phycTests --gtest_output="xml:results.xml"
            make gcov
            make lcov
            pwd
        '''
    }
}

def unit_tests_dummy(){
    sh '''
        pwd
    '''
}

def update_xml(String classname, String testsuites_name, String l1_automation_path = "./", String xml_file_path = "build/results.xml"){
    sh "python3 ${l1_automation_path}/L1-Automation/apps/UnitTestXmlUpdater/update_xml.py -f ${xml_file_path} -n ${testsuites_name} -c ${classname}"
}

def update_xml_dir(String classname, String testsuites_name, String l1_automation_path = "./", String xml_dir_path = "./"){
    sh "python3 ${l1_automation_path}/L1-Automation/apps/UnitTestXmlUpdater/update_xml.py -d ${xml_dir_path} -n ${testsuites_name} -c ${classname}"
}

def fapigen_test(){
    sh '''
        cd Source_code/Tool/Test/FAPIGEN
        ./fapibuild.sh
        ls -ltr
    '''
}

def matsim_test_sanity(){
    powershell '''
    
        cd matsim
        cd scripts
        Get-ChildItem
        . ./matsim_test_sanity.ps1
    
    '''
}

def visualizer(String input_pcap, String options){
    withEnv(["input_pcap=${input_pcap}", "options=${options}"]) 
    {   
        powershell '''   
                ipconfig

                \$pwd

                $strExpression = "python pcap_to_json.py -p '../../../$env:input_pcap' $env:options -out_path '../../../pcap_to_json_out/'"
                echo $strExpression
                
                "------------------------------ PCAP to JSON ------------------------------"
                cd Source_code/tool/fapi_analyzer

                \$pwd
                Invoke-Expression $strExpression
                
                "------------------------------ Visualizer ------------------------------------"
                cd ../../../matsim/source/testbench
                matlab -wait -logfile "visualizer_log.txt" -batch "rls_visualize_gen('../../../pcap_to_json_out');exit"

                
                if (Test-Path ./visualizer/testing/tests/testhtml) 
                {
                   cd visualizer/testing/tests 
                   tar -cf ../../../../../../v_out.tar testhtml testimages

                   cd ../../../../../..
                   tar -czf visualizer_out.tar.gz v_out.tar ./analyzers_input/*.pcap 
                }
                else
                {
                    "Warning: visualizer outputs not found"
                }
                
              '''
    }
}

def event_visualizer(String input_pcap, String options){
    withEnv(["input_pcap=${input_pcap}", "options=${options}"]) 
    {   
        powershell '''   
                ipconfig

                $strExpression = "python pcap_to_vcd.py -p '../../../$env:input_pcap' --vcdtemplate vcd_signals_template.csv --vcdconfig vcd_configured_signals.csv $env:options"
                echo $strExpression
                
                "------------------------------ PCAP to VCD ------------------------------"
                cd Source_code/tool/fapi_analyzer
                Invoke-Expression $strExpression

                cd ../../../analyzers_input
                if ((Test-Path -Path ./*.vcd -PathType leaf) -and (Test-Path -Path ./*.gtkw -PathType leaf))
                {
                    tar -czf event_visualizer_out.tar.gz *.gtkw *.vcd *.pcap *.json *.csv
                    Copy-Item -Path event_visualizer_out.tar.gz -Destination ./.. -force
                }
                else
                {
                    "Warning: event visualizer outputs not found"
                }

              '''
    }
}

def matsim_test_regression(){
    powershell '''
                "------------------------------ Building Matsim CMake ----------------------------------"
                cd matsim
                cmake -G "MinGW Makefiles" -D CMAKE_C_COMPILER=gcc -D CMAKE_CXX_COMPILER=g++
                cmake --build .\
                # Verify that static library was generated
                $isBuilt = Test-Path ./libmarvell_mex_standalone.a -PathType Leaf
                if ($isBuilt) {"Build succeeded"} else {"Build failed"; exit 1}

                "------------------------------ Building Matsim Mex ------------------------------------"
                cd source/testbench
                matlab -wait -logfile "build_mex_log.txt" -batch "build_mex_main;exit"

                "------------------------------ Running Matsim Regression ------------------------------"
                matlab -wait -batch "rls_regression('./long_regression.csv');exit"

                # Return exit 1 if above command failed
                if($LASTEXITCODE){"Regression tests failed"; exit 1} 

                Copy-Item -Path "matsim_results_long.json" -Destination "..\\..\\..\\matsim_results_long.json"

                if (Test-Path coverage_report.json)
                {
                    Copy-Item -Path "coverage_report.json" -Destination "..\\..\\..\\coverage_report.json"
                }
                else
                {
                    "Warning: Didn't copy coverage_report.json to artifactory. File not found."
                }

                "------------------------------ Running Matsim Performance ------------------------------"
                matlab -wait -batch "rls_performance();exit"

                # Return exit 1 if above command failed
                if($LASTEXITCODE){"Performance tests failed"; exit 1} 
                
                # Verify that all regression tests have passed.             
                $reg = Select-String -Path ./regression_log.txt -Pattern "FAIL" -CaseSensitive
                if ($reg.matches.count -gt 0) {"Regression failed"; exit 1}
                '''

}

def matsim_test_regression_parallel(String pipeline_type){
    withEnv(["pipeline_type=${pipeline_type}"]) {
        powershell('''

        cd matsim
        cd scripts
        Get-ChildItem
        . ./test_suite_caller.ps1 -PipelineType $env:pipeline_type

    ''')
    }

}

def analyze_matsim(String json_file){
    sh"""
    ls -l; pwd;
    if [ -f "L1-Automation/apps/Matsim_LogAnalyzer/matsim_analyzer.py" ]
    then
        python3 L1-Automation/apps/Matsim_LogAnalyzer/matsim_analyzer.py --input ${json_file} --output matsim_results
        mv outputs/matsim_results.xml matsim_results.xml
        rm -rf outputs
        ls -l; pwd;
    else
        echo "Error: Matsim LogAnalyzer script not found"
    fi
    """
}

def matsim_testgenD_sanity(String tc_csv, String tv_csv, String calledFrom="not-specified", Integer sv_enabled=1){
    withEnv(["tc_csv=${tc_csv}", "tv_csv=${tv_csv}", "print_in_logs=${calledFrom}", "sv_enabled=${sv_enabled}"]) {
        powershell '''
                "------------------------------ Building Matsim CMake ----------------------------------"
                cd matsim
                cmake -G "MinGW Makefiles" -D CMAKE_C_COMPILER=gcc -D CMAKE_CXX_COMPILER=g++
                cmake --build .\
                # Verify that static library was generated
                $isBuilt = Test-Path ./libmarvell_mex_standalone.a -PathType Leaf
                if ($isBuilt) {"$env:print_in_logs Build succeeded"} else {"$env:print_in_logs Build failed"; exit 1}

                "------------------------------ Building Matsim Mex ------------------------------------"
                cd source/testbench
                matlab -wait -logfile "build_mex_log.txt" -batch "build_mex_main;exit"

                "------------------------------ Running Matsim TestGenD -------------------------------"
                matlab -wait -batch "rls_test_gen('../../../System_test/testing/$env:tc_csv', '../../../System_test/testing/$env:tv_csv', $env:sv_enabled);exit"

                # Return exit 1 if above command failed
                if($LASTEXITCODE){"$env:print_in_logs Regression failed"; exit 1} else {"$env:print_in_logs Regression failed"}

                Copy-Item -Path "test_gen_out.tar.gz" -Destination "..\\..\\..\\test_gen_out.tar.gz"
                Copy-Item -Path "manifest.json" -Destination "..\\..\\..\\manifest.json"
                '''
    }
}

def matsim_testgenD_regression(String tc_csv, String tv_csv, String calledFrom="not-specified" ){
    powershell '''
                "------------------------------ Building Matsim CMake ----------------------------------"
                cd matsim
                cmake -G "MinGW Makefiles" -D CMAKE_C_COMPILER=gcc -D CMAKE_CXX_COMPILER=g++
                cmake --build .\
                # Verify that static library was generated
                $isBuilt = Test-Path ./libmarvell_mex_standalone.a -PathType Leaf
                if ($isBuilt) {"Build succeeded"} else {"Build failed"; exit 1}

                "------------------------------ Building Matsim Mex ------------------------------------"
                cd source/testbench
                matlab -wait -logfile "build_mex_log.txt" -batch "build_mex_main;exit"

                "------------------------------ Running Matsim TestGenD -------------------------------"
                matlab -wait -batch "rls_test_gen('../../../System_test/testing/Regression_AutoGen.csv');exit"

                # Return exit 1 if above command failed
                if($LASTEXITCODE){"Regression failed"; exit 1}

                Copy-Item -Path "test_gen_out.tar.gz" -Destination "..\\..\\..\\test_gen_out.tar.gz"
                Copy-Item -Path "manifest.json" -Destination "..\\..\\..\\manifest.json"
                
                cd ..\\..\\..
                $commit_id_matches = Select-String -Path ".\\.git\\HEAD" -Pattern ".*$"
                $commit_id = $commit_id_matches.matches.groups[0].Value
                
                $file_content = "Branch name: main `nCommit ID: $commit_id"
                
                New-Item info.txt
                Set-Content info.txt $file_content
                 
                '''
}
def unstash_file_with_default(String workspace="./", String fileName, String defaultFile=""){
    /*
        This Function will unstash a file to the desintationDir, if the file is empty it will be replaced with the 
        file specified with defaultFile
        if no default file is provided the unstashed file is left as is.
    */
    dir(workspace){
        println("Unstashing : ${fileName}")
        try {
            unstash "${fileName}"
        } catch (error) {
            echo "error unstashing: ${error}"
            // currentBuild.result = 'SUCCESS'
        }
        sh """
            if [ -f "$defaultFile" ] && ! [ -s "$fileName" ]; then
                echo "Using default file: $defaultFile"
                cp "$defaultFile" "$fileName"
            fi
        """
    }
}

def remoteMPLTD( String workspace, String tc_csv, String tv_csv, String host_sdk_path, String setup_ip, String tfr_config_path, String target_index='0', String max_timeout='2'){
    // Make sure to use double quotes ("") to wrap sh block when calling arguments.
    // Does not work with export calls for some reason
    dir(workspace){
        l1_core_dir = sh(script: "readlink -f .", returnStdout: true).trim()
        l1_automation_dir=sh(script: "readlink -f ./L1-Automation", returnStdout: true).trim()
        host_sdk_path=sh(script: "readlink -f ${host_sdk_path}", returnStdout: true).trim()
        
        sh """
            echo "l1_core_dir : ${l1_core_dir}"
            echo "l1_automation_dir : ${l1_automation_dir}"
            echo "host_sdk_path : ${host_sdk_path}"
            cd ${l1_automation_dir}/config/
            sed -i "s|L1_SOURCE|${l1_core_dir}/Source_code|g" config.yaml
            sed -i "s|L1-AUTOMATION|${l1_automation_dir}|g" config.yaml
            sed -i "s|L1_SYSTEM_TEST_PATH|${l1_core_dir}/System_test|g" config.yaml
            sed -i "s|HOST_SDK_PATH|${host_sdk_path}|g" config.yaml
            sed -i "s|tc_app_max_timeout : 2|tc_app_max_timeout : ${max_timeout}|g" config.yaml
            cat config.yaml
            cp ${tfr_config_path} tfr_config.json
        """
        catchError(stageResult: 'FAILURE') {
            sh """
                mkdir -p ${l1_core_dir}/Source_code/tool/build/mpltd_img_pkg
                cd ${l1_automation_dir}
                python3 scripts/l1-core-run-tests-remote.py --setup_ip ${setup_ip} \
                    --target_index ${target_index} \
                    -e "${tc_csv}" \
                    -v "${tv_csv}"
                echo Script exited with \$?
            """
        }
    }
}

def MPLTD(String workspace,String test_csv,String tv_csv,String test_category,String max_timeout){
    // Make sure to use double quotes ("") to wrap sh block when calling arguments.
    // Does not work with export calls for some reason
    sh """
        cd ${workspace}
        pwd
        ls -la
        cd L1-Automation/config/
        sed -i "s|L1_SOURCE|${workspace}/Source_code/|g" config.yaml
        sed -i "s|L1_SYSTEM_TEST_PATH|${workspace}/System_test|g" config.yaml
        sed -i "s|tc_app_max_timeout : 2|tc_app_max_timeout : ${max_timeout}|g" config.yaml
        cat config.yaml
        cd ../
        echo Current Path:
        pwd
        echo IP Address of the agent: ${IP_ADDR}
        ls -la
    """
    catchError(stageResult: 'FAILURE') {
        sh 'pwd; ls -ltr'
        sh "ls ${workspace}/System_test/testing"
        // Get Target Index env var from Jenkins Node. If env var does not exist, default to 0 
        if (env.TARGET_INDEX){
            ti = env.TARGET_INDEX
        }
        else{
            ti = 0
        }
        sh "cd ${workspace}/L1-Automation; python3 scripts/l1-core-run-tests.py --setup_ip ${IP_ADDR} --target_index ${ti} -e ${test_csv} -v ${tv_csv} -o ${test_category} -r ${BUILD_NUMBER}; echo Script exited with \$?"       
    }
    sh "mkdir -p ${WORKSPACE}/build/; cp ${workspace}/L1-Automation/outputs/run_${BUILD_NUMBER}/analyzed/${test_category}_Results.xml ${WORKSPACE}/build/ 2>/dev/null || :"
}

def get_testGenD_artifacts(String MPLTD_DELL_WS, Boolean matsim_enabled, String testgend_download_path, String pipeline_type){
    def Utils = new common.Utils()
    def L1GlobalVars = new sharedVars.L1GlobalVars()

    dir("${MPLTD_DELL_WS}") {
        switch(pipeline_type){
            case "weekend":
            case "nightly":
                String package_string = "test_gen_" + pipeline_type;
                println("${L1GlobalVars.ARTIFACT_PATH_L1_CORE_ON_DEMAND}/${package_string}/*/test_gen_out.tar.gz");

                // Download latest published test_gen_out.tar.gz + manifest.json package from L1Core_TestGenD_OnDemand
                rtDownload(
                    serverId: 'Artifactory-RR-PHM',
                    spec: """{
                        "files": [
                            {
                                "pattern": "${L1GlobalVars.ARTIFACT_PATH_L1_CORE_ON_DEMAND}/${package_string}/*/test_gen_out.tar.gz",
                                "flat": true,
                                "target": "./",
                                "sortBy": ["created", "name"],
                                "sortOrder": "desc",
                                "limit": 1
                            },
                            {
                                "pattern": "${L1GlobalVars.ARTIFACT_PATH_L1_CORE_ON_DEMAND}/${package_string}/*/manifest.json",
                                "flat": true,
                                "target": "./",
                                "sortBy": ["created", "name"],
                                "sortOrder": "desc",
                                "limit": 1
                            }
                        ]
                    }"""
                )
                break;

            default:
                if(matsim_enabled){
                    println "Unstashing TestGenD artifacts"
                    unstash 'test_gen_out'
                    unstash 'manifest_json'
                } 
                else{
                    // MP-67574
                    // If run_matsim==false, download TestGenD artifacts instead of generating new ones
                    println "Downloading TestGenD artifacts from ${testgend_download_path}"
                    Utils.downloadArtifact([testgend_download_path + "test_gen_out.tar.gz"]) 
                    Utils.downloadArtifact([testgend_download_path + "manifest.json"]) 
                }  
                break;
        }

        sh 'pwd; ls -ltr'
    }
}

// Function to copy and rename unstashed files using powershell.
// NOTE: Only a Windows agent with Powershell installed can use this function
def powershell_copy_unstashed_file(String input_stash_name, String output_file_name, String destination){
    // Rename stashed file to include file extension
    withEnv(["in_name=${input_stash_name}","out_name=${output_file_name}", "dest=${destination}"]) {
    powershell '''
        if (Get-Content $env:in_name){
            Copy-Item -Path "$env:in_name" -Destination "$env:dest/$env:out_name" -Force
            "$env:in_name successfully unstashed to $env:dest/$env:out_name"
        } else 
        {
            "Uploaded file not found or empty. Using default if available"
        }
    '''
    }
}

// NOTE: Only a Windows agent with Powershell installed can use this function
def powershell_prepare_analyzers_input(String input_stash_name, String output_file_name, String destination){

    powershell_copy_unstashed_file(input_stash_name, output_file_name, destination)

    powershell '''
        New-Item -Path '.\\analyzers_input' -ItemType Directory
    '''

    full_name = output_file_name
    FILE_NAME = full_name.replaceAll("\\..+\$", "")
    FILE_EXT = full_name.replaceAll(FILE_NAME, "")

    switch(FILE_EXT) {
        case ".tar.gz":
            withEnv(["filename=$input_pcap_FILENAME"]) 
            {   
                powershell '''
                    tar -xvf $env:filename -C ./analyzers_input
                '''
            }
            break

        case ".zip":
            withEnv(["filename=$input_pcap_FILENAME"]) 
            {   
                powershell '''
                    Expand-Archive -Path $env:filename -DestinationPath ./analyzers_input -force
                '''
            }
            break

        case [".pcap", ".txt"]:
            withEnv(["filename=$input_pcap_FILENAME"]) 
            {   
                powershell '''
                    \$pwd
                    Copy-Item -Path $env:filename -Destination "analyzers_input/$env:filename" -force
                '''
            }
            break
        default:
            println "Error: Unsupported compression format. Please use .tar.gz or .zip"
            break
        }

}

def MPLTD_manifest(String workspace,String manifest,String test_category,String max_timeout, int stage = 1){
    // Make sure to use double quotes ("") to wrap sh block when calling arguments.
    // Does not work with export calls for some reason
    sh """
        cd ${workspace}
        pwd
        ls -la
        cd L1-Automation/config/
        sed -i "s|L1_SOURCE|${workspace}/Source_code/|g" config.yaml
        sed -i "s|L1_SYSTEM_TEST_PATH|${workspace}/System_test|g" config.yaml
        sed -i "s|tc_app_max_timeout : 2|tc_app_max_timeout : ${max_timeout}|g" config.yaml
        cat config.yaml
        cd ../
        echo Current Path:
        pwd
        echo IP Address of the agent: ${IP_ADDR}
        ls -la
    """
    catchError(stageResult: 'FAILURE') {
        sh 'pwd; ls -ltr'
        sh "ls ${workspace}/System_test/testing"
        // Get Target Index env var from Jenkins Node. If env var does not exist, default to 0 
        if (env.TARGET_INDEX){
            ti = env.TARGET_INDEX
        }
        else{
            ti = 0
        }
        if (stage == 1){
            sh "cd ${workspace}/L1-Automation; python3 scripts/l1-core-run-tests.py --setup_ip ${IP_ADDR} --target_index ${ti} -m ${manifest} -o ${test_category} -r ${BUILD_NUMBER}; echo Script exited with \$?"
        }
        else if(stage == 3){
            sh "cd ${workspace}/L1-Automation; python3 scripts/l1-core-run-tests.py --stage 3 --setup_ip ${IP_ADDR} --target_index ${ti} -m ${manifest} -o ${test_category} -r ${BUILD_NUMBER}; echo Script exited with \$?"      
        }
    }
    sh "mkdir -p ${WORKSPACE}/build/; cp ${workspace}/L1-Automation/outputs/run_${BUILD_NUMBER}/analyzed/${test_category}_Results.xml ${WORKSPACE}/build/ 2>/dev/null || :"
}

def qtest_upload_xml(String classname, String testsuites_name, String l1_automation_path, String xml_file_path, Number parentID, String tools_mapping_path){
    /* 
    Process and upload a single or multiple JUnit XML to qTest. 
    Requires L1-Automation to be cloned and tools_mapping.yaml to be configured prior to calling this function.
    1. Update XML testsuites' name and testsuite classname tags to match TestDesign.py and tools_mapping.yaml values
    2. Call TestDesign.py to create TestCases in qTest for each test found in the XMLs (if they do not exist)
    3. Use XUnit to parse XML and have results available to view in Jenkins
    4. Submit XML results to qTest
    Args:
        classname: Value to set the classname attribute in all <testsuite> tags in the XML
        testsuites_name: Value to set the name attribue in the <testsuites> tag in the XML
        l1_automation_path: Path to the parent directory of L1-Automation
        xml_file_path: Path or pattern to JUnit XML with test results to upload to qTest. Starts from the current workspace. Examples:
            'mpltd_results/Regression_ShareServer_Results.xml'
            'mpltd_results/*_Results.xml'
        parentID: ID of the container in qTest Test Exectution tab in which to place the results of the XML(s)
        tools_mapping_path: Path to tools_mapping.yaml.
    */
    echo "XML file path/pattern: ${xml_file_path}"
    try {
        // Must be double quotes for TESTCATEGORY strings
        update_xml(classname, testsuites_name, "${l1_automation_path}/", xml_file_path)
        user_token = '2dbb6d37-d243-4911-b806-d8c3625d8e08'
        sh """
            python3 ${l1_automation_path}/L1-Automation/apps/QtestTestDesign/TestDesign.py --jenkins_qtest_process -f ${xml_file_path} -u ${user_token} -t ${tools_mapping_path}
        """
        xunit([JUnit(deleteOutputFiles: false, excludesPattern: '', pattern: xml_file_path, stopProcessingIfError: false)])

        qtest_submit_xml(xml_file_path, parentID)
    } 
    catch (Exception error) {
        echo 'Exception occurred during upload process: ' + error.toString()
    }
}

def qtest_submit_xml(String xml_file_path, Number parentID){
    /* 
    Upload a single or multiple JUnit XML to qTest. 
    Args:
        xml_file_path: Path or pattern to JUnit XML with test results to upload to qTest. Starts from the current workspace. Examples:
            'mpltd_results/Regression_ShareServer_Results.xml'
            'mpltd_results/*_Results.xml'
        parentID: ID of the container in qTest Test Exectution tab in which to place the results of the XML(s)
    */
    echo "XML file path/pattern: ${xml_file_path}"
    try {
        TOKEN='6aac68b7-bda6-4579-bba2-0ff3cb39b855'
        QTEST_URL='https://qtest.gtie.dell.com/'
        PROJ_ID=138
        CONT_ID=parentID
        CONT_TYPE='test-cycle'

        // pattern attribute MUST be a relative path. By default starts at ${WORKSPACE}
        submitJUnitTestResultsToqTest([apiKey:TOKEN, 
                                        qtestURL:QTEST_URL, 
                                        projectID: PROJ_ID, 
                                        containerID:CONT_ID, 
                                        containerType:CONT_TYPE, 
                                        overwriteExistingTestSteps:true, 
                                        parseTestResultsFromTestingTools: true, 
                                        createTestCaseForEachJUnitTestClass: false, 
                                        submitToExistingContainer:true, 
                                        submitToAReleaseAsSettingFromQtest:false, 
                                        utilizeTestResultsFromCITool:false, 
                                        createTestCaseForEachJUnitTestMethod:true, 
                                        createNewTestRunsEveryBuildDate: true,
                                        parseTestResultsPattern:xml_file_path]
        )
    } 
    catch (Exception error) {
        echo 'Exception occurred during upload process: ' + error.toString()
    }
}

def tool_validation(String workspace, String test_csv,String tv_csv,String test_category){
    catchError(stageResult: 'FAILURE') {
        // Hardcoded setup 8 IP address - L1-Automation will by pass the value in this stage
        sh "cd ${workspace}/L1-Automation; python3 scripts/l1-core-run-tests.py -e ${test_csv} -v ${tv_csv} -o ${test_category} -r ${BUILD_NUMBER} -s 2"
    }
}

def tool_validation_from_manifest(String workspace, String test_manifest, String test_category){
    catchError(stageResult: 'FAILURE') {
        // Hardcoded setup 8 IP address - L1-Automation will by pass the value in this stage
        sh "cd ${workspace}/L1-Automation; python3 scripts/l1-core-run-tests.py -m ${test_manifest} -o ${test_category} -r ${BUILD_NUMBER} -s 2"

    }
}

def pipeline_verification(String workspace = "./", String pipeline = null, String branch = "main"){
    // Scripts for verifying pipeline (artifacts, reports, logs, pcaps) called here
    username = "tolulope_olugbenga"
    password_part1 = "11926c832e5981a20"
    password_part2 = "ec6e90ec83eac73bf"
    
    if (pipeline == "l1-core") {
        catchError(stageResult: 'FAILURE') {
            sh """cd ${workspace}/L1-Automation; pwd; ls -ltr; 
            python3 apps/JenkinsHelper/JenkinsHelper.py -u ${BUILD_URL} -n ${username} -p ${password_part1 + password_part2}; 
            echo Script exited with \$?"""       
        }
    } else {
        sh '''
            echo "Error: This is not an L1-Core pipeline. JenkinsHelper.py is currently configured for L1-Core."
        '''
    }    
}

def verify_manifest_file(String workspace = "./", String build_vars){
    // Build Docker Image and Run Manifest Verification Script
    if (fileExists("${workspace}/L1-Automation/data/testgen/manifest.json") &&
        fileExists("${workspace}/L1-Automation/suites/JenkinsManifest.robot")) {
        sh """
            pwd; ls -al
            pip3 install robotframework

            cd ${workspace}/System_test
            mkdir -p reports
            mkdir -p libraries
            mkdir -p outputs
            echo '        user: \"\${DOCKER_UID}:\${DOCKER_GID}\"' >> docker-compose.yml

            echo "Re-Building Docker Image and Parsing Manifest File"
            ${build_vars} docker-compose up --build --force-recreate
            echo "Success: Log Files Can be Found here: ${workspace}/System_test/reports"
        """
    } else {
        echo "Error: manifest.json or JenkinsManifest.robot file not found"
    }
}

def convert_output_xml_to_xunit(String workspace = "./"){
     sh"""
        echo "Converting output.xml to xunitreport.xml"
        cd ${workspace}/System_test
        ls -al reports
        if [ -s "reports/output.xml" ]
        then
            cd reports
            rebot --xunit xunitreport.xml output.xml
        else
            echo "Error: Output XML file not found"
        fi
    """
}

def pipeline_placeholder(){
    // Scripts for verifying pipeline (artifacts, qtest uploads, tests ran, etc) called here
    sh '''
        echo "Hello World"
    '''
}

def build_marvell_sdk(String build_cmd, String output_folder, String output_filename, String l1_marvell_sdk_dir="l1-marvell-sdk"){
    return sh (returnStatus: true,
        script: """
            pwd;ls -la
            cd ${l1_marvell_sdk_dir}
            ls -la
            ${build_cmd}
            ls -la
            echo "Done SDK Build"
            tar -czvf ${WORKSPACE}/${output_filename}.tar.gz ${output_folder}/
        """)
    //archiveArtifactsTars()
}

def build_marvell_sdk_from_config(String target_yaml, String artifactory_path, String output_filename, Boolean upload_build=true, String buildInfoName=''){
    def configSDK = readYaml file: target_yaml
    def Utils = new common.Utils()
    if (buildInfoName == null || buildInfoName.allWhitespace) {
        buildInfoName = "${JOB_NAME}"
    }
    for (target in configSDK['targets']) {
        stage("Build ${target.name}") {
            Exit_code = build_marvell_sdk("${target.script}", "${target.output}", "${output_filename}", "./")
            if (Exit_code == 0) {
                if(upload_build){
                    retry(3) {
                        Utils.uploadArtifact(
                            ["${output_filename}.tar.gz"],
                            "${artifactory_path}/",
                            ['buildName':"${buildInfoName}",'buildNumber':"${BUILD_ID}"]
                        ) 
                    }
                }
            }
            else
            {
                error("Build Failed with Exit Code ${Exit_code}")
            }
        } 
    }
}

def get_sdk_image_name(String target_yaml, String build_num){
    def configSDK = readYaml file: target_yaml
    def image_name = "image_${configSDK.stream.name}-${configSDK.sdk.version}.${configSDK.stream.version}-${build_num}"
    return image_name
}

def get_sdk_build_folder(String target_yaml, Integer target_index=0){
    def configSDK = readYaml file: target_yaml
    def build_folder = "${configSDK.targets[target_index].build_folder}"
    return build_folder
}

def platform_coverity(String version, String interdir, String script, String options, String file, String stream) {
    sh """
        echo "Version/Commit id: ${version}"
        mkdir ${interdir}
        export CCACHE_DISABLE=1
        ./ci/lint/build_cov.sh ${COV_PATH} ${interdir} ${script} '${options}'
        ${COV_PATH}/bin/cov-manage-emit --dir ${interdir} list | tee ${file}
        ${COV_PATH}/bin/cov-commit-defects --url ${COV_URL} \
        --stream ${stream} --dir ${interdir} \
        --user ${COV_CREDS_USR} --password ${COV_CREDS_PSW} --ssl --on-new-cert trust --version "${version} --strip-path ${WORKSPACE}"
    """                   
}

def core_coverity(String interdir, String build_path, String build_cmd, String stream, String output_filename) {
    withCredentials([usernamePassword(credentialsId: 'cov_user_pass', usernameVariable: 'COV_USER', passwordVariable: 'COV_PW')]) {
        sh """
            ./run_coverity.sh -c ${COV_PATH} -d ${build_path} -i ${interdir} \
                -b \"${build_cmd}\" -s ${stream} -o ${output_filename} \
                -u ${COV_USER} -p ${COV_PW}
        """
    }
}

def coverity_results(Number issues, String filename) {
    sh """
        echo "<testsuite failures='${issues}'>" > ${filename}
        for i in \$(seq ${issues})
        do
            echo "<testcase name='\$i' classname='Coverity.Issues'>" >> ${filename}
            echo "<failure message='Detected Coverity Issue'></failure>" >> ${filename}
            echo "</testcase>" >> ${filename}
        done
        echo '</testsuite>' >> ${filename}
    """
}

def l1_coverity_check(String proj_name, String view_name, String output_filename){
    def L1GlobalVars = new sharedVars.L1GlobalVars()
    script{
        issues = coverityIssueCheck coverityInstanceUrl: L1GlobalVars.COVERITY_SERVER, projectName: proj_name, returnIssueCount: true, viewName: view_name
        coverity_results(issues, output_filename)
        junit allowEmptyResults: true, testResults: output_filename, skipMarkingBuildUnstable: true, skipPublishingChecks: true
    }
}

def checkoutReposAndGetConfig(env, pipelineParams, l1common, config_path, scmCheckout)
{
  println("Checking out branch ${env.PIPELINE_BRANCH} for PR ID: PR-${env.CHANGE_ID}")
  script {
      if(scmCheckout == true){
        scmData = checkout scm
        scmData.each{k, v -> env[k] = v}
      } 
      else{
        // Skip SCM checkout when not in a multibranch pipeline
        echo 'Skipping SCM checkout'
      }
      def L1GlobalVars = new sharedVars.L1GlobalVars()
      L1GlobalVars.debugPrintText(L1GlobalVars.ENABLE_DEBUG_PRINT, "pipelineParams  = ${pipelineParams}")

      if (pipelineParams.jenkins_branch && pipelineParams.jenkins_branch != "" ){
        jenkins_branch = pipelineParams.jenkins_branch
        println("Checking out Jenkins branch ${jenkins_branch}")
        l1common.checkout_l1_mp_jenkins("./", jenkins_branch)
      }
      else 
      {
          l1common.checkout_l1_mp_jenkins()
      }
      if (pipelineParams.l1_automation_tag && pipelineParams.l1_automation_tag != "" ){
        l1_automation_branch = pipelineParams.l1_automation_tag
      }
      else
      {
        l1_automation_branch = DEFAULT_L1_AUTOMATION_BRANCH
      }
      l1common.checkout_l1_automation("./", l1_automation_branch)
      // "mp-jenkins-shared-lib/jenkins/jobs/scripts/configs/L1-Core/config_105.yaml"
      l1common.configure_l1_automation("./", config_path)
      // config = l1common.load_config()
  }
  sh 'pwd; ls -ltr'

}

def getLatestBuildNumber(String pipeline_name){
    // If the build_num param is null, empty, or '0', use the latest successful run of the pipeline
    // Else use the build_num as is
    def Utils = new common.Utils()
    def buildNumber = L1GlobalVars.PIPELINE_LAST_SUCCESSFUL_BUILD_NUM_DEFAULT
    def lastSuccessfulBuild = Utils.getLastSuccessfulBuildID(pipeline_name)
    if (lastSuccessfulBuild != "") {
        buildNumber = lastSuccessfulBuild
        echo "Latest Successful build number for pipeline ${pipeline_name}: ${buildNumber}"

    } else {
        echo "FAILED! Latest Successful build number for pipeline ${pipeline_name}: ${buildNumber}"
    }
    return buildNumber
}

def get_commit_id(String path){
    // path [String] : Path to repo to fetch git commit ID from
    sh """
        cd ${path}
        GIT_COMMIT_ID=\$(git rev-parse HEAD)
        echo "GIT_COMMIT_ID=\$GIT_COMMIT_ID"> env.properties
    """
    envVars = readProperties file: 'env.properties'
    return envVars.GIT_COMMIT_ID
}

def get_sha256(String path){
    // path [String] : Path to directory or file to get sha256 of
    sh """
        if [ -f ${path} ]; then
            HASH=\$(sha256sum "${path}")
        elif [ -d ${path} ]; then
            HASH=\$(tar c ${path} | sha256sum | awk '{print  \$1}')
        else
            echo "${path} is not a valid file or directory"
            HASH=0
        fi

        echo "\$HASH"
        echo "HASH=\$HASH"> env.properties
    """
    envVars = readProperties file: 'env.properties'
    return envVars.HASH
}

def get_project_version(String l1_firmware_images_root, String path){
    // l1_firmware_images_root [String] : Path to root of l1_firmware_images git repo
    // path [String] : Path to repo to get version of
    sh """
        cd ${path}
        export PROD_VERSION=`${l1_firmware_images_root}/scripts/project-version-gen`
        echo "PROD_VERSION=\$PROD_VERSION"> env.properties
    """
    envVars = readProperties file: 'env.properties'
    return envVars.PROD_VERSION
}

def create_version_json(String l1_firmware_images_root, String name, String version, String git_id, String sha256, String output_file_name) {
    sh "python3 ${l1_firmware_images_root}/scripts/version-json-gen.py --name ${name} --version ${version} --git-id ${git_id} --hash ${sha256} --output ${output_file_name}"
}

def setToLastSuccessfulBuild(String build_num_param, String pipeline_name){
    // If the build_num param is null, empty, or '0', use the latest successful run of the pipeline
    // Else use the build_num as is
    def Utils = new common.Utils()
    def buildNumber = ""
    if (build_num_param == null || build_num_param.isEmpty() || build_num_param == '0') {
        def lastSuccessfulBuild = Utils.getLastSuccessfulBuildID(pipeline_name)
        // def lastSuccessfulBuild = currentBuild.rawBuild.getPreviousSuccessfulBuild()
        if (lastSuccessfulBuild != "") {
            buildNumber = lastSuccessfulBuild
        } else {
            buildNumber = "0"
            error('No previous successful build found.')
        }
    } else {
        buildNumber = build_num_param
    }
    echo " >>> Get build: ${buildNumber} artifacts for pipeline: ${pipeline_name}"
    return buildNumber
}

def BlackDuckScan(String workspace, String stash_name, String proj_name, String proj_ver, String file_path){
    def temp_folder_name = 'blackduck'
    // Clear temp blackduck folder before each scan
    sh "rm -rf ${workspace}/${temp_folder_name} || :"
    // Use temp blackduck folder to limit the workspace being scanned by blackduck
    dir("${workspace}/${temp_folder_name}"){
        unstash stash_name
        sh 'pwd'
        sh 'ls -ltr' 
        println "Blackduck Scan"
        runBlackDuckScanning(
            project_name: proj_name,
            project_version: proj_ver,
            file_path: file_path
        )    
    }
}

def print_jenkins_console(String text){
    echo text
}

def validate_tfr_test_results( String workspace="./",
                           String test_results_tar_file = "L1-Automation/tfr_results.tar.gz",
                           String test_summary_file_name = "tfr_results/test_summary.csv", 
                           String new_summary_file_name = "tfr_results/tfr_summary.csv"){
  dir(workspace){
    sh """
      [ -f ${test_results_tar_file} ]
      tar -xf ${test_results_tar_file} ${test_summary_file_name}
      mv  ${test_summary_file_name} ${new_summary_file_name}

    """
    test_summary_file_name = new_summary_file_name
    def test_results = readCSV file: "${test_summary_file_name}"
    archiveArtifacts artifacts: "${test_results_tar_file}"
    
    test_results.drop(1).each { test_result ->
      println("Test : ${test_result[0]} | Verification Status : ${test_result[1]} | Test Run Status : ${test_result[2]} ")
      if("${test_result[2]}" != "SUCCESS"){
        error("Test failed")
      }
    }
  }
  return test_summary_file_name
}

def get_pipeline_branch() {
    if (env.CHANGE_BRANCH == null) {
        //If CHANGE_BRANCH is null, it is not a pull request
        return env.BRANCH_NAME
    }
    else {
        //If CHANGE_BRANCH is not null, it is a pull request
        return env.CHANGE_BRANCH
    }
}

return this
