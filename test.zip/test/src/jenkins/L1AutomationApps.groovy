// Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
package jenkins

import groovy.transform.Field

// File to run L1 Automation Apps
// build, run target app in app directory

@Field String CONTAINER_IMAGE_REG = 'phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker'
@Field String container_runner = """container_runtime_holder run --rm \
        --privileged \
        -v \$(pwd)/L1-Automation/suites:/suites \
        -v \$(pwd)/L1-Automation/automation:/automation \
        -v \$(pwd)/L1-Automation/keywords:/keywords \
        -v \$(pwd)/L1-Automation/scripts:/scripts \
        -v \$(pwd)/L1-Automation/config:/config \
        -v \$(pwd)/L1-Automation/variables:/variables \
        -v \$(pwd)/L1-Automation/supporting_files:/supporting_files \
        -v \$(pwd)/L1-Automation/libraries:/libraries \
        -v \$(pwd)/L1-Automation/apps:/apps \
        -v \$(pwd)/L1-Automation/data:/data \
        -v \$(pwd)/output:/output \
        l1automation""" // no new line at the end so container_runner can be joined with a targeted L1-Automation/apps in method calls

// ==============================================================
// ====================  BUILD  METHODS  ========================
// ==============================================================
/**
 * @param container_runtime values can be only of sharedVars.ContainerRuntime.RuntimeType, it is the container runtime used to build a container
 * @param workspaceStr path for workspace's root of where L1-Automation repo is located
 */
def buildRuntime(container_runtime,String workspaceStr = "./") {
    withCredentials([usernamePassword(credentialsId: 'svc_acc_npmphran', passwordVariable: 'password', usernameVariable: 'username')]) {
        sh """
            sudo ${container_runtime} login -u $username -p $password ${CONTAINER_IMAGE_REG}
            ${container_runtime} build -f ${workspaceStr}/L1-Automation/Dockerfile -t l1automation ${workspaceStr}/L1-Automation
        """
    }
    // update container_runner with new container_runtime
    container_runner = container_runner.replaceAll(/^\s*container_runtime_holder/, "${container_runtime}")
}

// ==============================================================
// ===================  RUN APPS METHODS  =======================
// ==============================================================

/*
 * runs apps/SBOMGenerator/sbom-generator.py
 */
def runSbomGenerator(String l1_automation_path, String pipeline_name,String artifactory_path,String output_path) {
    sh(script:"""
    rm -rf ${WORKSPACE}/${output_path}
    mkdir -p ${WORKSPACE}/${output_path}
    """)
    dir("${l1_automation_path}") {
        sh(script:"""
        ls -halt; pwd; uname -n;
        python3 -m venv ${WORKSPACE}/venv
        . ${WORKSPACE}/venv/bin/activate
        python3 -m pip install --upgrade pip
        python3 -m pip install -r requirements.txt
        python3 apps/SBOMGenerator/sbom-generator.py \
            --pipeline ${pipeline_name} \
            --build-id ${BUILD_ID} \
            --workspace ${WORKSPACE} \
            --output-path ${WORKSPACE}/${output_path} \
            --artifactory ${artifactory_path} \
            --build-url ${BUILD_URL}
        python3 apps/SBOMGenerator/generate_html_sbom.py -p ${WORKSPACE}/${output_path}
        """)
    }
}

/**
 * Containerized apps/BlackDuckHelper/SpdxPackageComparer.py
 * @param blackduckSpdxSbomFilePath Blackduck Spdx Sbom File Path. Path must start with output/
 */
def runBlackDuckHelper_SpdxPackageComparer(String blackduckSpdxSbomFilePath) {
    println("Blackduck Spdx Sbom File Path: ${blackduckSpdxSbomFilePath}")
    String script_runner = """${container_runner} sh -c 'python3 /apps/BlackDuckHelper/SpdxPackageComparer.py \
        --buildroot /apps/BlackDuckHelper/SrcSboms/buildroot.spdx.json \
        --black_duck /${blackduckSpdxSbomFilePath} \
        --selectorFile /apps/BlackDuckHelper/Package_Selector.csv && \
        python3 /apps/BlackDuckHelper/SBOMParser.py --license_category /apps/BlackDuckHelper/dell-license-category.json \
        --json_path /src/mutated_sbom.spdx.json \
        -o oss_manifest.xlsx && \
        cp -r /src/* /output'
    """
    println "script_runner: ${script_runner}"
    sh(script: script_runner)
}

return this