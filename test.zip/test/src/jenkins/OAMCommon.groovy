// Copyright © 2023-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

package jenkins

def CleanWs() {
    cleanWs(cleanWhenNotBuilt: true,
            deleteDirs: true,
            disableDeferredWipeout: true,
            notFailBuild: true)
}

/**
 * This function trigger OAM Component Test.
 * @param ctopts. Default is an empty list
 */
def OamComponentTest( String... ctopts) {
    sh """
        pwd
        ./oam-dev-tools/devenv/scripts/pipeline.sh component-test --init -n ${JOB_NAME.replaceAll("[ -/]","_")}_component_test_${BUILD_ID} --oam-sim-src oam-node-simulator --test-src gNB_OAM_TEST
        ./oam-dev-tools/devenv/scripts/pipeline.sh component-test --component-test ${ctopts?.join(' ')} || true
        pwd
    """
}

def OamCheckoutSrc(
      String oam_dev_tools_BRANCH='main',
      String PR_REPO='gNB_OAM',
      String PR_BRANCH='main',
      String PR_TARGET='main',
      String gNB_node_controller_BRANCH='main',
      String gNB_ngp_BRANCH='main',
      String gNB_OAM_BRANCH='main',
      String yang_model_BRANCH='main',
      String gNB_DU_BRANCH='main',
      String gNB_OAM_TEST_BRANCH='main',
      String oam_node_simulator_BRANCH='main',
      String gNB_API_BRANCH='main',
      String gNB_CU_BRANCH='main'
    ) {
    //Checkout the appropriate branches for the oam-node-simulator submodules
    sh label: "Checkout repos...", script: """
        git clone -b main git@eos2git.cec.lab.emc.com:Mobile-Phoenix/oam-dev-tools.git oam-dev-tools_checkout
        ./oam-dev-tools_checkout/devenv/scripts/pipeline.sh checkout --pr-repo "${PR_REPO}" \
          --pr-branch "${PR_BRANCH}" \
          --pr-target "${PR_TARGET}" \
          --br-oam-dev-tools "${oam_dev_tools_BRANCH}" oam-dev-tools

        ./oam-dev-tools/devenv/scripts/pipeline.sh checkout --pr-repo "${PR_REPO}" \
          --pr-branch "${PR_BRANCH}" \
          --pr-target "${PR_TARGET}" \
          --br-gNB_node_controller "${gNB_node_controller_BRANCH}" \
          --br-gNB_ngp "${gNB_ngp_BRANCH}" \
          --br-gNB_OAM "${gNB_OAM_BRANCH}" \
          --br-yang_model "${yang_model_BRANCH}" \
          --br-gNB_DU "${gNB_DU_BRANCH}" \
          --br-gNB_OAM_TEST "${gNB_OAM_TEST_BRANCH}" \
          --br-oam-node-simulator "${oam_node_simulator_BRANCH}" \
          --br-gNB_API "${gNB_API_BRANCH}" \
          --br-gNB_CU "${gNB_CU_BRANCH}" \
          oam-node-simulator gNB_OAM_TEST
      """
}

/**
 * This function create container image, which can be used to deploy setup for simulator test or configuration mapping test
 * @param TEST_TYPE Default is 'sim-test', another possible value is 'cfgtest'
*/
def OamBuilderImg(String TEST_TYPE="sim-test") {
  // Clean up.  There may be stray images from previous aborted jenkins jobs.
  sh "${CNT_BUILDER} image prune --force"
  sh "${CNT_BUILDER} network prune --force"
  sh "${CNT_BUILDER} image rm robot --force || true"
  // Create OAM Test Bed for simulator
  sh "./oam-dev-tools/devenv/scripts/pipeline.sh ${TEST_TYPE} --init -n ${JOB_NAME.replaceAll("[ -/]","_")}_${TEST_TYPE.replaceAll("[ -/]","_")}_${BUILD_ID} --oam-sim-src oam-node-simulator --test-src gNB_OAM_TEST"
  // Login builder registry
  sh "./oam-dev-tools/devenv/scripts/registry-login.sh -u ${DOCKER_CREDS_USR} -p ${DOCKER_CREDS_PSW} -r ${REGISTRY}"
  //Build gnb-oam-builder image
  sh "./oam-dev-tools/devenv/scripts/pipeline.sh ${TEST_TYPE} --builder-image"
}

def OamCucpComponentTest() {

            parallel([
            "CUCP Others${OAM_MODE_TITLES} Component Tests": {
              if (run_expedited_tests == 'true') {
                sh "./oam-dev-tools/devenv/scripts/pipeline.sh sim-test --nightly-test --type CUCP_OTHERS --expedited --oam-mode ${oam_mode}"
              }
              else{
                sh "./oam-dev-tools/devenv/scripts/pipeline.sh sim-test --nightly-test --type CUCP_OTHERS --oam-mode ${oam_mode}"
              }
            },
          ]) // end of parallel

}
def OamCuupComponentTest() {

 parallel([
                  "CUUP Others${OAM_MODE_TITLES} Component Tests": {
                    if (run_expedited_tests == 'true') {
                      sh "./oam-dev-tools/devenv/scripts/pipeline.sh sim-test --nightly-test --type CUUP_OTHERS --expedited --oam-mode ${oam_mode}"
                    }
                    else{
                      sh "./oam-dev-tools/devenv/scripts/pipeline.sh sim-test --nightly-test --type CUUP_OTHERS --oam-mode ${oam_mode}"
                    }
                  },
                ]) // end of parallel

}

def getSubmoduleHash(String gitDir="oam-node-simulator") {
  def hashMap =[:]
  def output = ""
  try {
    output = sh(returnStdout: true,
                script:"""
                  cd ${gitDir} &&
                  git submodule foreach --quiet 'echo \${name}' | xargs -I{} bash -c 'cd {}; echo {}:\$(git rev-parse --short HEAD)'
                """
              ).trim()
  }
  catch (Exception error) {
    println "Failed to collect submodule commit hashes"
  }
  hashMap = output.split('\n').collectEntries { line -> line.split(':') as List }
  return hashMap
}

/**
 * This function leverages incredibuild to build OAM artifacts ($WORKSPACE/oam-node-simulator/target) which can be used for simulator test
 * @param SHARED_LIB_BRANCH The mp-jenkins-shared-lib branch for build script build_oam_ib.sh
 * @param PLATFORM_BRANCH The gNB_platform branch for buildah_oam.dockerfile which is used to build OAM simulator artifacts
 * @param BRANCH The cross-dependency branches to be checked out to build OAM simulator artifacts
 * @param OAM_NODE_SIMULATOR_BRANCH The explicit oam-node-simulator branch to be checked out to build OAM simulator artifacts
 * @param API_BRANCH The explicit gNB_API submodule branche to be checked out to build OAM simulator artifacts
 * @param DU_BRANCH The explicit gNB_DU submodule branche to be checked out to build OAM simulator artifacts
 * @param CU_BRANCH The explicit gNB_CU submodule branche to be checked out to build OAM simulator artifacts
 * @param NGP_BRANCH The explicit gNB_ngp submodule branche to be checked out to build OAM simulator artifacts
 * @param OAM_BRANCH The explicit gNB_OAM submodule branche to be checked out to build OAM simulator artifacts
 * @param YANG_MODEL_BRANCH The explicit yang_model submodule branche to be checked out to build OAM simulator artifacts
 * @param NODE_CONTROLLER_BRANCH The explicit gNB_node_controller submodule branche to be checked out to build OAM simulator artifacts
 * @param TMP_IMAGE_TAG The temporary container image tag of builder image
 */
def OamSimBuild(
  String SHARED_LIB_BRANCH='',
  String PLATFORM_BRANCH='',
  String OAM_NODE_SIMULATOR_BRANCH='',
  String BRANCH='',
  String API_BRANCH='',
  String DU_BRANCH='',
  String CU_BRANCH='',
  String NGP_BRANCH='',
  String OAM_BRANCH='',
  String YANG_MODEL_BRANCH='',
  String NODE_CONTROLLER_BRANCH='',
  String TMP_IMAGE_TAG=''
) {
  def GenericVars = new sharedVars.GenericVars()
  def Podman = new common.Podman()
  def GBI_IMAGE = GenericVars.GBI_PODMAN_IMAGE
  def SCRIPT_PATH = 'jenkins/jobs/scripts/shell'
  // Pull gbi image
  timeout(20) {
    waitUntil(initialRecurrencePeriod: 15000) {
      try {
        script {
          Podman.loginArtifactoryDockerRegistry()
        }
        sh "podman pull $GBI_IMAGE"
        return true
      }
      catch (exception) {
        return false
      }
    }
  } //end of timeout
  // Implictly assign cross-dependancy BRANCH to PLATFORM_BRANCH and/or SHARE_LIB_BRANCH if not explicitly defined. Fail over to 'main'
  PLATFORM_BRANCH = "${PLATFORM_BRANCH ?: BRANCH ?: 'main'}"
  SHARED_LIB_BRANCH = "${SHARED_LIB_BRANCH ?: BRANCH ?: 'main'}"
  // Assign 'main' to PLATFORM_BRANCH and/or SHARED_LIB_BRANCH if the none of branch names exists
  PLATFORM_BRANCH   = sh(script: "git ls-remote --heads git@eos2git.cec.lab.emc.com:Mobile-Phoenix/gNB_Platform.git ${PLATFORM_BRANCH} | grep ${PLATFORM_BRANCH} > /dev/null && echo ${PLATFORM_BRANCH} || echo main",
                        returnStdout:true).trim()
  SHARED_LIB_BRANCH = sh(script: "git ls-remote --heads git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git ${SHARED_LIB_BRANCH} | grep ${SHARED_LIB_BRANCH} > /dev/null && echo ${SHARED_LIB_BRANCH} || echo main",
                        returnStdout:true).trim()
  println 'Cloning gNB_platform and mp-jenkins-shared-lib repos...'
  sh "git clone --branch $PLATFORM_BRANCH --single-branch https://$GIT_ACCOUNT@eos2git.cec.lab.emc.com/Mobile-Phoenix/gNB_platform.git"
  sh "git clone --branch $SHARED_LIB_BRANCH --single-branch git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git build_scripts"
  println "Building OAM..."
  sh """
    cd $WORKSPACE/build_scripts/$SCRIPT_PATH && \
    sh build_oam_ib.sh -w ${WORKSPACE} \
      ${OAM_NODE_SIMULATOR_BRANCH ? "-s $OAM_NODE_SIMULATOR_BRANCH" : ""} \
      ${BRANCH ? "-b $BRANCH" : ""} \
      ${API_BRANCH ? "-i $API_BRANCH" : ""} \
      ${DU_BRANCH ? "-d $DU_BRANCH" : ""} \
      ${CU_BRANCH ? "-c $CU_BRANCH" : ""} \
      ${NGP_BRANCH ? "-n $NGP_BRANCH" : ""} \
      ${OAM_BRANCH ? "-o $OAM_BRANCH" : ""} \
      ${YANG_MODEL_BRANCH ? "-y $YANG_MODEL_BRANCH" : ""} \
      ${NODE_CONTROLLER_BRANCH ? "-N $NODE_CONTROLLER_BRANCH" : ""} \
      -t ${TMP_IMAGE_TAG}
  """
  println "Cleaning up builder image and container"
  cleanUpImage([image: "oam_env:${TMP_IMAGE_TAG}"], 'podman')
  cleanUpImage([container: "oam_dev_img_${TMP_IMAGE_TAG}"], 'podman')
}
