// Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

package jenkins

/**
* Returns test_execution_parent_id for qTest of L1-IVT-E2E test-cycle results directory
*/
def test_execution_parent_id(String testline) {
    result = null
    switch(testline) {
        case 'L1TL1':
            result = 768251
            break
        case 'L1TL3':
            result = 768252
            break
        default:
            return result
    }
    return result
}

/**
* Set of common libraries using across Test Lines
*/

/**
 * Gets latest green build of minerva-firmware, then installs onto @targetIp
 *
 * @param username the ssh username for the @targetIp 
 * @param password the ssh password for the @targetIp 
 * @param targetIp the IP address of the machine to ssh into
 */
def deployL1Firmware(username, password, targetIp) {
    sh 'pwd'
    def Utils = new common.Utils()
    Utils.downloadArtifactAQL([
                "items.find": [
                    "@build.name": [
                        "\$eq":"R2-DellRanMultiArch-main_dell_ran"
                    ],
                    "@build.parentName": [
                        "\$eq": "L1_App_DPDK :: main"
                    ],
                    "@build.parentNumber": [
                        "\$eq":"${Utils.getLastSuccessfulBuildID('L1_App_DPDK/main')}"
                    ]
                ]
            ],
            './')
    sh 'ls -ltr'
    retry(3) {
        timeout(time: 20, unit: 'MINUTES') {
            try {
                sh """
                    l1firmware=\$(ls | grep 'minerva-firmware')
                    echo \$l1firmware
                    sshpass -p ${password} ssh ${username}@${targetIp} sudo rpm -e --nodeps minerva-firmware
                    sshpass -p ${password} scp ./\$l1firmware ${username}@${targetIp}:./
                    sshpass -p ${password} ssh ${username}@${targetIp} sudo rpm -i ./\$l1firmware
                    sshpass -p ${password} ssh ${username}@${targetIp} sudo rm ./\$l1firmware
                    echo '"Installed: '\$l1firmware'"'
                """
            } catch (err) {
                sleep(time: 2, unit: "MINUTES")
                error("Error occurred during Deploy L1 Firmware! ${err}")
            }
        }
    }
    sh "sshpass -p ${password} ssh ${username}@${targetIp} sudo reboot >/dev/null &"
}

def set_interface_down(username, password, network_interface, targetIp) {
    sh 'pwd'
    retry(3) {
        timeout(time: 10, unit: 'MINUTES') {
            try {
                sh """
                    sleep 200
                    sshpass -p ${password} ssh ${username}@${targetIp} sudo ip link set ${network_interface} down
                    sshpass -p ${password} ssh ${username}@${targetIp} ip -br addr
                """
            } catch (err) {
                sleep(time: 2, unit: "MINUTES")
                error("Error occurred during setting interface ${network_interface} down! ${err}")
            }
        }
    }
}

def systemctl_stop_and_disable_firewalld(username, password, cu_targetIp) {
    sh 'pwd'
    retry(3) {
        timeout(time: 10, unit: 'MINUTES') {
            try {
                sh """
                    sleep 200
                    sshpass -p ${password} ssh ${username}@${cu_targetIp} sudo systemctl stop firewalld.service
                    sshpass -p ${password} ssh ${username}@${cu_targetIp} sudo systemctl disable firewalld.service
                    sshpass -p ${password} ssh ${username}@${cu_targetIp} ip -br addr
                """
            } catch (err) {
                sleep(time: 2, unit: "MINUTES")
                error("Error occurred during systemctl ${err}")
            }
        }
    }
}

def set_ens1f1_and_ens1f0_down(username, password, cu_targetIp) {
    sh 'pwd'
    retry(3) {
        timeout(time: 10, unit: 'MINUTES') {
            try {
                sh """
                    sleep 200
                    sshpass -p ${password} ssh ${username}@${cu_targetIp} sudo ip link set ens1f1 down
                    sshpass -p ${password} ssh ${username}@${cu_targetIp} sudo ip link set ens1f0 down
                    sshpass -p ${password} ssh ${username}@${cu_targetIp} sudo systemctl stop firewalld.service
                    sshpass -p ${password} ssh ${username}@${cu_targetIp} sudo systemctl disable firewalld.service
                    sshpass -p ${password} ssh ${username}@${cu_targetIp} ip -br addr
                """
            } catch (err) {
                sleep(time: 2, unit: "MINUTES")
                error("Error occurred during setting interface ens1f1 and ens1f0 down! ${err}")
            }
        }
    }
}

def submitQtestTestDesign() {
    withCredentials([string(credentialsId: 'L1_qtest_reports', variable: 'API_TOKEN')]) {
        env.QTEST_API_KEY = API_TOKEN
    }
    sh """
        cd $WORKSPACE/L1-Automation
        podman build -t l1automation -f Dockerfile .
        cd $WORKSPACE

        podman run --rm --privileged \
            -v \$(pwd)/L1-Automation/suites:/suites \
            -v \$(pwd)/L1-Automation/automation:/automation \
            -v \$(pwd)/L1-Automation/keywords:/keywords \
            -v \$(pwd)/L1-Automation/scripts:/scripts \
            -v \$(pwd)/L1-Automation/config:/config \
            -v \$(pwd)/L1-Automation/variables:/variables \
            -v \$(pwd)/L1-Automation/supporting_files:/supporting_files \
            -v \$(pwd)/L1-Automation/libraries:/libraries \
            -v \$(pwd)/L1-Automation/apps:/apps \
            -v \$(pwd)/L1-Automation/data:/data \
            -v \$(pwd)/product_test_5g:/product_test_5g \
            l1automation \
            python3 /apps/UnitTestXmlUpdater/update_xml.py -f /product_test_5g/xunitreport.xml --add_to_testsuites -n L1-IVT-E2E -c $TL_NUMBER

        podman run --rm --privileged \
            -v \$(pwd)/L1-Automation/suites:/suites \
            -v \$(pwd)/L1-Automation/automation:/automation \
            -v \$(pwd)/L1-Automation/keywords:/keywords \
            -v \$(pwd)/L1-Automation/scripts:/scripts \
            -v \$(pwd)/L1-Automation/config:/config \
            -v \$(pwd)/L1-Automation/variables:/variables \
            -v \$(pwd)/L1-Automation/supporting_files:/supporting_files \
            -v \$(pwd)/L1-Automation/libraries:/libraries \
            -v \$(pwd)/L1-Automation/apps:/apps \
            -v \$(pwd)/L1-Automation/data:/data \
            -v \$(pwd)/product_test_5g:/product_test_5g \
            l1automation \
            python3 /apps/QtestTestDesign/TestDesign.py \
                --jenkins_qtest_process \
                -f /product_test_5g/xunitreport.xml \
                -u ${env.QTEST_API_KEY} \
                -t /config/tools_mapping.yaml
    """
}

return this
