// Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.
package component
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.time.TimeCategory
import java.text.SimpleDateFormat;
import java.time.*
import java.util.concurrent.TimeUnit

def getPullRequests(apiUrl) {
  def nonDraftPullRequests = getnonDraft(apiUrl)
  def pullRequests = getbranches(nonDraftPullRequests)
  return pullRequests
}

def getnonDraftId(apiUrl) {
        withCredentials([string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
                response = sh(returnStdout: true,
							script:""" curl -ks -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" ${apiUrl}/pulls?sort=updated\\&direction=desc\\&per_page=100\\&state=open """)
				def json = new JsonSlurper().parseText(response)
				def subset = json.findAll { it.draft == false && isWithinOneDayOfNow(it.updated_at) && it.labels.toString().contains("testable") }
				println("all prs ready to be run: ${subset.number}")
				return subset.number
        }
}

def getnonDraft(apiUrl) {
        withCredentials([string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
                response = sh(returnStdout: true,
							script:""" curl -ks -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" ${apiUrl}/pulls?sort=updated\\&direction=desc\\&per_page=100\\&state=open """)
				def json = new JsonSlurper().parseText(response)
				def subset = json.findAll { it.draft == false && isWithinOneDayOfNow(it.updated_at) && it.labels.toString().contains("testable") }
				println("all prs ready to be run: ${subset.number}")
				return subset.url
        }
}

def getbranches(paths) {
	def branches = []
    for (path in paths) {
        withCredentials([string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
            response = sh(returnStdout: true,
							script:""" curl -ks -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" ${path}""")
			def json = new JsonSlurper().parseText(response)
			branches.add(json.head.ref)
        }
    }
	return branches
}

@NonCPS
String calculateTimeDifference(String dateStr) {
    def date2 = new Date()
	String pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'";
	SimpleDateFormat formatter = new SimpleDateFormat(pattern);
	Date date1 = formatter.parse(dateStr);
    use(TimeCategory) {
        def diff = date2 - date1
		println "Difference is ${diff.days} days"
		return diff.days
	}
}


def isWithinOneDayOfNow(String isoDate) {
    def givenDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss'Z'", isoDate)
    def now = Instant.now().toEpochMilli()
    def diff = now - givenDate.time
    return diff <= TimeUnit.DAYS.toMillis(1)
}