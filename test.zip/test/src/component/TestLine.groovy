// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package component

/**
* Set of common libraries using across Test Lines
*/

// Check SSH connection and copy ssh key to target
def initSshToRemoteVM(username, password, targetIp) {
    retry(3) {
        timeout(time: 5, unit: 'MINUTES') {
            try {
                sh """
                    set +x
                    # Checking SSH connection before copying public key
                    set +e
                    status=\$(ssh -q -o BatchMode=yes -o ConnectTimeout=60 -o StrictHostKeyChecking=no -i /home/jenkins/.ssh/id_ed25519 ${username}@${targetIp} echo OK 2>&1)
                    set -e
                    if [[ "\$status" == "OK" ]]; then
                        echo "SSH OK!"
                    else
                        sshpass -p ${password} ssh-copy-id -o ConnectTimeout=60 -o StrictHostKeyChecking=no -i /home/jenkins/.ssh/id_ed25519.pub ${username}@${targetIp}
                    fi
                """
                // setup netconf rsa
                withCredentials([file(credentialsId: 'MP_NETCONF_RSA_KEY', variable: 'private_key'),
                                 file(credentialsId: 'MP_NETCONF_RSA_PUBKEY', variable: 'public_key')]) {
                    writeFile file: 'netconf.rsa', text: readFile(private_key)
                    writeFile file: 'netconf.rsa.pub', text: readFile(public_key)

                    sh """
                        scp -o StrictHostKeyChecking=no -i /home/jenkins/.ssh/id_ed25519 netconf.rsa ${username}@${targetIp}:~/netconf.rsa
                        scp -o StrictHostKeyChecking=no -i /home/jenkins/.ssh/id_ed25519 netconf.rsa.pub ${username}@${targetIp}:~/netconf.rsa.pub
                        ssh -o StrictHostKeyChecking=no -i /home/jenkins/.ssh/id_ed25519 ${username}@${targetIp} "sudo mkdir -p /data/E2E/netconf/ && sudo mv ~/netconf.rsa ~/netconf.rsa.pub /data/E2E/netconf/"
                    """
                }
            } catch (err) {
                sleep(time: 2, unit: "MINUTES")
                error("Error occurred during SSH initialization!")
            }
        }
    }
}

// returns all directories containing test suite (robot) files in product_test_5g_root_suite_dir
String getRobotSuites(product_test_5g_root_suite_dir) {
    String suiteDirectories = sh(
        returnStdout: true,
        script: "cd product_test_5g; for dirpath in \$(find ${product_test_5g_root_suite_dir} -name '*.robot' -exec dirname {} \\; | sort -u); do echo -n \$dirpath'/*.robot '; done"
    ).trim()
    return suiteDirectories
}

def getTargetListFromInventoryFile(test_line) {
    targetlist = ""
    def tl_inventory = readYaml file: "gNB_deployer/inventory/${test_line}.yml"
    println("Getting target host ip for: " + test_line)
    def components_list =  tl_inventory.all.hosts
    components_list.each{key, value ->
        println "Host name: " + key
        println "IP: " + value.ansible_host
        targetlist += value.ansible_host + " "
    }
    return targetlist
}

def getE2ETargetListFromInventoryFile(test_line, repo) {
    targetlist = ""
    def tl_inventory = readYaml file: "gNB_deployer/inventory/${test_line}.yml"
    println('Getting target host ip for: ' + test_line)
    // Modify values based on deploy_greenload parameter
    if (repo == 'mobile-phoenix-rpm-candidate-rr') {
        tl_inventory.all.vars.GNB_RPM_REPOSITORY = 'mobile-phoenix-rpm-candidate-rr'
        tl_inventory.all.vars.GPG_CHECK_VALUE = false
    } else {
        tl_inventory.all.vars.GNB_RPM_REPOSITORY = 'mobile-phoenix-rpm-greenload-rr'
        tl_inventory.all.vars.GPG_CHECK_VALUE = true
    }
// Update the targetlist based on the modified inventory
    def components_list = tl_inventory.all.hosts
    components_list.each { key, value ->
        println 'Host name: ' + key
        println 'IP: ' + value.ansible_host
        targetlist += value.ansible_host + " "
    }
    return targetlist
}

// Set logsPath directory to be owned by username and permissions to 777
def setRateLogPathPermissions(username, password, targetIp, logsPath) {
    retry(3) {
        timeout(time: 5, unit: 'MINUTES') {
            try {
                sh """
                    sshpass -p ${password} ssh ${username}@${targetIp} sudo mkdir -p ${logsPath}
                    sshpass -p ${password} ssh ${username}@${targetIp} sudo chown -R ${username}:${username} ${logsPath}
                    sshpass -p ${password} ssh ${username}@${targetIp} sudo chmod 777 ${logsPath}
                """
            } catch (err) {
                sleep(time: 2, unit: "MINUTES")
                error("Error occurred during setting RATE LogPath Permissions!")
            }
        }
    }
}

// Use text2pcap for fapi logs. https://www.wireshark.org/docs/man-pages/text2pcap.html
def duFapiText2pcap(product_test_5g_logs_dir) {
    sh """
        for fapiFile in \$(find ${product_test_5g_logs_dir} -name 'du_fapi*.txt.tar.gz')
        do
            fapiFileTxt=\$(echo \$fapiFile | sed s/\\.txt\\.tar\\.gz/\\.txt/)
            outputFileName=\$(echo \$fapiFile | sed s/\\.txt\\.tar\\.gz/\\.pcap/)
            extractDir=\$(tar -xzvf \$fapiFile)
            mv \$extractDir \$fapiFileTxt
            text2pcap -u 100,100 -t '%d/%m/%Y %H:%M:%S.' \$fapiFileTxt \$outputFileName
            rm -f \$fapiFileTxt
        done
    """
}

/**
* Checkout tooling source for TLs. Eg: gNB_deployer, TL-Config, product_test_5g, gNB_platform
* @return
*/
def checkoutCodeForTl(git_account, repo_name, repo_reference) {
    script {
        sh """
            git clone https://${git_account}@eos2git.cec.lab.emc.com/Mobile-Phoenix/${repo_name}.git ${repo_name}
            cd ${repo_name}
            git checkout ${repo_reference}; cd ..
        """
    }
}

def getAgentLabelforRunRate(tlName='') {
    label = 'e2e-test'
    //List TL servers at the same location and subnet 10.237.168.xxx --> 10.237.171.xxx or 10.237.92.xxx --> 10.237.95.xxx
    // inn -> agents in innovation [inn_rate_agents]. rr -> agents in round rock [rr_rate_agents]
    // If the lab is in innovation both deploy and RUN-RATE-TEST stages should use agents from innovation. Similarly for other location TL's
    def run_rate_label_group_1 = ['TL8', 'TL10', 'TL25', 'TL26', 'TL27', 'TL28', 'TL29', 'TL42', 'TL43', 'TL44', 'TL51', 'TL52', 'TL54', 'TL55', 'TL56', 'TL57', 'TL58', 'TL59', 'PMTL1', 'PMTL2', 'PMTL3', 'PMTL4', 'PMTL5', 'PMTL6', 'SSTL1', 'SSTL2', 'SSTL3',  'SSTL4', 'SSTL5']
    if(run_rate_label_group_1.contains(tlName))
    {
        label = 'inn_rate_agents'
    }
    return label
}

/**
* Checkout tooling source for AIO update config. Eg: gNB_deployer, TL-Config, product_test_5g, gNB_platform
* @return
*/
def checkoutCodeForAIOUpdateConfig(git_account, repo_name, repo_reference) {
    script {
        sh """
            git clone https://${git_account}@eos2git.cec.lab.emc.com/Mobile-Phoenix/${repo_name}.git ${repo_name}
        """
        sh """
            cd ${repo_name}
            TAG_EXISTS=\$(git tag --list ${repo_reference} | tail -n 1)
            if [ -z "\${TAG_EXISTS}" ]; then
                echo "Could not find ${repo_reference} => using latest config"
            else
                echo "Tag ${repo_reference} exists! Checkout branch ${repo_reference}"
                git checkout ${repo_reference}; cd ..
            fi

        """
    }
}

def loadTLConfig(def tlName) {
    println "Loading configuration for: ${tlName}"

    // Parse TL info configuration
    def testlineInfoDefault = readYaml text: libraryResource("..//resources//testlines//${tlName}.yml")
    pipelineConfig = testlineInfoDefault["pipeline_config"] ?: [:]

    println "pipelineConfig:"
    println pipelineConfig

    return pipelineConfig
}


return this
