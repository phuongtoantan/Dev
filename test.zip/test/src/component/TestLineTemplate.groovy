// Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.
package component
import groovy.text.StreamingTemplateEngine

@NonCPS
def renderTemplate(templateFile, binding) {
    def template = new StreamingTemplateEngine().createTemplate(templateFile)
    String result = template.make(binding)
    engine = null
    template = null
    return result.toString()
}
