// Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.
package component
import java.net.InetAddress
import groovy.transform.TimedInterrupt
import java.util.concurrent.TimeUnit

@NonCPS
def checkRemoteServer(String host, String username, String password) {
        def command = "ssh ${username}@${host} ls -la"
        def process = command.execute()
        process.waitFor(60, TimeUnit.SECONDS)
        if (process.exitValue() == 0) {
            println("Remote server ${host} is already accessible.")
            return true;
        } else {
            println("Error rebooting remote server ${host}.")
            currentBuild.result = 'ABORTED'
        }

}

def removeDanglingImages(String host, String username, String password) {
    def command = "sudo podman images --filter \"dangling=true\" -q"
    def sshCommand = "ssh ${username}@${host} ${command}"
    def process = sshCommand.execute()
    process.waitFor(60, TimeUnit.SECONDS)
    if (process.exitValue() == 0) {
        def output = process.text.trim()
        println output
        if (output.isEmpty()) {
            println("No dangling images found.")
        } else {
            sshCommand = "sshpass -p ${password} ssh ${username}@${host} sudo podman rmi $output"
			println sshCommand
            process = sshCommand.execute()
            process.waitFor()
            if (process.exitValue() == 0) {
                println("Dangling images removed successfully.")
            } else {
                println("Error removing dangling images.")
            }
        }
    } else {
        println("Error ssh lost to server $host")
    }
}