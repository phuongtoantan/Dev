package common

def createVersion(version_number, application, build_number, build_date, application_sha, ngp_sha, oam_sha, dpdk_enable, sw_crypto_enable, drb_enable){
    template = """
/******************************************************************************
 *
 *   Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.
 *
 *   This software contains the intellectual property of Dell Inc.
 *   or is licensed to Dell Inc. from third parties.
 *   Use of this software and the intellectual property contained therein
 *   is expressly limited to the terms and conditions of the License Agreement
 *   under which it is provided by or on behalf of Dell Inc. or its
 *subsidiaries.
 *
 ******************************************************************************/

/*!************************************************************************************
    \\file        SoftwareVersionData.h
    \\brief       This header file contains initilization needed for
 mVersionItems in SofwareVersion class This data should be filled by DevOps
 ****************************************************************************************/
#ifndef VERSION_SOFTWAREVERSIONDATA_H
#define VERSION_SOFTWAREVERSIONDATA_H

char _mVersionItemsData[] __attribute__((section("version-info"))){
    "{ \\"version_number\\": \\"${version_number}\\",\\"application\\": \\"${application}\\","
    "\\"build_number\\": \\"${build_number}\\","
    "\\"build_date\\": \\"${build_date}\\","
    "\\"application_sha\\": \\"${application_sha}\\",\\"ngp_sha\\":"
    " \\"${ngp_sha}\\","
    "\\"oam_sha\\": \\"${oam_sha}\\",\\"dpdk_enable\\":"
    " \\"${dpdk_enable}\\",\\"sw_crypto_enable\\": \\"${sw_crypto_enable}\\",\\"drb_enable\\": \\"${drb_enable}\\"}"};

#endif // VERSION_SOFTWAREVERSIONDATA_H
    """

    return template
}