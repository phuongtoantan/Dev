// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

package common

def customSubmitJUnitTestResultsToqTest(Map qtestPluginConfig=[:], int retryCount=5, int sleepTimeInMinutes=2) {
    def i = 0
    retry(retryCount) {
        try {
            i++
            submitJUnitTestResultsToqTest(qtestPluginConfig)
        } catch (err) {
            if (i < retryCount) {
                sleep(time: sleepTimeInMinutes, unit: "MINUTES")
            }
            error("Could not upload result to qTest: " + err)
        }
    }
}


/**
 * This function reformats a XML file and uploads the result to qTest with retry and error handling.
 * The 'Automation Content' of qTest test case is the test case name only.
 *
 * @param qtestPluginConfig Configuration for qTest plugin. Default is an empty map.
 * @param xUnitReportPath Path to the xUnit XML report.
 * @param retryCount Number of retry attempts. Default is 5.
 * @param sleepTimeInMinutes Time to sleep between retries (in minutes). Default is 2.
 * @param processxUnit re-format unit report.
 * @throws Exception If any errors occur during XML reformatting or qTest upload.
 */

def submitTestResults(
    Map qtestPluginConfig = [:], 
    String xUnitReportPath = "",  
    boolean createTestCycleId = true, 
    int retryCount = 5, 
    int sleepTimeInMinutes = 2, 
    boolean processxUnit = true
) {
       script {
        if (processxUnit && xUnitReportPath == "") {
            throw new IllegalArgumentException("xUnitReportPath cannot be empty")
        }

        def retryAttempt = 0

        withCredentials([string(credentialsId: 'svc_prdmphoenix_qtest_api_sdk', variable: 'SDK_API_TOKEN')]) {
            env.QTEST_SDK_API_KEY = SDK_API_TOKEN
        }

        if (createTestCycleId) {
            def now = new Date()
            def DATE_STR = now.format("YYYY-MM-dd")
            createQTestTestCycle("${DATE_STR} build-${env.BUILD_ID}", env.QTEST_SDK_API_KEY, qtestPluginConfig.containerID, true)
            cycle_id = readFile('cycle_id_file').trim()
            qtestPluginConfig.containerID = cycle_id
        }
        
        // Customize the qTest upload config
        adjustQTestConfig(qtestPluginConfig)

        // // Reformat the XML result - temporally disabled so it can be enabled in a cordinated way across teams [MP-70137]
        // def xUnitReportPathReformat = xUnitReportPath.replace(".xml", "_reformat.xml")
        // println("Reformatted xUnit report path: ${xUnitReportPathReformat}")
        // reformatXUnitReport(xUnitReportPath, xUnitReportPathReformat)

        // // Parse the re-formatted xUnit report
        // xunit([JUnit(deleteOutputFiles: false,
        //              excludesPattern: '',
        //              pattern: xUnitReportPathReformat,
        //              stopProcessingIfError: true)])
        if (processxUnit) {
            xunit([JUnit(deleteOutputFiles: false,
                     excludesPattern: '',
                     pattern: xUnitReportPath,
                     stopProcessingIfError: true)])
        }
        // Apply retry approach for best effort
        retry(retryCount) {
            try {
                retryAttempt++
                // Calling official qTest plugin action to upload to qTest
                submitJUnitTestResultsToqTest(qtestPluginConfig)
            } catch (error) {
                if (retryAttempt < retryCount) {
                    sleep(time: sleepTimeInMinutes, unit: "MINUTES")
                }
                error("Failed to upload result to qTest: ${error}")
            }
        }
    }
}

/**
 * Adjusts the qTest plugin configuration for integration with automated testing.
 *
 * @param qtestPluginConfig The original qTest plugin configuration to be adjusted.
 */
def adjustQTestConfig(qtestPluginConfig) {
    println "Original qtestPluginConfig: ${qtestPluginConfig}"

    // Override the upload option to upload 'Automation Content' only
    // This will work with the reformatted XML result, where test case element has 'classname=Test case name' and 'name=""'
    // Documentation: https://confluence.cec.lab.emc.com/display/MP/Integration+with+QTest
    println "Overriding the upload option..."
    qtestPluginConfig.createTestCaseForEachJUnitTestClass = false
    qtestPluginConfig.createTestCaseForEachJUnitTestMethod = true

    withCredentials([string(credentialsId: 'svc_prdmphoenix_qtest_api', variable: 'API_TOKEN')]) {
        env.QTEST_API_KEY = API_TOKEN
    }

    // Default configuration values for qTest plugin
    def QTEST_PLUGIN_DEFAULT_CONFIG = [
        apiKey: env.QTEST_API_KEY,
        qtestURL: 'https://qtest.gtie.dell.com/',
        projectID: 138,
        containerType: 'test-cycle',
        overwriteExistingTestSteps: false,
        parseTestResultsFromTestingTools: false,
        submitToExistingContainer: true,
        submitToAReleaseAsSettingFromQtest: false,
        utilizeTestResultsFromCITool: true,
        createNewTestRunsEveryBuildDate: true
    ]

    // Adjust qTest configuration
    // Merge the default values if not explicitly defined
    println "Merging with the default configuration..."
    qtestPluginConfig.putAll(QTEST_PLUGIN_DEFAULT_CONFIG)
    println "Updated qtestPluginConfig: ${qtestPluginConfig}"
}

/**
 * Update Automation Content for all test cases in a Test Design directory by directory id.
 */
def UpdateQtestAutomationContent(def directoryId = null, def directorySize) {
    script {
        final py = libraryResource('..\\resources\\qtest\\update_qtest_automation_content.py')
        def directory_name = ""
        writeFile(file: 'update_qtest_automation_content.py', text: py)

        def output_file = "${env.WORKSPACE}/directory_name.txt"
        withCredentials([string(credentialsId: 'svc_prdmphoenix_qtest_api_sdk', variable: 'QTEST_API_TOKEN')]) {
            sh("python3 update_qtest_automation_content.py --qtest_token \"${QTEST_API_TOKEN}\" --directory_id \"${directoryId}\" --directory_size \"${directorySize}\" --output_file \"${output_file}\"")
        }

        // Get Directory name
        if (fileExists(output_file)) {
            directory_name = readFile(output_file)
        }
        return directory_name
    }
}

def UpdateQtestAutomationContentById(def testCasesIdFile) {
    script {
        final py = libraryResource('..\\resources\\qtest\\update_automation_content_by_id.py')
        writeFile(file: 'update_automation_content_by_id.py', text: py)
        withCredentials([string(credentialsId: 'svc_prdmphoenix_qtest_api_sdk', variable: 'QTEST_API_TOKEN')]) {
            sh("python3 update_automation_content_by_id.py --qtest_token \"${QTEST_API_TOKEN}\" --test_case_ids_file \"${testCasesIdFile}\"")
        }

        // No need to return any value
    }
}

return this
