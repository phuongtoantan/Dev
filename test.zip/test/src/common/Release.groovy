
// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package common

def loadStreamMetadata(def streamName="") {
    try {
        // Load the release metadata
        // Stream metadata YAML file naming convention: ${streamName}_metadata.yaml
        def yamlData = readYaml text: libraryResource("..//resources//releases//${streamName}_metadata.yaml")

        // Load stream elements
        def streamMetadata = yamlData ?: [:]

        return streamMetadata
    } catch (Exception e) {
        error("Error loading stream metadata for ${streamName}: ${e.message}")
    }
}

// Determine stream name by given branch
def determineStreamName(def streamBranch="") {
    try {
        /////////////////////////////////////////////////////////
        // NOTE: Whenever we have new stream, add it to this list
        // ...   and remove when the stream is deprecated!
        /////////////////////////////////////////////////////////
        def activeStreams = ["developstream", "developstream2", "main2stream"]
        println "Active Stream:"
        println activeStreams

        def streamName = null
        // Loop and find the stream that matches given branch
        activeStreams.each { activeStreamName ->
            // Load the candidate stream metadata
            def streamMetadata = loadStreamMetadata(activeStreamName)
            if (streamMetadata.stream_branch == streamBranch) {
                println "Found '${streamMetadata.stream_name}' for branch '${streamBranch}'"
                streamName = streamMetadata.stream_name
                return
            }

        }
        if (streamName == null) {
            error("Can not find the stream name for branch '${streamBranch}'")
        }
        return streamName
    } catch (Exception e) {
        error("Error loading stream info for ${streamBranch}: ${e.message}")
    }
}
