// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package common

/**
 * This class utilizes some podman action and wrap them up as groovy functions.
*/

/**
 ** Usage:
 * Import:
 *  def Podman = new common.Podman()
 *
 * Default:
 *  Podman.loginArtifactoryDockerRegistry()
 *
 * Input registry URL:
 *  Podman.loginArtifactoryDockerRegistry([dockerRegistry: "phm.artifactory.cec.lab.emc.com"])
 *
 * Input mode sudo:
 *  Podman.loginArtifactoryDockerRegistry([mode: "sudo"])
 *
 * Input both registry and sudo:
 *  Podman.loginArtifactoryDockerRegistry([dockerRegistry: "phm.artifactory.cec.lab.emc.com", mode: "sudo"])
 *
 * Input both registry and sudo with global vars:
 *  def GenericVars = new sharedVars.GenericVars()
 *  Podman.loginArtifactoryDockerRegistry([dockerRegistry: GenericVars.DEFAULT_ARTIFACTORY_DOCKER_REGISTRY, mode: "sudo"])
*/

def loginArtifactoryDockerRegistry(Map inputArgs = [:]) {
    script {
        // To retrieve the docker registry value from shared vars
        def GenericVars = new sharedVars.GenericVars()

        // Default should use default docker registry with normal mode
        def defaultValues = [
            dockerRegistry: GenericVars.DEFAULT_ARTIFACTORY_DOCKER_REGISTRY,
            mode: ""
        ]

        // Determine input parameters, the inputArgs with take precedence than the default values
        def args = defaultValues + inputArgs
        def dockerRegistry = args.dockerRegistry
        def mode = args.mode

        println "[INFO] Login to '${dockerRegistry}' with mode: '${mode}'"

        // Service account username associated with 'svc_npmphran_apikey' Jenkins credential
        serviceAccountUsername = "svc_npmphran"

        podman_cmd = "podman"
        if (mode == "sudo") {
            podman_cmd = "sudo podman"
        }

        withCredentials([string(credentialsId: 'svc_npmphran_apikey', variable: 'SVC_NPMPHRAN_API_TOKEN')]) {
            sh "${podman_cmd} login -u ${serviceAccountUsername} -p ${SVC_NPMPHRAN_API_TOKEN} ${dockerRegistry}"
        }
    }
}
return this
