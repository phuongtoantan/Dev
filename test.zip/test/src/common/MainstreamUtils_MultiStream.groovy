// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

package common
import groovy.json.JsonSlurperClassic
import groovy.json.JsonOutput
import java.util.Date

/** This class contains a set of common utilities functions of Mainstream pipeline
To use this in pipeline files (vars/*.groovy files):
    def MainstreamUtils = new common.MainstreamUtils()
Then run functions in this file within a script block, for example:
    script {
        Utils.getMainStreamStaticCheckInfo(job, component)
    }
*/

@NonCPS
def jsonParse(def json) {
    def parseResult = ""
    try {
        parseResult = new groovy.json.JsonSlurperClassic().parseText(json)
    } catch (error) {
        println "Error while parsing json: ${error}"
    }
    return parseResult
}

/**
* Get mainstream static check information from mainstraem static check pipeline
* @return staticResult
*/
def getMainStreamStaticCheckInfo(job, component) {
    script {
        def jobBuildVariables = job.getBuildVariables()
        def staticResult = [:]
        def covResult = [:]
        def cbannedResult = [:]

        //  Get cov result
        covResult['component'] = component
        covResult['overallStatus'] = "NOT-READY"
        if (jobBuildVariables.cov_status != null) {
            covResult['url'] = job.getAbsoluteUrl()
            covResult['overallStatus'] = jobBuildVariables.cov_status
            // Only show Jira URL if COV checks downstream is not SUCCESS
            covResult['jiraURL'] = jobBuildVariables.jiraaIssueRefefUrl != null & jobBuildVariables.cov_status != "SUCCESS" ? jobBuildVariables.jiraaIssueRefefUrl : ""
        }
        staticResult.covResult = covResult

        //  Get cbanned result
        cbannedResult['component'] = component
        cbannedResult['overallStatus'] = "NOT-READY"
        if (jobBuildVariables.cbanned_status != null) {
            cbannedResult['url'] = job.getAbsoluteUrl()
            cbannedResult['overallStatus'] = jobBuildVariables.cbanned_status
            // Only show Jira URL if Cbanned checks downstream is not SUCCESS/UNSTABLE
            cbannedResult['jiraURL'] = jobBuildVariables.jiraaIssueRefefUrl != null & !(jobBuildVariables.cbanned_status in ["SUCCESS","UNSTABLE"]) ? jobBuildVariables.jiraaIssueRefefUrl : ""
        }
        staticResult.cbannedResult = cbannedResult
        
        return staticResult
    }
}

def getMainStreamDynamicCheckInfo(job, component, variant) {
    script {
        def jobBuildVariables = job.getBuildVariables()
        def dynamicResult = [:]
        def blackduckResult = [:]

        //  Get Blackduck result
        blackduckResult['component'] = component
        blackduckResult['variant'] = variant
        blackduckResult['overallStatus'] = "NOT-READY"
        if (job.getResult() != null) {
            blackduckResult['url'] = job.getAbsoluteUrl()
            blackduckResult['overallStatus'] = job.getResult()
            // Only show Jira URL if Blackduck is not SUCCESS
            blackduckResult['jiraURL'] = jobBuildVariables.jiraaIssueRefefUrl != null & job.getResult() != "SUCCESS" ? jobBuildVariables.jiraaIssueRefefUrl : ""
        }

        dynamicResult.blackduckResult = blackduckResult
        return dynamicResult
    }
}

/**
* compare total number tc of current build with max total in the past, if current > max total => new max total = current
* indexName (string type)
* componentTestId: testID (Integer type)
* testName (string type)
* currentBuildTCTotal (Integer type)
* maxTriesLoop: max retry loop (Integer type)
*/
def checkAndUpdateMaxTotalTcsOfComponent(indexName, componentTestId, testName, currentBuildTCTotal, maxTriesLoop) {
    script {
        def Elasticsearch = new common.Elasticsearch()
        def component_test_map = [:]
        def maxTotal
        def breakFlag = false

        //decrementing maximum maxTriesLoop loop in case invalid testID => no data 
        for (int loop = 1; loop <= maxTriesLoop; loop++) {
            component_test_map = Elasticsearch.getMainstreamTestDataById(indexName, (componentTestId - loop))
            if (component_test_map != [:]) {
                def testResults = component_test_map.hits.hits[0]._source.testResults
                for (def element = 0; element < testResults.size(); element++) {
                    def testResult = testResults[element]
                    if ((testResult.testName == testName) && (testResult.containsKey("total"))) {
                        maxTotal = testResult.total
                        println "maxTotal at test ID: ${(componentTestId - loop)}"
                        breakFlag = true
                        break
                    }
                }
            } else {
                println "No data of ${indexName} at test ID: ${(componentTestId - loop)}. decrement and compare to previous testId of index (maxTriesLoop)"
            }
            if (breakFlag == true) {break}
        }

        if (maxTotal && (maxTotal > currentBuildTCTotal)) {
            return maxTotal //update new max
        } else {
            return currentBuildTCTotal //current total tc of build is max 
        }
    }
}

/** get missed and baseline tc, and update to ES if have a change as well
* INPUT (component, testName, note: string type | totalTcOfCurrentBuild: integer type)
*  OUTPUT (dataReturn: map)
*/
def getAndUpdateTcBaseline(streamMetadata, component, testName, totalTcOfCurrentBuild, note, getBaselineOnly=false) {
    def dataReturn = [:]
    node ('jira-generic') {
        cleanWs()
        script {
            def Elasticsearch = new common.Elasticsearch()
            baseline_index = streamMetadata.elk.streaminfo.streaminfo_testcase_baseline
            mainstreamTcBaseline = Elasticsearch.getLatestEsComponentData(baseline_index)
            for (def element = 0; element < mainstreamTcBaseline.baselines.size(); element++) {
                if ((mainstreamTcBaseline.baselines[element].component == component) && (mainstreamTcBaseline.baselines[element].testName == testName)) {
                    def baseline = mainstreamTcBaseline.baselines[element].baseline
                    if (getBaselineOnly) {
                        dataReturn["baseline"] = baseline
                        break
                    }
                    if (totalTcOfCurrentBuild <= baseline) {
                        dataReturn["miss"] = baseline - totalTcOfCurrentBuild
                        dataReturn["baseline"] = baseline
                    } else {
                        dataReturn["miss"] = 0
                        dataReturn["baseline"] = totalTcOfCurrentBuild

                        //uploading new baseline to ELK
                        Date currentTime = new Date()
                        mainstreamTcBaseline.baselines[element].date_created = currentTime
                        mainstreamTcBaseline.baselines[element].baseline = totalTcOfCurrentBuild
                        mainstreamTcBaseline.baselines[element].note = note

                        println "upload ES in Mainstream Utils"
                        println("Pipeline Params: " + mainstreamTcBaseline)

                        jsonResult = JsonOutput.prettyPrint(JsonOutput.toJson(mainstreamTcBaseline))

                        println "Data converted for ES integration...."
                        writeFile(file: "${env.WORKSPACE}/esdoc.json", text: jsonResult)
                        EStelemetry("${env.WORKSPACE}/esdoc.json", baseline_index, currentBuild.displayName)
                    }
                }
            }
        }
        cleanWs()
    }
    return dataReturn
}

/**
* Mark the status of the stage corresponding to the status of the downstream
*/
def handleDownstreamStatus(job) {
    script {
        def jobStatus = job.getResult()
        def jobName = job.getProjectName()

        switch (jobStatus) {
            case 'ABORTED':
                aborted("Downstream ${jobName} was Aborted!")
                break
            case 'FAILURE':
                error("Downstream ${jobName} was Failure!")
                break
            case 'UNSTABLE':
                unstable("Downstream ${jobName} was Unstable!")
                break
            case 'NOT_BUILT':
                error("Downstream ${jobName} was NOT_BUILT!")
                break
        }
    }
}

/**
* Get list RPM
*/
def getListRPM(streamName="") {
    def ARTIFACTORY_REPO = 'https://phm.artifactory.cec.lab.emc.com/artifactory'
    def rpmList = []
    def rpmPath = ""
    if (streamName.isEmpty()) {
        rpmPath = "mobile-phoenix-rpm-green_load/latest/*.rpm"
    } else {
        def Release = new common.Release()
        def streamMetadata = Release.loadStreamMetadata(streamName)
        rpmPath = streamMetadata.rpm_green_load_path + "/*.rpm"
    }
    node ('artifactory_cleanup' ) {
        script {
            withCredentials([usernamePassword(credentialsId: 'svc_npmphran', passwordVariable: 'password', usernameVariable: 'username')]) {
                try {
                    sh "jf config add artifactory-green --artifactory-url ${ARTIFACTORY_REPO} --user \${username} --password \${password}| true"
                    sh "jf c use artifactory-green"
                    
                    def searchCommand = """
                        jf rt s $rpmPath --user \${username} --password \${password} --url ${ARTIFACTORY_REPO} --recursive=false
                    """
                    def searchResponse = sh(returnStdout: true, script: searchCommand).trim()
                    rmpInfoList = jsonParse(searchResponse)
                    for (rmpInfo in rmpInfoList){
                        rpmList.add(rmpInfo["path"].split("/")[-1])
                    }
                }
                catch (err) {
                    println("Error appearing when getting list RPM Versions: " + err)
                }
            }
        }
        cleanWs()
    }
    return rpmList
}

/**
 * Get the list of successfully built Components by Build ID.
*/
def getMainstreamBuildSuccessList(def buildID = null, def ELK_ID = '') {
    def list_build_success= []
    node ('jira-generic'){
        cleanWs()
        script {
            def output_file = "${env.WORKSPACE}/output.txt"
            final get_mainstream_build_info = libraryResource('..//resources//elasticsearch//get_mainstream_build_info.py')
            final es_interface = libraryResource('..//resources//elasticsearch//es_interface.py')
            final requirements = libraryResource('..//resources//elasticsearch//requirements.txt')

            writeFile(file: 'get_mainstream_build_info.py', text: get_mainstream_build_info)
            writeFile(file: 'requirements.txt',text: requirements)
            writeFile(file: 'es_interface.py',text: es_interface)

            sh('pip3 install --user -r requirements.txt')
            sh("python3 get_mainstream_build_info.py --list_success --build_id \"${buildID}\" --elk_id \"${ELK_ID}\" --output_file \"${output_file}\"")

            // Get Directory name
            if (fileExists(output_file)) {
                fileContent = readFile(output_file)
                list_build_success = fileContent.split(',').collect { it.toString() }
            }
        }
        cleanWs()
    }
    return list_build_success
}

/**
* set mainstream data version
* Input is a map with format: [component_name: 'version', component_name: 'version']
* Ex: [CU: 'CU_2.1.0.0_2023', DU: 'DU_2.1.0.0_1935']
*
* @return map of data
*/
def setMainstreamBuildVersion(version_list) {
    script {
        def mainstreamBuildVersions = [
            "CU": [
                "version": "",
            ],
            "DU": [
                "version": "",
            ],
            "MPLANE": [
                "version": "",
            ],
            "l1fw": [
                "version": "",
            ],
            "l1dr": [
                "version": "",
            ],
            "NGP": [
                "version": "",
            ],
            "OAM": [
                "version": "",
            ],
            "NODED": [
                "version": "",
            ],
            "UESIM": [
                "version": "",
            ],
            "Transport": [
                "version": "",
            ],
            "RDC_service": [
                "version": "",
            ],
            "ACM": [
                "version": "",
            ],
        ]
        version_list.each { key, val ->
            // Cover null object returned from component build pipeline
            def invalidValues = ["null", null]
            if (!invalidValues.contains(val)) {
                mainstreamBuildVersions["${key}"]['version'] = "${val}"
            }
        }
        return mainstreamBuildVersions
    }
}

/**
* Define createNewBaseline function to upload component's baseline to ELK
*/
def createNewBaseline(baselineIndex, componentInfo, pipelineParams, buildNumber, tag) {
    node ('jira-generic') {
        cleanWs()
        script {
            println baselineIndex
            Date currentTime = new Date()
            def baselineInfo = [
                component: componentInfo.component,
                testType: componentInfo.testType,
                testName: componentInfo.testName,
                baseline: componentInfo.baseline.toInteger(),
                note: componentInfo.note,
                date_created: currentTime
            ]
            if (!pipelineParams.containsKey('baselines')) {
                pipelineParams.baselines = []
            }
            pipelineParams.baselines.add(baselineInfo)
            println "upload ES in stage"
            pipelineParams.testID = buildNumber
            pipelineParams.date_created = currentTime
            println("Pipeline Params: " + pipelineParams)
            println "Data converted for ES integration...."
            writeFile(file: "${env.WORKSPACE}/esdoc.json", text: JsonOutput.prettyPrint(JsonOutput.toJson(pipelineParams)))
            EStelemetry("${env.WORKSPACE}/esdoc.json", baselineIndex.toLowerCase(), tag)
            println "------> New baseline of ${componentInfo.testName} - ${componentInfo.component} is set to ${componentInfo.baseline} successfully"
        }
        cleanWs()
    }
}