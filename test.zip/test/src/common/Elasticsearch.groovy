// Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.
package common
import groovy.json.JsonSlurperClassic
@NonCPS
def jsonParse(def json) {
    new groovy.json.JsonSlurperClassic().parseText(json)
}


def getLastSuccessTLData(def tlName = null) {
    if (!tlName) {
        throw new IllegalArgumentException("Missing 'tlName' parameter!")
    }

    // Convert to lowercase before interacting with Elasticsearch
    tlNameInLowerCase  = tlName.toLowerCase()

    def lastSuccessData = [:]

    node('jira-generic') {
        cleanWs()
        script {
            // Preraring scripts and libararies
            final es_query = libraryResource('..//resources//elasticsearch//es_query.py')
            final get_last_success_tl_data = libraryResource('..//resources//elasticsearch//get_last_success_tl_data.py')
            writeFile(file: 'es_query.py', text: es_query)
            writeFile(file: 'get_last_success_tl_data.py', text: get_last_success_tl_data)

            // Install dependencies. TODO: Use a virtual enviroment for dependencies
            final requirements = libraryResource('..//resources//elasticsearch//requirements.txt')
            writeFile(file: 'requirements.txt', text: requirements)
            sh('pip3 install --user -r requirements.txt')

            // Start ES query
            tlSuccessJsonFile = "${WORKSPACE}/tl_success_data.json"
            sh "python3 get_last_success_tl_data.py --tl-name=${tlNameInLowerCase} --output-json=${tlSuccessJsonFile}"

            // Parse results
            def fileContents = readFile(tlSuccessJsonFile)
            lastSuccessData = jsonParse(fileContents)

            // Show data in console
            println "lastSuccessData:"
            println lastSuccessData
        }
        cleanWs()
    }

    return lastSuccessData
}

def getLatestEsComponentData(def indexName = null) {
    if (!indexName) {
        throw new IllegalArgumentException("Missing 'indexName' parameter!")
    }
    def latest_es_component_data = [:]

    node('jira-generic') {
        cleanWs()
        script {
            // Preparing scripts and libraries
            final es_interface = libraryResource('..//resources//elasticsearch//es_interface.py')
            final get_latest_es_component_data = libraryResource('..//resources//elasticsearch//get_latest_es_component_data.py')
            writeFile(file: 'es_interface.py', text: es_interface)
            writeFile(file: 'get_latest_es_component_data.py', text: get_latest_es_component_data)

            // Install dependencies. TODO: Use a virtual enviroment for dependencies
            final requirements = libraryResource('..//resources//elasticsearch//requirements.txt')
            writeFile(file: 'requirements.txt', text: requirements)
            sh('pip3 install --user -r requirements.txt')

            resultJsonFile = "${WORKSPACE}/resultJsonFile.json"
            sh "python3 get_latest_es_component_data.py --index-name=${indexName} --output-json=${resultJsonFile}"

            // Parse results
            def fileContents = readFile(resultJsonFile)
            latest_es_component_data = jsonParse(fileContents)
            
            // Show data in console
            println "latest es component data:"
            println latest_es_component_data
        }
        cleanWs()
    }

    return latest_es_component_data
}

def getMainstreamTestDataById(def indexName = null, def componentTestId = null) {
    if (!indexName) {
        throw new IllegalArgumentException("Missing 'indexName' parameter!")
    }
    def component_test_map = [:]

    node('jira-generic') {
        cleanWs()
        script {
            // Preparing scripts and libraries
            final es_interface = libraryResource('..//resources//elasticsearch//es_interface.py')
            final get_mainstream_test_data_by_id = libraryResource('..//resources//elasticsearch//get_mainstream_test_data_by_id.py')
            writeFile(file: 'es_interface.py', text: es_interface)
            writeFile(file: 'get_mainstream_test_data_by_id.py', text: get_mainstream_test_data_by_id)

            // Install dependencies. TODO: Use a virtual enviroment for dependencies
            final requirements = libraryResource('..//resources//elasticsearch//requirements.txt')
            writeFile(file: 'requirements.txt', text: requirements)
            sh('pip3 install --user -r requirements.txt')

            resultJsonFile = "${WORKSPACE}/resultJsonFile.json"
            sh "python3 get_mainstream_test_data_by_id.py --index-name=${indexName} --component-test-id=${componentTestId} --output-json=${resultJsonFile}"

            // Parse results
            def fileContents = readFile(resultJsonFile)
            if (fileContents.contains("testResults")){
                component_test_map = jsonParse(fileContents)
            }
            
            // Show data in console
            println "component test map:"
            println component_test_map
        }
        cleanWs()
    }

    return component_test_map
}

def getLatestSuccessComponentVersion(def indexName = null, def components = null) {
    if (!indexName) {
        throw new IllegalArgumentException("Missing 'indexName' parameter!")
    }
    if (!components) {
        throw new IllegalArgumentException("Missing 'components' parameter!")
    }
    def latest_success_component_data = [:]

    node('jira-generic') {
        cleanWs()
        script {
            // Preparing scripts and libraries
            final es_interface = libraryResource('..//resources//elasticsearch//es_interface.py')
            final get_latest_success_component_versions = libraryResource('..//resources//elasticsearch//get_latest_success_component_versions.py')
            writeFile(file: 'es_interface.py', text: es_interface)
            writeFile(file: 'get_latest_success_component_versions.py', text: get_latest_success_component_versions)

            // Install dependencies. TODO: Use a virtual enviroment for dependencies
            final requirements = libraryResource('..//resources//elasticsearch//requirements.txt')
            writeFile(file: 'requirements.txt', text: requirements)
            sh('pip3 install --user -r requirements.txt')

            resultJsonFile = "${WORKSPACE}/resultJsonFile.json"
            sh "python3 get_latest_success_component_versions.py --index-name=${indexName} --components='''${components}''' --output-json=${resultJsonFile}"

            // Parse results
            def fileContents = readFile(resultJsonFile)
            latest_success_component_data = jsonParse(fileContents)
            
            // Show data in console
            println "latest_success_component_data:"
            println latest_success_component_data
        }
        cleanWs()
    }

    return latest_success_component_data
}

return this
