// Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

package common
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import groovy.time.TimeCategory

/** This class contains a set of common utilities functions
To use this in pipeline files (vars/*.groovy files):
    def Utils = new common.Utils()
Then run functions in this file within a script block, for example:
    script {
        Utils.getSourceImageAndVersion(imageUrl)
    }
*/

/**
* Get source image URL and version from Artifactory docker image URL
* @param  imageUrl   Specify image URL. E.g: "phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker/artifactory/platform/dev-images/cu/cucp-dpdk/cucp-checking:v1.1"
* @return  [sourceImage, sourceImageVersion]
*/

def getSourceImageAndVersion(def imageUrl = null) {
    if (!imageUrl) {
        throw new IllegalArgumentException("Missing 'imageUrl' parameter!")
    }

    def sourceImage = imageUrl.substring(0, imageUrl.lastIndexOf(":"))
    def sourceImageVersion = imageUrl.substring(imageUrl.lastIndexOf(":") + 1, imageUrl.length())
    println("[INFO] sourceImages: " + sourceImage)
    println("[INFO] sourceImageVersion: " + sourceImageVersion)

    //return "latest" tag if version tag is not included in Image URL
    if (sourceImageVersion.contains('5068') && !sourceImage.contains('5068')) {
        return [imageUrl, "latest"]
    }
    else {
        return [sourceImage, sourceImageVersion]
    }
}
// The function getPipelineInfo is created with the purpose of displaying content in the report email when the build is aborted or test skipped.
def getPipelineInfo(params, build = null) {
    String message = ''
    List<String> skippedTests = []
    // Check if the test stage was skipped
    if (params?.SKIP_TEST) {
        message += 'The entire test stage was skipped'
    } else {
        if (build && build.buildVariables) {
            if (build.buildVariables.SKIP_CU_TEST == 'true') {
                skippedTests << 'CU_TEST'
            }
            if (build.buildVariables.SKIP_DU_TEST == 'true') {
                skippedTests << 'DU_TEST'
            }
            if (build.buildVariables.SKIP_L1_TEST == 'true') {
                skippedTests << 'L1_TEST'
            }
            if (build.buildVariables.SKIP_MPLANE_TEST == 'true') {
                skippedTests << 'MPLANE_TEST'
            }
            if (build.buildVariables.SKIP_NGP_TEST == 'true') {
                skippedTests << 'NGP_TEST'
            }
            if (build.buildVariables.SKIP_OAM_TEST == 'true') {
                skippedTests << 'OAM_TEST'
            }
            if (build.buildVariables.SKIP_RADIO_TEST == 'true') {
                skippedTests << 'RADIO_TEST'
            }
            if (build.buildVariables.SKIP_TRANSPORT_TEST == 'true') {
                skippedTests << 'TRANSPORT_TEST'
            }
            if (!skippedTests.isEmpty()) {
                if (!message.isEmpty()) {
                    message += ' '
                }
                message += "The test stage was skipped: ${skippedTests.join(', ')}"
            }
        }
    }
    // Check if the pipeline was aborted
    if (currentBuild.result == 'ABORTED') {
        if (!message.isEmpty()) {
            message += '\n'
        }
        message += 'The build was aborted'
    }
    // Return the message or an empty string if no conditions are met
    return message
}

// Check and kill port to run RDC pipeline.

def checkAndKillPorts(def ports){
    script {
        for (def port in ports) {
            def command = "sudo netstat -tulpn | grep :${port}"

            def result
            try {
                result = sh (script: command, returnStdout: true).trim()
            } catch (Exception error) {
                result = "Port ${port} is not in use."
            }
            // Check status of the ports before using them.

            if (!result.contains("use")) {
                def pid = result.split("\\s+")[6].split("/")[0]
                sh "sudo kill ${pid}"
                println("Port ${port} (pid ${pid}) has been killed. Port ${port} is ready to use.")
            } else {
                println("Port ${port} is ready to use." )
            }
        }
        // Kill ports in use. 

        // Kill port of the programe is LISTEN before using them.
        def programes=[
            "macmnsvc",
            "java"
        ]
        for (def programe in programes) {
            try {
                def command = """ sudo netstat -tulp | grep LISTEN | grep /${programe} | awk '{print \$7}' | cut -d'/' -f1 """
                def getPids = sh(script: command, returnStdout: true).trim()
                def pids = getPids.split('\n').collect { it.toInteger() }

                // kill pid
                for (def pid in pids) {
                    sh """ sudo kill -9 ${pid} || echo '${pid} killed' """
                }
            } catch (Exception error) {
                println("${programe} not using port.")
            }
        }
    }
}

def getTestResultFromRobotHTML(robotLogHtmlPath) {
    if (!robotLogHtmlPath) {
        throw new IllegalArgumentException("Missing 'robotLogHtmlPath' parameter!")
    }
    def testResult = "UNKNOWN"
    def totalFailed = 0


    String fileContents = readFile(robotLogHtmlPath)


    testContents = fileContents.split("\\[\\[\\{")[1].split("\\}\\]\\]")[0]
    testContents = "[[{" + testContents + "}]]"
    def testData = new JsonSlurper().parseText(testContents)
    println testData
    for(suite in testData){
        for(testInfo in suite){
            if ((testInfo["label"] == "All Tests")) {
                println testInfo
                totalFailed = testInfo["fail"]
            }
        }
    }
    println "Total failed:" + totalFailed
    if (totalFailed > 0) {
        testResult = "FAILURE"
    } else {
        testResult = "SUCCESS"
    }
    return testResult
}

/**
* Standard formating for Artifactory Build Name
* @param RELEASE_VERSION is to be L1GlobalVars that are prefixed with RELEASE_VERSION
* @param buildName is distinct name for an artifact's build that can be associated to a pipeline
* @param branchName is the branch associated to a pipeline or source git repo that the build used to create an artifact
* @return buildName to be found in https://phm.artifactory.cec.lab.emc.com/artifactory/webapp/#/builds/
*/
@NonCPS
String getBuildInfoName(RELEASE_VERSION, buildName = '', branchName = '') {

    buildNameTokens = "${buildName}".tokenize('/')
    buildNameWithOutFolders = buildNameTokens[buildNameTokens.size()-1]

    buildInfoName = "${RELEASE_VERSION}-${buildNameWithOutFolders}"
    buildBranchName = "${branchName}"

    return "${buildInfoName}-${buildBranchName}"
}

Map setBuildInfo(buildInfoName, buildNumber = '', gitRepo = null, gitTag = null) {
    if (!buildInfoName || buildInfoName.length() < 1) {
        return [:]
    }

    script {
        env.BUILD_INFO_NAME = buildInfoName
        env.BUILD_PROJECT = "${env.JOB_NAME}"
        if (buildNumber != '') {
            env.BUILD_INFO_NUMBER = "${buildNumber}"
        } else {
            buildNumber = "${BUILD_ID}"
            env.BUILD_INFO_NUMBER = "${BUILD_ID}"
        }
        if (gitTag)
        {
            env.BUILD_REPO = "${gitRepo}"
            env.BUILD_REPO_TAG = "${gitTag}"
        }
    }
    Map buildInfoMap = ['buildName':"${buildInfoName}",'buildNumber':"${buildNumber}"]
    echo "params ${params}"
    sh 'printenv | sort'
    rtBuildInfo (
        captureEnv: true,
        includeEnvPatterns: ['BUILD_*','build_*'],
        buildName: "${env.BUILD_INFO_NAME}",
        buildNumber: "${env.BUILD_INFO_NUMBER}"
    )
    return buildInfoMap
}

String setEnvForGitRepo (String gitRepo, String gitRepoBranch, String gitTag, String gitCommitId)
{
    env.BUILD_REPO = "${gitRepo}"
    env.BUILD_REPO_BRANCH = "${gitRepoBranch}"
    env.BUILD_REPO_TAG = "${gitTag}"
    env.BUILD_REPO_COMMIT_ID = "${gitCommitId}"
    
}

/**
* Sample definition for buildInfo:
    def buildDefinition = [
        "buildName": "name-of-build",
        "buildNumber": "build-number-to-associate-to-build"
    ]
*/
def downloadArtifact(patterns = [], target = "./", buildInfo = [:]) {
    for (pattern in patterns) {
        String specJson = """{
                "files": [
                    {
                        "pattern": "${pattern}",
                        "flat": true,
                        "target": "${target}"
                    }
                ]
            }"""
        if (buildInfo && !buildInfo.empty) {
            rtDownload(
                serverId: 'Artifactory-RR-PHM',
                spec: "${specJson}",
                buildName: "${buildInfo.buildName}",
                buildNumber: "${buildInfo.buildNumber}"
            )
        } else {
            rtDownload(
                serverId: 'Artifactory-RR-PHM',
                spec: "${specJson}"
            )
        }
    }
}

def downloadArtifactAQL(aql = [:], target = './', buildInfo = [:]) {
    String specJson = """{
            "files": [
                {
                    "aql": ${JsonOutput.toJson(aql)},
                    "flat": true,
                    "target": "${target}"
                }
            ]
        }"""
    println specJson
    if (buildInfo && !buildInfo.empty) {
        rtDownload(
            serverId: 'Artifactory-RR-PHM',
            spec: "${specJson}",
            buildName: "${buildInfo.buildName}",
            buildNumber: "${buildInfo.buildNumber}"
        )
    } else {
        rtDownload(
            serverId: 'Artifactory-RR-PHM',
            spec: "${specJson}"
        )
    }
}

def downloadLatestArtifactoryBuild( String buildInfoName,
                                    String pattern = "",
                                    String destination="./",
                                    Boolean failNoOp=true) {
    /*
    * This function downloads the latest artifacts from a buildI name on artifactory.
    * the build is searched for under artifactory adn the files matching the pattern are downloaded. 
    * The function fails the pipeline if no files found.
    * 
    * @param buildInfoName              build info name for artifact to download
    * @param pattern                    Pattern for file names to download under the build
    * @param destination                Destination to download the artifacts to defautls to current directory.
    * 
    */

    rtDownload(
            serverId: 'Artifactory-RR-PHM',
            spec: """{
            "files": [
                {
                    "build": "${buildInfoName}",
                    "pattern": "${pattern}",
                    "flat": true,
                    "target": "${destination}"
                }
            ]
        }""",
        failNoOp: failNoOp)
}

/**
* Sample definition for buildInfo:
    def buildDefinition = [
        "buildName": "name-of-build",
        "buildNumber": "build-number-to-associate-to-build"
    ]
*/
def uploadArtifact(patterns = [], target = "", buildInfo = [:]) {
    for (pattern in patterns) {
        String specJson = """{
                "files": [
                    {
                        "pattern": "${pattern}",
                        "target": "${target}/",
                        "recursive": "false"
                    }
                ]
            }"""
        if (buildInfo && !buildInfo.empty) {
            rtUpload (
                serverId: 'Artifactory-RR-PHM',
                spec: "${specJson}",
                buildName: "${buildInfo.buildName}",
                buildNumber: "${buildInfo.buildNumber}"
            )
        } else {
            rtUpload (
                serverId: 'Artifactory-RR-PHM',
                spec: "${specJson}"
            )
        }
    }
}

def publishArtifactBuildInfoNew(buildInfo = [:]) {
    if (!buildInfo.buildName)
    {
        print "No BuildInfo Available (PR branch)" 
        return
    }

    if (buildInfo.buildNumber && buildInfo.buildNumber != '') {
        rtPublishBuildInfo (
            serverId: 'Artifactory-RR-PHM',
            buildName: "${buildInfo.buildName}",
            buildNumber: "${buildInfo.buildNumber}"
        )
        print "Published BuildInfo Available ${buildInfo.buildName} : ${buildInfo.buildNumber}" 
    } else {
        rtPublishBuildInfo (
            serverId: 'Artifactory-RR-PHM',
            buildName: "${buildInfo.buildName}"
        )
    }
}

def publishArtifactBuildInfo(buildName = "", buildNumber = "") {
    if (buildNumber && buildNumber != '') {
        rtPublishBuildInfo (
            serverId: 'Artifactory-RR-PHM',
            buildName: "${buildName}",
            buildNumber: "${buildNumber}"
        )
    } else {
        rtPublishBuildInfo (
            serverId: 'Artifactory-RR-PHM',
            buildName: "${buildName}"
        )
    }
}

/**
 * Finds the last Successfully Built Job for @pipelineName
 *
 * @param pipelineName the Full Name of a pipeline found on the Jenkins instance
 * @return Last Successfully Built Job for @pipelineName
 */
hudson.model.Job getLastSuccessfulBuild(pipelineName) {
    def buildInfo = Jenkins.instance.getItemByFullName(pipelineName)
    if (buildInfo.getLastSuccessfulBuild()) {
        def lastSuccessfulBuildID = "${buildInfo.getLastSuccessfulBuild().number}"
        echo "Last ${pipelineName} successful build: ${lastSuccessfulBuildID}"
    } else {
        throw new Exception("ERROR: There is no successful build in ${pipelineName}.")
    }
    return buildInfo.getLastSuccessfulBuild()
}

def isMultiBranchPipeline(pipelineName) {
    return Jenkins.instance.getItemByFullName(pipelineName) instanceof org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject
}

/**
 * Finds the last Successfully Built Job's BuildId for @pipelineName
 *
 * @param pipelineName the Full Name of a pipeline found on the Jenkins instance
 * @return Last Successfully Built Job's BuildId for @pipelineName
 */
String getLastSuccessfulBuildID(pipelineName) {
    def buildInfo = Jenkins.instance.getItemByFullName(pipelineName)
    def lastSuccessfulBuildID = ""
    if (buildInfo.getLastSuccessfulBuild()) {
        lastSuccessfulBuildID = "${buildInfo.getLastSuccessfulBuild().number}"
        echo "Last ${pipelineName} successful build: ${lastSuccessfulBuildID}"
    } else {
        echo "ERROR: There is no successful build in ${pipelineName}."
    }
    return lastSuccessfulBuildID
}

def downloadLatestGreenloadData(artifactoryPath="", outputFileName="") {
    if (!artifactoryPath) {
        throw new IllegalArgumentException("Missing 'artifactoryPath' parameter!")
    }
    if (!outputFileName) {
        throw new IllegalArgumentException("Missing 'outputFileName' parameter!")
    }
     withCredentials([string(credentialsId: 'svc_npmphran_apikey', variable: 'SVC_NPMPHRAN_API_TOKEN')]){
        retry(3) {
            sh """
                curl -H "Authorization: Bearer ${SVC_NPMPHRAN_API_TOKEN}" -k "https://phm.artifactory.cec.lab.emc.com/artifactory/list/$artifactoryPath/" > green_load_latest_data.html
                cat green_load_latest_data.html | grep -oE ">.*.rpm<" | sed 's/>//g' | sed 's/.rpm<//g' > $outputFileName
            """
        }
    }
}

/**
* Get greenload versions
* @param  artifactoryGreenloadPath Specify the Artifactory greenload path, e.g:"mobile-phoenix-rpm-green_load/R1/latest", "mobile-phoenix-rpm-green_load/latest", ...
* @return  greenLoadVersions
*/
def getLatestGreenloadVersions(def artifactoryGreenloadPath="") {
    def greenLoadVersions = [:]
    def ParseComponentVer = new ParseComponentVer()

    node('jira-generic') {
        cleanWs()
        script {
            downloadLatestGreenloadData(artifactoryGreenloadPath, "green_load_latest_data.txt")
            greenLoadVersions = ParseComponentVer.getComponentVersions("green_load_latest_data.txt")
        }
        cleanWs()
    }
    return greenLoadVersions
}

def getLatestGreenloadImages(def artifactoryGreenloadImagePath="", ver="2.1.0.0") {
    def images_list = [:]

    node('jira-generic') {
        cleanWs()
        script {
            images_list.latestVerCU = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/cuup_dpdk/", "CU_" + ver)
            images_list.latestVerDU = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/du_dpdk/", "DU_" + ver)
            images_list.latestVerMPLANE = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/mplane/", "mplane_" + ver)
            images_list.latestVerUESIM = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/uesim/", "UESIM_" + ver)
            images_list.latestVerTRANSPORT = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/transport_fhmanger/", "TRANSPORT_" + ver)
            images_list.latestVerOAM = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/gnb_oama/", "OAM_" + ver)
        }
        cleanWs()
    }
    return images_list
}

def getLatestGreenloadImages_multistream(def artifactoryGreenloadImagePath="", ver="2.1.0.0", stream_name='') {
    def images_list = [:]

    node('jira-generic') {
        cleanWs()
        script {
            def du_image_name = 'du_mvl_prod'
            if (stream_name == 'mainstream') {
                du_image_name = 'du_dpdk'
            }
            images_list.latestVerCU = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/cuup_dpdk/", "CU_" + ver)
            images_list.latestVerDU = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/${du_image_name}/", "DU_" + ver)
            images_list.latestVerMPLANE = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/mplane/", "mplane_" + ver)
            images_list.latestVerUESIM = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/uesim/", "UESIM_" + ver)
            images_list.latestVerTRANSPORT = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/transport_fhmanger/", "TRANSPORT_" + ver)
            images_list.latestVerOAM = getLatestVersionFromArtifactory("${artifactoryGreenloadImagePath}/gnb_oama/", "OAM_" + ver)
        }
        cleanWs()
    }
    return images_list
}


/**
* Generate application build data
* @param  applicationName      (Required) Specify application name, e.g: CU, DU, Mplane,...
* @param  applicationVersion   (Required) Specify application version, e.g: CU_2.1.0.0_0123, DU_2.1.0.0_0456
* @param  jiraaIssueRefe       (Optional) Specify jira ID
* @param  jiraaIssueRefefUrl   (Optional) Specify jira URL
* @param  failedStages         (Optional) Specify failed stage
* @return  Json appBuildData
*/
def getAppBuildData(Map args = [applicationName: "", applicationVersion: "", jiraaIssueRefe: "", jiraaIssueRefefUrl: "", failedStages: ""]) {
    script {
        if (!args.applicationName) {
            throw new IllegalArgumentException("Missing 'applicationName' parameter!")
        }
        if (!args.applicationVersion) {
            throw new IllegalArgumentException("Missing 'applicationVersion' parameter!")
        }

        def appBuildData = ["applicationName": args.applicationName, "applicationVersion": args.applicationVersion, "jiraaIssueRefe": args.jiraaIssueRefe, "jiraaIssueRefefUrl": args.jiraaIssueRefefUrl, "failedStages": args.failedStages]

        return JsonOutput.toJson(appBuildData)
    }
}
def removeLastSlash(String path) {
    if(path.endsWith("/")) {
        return path.substring(0, path.lastIndexOf("/"))
    } else {
        return path
    }
}

def getTestData(Map args = [tl_job_ids: [], ct_job_id: ""]) {
    script {
        if (args.tl_job_ids.isEmpty()) {
            throw new IllegalArgumentException("Missing 'tl_job_ids' parameter!")
        }
        if (!args.ct_job_id) {
            throw new IllegalArgumentException("Missing 'ct_job_id' parameter!")
        }

        def testData = ["tl_job_ids": args.tl_job_ids, "ct_job_id": args.ct_job_id]

        return JsonOutput.toJson(testData)
    }
}

// Parse test result from xUnit report file and return a groovy Map of test data
def getTestResultFromXUnitReportFile(xUnitFilePath, totalPattern="tests", failPattern="errors", skipPattern="skipped"){
    script {
        def testResult = [:]
        try {
            def xmlString = readFile(xUnitFilePath)
            def xml = new XmlSlurper().parseText(xmlString)

            testResult.total = xml.@"$totalPattern".toInteger()
            testResult.fail = xml.@"$failPattern".toInteger()
            testResult.skip = xml.@"$skipPattern".toInteger()
            testResult.pass = testResult.total - testResult.fail - testResult.skip

            if (testResult.fail == 0) {
                testResult.testStatus="SUCCESS"
            } else {
                testResult.testStatus="FAILURE"
            }
        } catch (err) {
            print "Error while collecting test results" + err
        }
        println testResult

        return testResult
    }
}

// Parse test result from Jenkins build object and return a groovy Map of test data
def getTestResultFromJenkinsJobAction(def runWrapper, jenkinsActionClassName = "junitTestResultAction"){
    script {
        def testResult = [:]
        try {
            def action = null
            if (runWrapper != null) {
                switch (jenkinsActionClassName) {
                case 'robotRobotBuildAction':
                    action = runWrapper.rawBuild.getAction(hudson.plugins.robot.RobotBuildAction.class)
                    break
                case 'junitTestResultAction':
                    action = runWrapper.rawBuild.getAction(hudson.tasks.junit.TestResultAction.class)
                    break
                default:
                    println "Invalid Jenkins action name: " + jenkinsActionClassName
                    break
                }
            }

            if (action != null) {
                testResult.total = action.getTotalCount()
                testResult.fail = action.getFailCount()
                testResult.skip = action.getSkipCount()
                testResult.pass = testResult.total - testResult.fail - testResult.skip
            } else {
                testResult.total = 0
                testResult.fail = 0
                testResult.skip = 0
                testResult.pass = 0
            }

            if (testResult.fail == 0 && testResult.total > 0) {
                    testResult.testStatus="SUCCESS"
                } else {
                    testResult.testStatus="FAILURE"
            }
        } catch (err) {
            print "Error while collecting test results" + err
        }
        println testResult
        return testResult
    }
}

// Parse test line information to a Map of test line data
def getTestLineBuildInfo(testLineID, jobName, testLineResult, testLineURL) {
    def testLineInfo = [:]
    testLineInfo.id = testLineID
    testLineInfo.tl_name = jobName.find(/(tl\d+)/)?.toUpperCase()
    testLineInfo.job_name = jobName
    testLineInfo.result = testLineResult
    testLineInfo.url = testLineURL
    return testLineInfo
}

// Get latest image version on artifactory
def getLatestVersionFromArtifactory(def ArtifactoryImageURL="", def Version="") {
    script {
        def LatestImageVersion = ""

        node('jira-generic') {
            withCredentials([string(credentialsId: 'svc_npmphran_apikey', variable: 'SVC_NPMPHRAN_API_TOKEN')]){
                retry(3) {
                    LatestImageVersion = sh(returnStdout: true,
                        script: """
                            curl -L -s -H "{Authorization: Bearer ${SVC_NPMPHRAN_API_TOKEN}" ${ArtifactoryImageURL} | grep "${Version}" | tail -1 | sed -e 's!<.*">!!g;s!/<.*!!g'
                        """).trim()
                }
            }
        }
        return LatestImageVersion
    }
}

// Get SHA for all submodule in OAM Nightly Test pipeline 
def getOAMSubmoduleHashesMap(str) {
    def pattern = /Submodule path '(.+?)': checked out '(.+?)'/
    def submodule_sha_map = [:]
    def m = str =~ pattern
    m.each { match ->
        def submodule = match[1] 
        def hash = match[2] 
        submodule_sha_map.put(submodule, hash) 
    }
    print(submodule_sha_map)
    return submodule_sha_map
}


def getTestResultFromXUnitReportPattern(xUnitPattern, basepath, totalPattern="tests", failPattern="failures", skipPattern="disabled"){
    script {
        def testResult = [:]
        def xmlResult = [:]
        testResult.total = 0
        testResult.fail = 0
        testResult.skip = 0
        testResult.pass = 0
        testResult.testStatus="SUCCESS"
        def testResults = findFiles(glob: xUnitPattern)
        for (xUnitFile in testResults) {
            try {
                def xmlString = readFile(basepath + xUnitFile)
                def xml = new XmlSlurper().parseText(xmlString)
                xmlResult.total = xml.testsuite.@"$totalPattern".toInteger()
                xmlResult.fail = xml.testsuite.@"$failPattern".toInteger()
                xmlResult.skip = xml.testsuite.@"$skipPattern".toInteger()
                xmlResult.pass = xmlResult.total - xmlResult.fail - xmlResult.skip
                testResult.total += xmlResult.total
                testResult.fail += xmlResult.fail
                testResult.skip += xmlResult.skip
                testResult.pass += xmlResult.pass
                if (xmlResult.fail > 0) {
                    testResult.testStatus="FAILURE"
                }
            } catch (err) {
                print "Error while collecting test results" + err
            }
        }

        return testResult
    }
}


def combineComponentResults(componentResultsList){
    script {
        def componentResultsCombined = [:]
        def jiraIDList = []
        def jiraURLList = []
        def failedStagesList = []
        componentResultsCombined.total = 0
        componentResultsCombined.fail = 0
        componentResultsCombined.skip = 0
        componentResultsCombined.pass = 0
        componentResultsCombined.testStatus="SUCCESS"
        componentResultsCombined.failedStages = ""
        componentResultsCombined.jiraID = ""
        componentResultsCombined.jiraURL = ""
        componentResultsCombined.ruVersion = ""
        componentResultsCombined.executionTime = 0
        if (componentResultsList.size() > 0 )
        {
            for (component in componentResultsList){
                componentResultsCombined.total += component.get('total')
                componentResultsCombined.fail += component.get('fail')
                componentResultsCombined.skip += component.get('skip')
                componentResultsCombined.pass += component.get('pass')
                // The pipeline tests run in parallel so we need to compare the execution time between their tests in the list and select as the maximum time
                if (component.get('executionTime') > componentResultsCombined.executionTime) {
                    componentResultsCombined.executionTime = component.get('executionTime')
                }
                if (component.get('testStatus') == 'FAILURE'){
                    componentResultsCombined.testStatus="FAILURE"
                }
                if (!(component.get('failedStages') in ["", null])) {
                    failedStagesList.add(component.failedStages)
                }
                if (!(component.get('jiraID') in ["", null])) {
                    jiraIDList.add(component.jiraID)
                }
                if (!(component.get('jiraURL') in ["", null])) {
                    jiraURLList.add(component.jiraURL)
                }
                if (!(component.get('ruVersion') in ["", null])) {
                    componentResultsCombined.ruVersion = component.ruVersion
                }
            }
            componentResultsCombined.failedStages = failedStagesList.join(", ")
            componentResultsCombined.jiraID = jiraIDList.join(", ")
            componentResultsCombined.jiraURL = jiraURLList.join(", ")
        }
        else {
            componentResultsCombined.testStatus="FAILURE"
        }
        
        return componentResultsCombined
    }
}


def redirectFromJenkins(def redirectHTMLFile, def targetUrl ) {
    script {
        String redirectHtml = """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta http-equiv="refresh" content="0;URL=${targetUrl}" />
                    <title>Redirecting to artifactory...</title>
                </head>
                <body>
                    <a href="${targetUrl}">Click to go to ${redirectHTMLFile}</a>
                </body>
                </html>
                """
        writeFile file: redirectHTMLFile, text: redirectHtml
        archiveArtifacts redirectHTMLFile
    }
}

def getCTFilterBaseOnChangedModuleInNgpRepo(moduleList){
    script {
        def CT_FILTER = ""
        //Mapping table between Module & TestSuite. https://confluence.cec.lab.emc.com/display/MP/Test+Cases+on+gNB_ngp_ct+pipeline
        def testSuite = ['logging' : 'NGPLoggingTest*',
                         'thread' : 'NGPThreadTest*',
                         'comm' : 'NGPTlsTest*:NGPTlsEpollTest*',
                         'websocket' : 'NGPWebsocket*:NGPHttp*',
                         'mem' : 'NGPMemMonitoringTest*:NGPMemoryTest*:NGPTLPoolTest*',
                         'sys' : 'ExceptionHandling*:NGPSysAllocatorTest*:NGPSysPerfMeasx8664*',
                         'timer' : 'NGPFastTimerTest*:NGPTimerTest*',
                         'buffer' : 'NGPBufferTest*',
                         'json' : 'NGPJsonTest*']
        for (module in moduleList) {
            if (testSuite.containsKey(module)) {
                CT_FILTER = CT_FILTER + testSuite[module] + ":"
            }
            else{
                CT_FILTER = "*"
                break
            }
        }
        //removing extra ":" characters at the end of string.
        CT_FILTER = CT_FILTER.replaceFirst(/:$/, '')
        return CT_FILTER
    }
}

/**
* Get abort cause description when jenkins build is aborted
* @return  abortCause
*/
def getAbortCause(build) {
    def abortCause = ''
    def actions = build.rawBuild.getActions(jenkins.model.InterruptedBuildAction)
    for (action in actions) {
        for (cause in action.getCauses()) {
            abortCause = cause.getShortDescription()
        }
    }
    return abortCause
}


/**
 * Retrieves job information from the downstream pipeline.
 *
 * @param {string} job - The job name to fetch information for.
 * @param {string} component - The component associated with the job.
 * @param {boolean} flagExecutionTime - Optional flag to include execution time in the information.
 *
 * @return {object} job_info - An object containing build information for the specified job and component.
 */
def getMainStreamJobInfo(job, component, flagExecutionTime = false) {
    def job_info = [:]
    job_info['component'] = component
    job_info['componentName'] = job.getProjectName()
    job_info['description'] = job.getDescription()
    job_info['overallStatus'] = job.getResult()
    job_info['url'] = job.getAbsoluteUrl()
    job_info['id'] = job.getId()
    if (flagExecutionTime == true) {
        def executionTime = getExecutionTime(job)
        job_info['executionTime'] = executionTime != null ? executionTime : 0
    }
    return job_info
}

/**
 * Retrieves job information from the mainstream test pipeline.
 *
 * @param {string} tlJob - The Test Lab job name to fetch information for.
 * @param {string} component - The component associated with the test.
 * @param {string} testName - The name of the test to fetch information for.
 *
 * @return {object} test_info - An object containing test information for the specified Test Line job, component, and test name.
 */
def getMainStreamTestInfoFromTL(tlJob, component, testName) {
    script {
        def test_info = getMainStreamJobInfo(tlJob, component)
        test_info.testData = [:]
        test_info.testData.testResults = [:]
        // [MP-99433] Use junitTestResultAction as it counts the skipped test cases. Ensure that we have run the xUnit plugin step in the target job.
        def testResults = getTestResultFromJenkinsJobAction(tlJob, "junitTestResultAction")
        test_info.testData.testResults.putAll(testResults)
        test_info.testData.component = component
        test_info.testData.testName = testName
        test_info.testData.url = tlJob.getAbsoluteUrl()
        def additionalInfo = getMainStreamTestAdditionalInfo(tlJob) // Get failedStages, JiraURL, JiraID
        test_info.testData.testResults.putAll(additionalInfo)

        return test_info
    }
}

// Parse test result from Jenkins xunit object and return a groovy Map of test data
def getTestResultFromXUnitObject(xUnitData){
    script {
        def testResult = [:]
        testResult.total = "${xUnitData.totalCount}".toInteger()
        testResult.fail = "${xUnitData.failCount}".toInteger()
        testResult.skip = "${xUnitData.skipCount}".toInteger()
        testResult.pass = "${xUnitData.passCount}".toInteger()
        if (testResult.fail == 0 && testResult.total > 0) {
            testResult.testStatus="SUCCESS"
        } else {
            testResult.testStatus="FAILURE"
        }
        
        return testResult
    }
}
// Define schedule run for E2E-CI
def scheduleRun(job_name, reset_schedule, remove_single_schedule, date, time, recurrence, job_to_be_triggered, product_test_5g_branch, extra_test_param, enable_qtest_upload, enable_send_email, json_test_config) {
    def parameterizedSpecContent = ""
    def currentDescription = ""
    def item = Jenkins.instance.getItemByFullName(job_name)
    //Reset exist schedule list
    if (!reset_schedule){
        //this block is to get exist configuration
        println "get current list of scheduled runs from description of pipeline"
        currentDescription = item.getDescription()
        println currentDescription

        println "get current list of scheduled runs of pipeline"
        def job = Jenkins.instance.getItem(job_name)
        def configXml = job.getConfigFile().asString()
        def root = new XmlSlurper().parseText(configXml)
        parameterizedSpecContent = root.'**'.find { it.name() == 'parameterizedSpecification' }?.text()

        if (parameterizedSpecContent) {
            println "Parameterized Specification Content for ${job_name}:"
        } else {
            println "No parameterizedSpecification found in the configuration."
            parameterizedSpecContent = ""
        }
        println parameterizedSpecContent

        //remove single scheduled run from the exist list.
        if (remove_single_schedule){
            def scheduleList = currentDescription.split("\n")
            for (line in scheduleList) {
                def singleSchedule = line.split(" ->crontab ")
                if (remove_single_schedule == singleSchedule[0]){
                    def temp = singleSchedule[1].replace("[", "").replace("]", "")
                    parameterizedSpecContent = parameterizedSpecContent.replace(temp, "").replace("\n\n", "\n").trim()
                    currentDescription = currentDescription.replace(line, "").replace("\n\n", "\n").trim()
                    break
                }
            }
        }
    }

    println "add new scheduled runs"
    def addNewScheduledRuns = ""
    def addNewScheduledRunsForDescription = ""
    if (date && time){
        def inputDateAndTime = "${date} ${time}"
        def cron_tab_define = convertToCronTabFormat(inputDateAndTime, recurrence)
        addNewScheduledRuns = "\n" + "${cron_tab_define} % JOB_TO_BE_TRIGGERED=${job_to_be_triggered}; DATE=${date}; RECURRENCE=${recurrence}; PRODUCT_TEST_5G_BRANCH=${product_test_5g_branch}; EXTRA_TEST_PARAM=${extra_test_param}; ENABLE_QTEST_UPLOAD=${enable_qtest_upload}; ENABLE_SEND_EMAIL=${enable_send_email}; JSON_TEST_CONFIG=${json_test_config}"
        addNewScheduledRunsForDescription = "\n" + "[Date: ${inputDateAndTime}, Recurrence: ${recurrence}]" + " ->crontab " + "[${cron_tab_define} % JOB_TO_BE_TRIGGERED=${job_to_be_triggered}; DATE=${date}; RECURRENCE=${recurrence}; PRODUCT_TEST_5G_BRANCH=${product_test_5g_branch}; EXTRA_TEST_PARAM=${extra_test_param}; ENABLE_QTEST_UPLOAD=${enable_qtest_upload}; ENABLE_SEND_EMAIL=${enable_send_email}; JSON_TEST_CONFIG=${json_test_config}]"
    }
    parameterizedSpecContent = "${parameterizedSpecContent}${addNewScheduledRuns}".trim()
    currentDescription = "${currentDescription}${addNewScheduledRunsForDescription}".trim()

    println "Display new list of scheduled runs on description field"
    item.setDescription("${currentDescription}") 
    item.save()

    if(parameterizedSpecContent == '') {
        println "The schedule is removed successfully."
    } else {
        println "The schedule is setup successfully."
    }

    return parameterizedSpecContent
}

// Get failedStages, JiraID and JiraURL from downstream of component mainstream_test
def getMainStreamTestAdditionalInfo(job, flagExecutionTime = true){
    def additionalInfo = [:]
    def jobBuildVariables = job.getBuildVariables()
    additionalInfo.failedStages = jobBuildVariables.failedStages != null ? jobBuildVariables.failedStages : ""
    additionalInfo.jiraID = jobBuildVariables.jiraaIssueRefe != null ? jobBuildVariables.jiraaIssueRefe : ""
    additionalInfo.jiraURL = jobBuildVariables.jiraaIssueRefefUrl != null ? jobBuildVariables.jiraaIssueRefefUrl : ""
    additionalInfo.ruVersion = jobBuildVariables.ruVersion != null ? jobBuildVariables.ruVersion : ""
    additionalInfo.ruBaseline = jobBuildVariables.RU_BASELINE != null ? jobBuildVariables.RU_BASELINE : ""
    additionalInfo.ruAlbus = jobBuildVariables.RU_ALBUS != null ? jobBuildVariables.RU_ALBUS : ""
    additionalInfo.ruFoxconn = jobBuildVariables.RU_FOXCONN != null ? jobBuildVariables.RU_FOXCONN : ""
    if (flagExecutionTime == true) {
        def executionTime = getExecutionTime(job)
        additionalInfo.executionTime = executionTime != null ? executionTime : 0
    }

    return additionalInfo
}

// Get execution time for the downstream jobs of TL CT pipeline
def getContinuousTestAdditionalInfo(job, flagExecutionTime = true){
    def additionalInfo = [:]
    if (flagExecutionTime == true) {
        def executionTime = getExecutionTime(job)
        additionalInfo.executionTime = executionTime != null ? executionTime : 0
    }
    return additionalInfo
}

// Get time execution from downstream job of component mainstream_test
def getExecutionTime(def runWrapper) {
    script {
        def timeExecution = null
        try {
            def action = null
            if (runWrapper != null) {
                action = runWrapper.rawBuild.getAction(jenkins.metrics.impl.TimeInQueueAction.class)
                if (action != null) {
                    timeExecution = action.getBuildingDurationMillis()
                }
            }
        }
        catch (err) {
            print "Error while collecting time execution" + err
        }
        println "Execution time: ${timeExecution}"
        return timeExecution
    }
}

// Get test results and additional info (Jira ID, Jira URL) of component mainstream test
def getMainstreamTestResultFromJenkinsJobAction(def runWrapper, jenkinsActionClassName = "junitTestResultAction", flagExecutionTime = true){
    script {
        def result = [:]

        // Get test results from Jenkins job action
        def testResult = getTestResultFromJenkinsJobAction(runWrapper, jenkinsActionClassName)

        // Get additional info: failedStages, JiraURL, JiraID
        def additionalInfo = getMainStreamTestAdditionalInfo(runWrapper, flagExecutionTime)

        result.putAll(testResult)
        result.putAll(additionalInfo)

        return result
    }
}

/**
* Collect and display scheduled run list
* @return  list of schedued run
*/
def collectAndDisplayScheduledRunList(job_name, reset_scheduled_runs, remove_single_scheduled_run, date, time, recurrence, job_to_be_trigger, tl_name, product_test_5g, robot_test_param, extra_test_param, enabled_upload_qtest, qtest_contener_id, qtest_container_type, timeout, jenkins_agent_label) {
    def parameterizedSpecContent = ""
    def currentDescription = ""
    def item = Jenkins.instance.getItemByFullName(job_name)
    //Reset exist schedule list
    if (!reset_scheduled_runs){
        //this block is to get exist configuration
        println "get current list of scheduled runs from description of pipeline"
        currentDescription = item.getDescription()
        println currentDescription

        println "get current list of scheduled runs of pipeline"
        def job = Jenkins.instance.getItem(job_name)
        def configXml = job.getConfigFile().asString()
        def root = new XmlSlurper().parseText(configXml)
        parameterizedSpecContent = root.'**'.find { it.name() == 'parameterizedSpecification' }?.text()

        if (parameterizedSpecContent) {
            println "Parameterized Specification Content for ${job_name}:"
        } else {
            println "No parameterizedSpecification found in the configuration."
            parameterizedSpecContent = ""
        }
        println parameterizedSpecContent

        //remove single scheduled run from the exist list.
        if (remove_single_scheduled_run){
            def scheduleList = currentDescription.split("\n")
            for (line in scheduleList) {
                def singleSchedule = line.split(" ->crontab ")
                if (remove_single_scheduled_run == singleSchedule[0]){
                    def temp = singleSchedule[1].replace("[", "").replace("]", "")
                    parameterizedSpecContent = parameterizedSpecContent.replace(temp, "").replace("\n\n", "\n").trim()
                    currentDescription = currentDescription.replace(line, "").replace("\n\n", "\n").trim()
                    break
                }
            }
        }
    }

    println "add new scheduled runs"
    def addNewScheduledRuns = ""
    def addNewScheduledRunsForDescription = ""
    if (date && time){
        def inputDateAndTime = "${date} ${time}"
        def cron_tab_define = convertToCronTabFormat(inputDateAndTime, recurrence)
        addNewScheduledRuns = "\n" + "${cron_tab_define} % JOB_TO_BE_TRIGGERED=${job_to_be_trigger}; DATE=${date}; RECURRENCE=${recurrence}; TL_NAME=${tl_name}; PRODUCT_TEST_5G_BRANCH=${product_test_5g}; ROBOT_TEST_PARAM=${robot_test_param}; EXTRA_TEST_PARAM=${extra_test_param}; ENABLE_QTEST_UPLOAD=${enabled_upload_qtest}; QTEST_CONTAINER_ID=${qtest_contener_id}; QTEST_CONTAINER_TYPE=${qtest_container_type}; TIMEOUT=${timeout}; JENKINS_AGENT_LABEL=${jenkins_agent_label}"
        addNewScheduledRunsForDescription = "\n" + "[Date: ${inputDateAndTime}, Recurrence: ${recurrence}]" + " ->crontab " + "[${cron_tab_define} % JOB_TO_BE_TRIGGERED=${job_to_be_trigger}; DATE=${date}; RECURRENCE=${recurrence}; TL_NAME=${tl_name}; PRODUCT_TEST_5G_BRANCH=${product_test_5g}; ROBOT_TEST_PARAM=${robot_test_param}; EXTRA_TEST_PARAM=${extra_test_param}; ENABLE_QTEST_UPLOAD=${enabled_upload_qtest}; QTEST_CONTAINER_ID=${qtest_contener_id}; QTEST_CONTAINER_TYPE=${qtest_container_type}; TIMEOUT=${timeout}; JENKINS_AGENT_LABEL=${jenkins_agent_label}]"
    }
    parameterizedSpecContent = "${parameterizedSpecContent}${addNewScheduledRuns}".trim()
    currentDescription = "${currentDescription}${addNewScheduledRunsForDescription}".trim()

    println "Display new list of scheduled runs on description field"
    item.setDescription("${currentDescription}") 
    item.save()

    if(parameterizedSpecContent == '') {
        println "The schedule is removed successfully."
    } else {
        println "The schedule is setup successfully."
    }

    return parameterizedSpecContent
}

/**
* input: dateTime (yyyy-MM-dd HH:mm) and recurrence (weekyly/daily/once)
* @return  crontab format
*/
def convertToCronTabFormat(inputDateAndTime, recurrence){
    def dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm")
    Date parsedDate = dateFormat.parse(inputDateAndTime)
    
    Calendar calendar = Calendar.getInstance()
    calendar.setTime(parsedDate)
    int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK) - 1 // The day of the week of crontab is (0–7) where 0 and 7 are Sunday, smaller than Calendar one unit.
    
    def cronFormat
    if (recurrence == "weekly") {
        cronFormat = new SimpleDateFormat("mm HH * * " + String.valueOf(dayOfWeek))
    } else if (recurrence == "daily") {
        cronFormat = new SimpleDateFormat("mm HH * * *")
    } else {
        cronFormat = new SimpleDateFormat("mm HH dd MM *")
    }

    return cronFormat.format(parsedDate)     
}

/** this function to cover 2 cases below:
* start a weekly/daily schedule from a specific day, but not the day configured
* schedule run for only one time
*/
boolean checkRunDate(inputDate, recurrence) {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd")
    Date currentDate = new Date()
    
    Date parsedInputDate = dateFormat.parse(inputDate)
    currentDate = dateFormat.parse(dateFormat.format(currentDate))
    parsedInputDate = dateFormat.parse(dateFormat.format(parsedInputDate))
    
    if (recurrence == "weekly" || recurrence == "daily") {
        //the current day must equal or after.
        return currentDate >= parsedInputDate
    } else {
        return currentDate == parsedInputDate
    }
}

/**
* Collect RU IP from E2E Lab
* @return RU IP (string) or ""
*/

def getRuIPFromE2E(remoteServer) {
    script {
        ruIP = ""
        def getRUIPCommand = """
            curl -X POST -H "Content-Type: application/json" -d '{ "command": "lease4-get-all", "service": [ "dhcp4" ] }' http://localhost:8000 | jq . \
            | perl -nle 'if (/192\\.168\\.0\\.(\\d{1,3})/ && \$1 >= 0 && \$1 <= 254) { print "192.168.0.\$1"; last; }'
        """

        try {
            getRUIPResultStr= sshCommand remote: remoteServer, command: getRUIPCommand, failOnError: false
            // Get RU IP from command result
            if (getRUIPResultStr) {
                ruIP = getRUIPResultStr
            }
        } 
        catch (Exception e){
            println("Error occurred while get RuIP in remote server: ${e.message}")
        }

        return ruIP
    }
}

/**
* Bring up DU in E2E Lab
*/
def bringUpDUInRemoteServer(remoteServer) {
    script {
        // Command for start DU
        def startDUCommand = "/opt/gnb/du_marvell/bin/start_du_marvell"

        // Check "sync_status {}" in log file
        def checkDUStatusCommand = """cat /tmp/bring_up_du_log.txt | grep "sync_status {" || true"""

        // DU and Mplane bring up, run in background, add logs to /tmp/bring_up_du_log.txt
        sshCommand remote: remoteServer, command: "${startDUCommand} > /tmp/bring_up_du_log.txt 2>&1 &", failOnError: false, sudo : true
        try {
            timeout(time: 5, unit: 'MINUTES') {
                while (true) {
                    // Check the log file has the text "sync_status {}" or not
                    def checkDUStatusResult = sshCommand remote: remoteServer, command: checkDUStatusCommand, failOnError: false
                    if (checkDUStatusResult != "") {
                        echo "Found 'sync_status {}' in console log. Proceeding to the next step."
                        return true
                    } else {
                        sleep(30)
                    }
                }
            }
        } catch (Exception e) {
            echo "Timeout waiting for 'sync_status {}' in console log."
            return false
        }
    }
}

/**
* Collect RU version from E2E Lab
* @return RU version (string) or null
* This function is almost executed on remote server
* Limit timeout to prevent stuck in case of no response from remote server
*/
def getRuVersionFromE2E(remoteHost, remoteUsername, remotePassword) {
    script{
        timeout(time: 20, unit: 'MINUTES') {
            def remoteServer = [:]
            remoteServer.name = 'du-remote-server'
            remoteServer.host = remoteHost
            remoteServer.user = remoteUsername
            remoteServer.password = remotePassword
            remoteServer.allowAnyHosts = true
            
            def commandResultStr = null
            def ruVersion = null
            
            // Command for stop DU process in server
            def cleanProcessCommand = """
                sudo pkill -9 -f /gnb
            """
            
            // Bring up DU in E2E Lab
            bringUpDUInRemoteServer(remoteServer)
            
            // Collect RU IP from E2E Lab
            ruIP = getRuIPFromE2E(remoteServer)
            if (ruIP == "") {
                println("Unable to get RU IP on remote server")
                return ruVersion
            }
            
            //  Run command in remote server for check RU Version
            def getRUVersionCommand = """
                /data/confd-basic-7.3.3.linux.x86_64/confd/bin/netconf-console \
                --host=${ruIP} \
                --port=830 \
                --user=root \
                --pass=root \
                --get -x //component[1]/software-rev \
                | perl -0777 -ne 'if (/<software-rev>(.*?)<\\/software-rev>/s) { print "\$1\\n"; exit; }'
            """
            try {
                commandResultStr = sshCommand remote: remoteServer, command: getRUVersionCommand, failOnError: false
                // Get RU Version from command result
                if (commandResultStr) {
                    ruVersion = commandResultStr
                }
            } 
            catch (Exception e){
                println("Error occurred while get RU Version in remote server: ${e.message}")
            } finally {
                // Stop process of DU
                // Remove log file
                sshCommand remote: remoteServer, command: cleanProcessCommand, failOnError: false, sudo : true
                sshCommand remote: remoteServer, command: 'rm -f /tmp/bring_up_du_log.txt || true', failOnError: false
            }
            return ruVersion
        }
    }
}

/**
* Build Info Continuous Test Json
*/
def buildInfoContinuousTesting(tlJob, deploy, smokeTest, extraJob) {
    script {
        def build_info = [:]
        build_info.stages = []
        build_info.deployResults = []
        build_info.testResults = []
        def testInfo = [:]
        def deployInfo = [:]

        if (tlJob) {
            if (deploy) {
                build_info.stages << "deploy"
                if ( getTLResultsFromParams(tlJob, "deploymentStatus") != "Deployed") {
                    deployInfo.deploymentStatus = "FAILED"
                } else {
                    deployInfo.deploymentStatus = "SUCCESS"
                }
                deployInfo.url = tlJob.getAbsoluteUrl()
            } else {
                deployInfo.deploymentStatus = "SKIP"
                deployInfo.url = "-"
            }
            build_info.deployResults.add(deployInfo)
            if (smokeTest) {
                smokeTestResults = [:]
                smokeTestResults.total = getTLResultsFromParams(tlJob, "totaltests")
                smokeTestResults.pass = getTLResultsFromParams(tlJob, "testpass")
                smokeTestResults.fail = getTLResultsFromParams(tlJob, "testfail")
                smokeTestResults.executiontime = getTLResultsFromParams(tlJob, "executiontime")
                testInfo.smokeTest = [:]
                testInfo.smokeTest.testType = "smokeTest"
                testInfo.smokeTest.testResults = [:]
                testInfo.smokeTest.overallstatus = tlJob.getResult()
                testInfo.smokeTest.url = tlJob.getAbsoluteUrl()
                testInfo.smokeTest.testResults.putAll(smokeTestResults)
                build_info.testResults.add(testInfo.smokeTest)
                build_info.stages << "smoke_test"
            }
        }
        if (extraJob) {
            def data_json = getExtraJsonFromArtifact(extraJob)
            def additionalInfo_extraJob = getContinuousTestAdditionalInfo(extraJob)
            if (data_json) {
                extraTestResults = [:]
                extraTestResults.total = data_json.total
                extraTestResults.pass = data_json.pass
                extraTestResults.fail = data_json.fail
                extraTestResults.executiontime = additionalInfo_extraJob.executionTime
                testInfo.extraTests = [:]
                testInfo.extraTests.testType = "extraTests"
                testInfo.extraTests.testResults = [:]
                testInfo.extraTests.overallstatus = extraJob.getResult()
                testInfo.extraTests.url = extraJob.getAbsoluteUrl()
                testInfo.extraTests.testResults.putAll(extraTestResults)
                build_info.testResults.add(testInfo.extraTests)
                build_info.stages << "extra_tests"
            }
        }
        return build_info
    }
}

def getExtraJsonFromArtifact(job) {
    node('jira-generic') {
        script {
            def urljob = job.getAbsoluteUrl()
            def buildid = job.getId()
            String artifactUrl = urljob + "artifact/robot-result.json"
            withCredentials([usernamePassword(credentialsId: 'svc_npmphran', passwordVariable: 'password', usernameVariable: 'username')]) {
                sh """
                   curl -u \$username:\$password --location -g --request GET -s "${artifactUrl}" > testResults${buildid}.json
                """
            }
            jsonResult = readJSON file: """testResults${buildid}.json"""
        }
        cleanWs()
        return jsonResult
    }
}

def getBlockTestCase(tlName, type, dayOfWeek, product_test_5g_branch="main") {
    node('jira-generic') {
        def robotCommandList = []
        script {
            cleanWs()
            withCredentials([string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
                sh """
                    git clone -b ${product_test_5g_branch} https://${GITHUB_TOKEN}@eos2git.cec.lab.emc.com/Mobile-Phoenix/product_test_5g.git product_test_5g
                """
            }
            
            try{
                def blockTestCaseJson = readJSON file: "${env.WORKSPACE}/product_test_5g/resources/CT_Daily/${type}/${tlName}.json"
                blockTestCaseJson?.each { block ->
                    block.period?.each { day ->
                        if (day == dayOfWeek.toString()){
                            block.test_script?.each { script ->
                                def robotCommand = ""
                                script.test_cases?.each { testcase ->
                                    robotCommand += " -t ${testcase}"
                                }
                                robotCommand += " ${script.name}"
                                robotCommandList.add(robotCommand)
                            }

                            
                        }
                    }
                }
            } catch (Exception error) {
                println "${error}"
            }
        }
        return robotCommandList
    }
}

def getTLResultsFromParams(job, item) {
    def getValue = null
    def pairs = job.buildVariables.pipelineParams.replaceAll(/^\{|\}$/,'').split(', ')
    pairs.each { pair ->
        def parts = pair.split('=')
        if (parts.size() == 2) {
            def key = parts[0].trim()
            def value = parts[1].trim()
            if (key == item) { getValue = value }
        }
    }
    return getValue
}

def collectChurnStatisticsInfo(repo, branch, latestCommit, branchPointCommit, releaseName, isBranchPointCollected = false, preReleaseName = "") {
    script {
        sh """
            cd "${repo}_${releaseName}"
            podman run --privileged --rm -v "${WORKSPACE}/${repo}_${releaseName}":/tmp aldanial/cloc:1.96 --git --count-and-diff "$branchPointCommit" "$latestCommit" --out="results/${repo}_${releaseName}/" --timeout 300
            echo "Collect results"
            find "results/${repo}_${releaseName}" -type f -exec cat {} \\;
            mv "results/${repo}_${releaseName}/.$latestCommit" "results/${repo}_${releaseName}/LOC_${repo}_${releaseName}.txt"
            if [ "$isBranchPointCollected" = true ]; then
                mv "results/${repo}_${releaseName}/.$branchPointCommit" "results/${repo}_${releaseName}/LOC_${repo}_Branch_Point_${preReleaseName}_${releaseName}.txt"
            fi
            
            if [ -f "results/${repo}_${releaseName}/.diff.$branchPointCommit.$latestCommit" ]; then
                mv "results/${repo}_${releaseName}/.diff.$branchPointCommit.$latestCommit" "results/${repo}_${releaseName}/Churn_${repo}_${releaseName}.txt"
                add_comment="\\n${releaseName} Branchpoint SHA:  $branchPointCommit \\n ${releaseName} Latest SHA: $latestCommit \\n \\n ${releaseName} Churn Statictics (from ${releaseName} branchpoint):  \n"
                echo -e \$add_comment | cat - "results/${repo}_${releaseName}/Churn_${repo}_${releaseName}.txt" > temp && mv temp "results/${repo}_${releaseName}/Churn_${repo}_${releaseName}.txt"
            else
                echo "Nothing changed from ${releaseName} Branch point: $branchPointCommit to latest: $latestCommit on ${repo}_${releaseName}"
            fi
            cp -r "results/${repo}_${releaseName}/" "${WORKSPACE}/results/"
        """
    }   
}

/**
 * This function gets the branch point commit for a given release branch. It 
 * takes into account the previous release branch and the latest commit time
 * to determine the correct branch point.
 * @param cur_release_branch The current release branch
 * @param next_release_branch The next release branch
 * @param prev_release_branch The previous release branch
 * @param git_path The path to the git repository
 * @param prev_branchpoint_commit The previous branch point commit
 * @param prev_latest_commit The latest commit time of the previous release
 * @return The branch point commit
 */
def getChurnBranchPointCommit(cur_release_branch, next_release_branch, prev_release_branch, git_path, prev_branchpoint_commit="", prev_latest_commit="") {
    def branchPointCommit = ""
    // Check if the current release branch is different from the next release branch
    if(cur_release_branch != next_release_branch && next_release_branch != "") {
        // If the previous release branch is empty, use the merge-base command to find the branch point commit
        if(prev_release_branch == "") {
            branchPointCommit = sh(returnStdout: true, script:""" 
                cd "${git_path}"
                git checkout ${next_release_branch}; git checkout ${cur_release_branch}
                git merge-base ${cur_release_branch} ${next_release_branch}
                """).trim().split("\n")[-1]
        } else if (cur_release_branch == prev_release_branch) {
            // If the current release branch is the same as the previous release branch, use the latest commit time of the previous release
            branchPointCommit = prev_latest_commit
        } else {
            // Otherwise, use the previous branch point commit
            branchPointCommit = prev_branchpoint_commit
        }
    } else {
        if (prev_branchpoint_commit != "" || prev_latest_commit != "") {
            if(cur_release_branch == prev_release_branch) {
                // If the current release branch is the same as the previous release branch, use the latest commit time of the previous release
                branchPointCommit = prev_latest_commit
            } else {
                // Otherwise, use the previous branch point commit
                branchPointCommit = prev_branchpoint_commit
            }
        } else {
            // If neither the previous branch point commit nor the latest commit time of the previous release are available, use the latest commit of the repository
            branchPointCommit = sh(returnStdout: true, script:""" 
                cd "${git_path}"
                git log --reverse --format="%H" | head -n 1
                """).trim().split("\n")[-1]
        }
    }
    
    return branchPointCommit
}

/**
 * This function gets the latest commit of the repository. It takes into account 
 * the current and next release branches and the previous release branch.
 * @param cur_release_branch The current release branch
 * @param next_release_branch The next release branch
 * @param prev_release_branch The previous release branch
 * @param git_path The path to the git repository
 * @param prev_latest_commit The latest commit time of the previous release
 * @param latestCommitTime The latest commit time
 * @return The latest commit of the repository
 */
def getChurnLatestCommit(cur_release_branch, next_release_branch, prev_release_branch, git_path, prev_latest_commit="", latestCommitTime="") {
    def latestCommit = ""
    // Check if the current release branch is different from the next release branch
    if (cur_release_branch != next_release_branch) {
        if (prev_release_branch == "") {
            // If the previous release branch is empty, use the latest commit of the repository
            latestCommit = sh(returnStdout: true, script:"""
                cd "${git_path}"
                git log -n 1 --format="%H"
                """).trim().split("\n")[-1]
        } else if (cur_release_branch == next_release_branch) {
            // If the current release branch is the same as the next release branch, use the latest commit until a given time
            latestCommit = sh(returnStdout: true, script:"""
                cd "${git_path}"
                git log --until="${latestCommitTime}" --date-order --format="%H" | head -1
                """).trim().split("\n")[-1]
        } else {
            // Otherwise, use the latest commit of the repository
            latestCommit = sh(returnStdout: true, script:"""
                cd "${git_path}"
                git log -n 1 --format="%H"
                """).trim().split("\n")[-1]
        }
    } else if (next_release_branch != "") {
        // If the current release branch is the same as the next release branch, use the latest commit until a given time
        latestCommit = sh(returnStdout: true, script:"""
            cd "${git_path}"
            git log --until="${latestCommitTime}" --date-order --format="%H" | head -1
            """).trim().split("\n")[-1]
    } else {
        // Otherwise, use the latest commit of the repository
        latestCommit = sh(returnStdout: true, script:"""
            cd "${git_path}"
            git log -n 1 --format="%H"
            """).trim().split("\n")[-1]
    }

    return latestCommit
}

@NonCPS
def convertTimestampToDate(timestamps, pattern="yyyy-MM-dd'T'HH:mm:ss'Z'") {
    def convertedDate = ""
    def dateObject = new Date(timestamps)
    use (groovy.time.TimeCategory) {
        convertedDate = dateObject.format(pattern)
        println "Date Converted: " + convertedDate
    }
    return convertedDate
}

def pushELK(def inputMap, def index, def id) {
    println("inputMap: " + inputMap)
    // Convert map to json
    jsonResult = JsonOutput.prettyPrint(JsonOutput.toJson(inputMap))
    println "Data converted for ES integration...."
    writeFile(file: "${env.WORKSPACE}/esdoc.json", text: jsonResult)
    EStelemetry("${env.WORKSPACE}/esdoc.json", index, id)
}

/**
* Define getRepoContent function
*/
String getRepoContent(String baseUrl, String gpgcheck, String repoName, String mp_cred_password, String mp_cred_username) {
    return """
|[gnb-rpm]
|baseurl = ${baseUrl}
|enabled = 1
|gpgcheck = ${gpgcheck}
|metadata_expire = 1
|name = ${repoName}
|password = ${mp_cred_password}
|username = ${mp_cred_username}
""".stripMargin()
}

/**
* Define provideKeyFiles function to get the rpm key file from the Artifactory
*/
def provideKeyFiles(String artifactoryRepo, String credentialsId, String targetPath, String filename) {
        def repoKeyPath = "${targetPath}/${filename}"
        // Ensure the directory exists before trying to download the file
        sh "mkdir -p ${targetPath}"
        
        // Use credentials to download the key file
        withCredentials([string(credentialsId: 'svc_npmphran_apikey', variable: 'SVC_NPMPHRAN_API_TOKEN')]){
            // Use curl with credentials to download the key file
            sh """
            curl -H "Authorization: Bearer ${SVC_NPMPHRAN_API_TOKEN}" -o ${repoKeyPath} ${artifactoryRepo}/mobile-phoenix-rpm-green_load/${filename}
            """
        }
}

/**
* Define provideKeyFiles function to get the rpm key file from the Artifactory
* Use for multistream feature, we will retire the 'provideKeyFiles' soon (only keep it to support mainstream activities)
*/
def provideKeyFilesMultistream(String artifactoryRepo, String repoName, String credentialsId, String targetPath, String filename) {
        def repoKeyPath = "${targetPath}/${filename}"
        // Ensure the directory exists before trying to download the file
        sh "mkdir -p ${targetPath}"

        // Use credentials to download the key file
        withCredentials([string(credentialsId: 'svc_npmphran_apikey', variable: 'SVC_NPMPHRAN_API_TOKEN')]){
            // Use curl with credentials to download the key file
            sh """
            curl -H "Authorization: Bearer ${SVC_NPMPHRAN_API_TOKEN}" -o ${repoKeyPath} ${artifactoryRepo}/${repoName}/${filename}
            """
        }
}

/**
* Convert summary text file to JSON format
*/
String convertRpmListToJson(script, String summaryFilePath) {
    def summaryText = script.readFile(summaryFilePath)
    def packagesMap = [:]

    summaryText.readLines().each { line ->
        if (line.startsWith('Installed:')) {
            def packageWithVersion = line.replaceFirst(/Installed:\s+/, '').trim()
            // Match the package name up to the last two hyphens
            // The assumption here is that the architecture will not contain hyphens
            def lastHyphenIndex = packageWithVersion.lastIndexOf('-')
            def secondLastHyphenIndex = packageWithVersion[0..<(lastHyphenIndex-1)].lastIndexOf('-')
            def packageName = packageWithVersion.substring(0, secondLastHyphenIndex)
            def versionArch = packageWithVersion.substring(secondLastHyphenIndex + 1)
                
            // Store the package name and version/architecture in the map
            packagesMap[packageName] = versionArch        
        }
    }
    // Check if the packages map is empty
    if (packagesMap.isEmpty()) {
        script.echo "No RPM packages were parsed from the summary file."
        return null
    }
    // Convert the map to a JSON string
    def jsonOutput = JsonOutput.toJson(packagesMap)

    // Define the JSON filename
    def jsonFileName = 'greenload.json'

    // Write the JSON output to a file
    script.writeFile(file: jsonFileName, text: jsonOutput)

    // Return the name of the JSON file
    return jsonFileName
}
/**
* Create two functions: getVersion and transformVersion with the aim of refactoring the MultiStream_Test
*/
def getVersion(env, component, repo, streamMetadata, GitHub) {
        def componentVersion = "${component}_VERSION"
        if (!env."$componentVersion") {
            def componentKey = component.toLowerCase()
            def componentData = streamMetadata.components[componentKey]
            // Directly retrieve the pattern from the metadata using the component key
            def componentTagPattern = componentData?.sem_pattern
            if (componentTagPattern) {
                env."$componentVersion" = GitHub.getLatestTagWithPattern(targetRepo: repo, tagPattern: componentTagPattern)
            } else {
                println("Tag pattern for $component is missing!")
            }
        }
        return componentVersion
}

String convertSimpleRpmListToJson(String rpmList) {
    def packagesMap = [:]

    rpmList.split('\n').each { line ->
        line = line.replaceAll('\\.x86_64$', '')
        // Now split based on hyphens to separate package name from version
        def parts = line.tokenize('-')
        if (parts.size() > 1) {
            String versionArch = parts.pop()  // Remove the last part which is version
            String lastVersionPart = parts.pop()  // Remove the second last part which could be part of version
            String packageName = parts.join('-')  // Join the remaining parts as the package name
            String version = lastVersionPart + '-' + versionArch + ".x86_64"  // Reconstruct version with architecture
            packagesMap[packageName] = version
        }    
    }

    if (packagesMap.isEmpty()) {
        println("No RPM packages found.")
        return null
    }

    def jsonOutput = JsonOutput.toJson(packagesMap)
    def jsonFileName = 'greenload.json'
    writeFile(file: jsonFileName, text: jsonOutput)
    return jsonFileName
}

def transformVersion(env, component, rpmTransform) {
    def componentVersion = "${component}_VERSION"
    def rpmVersion = "${component}_VERSION_RPM"
    if (env."$componentVersion") {
        switch (rpmTransform) {
            case 'l1':
                env."$rpmVersion" = env."$componentVersion".replace("_", "-")
                println("Transformed ${componentVersion} to ${rpmVersion}: ${env."$rpmVersion"}")
                break
            case 'l1dr':
                env.L1_HOST_DRIVERS_VERSION_RPM = env."$componentVersion".replace("_", "-")
                println("Transformed ${componentVersion} to L1_HOST_DRIVERS_VERSION_RPM: ${env.L1_HOST_DRIVERS_VERSION_RPM}")
                break
            case 'l1fw':
                env.L1_MINERVA_VERSION_RPM = env."$componentVersion".replace("v", "")
                println("Transformed ${componentVersion} to L1_MINERVA_VERSION_RPM: ${env.L1_MINERVA_VERSION_RPM}")
                break
            case 'basic':
                env."$rpmVersion" = env."$componentVersion".split("_", 2)[1]?.replaceAll("_", "-") ?: ""
                println("Transformed ${componentVersion} to ${rpmVersion}: ${env."$rpmVersion"}")
                break
        }
    }
}
def triggerTestJob(component, details, streamMetadata, env, params, pipelineParams, successfulBuildComponents) {
    if (!params."SKIP_${component}_TEST" && component in successfulBuildComponents) {
        def streamTestJob = streamMetadata.stream_job_name[details.jobName]
        println "Triggering job: ${streamTestJob}"
        def buildParams = [
            string(name: "STREAM_NAME", value: "${streamMetadata.stream_name}"),
            string(name: "SHARED_LIB_BRANCH", value: SHARED_LIB_BRANCH),
            string(name: "QTEST_CONTAINER_ID", value: env.QTEST_CONTAINER_ID),
            booleanParam(name: 'ENABLE_JIRA_CREATION', value: params.ENABLE_JIRA_CREATION),
            booleanParam(name: 'ENABLE_QTEST_UPLOAD', value: params.ENABLE_QTEST_UPLOAD)
        ]
        if (details.versionParam) {
            buildParams << string(name: details.versionParam, value: env[details.versionParam])
        }
        if (details.rpmParam) {
            buildParams << string(name: details.rpmParam, value: env[details.rpmParam])
        }
        if (details.extraParams) {
            buildParams.addAll(details.extraParams)
        }

        def testResult = build job: streamTestJob, parameters: buildParams, propagate: false
        // Add test information for the component's mainstream test
        def testInfo = getMainStreamJobInfo(testResult, component)
        pipelineParams.testStages.add(testInfo)
        if (testResult.getResult() != 'SUCCESS') {
            error("Downstream ${streamTestJob} failed!")
        }
    }
}
return this
