package common
import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import groovy.json.*
import org.apache.http.util.EntityUtils

/**
 * This class contains functions that access the blackduck api to conduct various tasks such as authenticating and downloading a report
*/

/**
* Generates a sorted CVE report based on existing CVE reports only. DOes not generate a new one
* @param  bearer    Specify a bearer token to be able to authenticate the black duck call. Can be obtained from another method
* @param  url      Specify the url that include the project version and id
* @param  output   Specify the output path within the workspace that the sorted json file will be added to
*/
def CVESearching(bearer,url,output){
    def link = "${url}/vulnerable-bom-components"

    sh """
    curl -L -k --location '${link}?limit=800' \
        --header 'Authorization: Bearer ${bearer}' \
        --header 'Accept: application/vnd.blackducksoftware.bill-of-materials-6+json' \
        --output ${output}/CVE.json
    ls -lah ${output}
    """
    // Read the JSON file
    def jsonText = readFile("${output}/CVE.json")

    // Parse the JSON data
    def data = new JsonSlurperClassic().parseText(jsonText)
    println("data: ${data}")
    println("items: ${data.items}")
    def sortedData = data.items.sort { it.vulnerabilityWithRemediation.baseScore }
    println("sorted: ${sortedData}")
    def sortedoutput = new JsonSlurperClassic().parseText(jsonText)
    sortedData.each { obj ->
        println("obj: ${obj}")
        sortedoutput.items.add(obj)}
    def sortedJsonText = JsonOutput.prettyPrint(JsonOutput.toJson(sortedoutput))
    println("sorted: ${sortedJsonText}")
    writeFile(file: "${output}/sorted_CVE.json", text: sortedJsonText)
}
/**
* Generates a temporary bearer token that can be used to send API requests to blakcduck
* @param  token     Specify a user generated token from the blackduck UI 
*/
def authenticateBlackDuck(token){
	def client = new RESTClient('https://blackduck.pas.sro.dell.com/api/tokens/authenticate')

	def authToken = token

	def requestHeader = [
		'Authorization': "token ${authToken}",
		'Accept': 'application/vnd.blackducksoftware.user-4+json'
	]

	def response = client.post(
		headers: requestHeader

	)
	def jsonSlurper = new JsonSlurper()
    def responseBodyMap = jsonSlurper.parse(response.getData())

    // Get the value of a specific key from the response body map
    def bearer = responseBodyMap['bearerToken']
	return bearer
}

/**
* Generates a BlackDuck SBOM Report
* @param  bearer    Specify a bearer token to be able to authenticate the black duck call. Can be obtained from another method
* @param  href     Specify the link for the project and version for which the SBOM will be generated
* @param  report_format     Specify the format of the report that will be generated default JSON
* @param  sbom_type   Specify the type of sbom that will be generated
*/
def createBlackDuckReport(bearer,href, report_format = 'JSON', sbom_type = 'SPDX_22'){
  def client = new RESTClient("${href}/sbom-reports")
	def requestHeaders = [
		'Authorization': "Bearer ${bearer}"     
    ]   

	def requestBody = [
		reportFormat: report_format,
		sbomType: sbom_type
	]

	def response = client.post(
		headers: requestHeaders, 
		body: requestBody,
        contentType : 'application/json'
	)

    def lines = response.getHeaders().toList()
    def desiredLine = null

    for (line in lines) {
        if (line.toString().contains('Location:')){
            desiredLine = line.toString()
            break
        }        
    }

    def url = desiredLine.substring(desiredLine.indexOf(':') + 1)
    println "url:${url.trim()}"
    return url.trim()
}

/**
* Download a generated SBOM report
* @param  bearer    Specify a bearer token to be able to authenticate the black duck call. Can be obtained from another method
* @param  project_id   Specify the url from which the report ill be generated
* @param  output   Specify the output path within the workspace that the sorted json file will be added to
*/
def downloadBlackDuckReport(bearer,url, output){
    def link = "${url}/download"
    link = link.trim()
    println "link:${link}"

    retry(3) { 
	         timeout(time: 10, unit: 'MINUTES') { 
	             try { 
	                 sh """ 
	                 status='' 
	                 finished=False 
	                 while [ \$finished = False ] 
	                 do  
	                     status=\$(curl --location '${url}' --header 'Authorization: Bearer ${bearer}' --header 'Accept: application/vnd.blackducksoftware.report-4+json' | jq .status) 
	                     echo \$status 
	                     if [ \$status = '\"COMPLETED\"' ] 
	                     then 
	                         finished=True 
	                     fi 
	                     sleep 15 
	                 done 
	                 """ 
	             } catch (err) { 
	                 error("Error getting black duck report status! ${err}") 
	             } 
	         } 
	     } 

    sh """
    curl -L -k --location '${link}' \
        --header 'Authorization: Bearer ${bearer}' \
        --header 'Accept: application/vnd.blackducksoftware.report-4+json' \
        --output ${output}/Blackduck.zip
    ls -lah ${output}
    """
}
/**
* Retruns the id of a project
* @param  bearer    Specify a bearer token to be able to authenticate the black duck call. Can be obtained from another method
* @param  projectName Specify the name of the project who's id will be returned 
* @param  output   Specify the output path within the workspace that the sorted json file will be added to
*/
def getProjectId(bearer,projectName,output){
    def url = "https://blackduck.pas.sro.dell.com/api/projects"
    sh """
    curl --location '${url}' \
        --header 'Authorization: Bearer ${bearer}' \
        --output ${output}/project.json
    ls -lah ${output}
    """
    // Read the JSON file
    def jsonText = readFile("${output}/project.json")

    // Parse the JSON data
    def data = new JsonSlurperClassic().parseText(jsonText)
    println("data: ${data}")
    def project = data.items.find { it.name == projectName }
    if (project){
        println(project._meta.href)
        return project._meta.href
    }
    else{
        println "Project not found"
        def projectNotFound = 'Project not found'
        return projectNotFound
    }   
}
/**
* Retruns the id of a version of a project
* @param  bearer    Specify a bearer token to be able to authenticate the black duck call. Can be obtained from another method
* @param  projectURL    Specify the URL of the projects whose version will be returned
* @param  version   Specify the name of the the version whose id will be returned
* @param  filter   Specify a filter for the version name to narrow the ammount of results returned
* @param  output   Specify the output path within the workspace that the sorted json file will be added to
*/
def getVersionID(bearer,projectURL,version,output){
    sh """ 
        curl --location --request GET '${projectURL}/versions?limit=100' \
            --header 'Accept: application/vnd.blackducksoftware.project-detail-5+json' \
            --header 'sort: versionName asc' \
            --header 'Authorization: Bearer ${bearer}' \
            --output ${output}/version.json
        ls -lah ${output}
    """
    // Read the JSON file
    def jsonText = readFile("${output}/version.json")

    // Parse the JSON data
    def data = new JsonSlurperClassic().parseText(jsonText)
    println("data: ${data}")
    def projectVersion = data.items.find { it.versionName == version }
    if (projectVersion){
        println(projectVersion._meta.href)
        return projectVersion._meta.href
    }
    else{
        println "Project Version not found"
        def versionNotFound = 'Project Version not found'
        return versionNotFound
    }
}