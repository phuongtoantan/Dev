// Copyright © 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.

package common

/* This function should take the TL name (Ex. TL27) as an input and will check in the deployer (gNB_deployer) inventory 
the components list of this TL, and gets the info list for each component and call 
the updateGoldenConfigsComponent function for every component in this TL
*/
def updateGoldenConfigsTL(test_line, du_golden_config="golden_config_oam_3gpp_du_sa.xml") {
    try{
        //Getting the TL info from the gNB_deployer inventory
        def tl_inventory = readYaml file: "gNB_deployer/inventory/${test_line}.yml"
        println("Working on:" + test_line)
        def componenets_list =  tl_inventory.all.children

        //Going through all the children/components in the inventory file one by one
        componenets_list.each{key, value ->
            if(key in ["cucp","cuup","du_minerva"]){
                componenets_list.get(key).hosts.each{component_host_name, component_details ->
                    def component_host_ip = tl_inventory.all.hosts.get(component_host_name).ansible_host

                    //Getting the component's host username and password by using the credentials ID and Jenkins Credentials
                    def TL_ACCOUNT = tl_inventory.all.hosts.get(component_host_name).ansible_user
                    def TL_ACCOUNT_USR
                    def TL_ACCOUNT_PSW
                    withCredentials([usernamePassword(credentialsId: TL_ACCOUNT, usernameVariable: 'TL_USERNAME', passwordVariable: 'TL_PASSWORD')]) {
                        TL_ACCOUNT_USR = TL_USERNAME
                        TL_ACCOUNT_PSW = TL_PASSWORD
                    }

                    //Building a map for the component needed info to send it to the updateGoldenConfigsComponent function
                    def component_info = [
                        "name": key,
                        "test_line": test_line,
                        "host_info": [
                            "name": component_host_name,
                            "host": component_host_ip,
                            "user": TL_ACCOUNT_USR,
                            "password": TL_ACCOUNT_PSW,
                            "allowAnyHosts": true
                        ],
                        "config_path": value.hosts.get(component_host_name)[value.hosts.get(component_host_name).keySet()[2]],
                        "config_file": value.hosts.get(component_host_name)[value.hosts.get(component_host_name).keySet()[3]],
                        "golden_xml_config": null
                    ]

                    //In case the component is a DU then there is a different sort for the data
                    if(key == "du_minerva"){
                        component_info["name"] = "du_marvell"
                        component_info["config_path"] = value.hosts.get(component_host_name)[value.hosts.get(component_host_name).keySet()[0]]
                        component_info["config_file"] = value.hosts.get(component_host_name)[value.hosts.get(component_host_name).keySet()[1]]
                        component_info["golden_xml_config"] = du_golden_config
                    }
                    
                    println("Final component info:" + component_info)
                    updateGoldenConfigsComponent(component_info)
                }
            }
        }
    } catch (Exception ex) {
        // Only show error, not failing the whole pipeline.
        println ex

        // Copy configs from TL-Config repo into /opt/gnb/<application>/config
        sshCommand remote: component_info.host_info, command: \
        """
            sudo cp -r /data/E2E/${component_info.name}/*.* /opt/gnb/${component_info.name}/config
        """
        sh "exit 1"
    }
}


/* This function takes a component's info (groovy map) and then updates the configs of this component, 
It is being called by the function updateGoldenConfigsTL
*/
def updateGoldenConfigsComponent(component_info) {
    try{
        //Setting the needed paths based on the component
        application_config_path = "/opt/gnb/${component_info.name}/config"
        manage_config_path = "${WORKSPACE}/product_test_5g/framework/libraries/common/manage_config.py"
        delta_config_path = component_info.config_path.minus("../")
        delta_config_path = delta_config_path.substring(0, delta_config_path.length() - 1)
        remote_server = component_info.host_info

        switch (component_info.name) {
            case 'du_marvell':
                golden_xml_config =  component_info.golden_xml_config
                manage_config_folder = "du_configs"
                break
            case 'cucp':
                golden_xml_config =  "golden_config_oam_3gpp_cu_cp_sa.xml"
                manage_config_folder = "cucp_configs"
                break
            case 'cuup':
                golden_xml_config =  "golden_config_oam_3gpp_cu_up_sa.xml"
                manage_config_folder = "cuup_configs"
                break
            default:
                println "Component name should be: du_marvell, cuup, cucp."
                return 1
        }
        // Create a folder to put Golden & Delta configs into this
        sh """
            cd ${WORKSPACE}
            mkdir -p ${manage_config_folder}

            touch ${WORKSPACE}/${delta_config_path}/empty.txt
            touch ${WORKSPACE}/${delta_config_path}/empty.xml
        """

        output_xml_config = component_info.config_file.minus("delta_")

        retry(3) {
            try{
                sshGet remote: remote_server, from: "${application_config_path}/${golden_xml_config}", into: "${manage_config_folder}/${golden_xml_config}", override: true

            } catch (err) {
                sleep(time: 2, unit: "MINUTES")
                error("Could get config from the server: " + err)
            }
        }
        
        // Delta config is existing or not
        delta_xml_config= sh(returnStatus: true,
                                script:"""
                                    cd ${WORKSPACE}/${delta_config_path}/
                                    ls -l delta_${output_xml_config}
                                """
                            ) == 0 

        delta_xml_config = (delta_xml_config == true)? "delta_${output_xml_config}" : 'empty.xml'

        // Create custom configs
        sh """
            sudo pip3 install click
            cd ${WORKSPACE}/${manage_config_folder}/
            python3 ${manage_config_path} --golden_cfg_file ${golden_xml_config} --tl_cfg ${WORKSPACE}/${delta_config_path}/${delta_xml_config} --output_cfg_file ${output_xml_config}
            
            cp ${WORKSPACE}/${delta_config_path}/${delta_xml_config} ${WORKSPACE}/${manage_config_folder}/${delta_xml_config}
            ls -ltr
            rm empty.txt empty.xml || true
            cd ${WORKSPACE}
            sudo zip -r ${manage_config_folder}.zip ${manage_config_folder}
        """
        
        // Copy file config to TL server
        list_file = [output_xml_config]

        for (file in list_file) {
            retry(3) {
                try{
                    println "Clean up previous files on the remote server"
                    sshCommand remote: remote_server, command: \
                    """
                        pwd
                        sudo rm -rf ${file} || true
                    """

                    println "Copy files to the remote server"
                    sshPut remote: remote_server, from: "${manage_config_folder}/${file}", into: "."
                    sshCommand remote: remote_server, command: \
                    """
                        sudo mv ${file} ${application_config_path}
                    """
                    
                } catch (err) {
                    sleep(time: 2, unit: "MINUTES")
                    error("Could not copy new config to the server: " + err)
                }
            }
        }

        // Push folder config to Jenkins build artifactory
        archiveArtifacts artifacts: "${manage_config_folder}.zip"

    } catch (Exception ex) {
        // Only show error, not failing the whole pipeline.
        println ex

        // Copy configs from TL-Config repo into /opt/gnb/<application>/config
        sshCommand remote: remote_server, command: \
        """
            sudo cp -r /data/E2E/${component_info.name}/*.* /opt/gnb/${component_info.name}/config
        """
        sh "exit 1"
    }
    
}

/////////////////// The following function must be deprecated and replaced by the one above (After modifying all the TLs pipelines to use the new one) //////////////////
def updateGoldenConfigs(remote_server, test_line, component_name , output_xml_config, tl_config_internal_path = '') {    
    try{
        application_config_path = "/opt/gnb/${component_name}/config"
        manage_config_path = "${WORKSPACE}/product_test_5g/framework/libraries/common/manage_config.py"
        switch (component_name) {
            case 'du_marvell':
                golden_xml_config =  "golden_config_oam_3gpp_du_sa.xml"
                manage_config_folder = "du_configs"
                // The tl_config_internal_path is used in case of the TL two or more of any module so in the TL-Config repo it will has multiple folders for this module
                delta_config_path = "TL-Config/DU/${test_line}/${tl_config_internal_path}"
                break
            case 'cucp':
                golden_xml_config =  "golden_config_oam_3gpp_cu_cp_sa.xml"
                manage_config_folder = "cucp_configs"
                // The tl_config_internal_path is used in case of the TL two or more of any module so in the TL-Config repo it will has multiple folders for this module
                delta_config_path = "TL-Config/CU-CP/${test_line}/${tl_config_internal_path}"
                break
            case 'cuup':
                golden_xml_config =  "golden_config_oam_3gpp_cu_up_sa.xml"
                manage_config_folder = "cuup_configs"
                // The tl_config_internal_path is used in case of the TL two or more of any module so in the TL-Config repo it will has multiple folders for this module
                delta_config_path = "TL-Config/CU-UP/${test_line}/${tl_config_internal_path}"
                break
            default:
                println "Component name should be: du_marvell, cuup, cucp."
                return 1
        }
        // Create a folder to put Golden & Delta configs into this
        sh """
            cd ${WORKSPACE}
            mkdir -p ${manage_config_folder}

            touch ${WORKSPACE}/${delta_config_path}/empty.txt
            touch ${WORKSPACE}/${delta_config_path}/empty.xml
        """

        retry(3) {
            try{
                sshGet remote: remote_server, from: "${application_config_path}/${golden_xml_config}", into: "${manage_config_folder}/${golden_xml_config}", override: true

            } catch (err) {
                sleep(time: 2, unit: "MINUTES")
                error("Could get config from the server: " + err)
            }
        }
        
        // Delta config is existing or not
        delta_xml_config= sh(returnStatus: true,
                                script:"""
                                    cd ${WORKSPACE}/${delta_config_path}/
                                    ls -l delta_${output_xml_config}
                                """
                            ) == 0 

        delta_xml_config = (delta_xml_config == true)? "delta_${output_xml_config}" : 'empty.xml'

        // Create custom configs
        sh """
            sudo pip3 install click
            cd ${WORKSPACE}/${manage_config_folder}/
            python3 ${manage_config_path} --golden_cfg_file ${golden_xml_config} --tl_cfg ${WORKSPACE}/${delta_config_path}/${delta_xml_config} --output_cfg_file ${output_xml_config}
            
            cp ${WORKSPACE}/${delta_config_path}/${delta_xml_config} ${WORKSPACE}/${manage_config_folder}/${delta_xml_config}
            ls -ltr
            rm empty.txt empty.xml || true
            cd ${WORKSPACE}
            sudo zip -r ${manage_config_folder}.zip ${manage_config_folder}
        """

        // Copy file config to TL server
        list_file = [output_xml_config]

        for (file in list_file) {
            retry(3) {
                try{
                    println "Clean up previous files on the remote server"
                    sshCommand remote: remote_server, command: \
                    """
                        pwd
                        sudo rm -rf ${file} || true
                    """

                    println "Copy files to the remote server"
                    sshPut remote: remote_server, from: "${manage_config_folder}/${file}", into: "."
                    sshCommand remote: remote_server, command: \
                    """
                        sudo mv ${file} ${application_config_path}
                    """

                } catch (err) {
                    sleep(time: 2, unit: "MINUTES")
                    error("Could not copy new config to the server: " + err)
                }
            }
        }

        // Push folder config to Jenkins build artifactory
        archiveArtifacts artifacts: "${manage_config_folder}.zip"

    } catch (Exception ex) {
        // Only show error, not failing the whole pipeline.
        println "Failed at step update config file:"
        println ex
        // Copy configs from TL-Config repo into /opt/gnb/<application>/config
        sh "exit 1"
    }
    
}

def updateGoldenConfigForAIO(component_name, output_xml_configs=[]){
    try{
        manage_config_path = "${WORKSPACE}/product_test_5g/framework/libraries/common/manage_config.py"
        switch (component_name) {
            case 'cuup':
                golden_xml_config = "golden_config_oam_3gpp_cu_cp_sa.xml"
                delta_config_path = "TL-Config/CU-UP/AIO"
                golden_config_path = "gNB_CU/config/golden_config/"
                break
            case 'cucp':
                golden_xml_config = "golden_config_oam_3gpp_cu_cp_sa.xml"
                delta_config_path = "TL-Config/CU-CP/AIO"
                golden_config_path = "gNB_CU/config/golden_config/"
                break
            case 'du':
                golden_xml_config = "golden_config_oam_3gpp_du_sa.xml"
                delta_config_path = "TL-Config/DU/AIO"
                golden_config_path = "gNB_DU/config"
                break
            default:
                println "Component name should be: du, cuup, cucp"
                return 1
        }

        // Create backup for TL-Config + Install click module
        sh """
            cp -R ${WORKSPACE}/${delta_config_path} ${WORKSPACE}/backup_TL-Config

            cp ${WORKSPACE}/${golden_config_path}/${golden_xml_config} ${WORKSPACE}/${delta_config_path}/
            sudo pip3 install click
        """

        for (file in output_xml_configs) {
            // Delta config is existing or not
            delta_config= sh(returnStatus: true,
                                script:"""
                                    cd ${WORKSPACE}/${delta_config_path}/
                                    ls -l delta_${file}
                                """
                            ) == 0

            if (delta_config){
                sh """
                    cd ${WORKSPACE}/${delta_config_path}/
                    python3 ${manage_config_path} --golden_cfg_file ${golden_xml_config} --tl_cfg delta_${file} --output_cfg_file ${file}
                """
            } else {
                println "Could not found delta config => Skip update config for ${file}"
            }
            
        }

        sh """
            cd ${WORKSPACE}/${delta_config_path}/
            ls -ltr
        """

    } catch (Exception ex) {
        // Only show error, not failing the whole pipeline.
        println "Failed at step update config file:"
        println ex
        // Copy configs from TL-Config repo into /opt/gnb/<application>/config
        sh "exit 1"
    }
}

return this