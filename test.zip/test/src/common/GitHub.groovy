// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package common
import groovy.json.JsonSlurperClassic
import groovy.json.JsonSlurper
@NonCPS
def jsonParse(def json) {
    new groovy.json.JsonSlurperClassic().parseText(json)
}

/**
* Get latest tag name of repo based on tag pattern in regex context.
* Use GitHub API call to retrive all the tags data, see: http://developer.github.com/v3/git/refs/
*
* @param  targetRepo   Specify target repo, for example: "gNB_CU", "gNB_DU", ...
* @param  tagPattern   Specify tag pattern with regex syntax, see: https://regexr.com/. For example: "CU_2.1.0.0_[0-9]+", "DU_2.1.0.0_[0-9]+", "v1.2.3.*"
* @param  agentLabel   Specify agent label to do the API call, for example: rhel8, ... Default is 'rhel8'
* @return  tagName   Latest tag name based on tag pattern
*/

def getLatestTagWithPattern(args=[targetRepo: null, tagPattern: null], agentLabel='rhel8') {
    if (!args.targetRepo) {
        throw new IllegalArgumentException("Missing 'targetRepo' parameter!")
    }
    if (!args.tagPattern) {
        throw new IllegalArgumentException("Missing 'tagPattern' parameter!")
    }
    if (!agentLabel) {
        throw new IllegalArgumentException("Missing 'agentLabel' parameter!")
    }

    def GenericVars = new sharedVars.GenericVars()
    node (agentLabel) {
        def tagName = null
        // Using Github token from Jenkins credentials
        withCredentials([string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
            retry(3) {
                // Make API call to GitHub
                tagName = sh(returnStdout: true,
                    script:"""
                        curl -ks -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" \
                        ${GenericVars.GITHUB_API_BASE_URL}/${args.targetRepo}/git/refs/tags | grep -oE "refs/tags/${args.tagPattern}" | tail -n 1
                    """
                ).trim()

                tagName = tagName.replace("refs/tags/","")

                if (!tagName) {
                    println "Unable to get tag!"
                    sleep(time: 1, unit: "MINUTES")
                }
            }
            println ("Tag name: " + tagName)
            return tagName
        }
    }
}

// To get most latest tag from Mainstream Tag ID.
// So we will get both TMP tag or official tag of a component builds
def getLatestTagFromMainstreamBuild(args=[targetRepo: null, inputTag: null, semPrefix: ""], agentLabel='git_api') {
    if (!args.targetRepo) {
        throw new IllegalArgumentException("Missing 'targetRepo' parameter!")
    }
    if (!args.inputTag) {
        throw new IllegalArgumentException("Missing 'inputTag' parameter!")
    }
    if (!agentLabel) {
        throw new IllegalArgumentException("Missing 'agentLabel' parameter!")
    }
    if (!args.semPrefix) {
        throw new IllegalArgumentException("Missing 'semPrefix' parameter!")
    }

    node (agentLabel) {
        def tagName = ""
        def githubOwner = "Mobile-Phoenix"
        retry(3) {
            try {
                cleanWs()
                // Make API call to GitHub
                tagName = sh(returnStdout: true,
                    script:"""
                        git clone git@eos2git.cec.lab.emc.com:${githubOwner}/${args.targetRepo}.git
                        cd ${args.targetRepo}
                        git checkout ${args.inputTag}
                        git describe --tags --abbrev=0 --match "${args.semPrefix}*"
                    """
                ).trim()

                if (!tagName) {
                    println "Unable to get tag!"
                    sleep(time: 1, unit: "MINUTES")
                }
                cleanWs()
            } catch (Exception ex) {
                println ("Error message: " + ex)
            }
        }
        println ("Tag name: " + tagName)
        return tagName
    }
}

def getCommitIdFromTag(args=[targetRepo: null, tagName: null], agentLabel='git_api', shortID=true) {
    if (!args.targetRepo) {
        throw new IllegalArgumentException("Missing 'targetRepo' parameter!")
    }
    if (!args.tagName) {
        throw new IllegalArgumentException("Missing 'tagName' parameter!")
    }
    if (!agentLabel) {
        throw new IllegalArgumentException("Missing 'agentLabel' parameter!")
    }

    def GenericVars = new sharedVars.GenericVars()
    node (agentLabel) {
        def commitID = null
        // Using Github token from Jenkins credentials
        withCredentials([string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
            try {
                // Make API call to GitHub
                object = sh(returnStdout: true,
                    script:"""
                        curl -ks -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" \
                        ${GenericVars.GITHUB_API_BASE_URL}/${args.targetRepo}/git/refs/tags/${args.tagName} | jq -r '.object'
                    """
                ).trim()
                tag_json = jsonParse(object)
                while(tag_json.type == "tag")
                {
                    object = sh(returnStdout: true,
                        script:"""
                            curl -ks -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" \
                            $tag_json.url | jq -r '.object'
                        """
                    ).trim()
                    tag_json = jsonParse(object)
                }
                commitID = tag_json.sha
            } catch (Exception ex) {
                println ("Error message: " + ex)
            }
            if (shortID && commitID) {
                commitID = commitID.substring(0,8)
            } 
            println ("Commit ID: " + commitID)
            return commitID
        }
    }
}

def getChangeLog(current_tag, previous_tag, target_repo, agentLabel='rhel8') {
    node (agentLabel) {
        def changes_log = []
        try {
            script {
                withCredentials([string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
                    response = sh(returnStdout: true,
                        script:"""
                            curl -ks -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" \
                            https://eos2git.cec.lab.emc.com/api/v3/repos/Mobile-Phoenix/gNB_CU/compare/${previous_tag}...${current_tag}
                        """
                    ).trim()
                    
                    def response = jsonParse(response)
                    for (commit in response["commits"]){
                        def change = [:]
                        if (commit["commit"]["message"].length() > 100){
                            message = commit["commit"]["message"][0..100] + "..."
                        } else {
                            message = commit["commit"]["message"]
                        }
                        change["commitId"] = commit["sha"]
                        change["message"] = message
                        change["author"] = commit["commit"]["author"]["name"]
                        change["timestamp"] = commit["commit"]["author"]["date"]
                        change["url"] = commit["html_url"]
                        changes_log.add(change)
                    }
                }
            }
        } catch (Exception ex) {
            println ("Error message: " + ex)
            changes_log=""
        }
        return changes_log
    }
}

/**
* Get latest submodule hashs of super Repo CU/DU.
* Use GitHub API call to retrive all the tags data, see: http://developer.github.com/v3/git/refs/
*
* @param  targetRepo   Specify target repo, for example: "CU", "DU", ...
* @param  agentLabel   Specify agent label to do the API call, for example: rhel8, ... Default is 'rhel8'
* @return  submodules   A map containing all the hash strings of the submodules.
*/
def getLatestSubModuleHashs(args=[targetRepo: null], agentLabel='rhel8') {
    if (!args.targetRepo) {
        throw new IllegalArgumentException("Missing 'targetRepo' parameter!")
    }
    if (!agentLabel) {
        throw new IllegalArgumentException("Missing 'agentLabel' parameter!")
    }

    def GenericVars = new sharedVars.GenericVars()
    node (agentLabel) {
        def submodules = [:]
        def response = null
        // Using Github token from Jenkins credentials
        withCredentials([string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
            retry(3) {
                // Make API call to GitHub
                response = sh(returnStdout: true,
                    script:"""
                        curl -ks -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" \
                        ${GenericVars.GITHUB_API_BASE_URL}/${args.targetRepo}/contents/
                    """
                ).trim()

                if (!response) {
                    println "Unable to get submodules!"
                    sleep(time: 1, unit: "MINUTES")
                }
            }
            subModuleHashs = jsonParse(response)
            println ("Submodule hashs: " + subModuleHashs)
            for (module in subModuleHashs) {
                if(!module["download_url"]) {
                    submodules[module["name"]] = module["sha"]
                }
            }
            return submodules
        }
    }
}

return this

/*
* Check and update submodule branch name for supporting cross dependency
* submoduleName should follow the template [submodule name: "default branch"]
* Ex: submoduleName = [gNB_OAM: "main", gNB_ngp:"main", gNB_platform:"main"]
*/
def updateSubmoduleBranchName(def submoduleName, branchName='main', agentLabel='rhel8') {
    script {
        def repos = submoduleName
        node (agentLabel) {
            def runs = [:]
            repos.each{ k, v ->
                       runs["${k}"] = {repos."${k}" = sh(script:"git ls-remote --heads git@eos2git.cec.lab.emc.com:Mobile-Phoenix/${k}.git ${branchName} | grep ${branchName} > /dev/null && echo ${branchName} || echo ${v}",
                       returnStdout:true).trim()}
            }
            parallel runs
        }
        return repos
    }
}

/*
* Check and update submodule branch name for supporting cross dependency
* submoduleName should follow the template [submodule name: "default branch"]
* Ex: submoduleName = [gNB_OAM: "main", gNB_ngp:"main", gNB_platform:"main"]
*/
// TODO: Deprecate updateSubmoduleBranchName() once migration completed
def updateSubmoduleBranchNameMultiStream(def submoduleName, branchName='main', streamBranch='main', agentLabel='rhel8') {
    script {
        def repos = submoduleName
        node (agentLabel) {
            def runs = [:]
            repos.each{ k, v ->
                       runs["${k}"] = {repos."${k}" = sh(script:"git ls-remote --heads git@eos2git.cec.lab.emc.com:Mobile-Phoenix/${k}.git ${branchName} | grep ${branchName} > /dev/null && echo ${branchName} || echo ${streamBranch}",
                       returnStdout:true).trim()}
            }
            parallel runs
        }
        return repos
    }
}



def deleteMplaneTag(tagName, gitAccount) {
      // Check if tag exists
      def tagExists = sh(script: "git ls-remote --exit-code --refs https://${gitAccount}@eos2git.cec.lab.emc.com/Mobile-Phoenix/gNB_FH_MPLANE.git refs/tags/${tagName}", returnStatus: true)
      
      if (tagExists == 0) {
          sh "git push --delete https://${gitAccount}@eos2git.cec.lab.emc.com/Mobile-Phoenix/gNB_FH_MPLANE.git ${tagName}"
          sh "git tag -d ${tagName}"
          echo "Deleted tag '${tagName}'"
      } else {
          echo "Tag '${tagName}' does not exist."
      }
  }

/**
* Get Changed folder from a PR
* Use Git diff to retreive all changed files and get the parent folder
*
* @param  repository   Specify target repo, for example: "CU", "DU", ...
* @param  gitAccount   Specify git credentials
* @param  PRSrcBranch   Specify pull request source branch, for example MP-..
* @param  PRTargetBranch   Specify pull request target branch, for example main
* @return  folders   A list containing all changed folders in the first level under the specified repo.
*/
def getChangeFolder(repository, gitAccount, PRSrcBranch, PRTargetBranch){
    sh """
        git clone -b $PRSrcBranch https://${gitAccount}@eos2git.cec.lab.emc.com/Mobile-Phoenix/${repository}.git
        cd $repository
        git remote set-url origin https://${gitAccount}@eos2git.cec.lab.emc.com/Mobile-Phoenix/${repository}.git
        git fetch origin --no-tags $PRTargetBranch +refs/heads/$PRTargetBranch:refs/remotes/origin/$PRTargetBranch # timeout=10
    """
    git_diff = sh (
        script: """cd $repository 
        git diff --name-only origin/$PRTargetBranch..HEAD | cut -d '/' -f 1""",
        returnStdout: true
    ).trim()
    git_diff_arr = git_diff.split("\n").collect()
    folders = git_diff_arr.unique()
    return folders
}

//Get email address of user on github. If the email of user does not visible, the function will return as null
def getEmailOfUsername(username, git_account){
    def email = null
    try {
        def command = """
        curl --location --request GET "https://eos2git.cec.lab.emc.com/api/v3/users/${username}" -s \
        --header "Authorization: Bearer $git_account" \
        --header "Accept: application/vnd.github.v3+json"
        """
        def response = sh(returnStdout: true, script: command)
        def jsonSlurper = new JsonSlurper()
        def jsonResponse = jsonSlurper.parseText(response)
        email = jsonResponse.email
        println "email address: ${email}"
    } catch (Exception ex) {
        println ("Error message: " + ex)
    }
    return email
}

def setPRLabels(githubRepo, prNumber, labels, git_account){
    try {
        def apiUrl = "https://eos2git.cec.lab.emc.com/api/v3/repos/Mobile-Phoenix/${githubRepo}/issues/${prNumber}/labels"
        def curlCommand = """
            curl -L \
            -X PUT \
            -H 'Accept: application/vnd.github+json' \
            -H 'Authorization: Bearer ${git_account}' \
            -H 'Content-Type: application/json' \
            ${apiUrl} \
            -d '{"labels":${labels}}'
        """
        sh curlCommand
    } catch (Exception ex) {
        println ("Error message: " + ex)
    }
}

def getPullRequestStatus(git_account) {
    def prNumber = env.CHANGE_ID
    def apiUrl = "https://eos2git.cec.lab.emc.com/api/v3/repos/Mobile-Phoenix/product_test_5g/pulls/${prNumber}"
    // Use curl with authentication to get pull request information
    def response = sh(
        script: """
            curl -s -H 'Authorization: token $git_account' $apiUrl
        """,
        returnStdout: true
    ).trim()
    echo "API Response: $response"
    // Parse the JSON response
    def jsonSlurper = new JsonSlurper()
    def jsonResponse = jsonSlurper.parseText(response)
    // Check if the pull request is open and not a draft
    if (jsonResponse.state == 'open' && jsonResponse.draft == false) {
        echo "The pull request is in Open status."
        return 'Open'
    } else {
        echo "The pull request is in Draft status."
        return 'Draft'
    }
}

def isRunBuildStage(repoName, tagPattern, gitAccount) {
    if (!repoName) {
        error("Missing repository name")
        return
    }
    def isRunBuild = true
    try {
        sh "git clone --recursive -b main https://${gitAccount}@eos2git.cec.lab.emc.com/Mobile-Phoenix/${repoName}"
        dir("${repoName}") {
            def latestTag = getLatestTagWithPattern([targetRepo: "${repoName}", tagPattern: "${tagPattern}"] )
            println "latestTag: ${latestTag}"

            def latestCommit = sh(returnStdout: true, script: "git rev-parse main").trim()
            println "latestCommit: ${latestCommit}"

            def commitOfLatestTag = sh(script: "git rev-list -n 1 ${latestTag}", returnStdout: true).trim()
            println "CommitOfLatestTag: ${commitOfLatestTag}"

            if (latestCommit == commitOfLatestTag) {
                isRunBuild = false
            }
        }
    } catch (Exception ex) {
        println ("Error message: " + ex)
    }
    return isRunBuild
}

/**
* Update PR Checker
*
* @param  repository   Specify target repo, for example: "CU", "DU", ...
* @param  gitAccount   Specify git credentials
* @param  PRSrcBranch   Specify pull request source branch, for example MP-..
* @param  PRTargetBranch   Specify pull request target branch, for example main
* @return  folders   A list containing all changed folders in the first level under the specified repo.
*/
def updatePRChecker(repository, gitAccount, PR_SHA, BUILD_URL, checkerName, buildResult,description){
    sh"""
        curl --location -s --request POST 'https://eos2git.cec.lab.emc.com/api/v3/repos/Mobile-Phoenix/${repository}/statuses/${PR_SHA}' \
        --header 'Accept: application/vnd.github.v3+json' \
        --header 'X-GitHub-Api-Version: 2022-11-28' \
        --header 'Authorization: Bearer ${gitAccount}' \
        --header 'Content-Type: application/json' \
        --header 'Cookie: logged_in=no' \
        --data '{
            "state": "${buildResult}",
            "context": "${checkerName}",
            "target_url": "${env.BUILD_URL}",
            "description": "${description}"
        }'
    """
}

/*
* Creates a new tag within a repository from a specified branch.
*
* @param gitAccount The Git account or repository where the tag creation operation will be performed.
* @param repoName The name of the repository where the tag will be created.
* @param originBranch The branch from which the tag will be created.
* @param originCommit (optional) the commit id from which the tag will be created.
* @param targetTag The tag that will be created in the repository.
* @param recursiveSubmodules (optional) A boolean flag indicating whether the tag creation should be applied recursively to submodules. Defaults to false.
*/

def createTag(def gitAccount = "", def repoName="", def originBranch="", def originCommit=null, def targetTag="", recursiveSubmodules=false, def retryCount=3, def timeoutInMinutes=5) {
    def retryAttempt = 0
    def githubOwner = "Mobile-Phoenix"

    // Using retry to mitigate network issues
    retry(retryCount) {
        timeout(time: timeoutInMinutes, unit: 'MINUTES') {
            script {
                retryAttempt++
                cleanWs()
                // TODO: check and apply the 'shallow clone' feature for multibranch.
                // Shallow clone  (with --depth=1) would help us clone quickly but it does not work for multibranch now. Only works with main)

                def cloneOptions = originCommit ? '--single-branch' : ''
                def targetCommitID = originCommit ? originCommit : ""

                if (recursiveSubmodules) {
                    cloneOptions += ' --recurse-submodules -j10'
                }

                try {
                    print "Create tag for repository: ${repoName}"
                    // Clone the repository
                    sh "git clone ${cloneOptions} --branch ${originBranch} https://${gitAccount}@eos2git.cec.lab.emc.com/${githubOwner}/${repoName}.git"
                    // Navigate to the repository directory
                    dir("${WORKSPACE}/${repoName}") {
                        // Set git config user.name and user.email on the agent
                        sh """
                            git config --global user.name 'Git bot'
                            git config --global user.email 'bot@noreply.github.com'
                            git config --list
                        """

                        if (targetCommitID) {
                            println "Create tag on specific commit ID: ${targetCommitID}"
                            sh "git checkout ${targetCommitID}"
                            if (recursiveSubmodules) {
                                sh 'git submodule update --init --recursive'
                            }
                        }

                        // Tag the main repository
                        sh """
                            if git fetch -q --tags origin; git rev-parse -q --verify "refs/tags/$targetTag" >/dev/null; then
                                echo "Tag $targetTag already exists. Skipping tag creation."
                            else
                                if [[ "${targetCommitID}" == "" ]]; then
                                    git checkout ${originBranch}
                                else
                                    echo "Tag on specific commit ID ${targetCommitID}"
                                fi
                                git tag -a ${targetTag} -m "Annotated tag version: ${targetTag}"
                                git push origin ${targetTag}
                                echo "Tag $targetTag created successfully."
                            fi
                        """

                        if (recursiveSubmodules) {
                            // Get a list of submodules
                            def submoduleList = sh(script: 'git submodule', returnStdout: true).trim().split('\n')

                            // Tag submodules in parallel
                            parallel submoduleList.collectEntries { submodule ->
                                def submodulePath = submodule.split()[1]
                                ["Tag submodule - ${submodulePath}" : {
                                    print "Create tag for submodule: ${repoName}/${submodulePath}"
                                    dir("${WORKSPACE}/${repoName}/${submodulePath}") {
                                        // Checkout the main branch/tag in submodules
                                        sh """
                                            if git fetch -q --tags origin; git rev-parse -q --verify "refs/tags/$targetTag" >/dev/null; then
                                                echo "Tag $targetTag already exists. Skipping tag creation."
                                            else
                                                if [[ "${targetCommitID}" == "" ]]; then
                                                    git checkout ${originBranch}
                                                else
                                                    echo "Tag on specific commit ID ${targetCommitID}"
                                                fi
                                                git tag -a ${targetTag} -m "Annotated tag version: ${targetTag}"
                                                git push origin ${targetTag}
                                                echo "Tag $targetTag created successfully."
                                            fi
                                        """
                                    }
                                }]
                            }
                        }
                    }
                } catch (Exception e) {
                    if (retryAttempt < retryCount) {
                        sleep(time: 1, unit: "MINUTES")
                    }
                    // Handle any exceptions or errors
                    throw new Exception("Error occurred during tagging: ${e.message}")
                }
            }
        }
    }
}

/*
* Promotes a specific tag within a repository from one branch to another.
*
* @param gitAccount The Git account or repository where the tag promotion operation will be performed.
* @param repoName The name of the repository where the tag promotion will take place.
* @param originBranch The branch from which the tag needs to be promoted.
* @param originCommit (optional) the commit id from which the tag will be created.
* @param sourceTag The existing tag that needs to be promoted.
* @param targetTag The target tag that will be created as a result of the promotion.
* @param recursiveSubmodules (optional) A boolean flag indicating whether the tag promotion should be applied recursively to submodules. Defaults to false.
*/

def promoteTag(def gitAccount="", def repoName="", def originBranch="", def originCommit=null, def sourceTag="", def targetTag="", recursiveSubmodules=false, def retryCount=3, def timeoutInMinutes=5) {
    def retryAttempt = 0
    def githubOwner = "Mobile-Phoenix"
    // Using retry to mitigate network issues
    retry(retryCount) {
        timeout(time: timeoutInMinutes, unit: 'MINUTES') {
            retryAttempt++
            cleanWs()
            script {
                // TODO: check and apply the 'shallow clone' feature for multibranch.
                // Shallow clone  (with --depth=1) would help us clone quickly but it does not work for multibranch now. Only works with main)
                def cloneOptions = originCommit ? '--single-branch' : ''
                def targetCommitID = originCommit ? originCommit : ""

                if (recursiveSubmodules) {
                    cloneOptions += ' --recurse-submodules -j10'
                }

                try {
                    print "Promote tag for repository: ${repoName}"
                    // Clone the repository
                    sh "git clone ${cloneOptions} --branch ${originBranch} https://${gitAccount}@eos2git.cec.lab.emc.com/${githubOwner}/${repoName}.git"
                    // Navigate to the repository directory
                    dir("${WORKSPACE}/${repoName}") {
                        // Set git config user.name and user.email on the agent
                        sh """
                            git config --global user.name 'Git bot'
                            git config --global user.email 'bot@noreply.github.com'
                            git config --list
                        """

                        if (targetCommitID) {
                            println "Create tag on specific commit ID: ${targetCommitID}"
                            sh "git checkout ${targetCommitID}"
                            if (recursiveSubmodules) {
                                sh 'git submodule update --init --recursive'
                            }
                        }

                        // Tag the main repository
                        sh """
                        if git fetch -q --tags origin; git rev-parse -q --verify "refs/tags/$targetTag" >/dev/null; then
                            echo "Tag $targetTag already exists. Skipping tag creation."
                        else
                            if [[ "${targetCommitID}" == "" ]]; then
                                git checkout ${originBranch}
                            else
                                echo "Tag on specific commit ID ${targetCommitID}"
                            fi
                            git tag -a ${targetTag} ${sourceTag} -m "Annotated tag version: ${targetTag}"
                            git tag -d ${sourceTag}
                            git push origin ${targetTag} :refs/tags/${sourceTag}
                            echo "Tag $targetTag promoted successfully."
                        fi
                        """

                        if (recursiveSubmodules) {
                            // Get a list of submodules
                            def submoduleList = sh(script: 'git submodule', returnStdout: true).trim().split('\n')

                            // Tag submodules in parallel
                            parallel submoduleList.collectEntries { submodule ->
                                def submodulePath = submodule.split()[1]
                                ["Tag submodule - ${submodulePath}" : {
                                    print "Promote tag for submodule: ${repoName}/${submodulePath}"
                                    dir("${WORKSPACE}/${repoName}/${submodulePath}") {
                                        // Checkout the main branch/tag in submodules
                                        sh """
                                        if git fetch -q --tags origin; git rev-parse -q --verify "refs/tags/$targetTag" >/dev/null; then
                                            echo "Tag $targetTag already exists. Skipping tag creation."
                                        else
                                            if [[ "${targetCommitID}" == "" ]]; then
                                                git checkout ${originBranch}
                                            else
                                                echo "Tag on specific commit ID ${targetCommitID}"
                                            fi
                                            git tag -a ${targetTag} ${sourceTag} -m "Annotated tag version: ${targetTag}"
                                            git tag -d ${sourceTag}
                                            git push origin ${targetTag} :refs/tags/${sourceTag}
                                            echo "Tag $targetTag promoted successfully."
                                        fi
                                        """
                                    }
                                }]
                            }
                        }
                    }
                } catch (Exception e) {
                    if (retryAttempt < retryCount) {
                        sleep(time: 1, unit: "MINUTES")
                    }
                    // Handle any exceptions or errors
                    throw new Exception("Error occurred during tagging: ${e.message}")
                }
            }
        }
    }
}

/*
* Deletes a specified tag within a repository from a specified branch.
*
* @param gitAccount The Git account or repository where the tag deletion operation will be performed.
* @param repoName The name of the repository from which the tag will be deleted.
* @param originBranch The branch from which the tag deletion will occur.
* @param originCommit (optional) the commit id from which the tag will be created.
* @param targetTag The tag that will be deleted from the repository.
* @param recursiveSubmodules (optional) A boolean flag indicating whether the tag deletion should be applied recursively to submodules. Defaults to false.
* @param retryCount (optional) The number of retries attempted if deletion fails. Defaults to 3.
* @param timeoutInMinutes (optional) The timeout duration for the deletion operation in minutes. Defaults to 5 minutes.
*/
def deleteTag(def gitAccount = "", def repoName="", def originBranch="", def originCommit=null, def targetTag="", recursiveSubmodules=false, def retryCount=3, def timeoutInMinutes=5) {
    def retryAttempt = 0
    def githubOwner = "Mobile-Phoenix"

    // Using retry to mitigate network issues
    retry(retryCount) {
        timeout(time: timeoutInMinutes, unit: 'MINUTES') {
            script {
                retryAttempt++
                cleanWs()

                // TODO: check and apply the 'shallow clone' feature for multibranch.
                // Shallow clone  (with --depth=1) would help us clone quickly but it does not work for multibranch now. Only works with main)
                def cloneOptions = originCommit ? '--single-branch' : ''
                def targetCommitID = originCommit ? originCommit : ""

                if (recursiveSubmodules) {
                    cloneOptions += ' --recurse-submodules -j10'
                }

                try {
                    print "Delete tag for repository: ${repoName}"
                    // Clone the repository
                    sh "git clone ${cloneOptions} --branch ${originBranch} https://${gitAccount}@eos2git.cec.lab.emc.com/${githubOwner}/${repoName}.git"

                    // Navigate to the repository directory
                    dir("${WORKSPACE}/${repoName}") {
                        // Set git config user.name and user.email on the agent
                        sh """
                            git config --global user.name 'Git bot'
                            git config --global user.email 'bot@noreply.github.com'
                            git config --list
                        """

                        if (targetCommitID) {
                            println "Create tag on specific commit ID: ${targetCommitID}"
                            sh "git checkout ${targetCommitID}"
                            if (recursiveSubmodules) {
                                sh 'git submodule update --init --recursive'
                            }
                        }

                        // Tag the main repository
                        sh """
                            if git fetch -q --tags origin; git show-ref --tags --quiet refs/tags/$targetTag >/dev/null; then
                                echo "Tag $targetTag exists. Deleting tag..."
                                git push origin --delete $targetTag || true
                                git tag -d $targetTag || true
                            else
                                echo "Tag $targetTag does not exist. Skipping deletion"
                            fi
                        """

                        if (recursiveSubmodules) {
                            // Get a list of submodules
                            def submoduleList = sh(script: 'git submodule', returnStdout: true).trim().split('\n')

                            // Tag submodules in parallel
                            parallel submoduleList.collectEntries { submodule ->
                                def submodulePath = submodule.split()[1]
                                ["Tag submodule - ${submodulePath}" : {
                                    print "Delete tag for submodule: ${repoName}/${submodulePath}"
                                    dir("${WORKSPACE}/${repoName}/${submodulePath}") {
                                        // Checkout the main branch/tag in submodules
                                        sh """
                                            if git fetch --prune -q --tags origin; git show-ref --tags --quiet refs/tags/$targetTag >/dev/null; then
                                                echo "Tag $targetTag exists. Deleting tag..."
                                                if [[ "${targetCommitID}" == "" ]]; then
                                                    git checkout ${originBranch}
                                                else
                                                    echo "Delete tag on specific commit ID ${targetCommitID}"
                                                fi
                                                git push origin --delete $targetTag || true
                                                git tag -d $targetTag || true
                                            else
                                                echo "Tag $targetTag does not exist. Skipping deletion"
                                            fi
                                        """
                                    }
                                }]
                            }
                        }
                    }
                } catch (Exception e) {
                    if (retryAttempt < retryCount) {
                        sleep(time: 1, unit: "MINUTES")
                    }
                    // Handle any exceptions or errors
                    throw new Exception("Error occurred during tagging: ${e.message}")
                }
            }
        }
    }
}


/*
* Creates tags in multiple repositories in parallel based on provided configurations.
*
* @param gitAccount The Git account to perform tagging operations.
* @param tagsDefinition A map containing repository names as keys and their corresponding configurations as values.
*                       Each configuration includes:
*                         - "branch": The branch to tag from.
*                         - "commit" (optional): The commit to tag from.
*                         - "targetTag": The tag that will be created.
*                         - "recursive" (optional): A flag indicating whether tagging should be done recursively.
* @throws IllegalArgumentException if any required parameters are missing in the configuration.
* @throws Exception if an error occurs during the tagging process.
*
* Sample definition for creating tag:
    def tagsDefinition = [
        "repo1": [
            "branch": "main",
            "targetTag": "tmp_v1",
            "recursive": true
        ],
        "repo2": [
            "branch": "dev",
            "targetTag": "tmp_dev_v2",
        ],
        "repo3": [
            "branch": dev,
            "commit": "sha1-hash"
            "targetTag": "tmp_dev_v2",
        ],
    ]
*/
def createTagsInParallel(def gitAccount, def tagsDefinition, def retryCount=3, def timeoutInMinutes=5) {
    script {
        taggingJobs = [:]

        try {

            tagsDefinition.each { repoName, config ->
                println "${repoName}: ${config}"

                // Validate required parameters
                if (!config.branch || !config.targetTag) {
                    throw new IllegalArgumentException("Error: Missing required parameters for ${repoName}")
                }

                // Set default value for recursive flag if not provided
                def recursiveFlag = config.recursive ?: false
                def commitId = config.commit ?: null

                taggingJobs["Tag::${repoName}"] = {
                    createTag(gitAccount, repoName, config.branch, commitId, config.targetTag, recursiveFlag, retryCount, timeoutInMinutes)
                }
            }
            // Start tagging in parallel
            parallel taggingJobs
        } catch (Exception e) {
            // Handle any exceptions or errors
            throw new Exception("Error occurred during tagging: ${e.message}")
        }
    }
}

/*
* Promotes tags in multiple repositories concurrently based on provided configurations.
*
* @param gitAccount The Git account or repository to perform tag promotion operations.
* @param tagsDefinition A map containing repository names as keys and their corresponding configurations as values.
*                       Each configuration includes:
*                         - "branch": The branch from which the tag promotion will be done.
*                         - "sourceTag": The existing tag that needs to be promoted.
*                         - "targetTag": The tag that will be created as a result of promotion.
*                         - "recursive" (optional): A flag indicating whether tag promotion should be done recursively.
* @throws IllegalArgumentException if any required parameters are missing in the configuration.
* @throws Exception if an error occurs during the tag promotion process.
*
* Sample definition for promoting tag:
    def tagsDefinition = [
        "CU": [
            "branch": "main",
            "sourceTag": "tmp_v1.0",
            "targetTag": "v1.0",
            "recursive": true
        ],
        "oam-node-simulator": [
            "branch": "main",
            "sourceTag": "tmp_v2.0",
            "targetTag": "v2.0",
        ],
        "CU": [
            "branch": "main",
            "commit": "sha1-hash"
            "targetTag": "tmp_dev_v2",
        ],
    ]
*/

def promoteTagsInParallel(def gitAccount, def tagsDefinition, def retryCount=3, def timeoutInMinutes=5) {
    script {
        def promoteTagJobs = [:]

        try {
            tagsDefinition.each { repoName, config ->
                println "${repoName}: ${config}"

                // Validate required parameters
                if (!config.branch || !config.sourceTag || !config.targetTag) {
                    throw new IllegalArgumentException("Error: Missing required parameters for ${repoName}")
                }

                // Set default value for recursive flag if not provided
                def recursiveFlag = config.recursive ?: false
                def commitId = config.commit ?: null

                promoteTagJobs["PromoteTag::${repoName}"] = {
                    promoteTag(gitAccount, repoName, config.branch, commitId, config.sourceTag, config.targetTag, recursiveFlag, retryCount, timeoutInMinutes)
                }
            }

            // Start tagging in parallel
            parallel promoteTagJobs
        } catch (Exception e) {
            // Handle any exceptions or errors
            throw new Exception("Error occurred during tagging: ${e.message}")
        }
    }
}


/*
* Deletes tags in multiple repositories in parallel based on provided configurations.
*
* @param gitAccount The Git account to perform tag deletion operations.
* @param tagsDefinition A map containing repository names as keys and their corresponding configurations as values.
*                       Each configuration includes:
*                         - "branch": The branch from which the tag will be deleted.
*                         - "targetTag": The tag that will be deleted.
*                         - "recursive" (optional): A flag indicating whether deletion should be done recursively.
* @param retryCount (optional) The number of retries attempted if deletion fails for any tag. Defaults to 3.
* @param timeoutInMinutes (optional) The timeout duration for the deletion operation in minutes. Defaults to 5 minutes.
* @throws IllegalArgumentException if any required parameters are missing in the configuration.
* @throws Exception if an error occurs during the deletion process.
*
* Sample definition for deleting tags:
    def tagsDefinition = [
        "repo1": [
            "branch": "main",
            "targetTag": "tmp_v1",
            "recursive": true
        ],
        "repo2": [
            "branch": "dev",
            "targetTag": "tmp_dev_v2",
        ],
        "repo3": [
            "branch": "dev",
            "commit": "sha1-hash"
            "targetTag": "tmp_dev_v2",
        ],
    ]
*/
def deleteTagsInParallel(def gitAccount, def tagsDefinition, def retryCount=3, def timeoutInMinutes=5) {
    script {
        deleteTagJobs = [:]

        try {
            tagsDefinition.each { repoName, config ->
                println "${repoName}: ${config}"

                // Validate required parameters
                if (!config.branch || !config.targetTag) {
                    throw new IllegalArgumentException("Error: Missing required parameters for ${repoName}")
                }

                // Set default value for recursive flag if not provided
                def recursiveFlag = config.recursive ?: false
                def commitId = config.commit ?: null

                deleteTagJobs["DeleteTag::${repoName}"] = {
                    deleteTag(gitAccount, repoName, config.branch, commitId, config.targetTag, recursiveFlag, retryCount, timeoutInMinutes)
                }
            }
            // Start tagging in parallel
            parallel deleteTagJobs
        } catch (Exception e) {
            // Handle any exceptions or errors
            throw new Exception("Error occurred during tagging: ${e.message}")
        }
    }
}

def getMainstreamBuildVersions(def mainstreamBuildTag) {
    def getTagJobs = [:]
    def GitHub = new common.GitHub()
    def currentVersions = [:]
    def mainstreamBuildVersions = [:]

    SEM_VERSION_L1FW = "v2.3.12.0-[0-9]+"
    SEM_VERSION_L1DR = "2.5.2403.0-[0-9]+"

    try {
        println "Start getting build versions"
        // We don't have the L1 build in mainstream now, so just get latest tag from their repositores
        getTagJobs["GetTag::L1FW"] = {
            currentVersions.l1fwVersion = GitHub.getLatestTagWithPattern([targetRepo: "L1-Core", tagPattern: SEM_VERSION_L1FW])
        }

        getTagJobs["GetTag::L1DR"] = {
            currentVersions.l1drVersion = GitHub.getLatestTagWithPattern([targetRepo: "l1-marvell-drivers", tagPattern: SEM_VERSION_L1DR])
        }

        // TODO: Apply same approach for L1 once it's ready in mainstream build
        // currentVersions.l1fwVersion = getLatestTagFromMainstreamBuild([targetRepo: "L1-Core", inputTag: "v2.3.12.0-4355", semPrefix: "v2.3"])
        // currentVersions.l1drVersion = getLatestTagFromMainstreamBuild([targetRepo: "l1-marvell-drivers", inputTag: "2.4.112302.0-142", semPrefix: "2.4"])

        getTagJobs["GetTag::CU"] = {
            currentVersions.CU_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "CU", inputTag: mainstreamBuildTag, semPrefix: "CU"])
        }
        getTagJobs["GetTag::DU"] = {
            currentVersions.DU_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "DU", inputTag: mainstreamBuildTag, semPrefix: "DU"])
        }
        getTagJobs["GetTag::MPLANE"] = {
            currentVersions.MPLANE_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "gNB_FH_MPLANE", inputTag: mainstreamBuildTag, semPrefix: "mplane"])
        }
        getTagJobs["GetTag::OAM"] = {
            currentVersions.OAM_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "gNB_OAM", inputTag: mainstreamBuildTag, semPrefix: "OAM"])
        }
        getTagJobs["GetTag::UESIM"] = {
            currentVersions.UESIM_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "gNB_UESIM", inputTag: mainstreamBuildTag, semPrefix: "UESIM"])
        }
        getTagJobs["GetTag::NGP"] = {
            currentVersions.NGP_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "gNB_ngp", inputTag: mainstreamBuildTag, semPrefix: "gNB_ngp"])
        }
        getTagJobs["GetTag::NODED"] = {
            currentVersions.NODED_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "gNB_node_controller", inputTag: mainstreamBuildTag, semPrefix: "Noded"])
        }
        getTagJobs["GetTag::transport"] = {
            currentVersions.TRANSPORT_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "transport", inputTag: mainstreamBuildTag, semPrefix: "Transport"])
        }
        getTagJobs["GetTag::RDC_SERVICE"] = {
            currentVersions.RDC_SERVICE_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "rdc_service", inputTag: mainstreamBuildTag, semPrefix: "RDC"])
        }
        getTagJobs["GetTag::ACM"] = {
            currentVersions.ACM_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "gNB_ACM", inputTag: mainstreamBuildTag, semPrefix: "ACM"])
        }

        // TODO: Implement once Radio ready with tagging approach
        // currentVersions.RADIO_VERSION = getLatestTagFromMainstreamBuild([targetRepo: "radiosw-src", inputTag: mainstreamBuildTag, semPrefix: "radiosw"])

        // Start getting tags in parallel
        parallel getTagJobs
        println "Get build versions completed!"

        // Get all versions from mainstream build (both TMP and PROD)
        mainstreamBuildVersions = [
            "CU": [
                "version": currentVersions.CU_VERSION,
            ],
            "DU": [
                "version": currentVersions.DU_VERSION,
            ],
            "MPLANE": [
                "version": currentVersions.MPLANE_VERSION,
            ],
            "l1fw": [
                "version": currentVersions.l1fwVersion,
            ],
            "l1dr": [
                "version": currentVersions.l1drVersion,
            ],
            "NGP": [
                "version": currentVersions.NGP_VERSION,
            ],
            "OAM": [
                "version": currentVersions.OAM_VERSION,
            ],
            "NODED": [
                "version": currentVersions.NODED_VERSION,
            ],
            "UESIM": [
                "version": currentVersions.UESIM_VERSION,
            ],
            "Transport": [
                "version": currentVersions.TRANSPORT_VERSION,
            ],
            "RDC_service": [
                "version": currentVersions.RDC_SERVICE_VERSION,
            ],
            "ACM": [
                "version": currentVersions.ACM_VERSION,
            ],
        ]
    } catch (err) {
        println("Error appearing when getting list Versions: " + err)
    }
    return mainstreamBuildVersions
}

def getLatestCommit(args=[targetRepo: null], agentLabel='git_api') {
    if (!args.targetRepo) {
        throw new IllegalArgumentException("Missing 'targetRepo' parameter!")
    }
    if (!agentLabel) {
        throw new IllegalArgumentException("Missing 'agentLabel' parameter!")
    }

    def GenericVars = new sharedVars.GenericVars()
    node (agentLabel) {
        def commit = null
        // Using Github token from Jenkins credentials
        withCredentials([string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
            try {
                commit = sh(returnStdout: true,
                    script:"""
                        curl -ks -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" \
                        ${GenericVars.GITHUB_API_BASE_URL}/${args.targetRepo}/commits?per_page=1 | jq -r '.[0].sha'
                    """
                ).trim()
                if (!commit) {
                    println "Unable to get commit!"
                    sleep(time: 1, unit: "MINUTES")
                }
            } catch (Exception ex) {
                println ("Error message: " + ex)
            }
            println ("Latest commit ${args.targetRepo}: " + commit)
            return commit
        }
    }
}

def getMainstreamBuildNonVersions(def mainstreamCommit=null) {
    def currentCommit = [:]
    def mainstreamBuildNonVersions = [:]

    try {
        println "Start getting commit Id"

        currentCommit.DEVOPS_COMMIT = getLatestCommit(targetRepo: "mp-jenkins-shared-lib").substring(0, 7)
        currentCommit.RATE_COMMIT = getLatestCommit(targetRepo: "product_test_5g").substring(0, 7)
        currentCommit.RADIO_COMMIT = getLatestCommit(targetRepo: "radiosw-src").substring(0, 7)

        // Get all versions from mainstream build (both TMP and PROD)
        mainstreamBuildNonVersions = [
            "DEVOPS": [
                "version": currentCommit.DEVOPS_COMMIT,
            ],
            "RATE": [
                "version": currentCommit.RATE_COMMIT,
            ],
            "RADIO": [
                "version": currentCommit.RADIO_COMMIT,
            ]
        ]
        println ("mainstreamBuildNonVersions: ${mainstreamBuildNonVersions}: ")
    } catch (err) {
        println("Error appearing when getting list Commit: " + err)
    }
    return mainstreamBuildNonVersions
}