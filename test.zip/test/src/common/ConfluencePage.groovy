// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package common
import groovy.json.JsonSlurperClassic
import groovy.json.JsonSlurper

def confluencePageAction(arg = [cfID: null, typeAction: null, fileName: null, tlRun: [], shareLibBranch: "main"]) {
    if (!arg.cfID) {
        throw new IllegalArgumentException("Missing 'cfID' parameter!")
    }
    if (!arg.typeAction) {
        throw new IllegalArgumentException("Missing 'typeAction' parameter!")
    }
    if (!arg.fileName) {
        throw new IllegalArgumentException("Missing 'fileName' parameter!")
    }
    def resultJson = [:]
    def containerName = "confluence_page${BUILD_ID}"

    node('reporting_tool') {
      cleanWs()
      script{
        withCredentials([usernamePassword(credentialsId: 'svc_acc_npmpticketcheck', usernameVariable: 'npmpticketcheck_username', passwordVariable: 'npmpticketcheck_password')]) {
          sh """
            git clone -b ${arg.shareLibBranch} git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git mp-jenkins-shared-lib
            cd mp-jenkins-shared-lib
            buildah build --layers -t confluence_page -f resources/tools/confluence_page/confluence_page_tool.dockerfile .
            podman run --network host --privileged --rm --name ${containerName}\
              -e "USERNAME=${npmpticketcheck_username}" \
              -e "PASSWORD=${npmpticketcheck_password}" \
              -e "ACTION=${arg.typeAction}" \
              -e "CONFLUENCE_PAGE_ID=${arg.cfID}" \
              -e "LIST_TL=${arg.tlRun}" \
              -v ${WORKSPACE}/mp-jenkins-shared-lib/resources/:/tmp \
              confluence_page python3 tools/confluence_page/${arg.fileName}
        """
        }

        resultFile = "${WORKSPACE}/mp-jenkins-shared-lib/resources/output.json"
        resultJson = readJSON file: resultFile
      }
      cleanWs()
      //cleanup image name and tag is none
      sh "podman rm -f ${containerName} || true"
    }

    return resultJson
}