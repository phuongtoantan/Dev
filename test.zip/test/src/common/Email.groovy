// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

package common
import groovy.json.JsonSlurperClassic
import groovy.json.JsonSlurper
import groovy.transform.Field

/**
 *  Template for sending generic results email.
 *  @param  args.cuVersion: Specify the CU version
 *  @param  args.duVersion: Specify the DU version
 *  If missing CU version or DU version, this function will detect them from Github before starting the sending email process.
*/
def sendReport(args = [emailsOverride: null, reportType: "mainstream", emailsOverride: null, applicationData: null, mainstreamData: null, releaseRPM: null, greenLightResult: null, greenLightExecutionLog: null, shareLibBranch:null, mainstreamInfo: null]) {
  //def GitHub = new common.GitHub()
  def emailSendingStatus = false
  def MainstreamUtils = new common.MainstreamUtils()
  // Tag pattern in regex context, see: https://regexr.com/
  def mainstreamDataJsonFile = ""
  def mainstreamDataJson = [:]
  def applicationName = ""

  // Check input parameters
  node ('reporting_tool') {
    cleanWs()
    script {
      echo 'Start ES interaction'
      dataHtmlFile = "${env.WORKSPACE}/data.html"

      // Covert to python context
      arguments = " --output-html=./report/data.html"
      if (env.UPSTREAM_URL != null) {
        arguments += " --build-url='${env.UPSTREAM_URL}'"
      } else {
        arguments += " --build-url='${env.BUILD_URL}'"
      }
      arguments += " --build-number='${env.PIPELINE_BUILD_NUMBER}'"
      arguments += " --flag-checker='${args.greenLightResult}'"
      arguments += " --mainstream-info='${args.mainstreamInfo}'"

      // Log transfering
      println "Store greenLight execution log to file for later use"
      greenLightExecutionLogTxt = ""
      greenLightExecutionLogPath = "green_execution_log.txt"

      if (args.greenLightExecutionLog) {
        greenLightExecutionLogTxt = args.greenLightExecutionLog
      }
      writeFile(file: greenLightExecutionLogPath, text: greenLightExecutionLogTxt)
      arguments += " --greenlight-log='${greenLightExecutionLogPath}'"

      if (args.inputMainstreamData) {
        arguments += " --input-mainstream-data='''${args.inputMainstreamData}'''"
      }
      if (args.passRateData) {
        arguments += " --pass-rate-data='''${args.passRateData}'''"
      }
      if (args.mainstreamData) {
        arguments += " --mainstream-data='''${args.mainstreamData}'''"
      }
      if (args.applicationData) {
        arguments += " --application-data='''${args.applicationData}'''"
        def applicationDataMap = new groovy.json.JsonSlurperClassic().parseText(args.applicationData)
        applicationName = applicationDataMap['applicationName']
      }
      if(args.reportType) {
        arguments += " --report-type=${args.reportType}"
        if(args.reportType == 'build' || args.reportType == 'test' || args.reportType == 'interim_build' || args.reportType == 'interim_sanity_test') {
          // Capture output of mainstream data in json
          mainstreamDataJsonFile = "${env.WORKSPACE}/mainstream_data.json"
          arguments += " --mainstream-json=./report/mainstream_data.json"
        }
        if(args.reportType == 'official_mainstream') {
          mainstreamDataJsonFile = "${env.WORKSPACE}/mainstream_data.json"
          arguments += " --mainstream-json=./report/mainstream_data.json"
          
          if (args.releaseRPM){
            arguments += " --release-rpm='${args.releaseRPM}'"
            // Get RPM list
            def rpmList = MainstreamUtils.getListRPM()
            if (rpmList) {
              arguments += " --rpm-list='${rpmList.join(",")}'"
            }
          }
        }
      }

      // Execute main script to collect and generate email data
      withCredentials([usernamePassword(credentialsId: 'svc_acc_npmphran', usernameVariable: 'ldap_username', passwordVariable: 'ldap_password'),
                      string(credentialsId: 'github-checks-updater', variable: 'GITHUB_TOKEN')]) {
        arguments += " --github-token=${GITHUB_TOKEN} --ldap-username=${ldap_username} --ldap-password=${ldap_password}"
        arguments.trim()
        sh """
            git clone -b ${args.shareLibBranch} git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git mp-jenkins-shared-lib
            cd mp-jenkins-shared-lib
            buildah build --layers -t send_report_email -f resources/tools/report/send_report_email.dockerfile .
            podman run --network host --privileged --rm \
            -v ${env.WORKSPACE}:/app/report \
            -v ${env.WORKSPACE}/$greenLightExecutionLogPath:/app/$greenLightExecutionLogPath \
            send_report_email python3 generate_email_report.py ${arguments}
        """
      }
      // Parse mainsream data json file generated from python script
      if (mainstreamDataJsonFile != "") {
        mainstreamDataJson = readJSON file: mainstreamDataJsonFile
      }
      // Determine subject
      def subject = determineEmailSubject(args.reportType, mainstreamDataJson, applicationName)
      // Determine recipients
      def emailRecipients = determineEmailRecipients(args.reportType, mainstreamDataJson, args.emailsOverride, applicationName)
      // Perform sending email
      if (fileExists(dataHtmlFile)) {
        emailext to: "${emailRecipients.join(',')}" ,
          subject: "${subject}",
          body: readFile(dataHtmlFile)
        emailSendingStatus = true
      } else {
        println "Skip sending email as data.html does not exist!"
      }
    }
    cleanWs()
    //cleanup image name and tag is none
    sh "podman system prune -f || true"
  }
  return emailSendingStatus
}

// Functions
def determineEmailSubject(reportType = "", mainstreamDataJson = [:], applicationName= "") {
    def subject = "5G RAN software mainstream sanity report"
    if(reportType == 'build') {
      if(applicationName == "DU") {
        subject = "5G RAN ${applicationName} Build Report - Main #${env.PIPELINE_BUILD_NUMBER}"
      } else if(applicationName == "CU") {
          subject = "5G RAN ${applicationName} Build Report - Main #${env.PIPELINE_BUILD_NUMBER}"
      } else if(applicationName == "MPLANE") {
          subject = "5G RAN ${applicationName} Build Report - Main #${env.PIPELINE_BUILD_NUMBER}"
      } else {
          subject = "5G RAN ${applicationName} Build Report - Main"
      }
    }
    if(reportType == 'deploy') {
      subject = "5G RAN Mainstream Deploy Report - Main"
    }
    if(reportType == 'test') {
      subject = "5G RAN CI continous test report - Main"
    }
    if(reportType == 'mainstream_basic') {
      subject = "5G RAN software mainstream basic sanity report"
    }
    if(reportType == 'official_mainstream') {
      subject = "5G RAN mainstream report"
    }
    if(reportType == 'continuous_test') {
      subject = "5G RAN TL Continous Test Report - #${env.PIPELINE_BUILD_NUMBER}"
    }
    if(reportType == 'interim_build') {
      subject = "5G RAN Interim Build Report #${env.PIPELINE_BUILD_NUMBER}"
    }
    if(reportType == 'interim_sanity_test') {
      subject = "5G RAN interim sanity test report #${env.PIPELINE_BUILD_NUMBER}"
    }
    return subject
}

def getDevOpsMainstreamSupportPrimes(cfID='1256518500', actionType='get', fileName='devops_mainstream_support_prime_cf.py', shareLibBranch='main') {
  def ConfluencePage = new common.ConfluencePage()
  return ConfluencePage.confluencePageAction([cfID: cfID, 
                                              typeAction: actionType, 
                                              fileName: fileName, 
                                              shareLibBranch: shareLibBranch])
}

def determineEmailRecipients(reportType = "", mainstreamDataJson = [:], emailsOverride = [], applicationName = "") {
  def RAN_ORG_RECIPIENTS = ["mp.ran.sw.eng@dell.com", "mobile.phoenix.ran.l1.sw.all@dell.com", "tsb.ru.sw@Dell.com", "tsb.pw.ran.load.notification@dell.com"]
  def devOpsAllRecipients = ["mp.devops.full.team@dell.com"]
  def devOpsSanityRecipients = getDevOpsMainstreamSupportPrimes()
  def cuRecipients = ["software.team.cu@dell.com"]
  def duRecipients = ["mobile.phoenix.du.full.team@dell.com"]
  def emailRecipients = RAN_ORG_RECIPIENTS
  def invalidRecipients = [null]

  if (emailsOverride) {
    emailRecipients = emailsOverride
    return emailRecipients
  }

  // Build report recipients
  if((reportType == 'build')) {
    // In case build success send email to DevOps + submitters  + sumitter managers emails only
    if (mainstreamDataJson["is_success"]) {
      def appCommitterRecipients = []
      def managerRecipients = []
      def appNameLow = applicationName.toLowerCase()
      // Get committer emails
      if (mainstreamDataJson.containsKey('committer_emails')) {
        appCommitterRecipients = mainstreamDataJson["committer_emails"]["${appNameLow}"].unique()
      }
      // Get manager emails
      if (mainstreamDataJson.containsKey('manager_emails')) {
        managerRecipients = mainstreamDataJson["manager_emails"].unique()
      }
      emailRecipients = devOpsAllRecipients + appCommitterRecipients + managerRecipients
    }else {
      // Should only go to people in the change log and their managers, unless there is a failure, then it should only go to the CU
      if (applicationName == 'CU') {
        emailRecipients = devOpsAllRecipients + cuRecipients
      } else if (applicationName == 'DU') {
        emailRecipients = devOpsAllRecipients + duRecipients
      }
    }
  } else if(reportType == 'test') {
    def appCommitterRecipients = []
    def managerRecipients = []
    // Get committer emails
    if (mainstreamDataJson.containsKey('committer_emails')) {
      appCommitterRecipients = mainstreamDataJson["committer_emails"].values().flatten().unique()
    }
    // Get manager emails
    if (mainstreamDataJson.containsKey('manager_emails')) {
      managerRecipients = mainstreamDataJson["manager_emails"].values().flatten().unique()
    }
    if (mainstreamDataJson["is_success"]) {
      if(mainstreamDataJson["previous_test_status"] == "SUCCESS") {
        // Send email to the people accountable for changes and their managers if the test passed
        emailRecipients = devOpsAllRecipients + appCommitterRecipients + managerRecipients
      } else {
        // Send to 5GRanSwEngRecipients and Mobile Phoenix RAN L1 SW All
        emailRecipients = RAN_ORG_RECIPIENTS 
      }
    } else {
      // On failure the email should be sent TO: anybody responsible for a change listed in the change log and their managers. 
      // The email should be CC: to MP RAN SW Eng <mp.ran.sw.eng@dell.com> AND Mobile Phoenix RAN L1 SW All <mobile.phoenix.ran.l1.sw.all@dell.com>
      ccEmails = determineCopyEmails(RAN_ORG_RECIPIENTS)
      emailRecipients = appCommitterRecipients + managerRecipients + ccEmails
    }
  } else if(reportType == 'interim_build' || reportType == 'interim_sanity_test') {
    def appCommitterRecipients = []
    def managerRecipients = []
    //Get committer emails
    println mainstreamDataJson
    if (mainstreamDataJson.containsKey('committer_emails')) {
      appCommitterRecipients = mainstreamDataJson["committer_emails"].values().flatten().unique()
    }
    //Get manager emails
    if (mainstreamDataJson.containsKey('manager_emails')) {
      managerRecipients = mainstreamDataJson["manager_emails"].values().flatten().unique()
    }
    if (mainstreamDataJson["is_success"] == "true") {
      ccEmails = determineCopyEmails(devOpsAllRecipients)
      emailRecipients = appCommitterRecipients  + ccEmails
    }
    else {
      ccEmails = determineCopyEmails(devOpsAllRecipients)
      emailRecipients = appCommitterRecipients + managerRecipients + devOpsSanityRecipients + ccEmails
    }
  } else if(reportType == 'official_mainstream') {
    def appCommitterRecipients = []
    // Get committer emails
    if (mainstreamDataJson.containsKey('committer_emails')) {
      appCommitterRecipients = mainstreamDataJson["committer_emails"].values().flatten().unique()
    }
    if (mainstreamDataJson["flag_checker"] == "RED") {
      ccEmails = determineCopyEmails(RAN_ORG_RECIPIENTS)
      emailRecipients = appCommitterRecipients + devOpsSanityRecipients + ccEmails
    }
  }
  
  // Remove invalid Recipients
  emailRecipients.removeAll(invalidRecipients)

  return emailRecipients
}

def determineCopyEmails(ccEmails = []){
  prefix = 'cc:'
  ccEmails = ccEmails.collect { prefix + it }
  return ccEmails
}
