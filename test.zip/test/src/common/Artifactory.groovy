// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
package common

/**
 * This class utilizes some Artifactory APIs and wrap them up as groovy functions.
*/

/**
* Copy an artifact or a folder to the specified destination. Supported for local, remote and federated repositories only.
* @param  sourcePath   Specify source artifact path, e.g: mobile-phoenix-ran-generic-local/test-files/src/
* @param  destinationPath   Specify destination artifact path, e.g: mobile-phoenix-ran-generic-local/test-files/dest/
* @param  agentLabel   Specify Jenkins agent label to call the API. Default 'rhel8'
*/

def copyItem(def sourcePath=null, def destinationPath=null, agentLabel='rhel8') {
    if (!sourcePath) {
        throw new IllegalArgumentException("Missing 'sourcePath' parameter!")
    } else {
        println("sourcePath: " + sourcePath)
    }
    if (!destinationPath) {
        throw new IllegalArgumentException("Missing 'destinationPath' parameter!")
    } else {
        println("destinationPath: " + destinationPath)
    }


    node(agentLabel) {
        withCredentials([string(credentialsId: 'svc_npmphran_apikey', variable: 'SVC_NPMPHRAN_API_TOKEN')]){ 
            // Prepare shell environment
            env.artifactoryBaseUrl = "https://phm.artifactory.cec.lab.emc.com/artifactory"
            env.sourcePath = sourcePath
            env.destinationPath = destinationPath

            sh '''
                set +x
                api_request_url="$artifactoryBaseUrl/api/copy/$sourcePath?to=$destinationPath"
                # Standarize URL path (repace all '//' by '/' if any)
                api_request_url=$(echo "${api_request_url}" | sed 's://:/:g')
                echo "Sending request: $api_request_url"
                response=$(curl -sSk -H "X-JFrog-Art-Api: $SVC_NPMPHRAN_API_TOKEN" -w "%{http_code}" -X POST $api_request_url)
                http_code=${response: -3}
                content=$(sed '$ d' <<< "$response")   # get all but the last line which contains the status code
                echo "HTTP status code: $http_code"
                echo "$content"
                if [[ $http_code != 200 ]] ; then
                    echo "Error code $http_code in HTTP request"
                    exit 1
                fi
            '''
        }
    }
}


/**
*  Move an artifact or a folder to the specified destination. Supported for local, remote and federated repositories only.
* @param  sourcePath   Specify source artifact path, e.g: mobile-phoenix-ran-generic-local/test-files/src/
* @param  destinationPath   Specify destination artifact path, e.g: mobile-phoenix-ran-generic-local/test-files/dest/
* @param  agentLabel   Specify Jenkins agent label to call the API. Default 'rhel8'
*/

def moveItem(def sourcePath=null, def destinationPath=null, agentLabel='rhel8') {
    if (!sourcePath) {
        throw new IllegalArgumentException("Missing 'sourcePath' parameter!")
    } else {
        println("sourcePath: " + sourcePath)
    }
    if (!destinationPath) {
        throw new IllegalArgumentException("Missing 'destinationPath' parameter!")
    } else {
        println("destinationPath: " + destinationPath)
    }

    node(agentLabel) {
        withCredentials([string(credentialsId: 'svc_npmphran_apikey', variable: 'SVC_NPMPHRAN_API_TOKEN')]){
            // Prepare shell environment
            env.artifactoryBaseUrl = "https://phm.artifactory.cec.lab.emc.com/artifactory"
            env.sourcePath = sourcePath
            env.destinationPath = destinationPath

            sh '''
                set +x
                api_request_url="$artifactoryBaseUrl/api/move/$sourcePath?to=$destinationPath"
                # Standarize URL path (repace all '//' by '/' if any)
                api_request_url=$(echo "${api_request_url}" | sed 's://:/:g')
                echo "Sending request: $api_request_url"
                response=$(curl -sSk -H "X-JFrog-Art-Api: $SVC_NPMPHRAN_API_TOKEN" -w "%{http_code}" -X POST $api_request_url)
                http_code=${response: -3}
                content=$(sed '$ d' <<< "$response")   # get all but the last line which contains the status code
                echo "HTTP status code: $http_code"
                echo "$content"
                if [[ $http_code != 200 ]] ; then
                    echo "Error code $http_code in HTTP request"
                    exit 1
                fi
            '''
        }
    }
}

def promoteDockerImage(artifactoryRepo=null, dockerRepo=null, sourceTag=null, targetTag=null, agentLabel='rhel8') {
    if (!artifactoryRepo) {
        throw new IllegalArgumentException("Missing 'artifactoryRepo' parameter!")
    }
    if (!dockerRepo) {
        throw new IllegalArgumentException("Missing 'dockerRepo' parameter!")
    }
    if (!sourceTag) {
        throw new IllegalArgumentException("Missing 'sourceTag' parameter!")
    }
    if (!targetTag) {
        throw new IllegalArgumentException("Missing 'targetTag' parameter!")
    }

    artifactoryBaseUrl = "https://phm.artifactory.cec.lab.emc.com/artifactory"

    node(agentLabel) {
        withCredentials([string(credentialsId: 'svc_npmphran_apikey', variable: 'SVC_NPMPHRAN_API_TOKEN')]) {
            sh """
                echo "Promoted docker image"
              
                curl -H 'Content-Type: application/json' -v -H "Authorization: Bearer ${SVC_NPMPHRAN_API_TOKEN}" -sSfk  -X POST \
                    "$artifactoryBaseUrl/api/docker/$artifactoryRepo/v2/promote" \
                    --data '{"dockerRepository" : "$dockerRepo", "targetRepo" : "$artifactoryRepo", "tag" : "$sourceTag", "targetTag" : "$targetTag", "copy": true}'
            """
        }
    }
}

return this
