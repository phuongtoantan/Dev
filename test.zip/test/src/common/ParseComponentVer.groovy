package common
import java.util.regex.Pattern
import java.util.regex.Matcher

def getVersion(summaryPath, component, release, releaseSufix="-(\\d{4})") {
    data = readFile(summaryPath)

    lines = data.split('\n')
    for (int i = 0; i < lines.size(); i++){
        if (lines[i].find(component.toLowerCase())){
            Pattern pattenRelease = Pattern.compile(release + releaseSufix)
            Matcher matcher = pattenRelease.matcher(lines[i])
            while (matcher.find()){
                println(component + ": " + lines[i].substring(matcher.start(), matcher.end()))
                return component + "_" + lines[i].substring(matcher.start(), matcher.end()).replace("-", "_")
            }
        }
    }
}

def getComponentVersions(greenloadMetadata) {
    def componentVersions = [:]
    componentVersions.latestVerCU = getVersion(greenloadMetadata, "CU", "\\d\\.\\d\\.\\d\\.\\d")
    componentVersions.latestVerDU = getVersion(greenloadMetadata, "DU", "\\d\\.\\d\\.\\d\\.\\d")
    componentVersions.latestVerMPLANE = getVersion(greenloadMetadata, "MPLANE", "\\d\\.\\d\\.\\d\\.\\d")
    componentVersions.latestVerUESIM = getVersion(greenloadMetadata, "UESIM", "\\d\\.\\d\\.\\d\\.\\d")
    componentVersions.latestVerL1FW = getVersion(greenloadMetadata, "minerva-firmware", "\\d+\\..*\\.\\d+", "\\-\\d+")
    componentVersions.latestVerL1DRV = getVersion(greenloadMetadata, "minerva-host-drivers", , "\\d.*\\-.*\\_\\d\\-\\d.*","\\-\\d+")
    return componentVersions
}

return this