// Copyright © 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.
package common

/**
 * This function is used to scan security vulnerabilities in image.
 * Parameters Explaination: https://confluence.dell.com/display/CONS/twistcli+scan
 *
 * @param image_name: image used to scan security vulnerabilities.
 * @param output_file: Write the results of the scan to a file in JSON format.
 * @param format: Only support JSON and tabular formats.
 * @param address: address to the twistlock scan server
 * @param project: project to upload the scan result.
 */
def twistlockScan(image_name, output_file, format="tabular", address="", project=""){
    tlProperties = " --ci --details"
    TWISTLOCK_CLOUD_URL = 'https://containersecurity.dell.com'

    if (address != "") {
        TWISTLOCK_CLOUD_URL = "${address}"
    }
    if (format == 'json') {
        tlProperties += " --output-file ${output_file}"
    }
    if (project) {
        tlProperties += " --project ${project}"
    } else {
        tlProperties += " --project DELL_DIGITAL"
    }
    if (image_name) {
        tlProperties += " ${image_name}"
    }

    script {
        // Download twistcli tool from artifactory
        rtDownload (
            serverId: 'Artifactory-RR-PHM',
            spec: '''{
                "files": [
                    {
                        "pattern": "mobile-phoenix-ran-generic/tools/twistcli",
                        "target": "${WORKSPACE}/twistcli",
                        "flat": true
                    }
                ]
            }'''
        )
        // Add permission
        sh """
            chmod a+x twistcli
            ls -ltr
        """
        withCredentials([usernamePassword(credentialsId: 'svc_npmptwistlock', passwordVariable: 'password', usernameVariable: 'username')]) {
            if (format == 'tabular')
            {
                sh "./twistcli images scan --address $TWISTLOCK_CLOUD_URL -u $username -p $password $tlProperties > $output_file"
            } else {
                sh "./twistcli images scan --address $TWISTLOCK_CLOUD_URL -u $username -p $password $tlProperties"
            }
            
        }
    }
}
