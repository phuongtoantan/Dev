// Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

package common
import groovy.json.JsonSlurperClassic
import groovy.json.JsonSlurper

/**
 *  Template for sending generic results email from json.
*/
def reportFromJson(args = [jsonResult :null, reportType :null, buildNumber :null, buildURL :null, emailsOverride: null]) {
  node ('reporting_tool') {
    cleanWs()
    script {
      def Email = new common.Email()
      dataHtmlFile = "${env.WORKSPACE}/data.html"
      env.PIPELINE_BUILD_NUMBER = args.buildNumber

      arguments = " --output-html=./report/data.html"
      if(args.reportType) {
        arguments += " --report-type='${args.reportType}'"
        arguments += " --build-number='${args.buildNumber}'"
        arguments += " --build-url='${args.buildURL}'"
        if(args.reportType == 'continuous_test'){
          dataJson = args.jsonResult
          arguments += " --json-result='${args.jsonResult}'"
        }
      }
      arguments.trim()

      sh """
          git clone --branch main git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git mp-jenkins-shared-lib
          cd mp-jenkins-shared-lib
          buildah build --layers -t email_simple -f resources/tools/report/reportJsonSimple/email_simple.dockerfile .
          podman run --network host --privileged --rm \
          -v ${env.WORKSPACE}:/app/report \
          email_simple python3 generate_email_from_json.py ${arguments}
      """

      // Determine subject
      def subject = Email.determineEmailSubject(args.reportType, "", "")
      // Determine recipients
      def emailsOverride = ["sean.ohagan@dell.com", "Srecko.Pavicevic@Dell.com", "mike_boev@dell.com", "sang_nguyen1@dellteam.com", "vinh_vo@dellteam.com", "nhan_n@dellteam.com", "mp.devops.full.team@dell.com"]
      if(args.emailsOverride) {
        emailsOverride = args.emailsOverride
      }
      def emailRecipients = Email.determineEmailRecipients("", "", emailsOverride, "")
      if (fileExists(dataHtmlFile)) {
        emailext to: "${emailRecipients.join(',')}" ,
          subject: "${subject}",
          body: readFile(dataHtmlFile)
        emailSendingStatus = true
      } else {
        println "Skip sending email as data.html does not exist!"
      }
    }
    cleanWs()
    sh "podman system prune -f || true"
  }
  return emailSendingStatus
}