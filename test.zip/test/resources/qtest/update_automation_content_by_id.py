# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
import argparse
import requests
import logging
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

logging.basicConfig(level=logging.INFO, format='[%(asctime)s]   %(levelname)s: %(message)s', datefmt='%H:%M:%S')

class AutomationContentUpdater:
    def __init__(self, qtest_token):
        self.base_url = "https://qtest.gtie.dell.com/api/v3/projects/138"
        self.headers = {'Authorization': f'Bearer {qtest_token}'}
        self.qtest_token = qtest_token

    def get_test_case_by_id(self, test_case_id):
        """
        Get a test case by its ID
        """
        endpoint = f'{self.base_url}/test-cases/{test_case_id}'
        response = requests.get(endpoint, headers=self.headers, verify=False)
        if response.status_code == 200:
            return response.json()
        else:
            logging.error(f'Failed to fetch test case with ID {test_case_id}. Status code: {response.status_code}')
            return None

    def update_automation_content(self, test_case_ids):
        """
        Update automation content for test cases
        """
        logging.info(f'Updating automation content for {len(test_case_ids)} test cases')

        updated_count = 0
        for test_case_id in test_case_ids:
            test_case = self.get_test_case_by_id(test_case_id)
            if test_case:
                test_case_name = test_case['name']
                # Check if automation content needs update
                automation_content_prop = next((prop for prop in test_case.get('properties', []) if prop['field_name'] == 'Automation Content'), None)
                if automation_content_prop:
                    existing_content = automation_content_prop['field_value']
                    # Check if existing automation content contains '#'
                    if '#' in existing_content:
                        logging.info(f'Skipped test case "{test_case_name}" (ID: {test_case_id}). This test case contains "#" in its automation content.')
                    # Check if existing automation content is the same as test case name
                    elif existing_content == test_case_name:
                        logging.info(f'Skipped test case "{test_case_name}" (ID: {test_case_id}). Existing automation content is the same as the test case name.')
                    else:
                        field_id = automation_content_prop['field_id']  # Field ID for Automation Content
                        # Update automation content
                        updated_content = f"{existing_content}#{test_case_name}"
                        update_payload = {'properties': [{'field_id': field_id, 'field_name': 'Automation Content', 'field_value': updated_content}]}
                        response = requests.put(f'{self.base_url}/test-cases/{test_case_id}', json=update_payload, headers=self.headers, verify=False)
                        if response.status_code == 200:
                            logging.info(f'Updated automation content for test case "{test_case_name}" (ID: {test_case_id})')
                            updated_count += 1
                        else:
                            logging.error(f'Failed to update automation content for test case "{test_case_name}" (ID: {test_case_id}). Status code: {response.status_code}')
                            logging.error(f'Response content: {response.content}')
                else:
                    logging.info(f'Skipped test case "{test_case_name}" (ID: {test_case_id}). Automation content not found.')
            else:
                logging.error(f'Test case with ID {test_case_id} not found.')

        logging.info(f'Updated automation content for {updated_count} out of {len(test_case_ids)} test cases')

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--qtest_token", required=True, help="Provide qTest token")
    parser.add_argument("--test_case_ids_file", required=True, help="File containing test case IDs to update")
    args = parser.parse_args()

    # Read test case IDs from the file
    with open(args.test_case_ids_file, 'r') as f:
        test_case_ids = [int(line.strip()) for line in f]

    updater = AutomationContentUpdater(args.qtest_token)
    updater.update_automation_content(test_case_ids)
