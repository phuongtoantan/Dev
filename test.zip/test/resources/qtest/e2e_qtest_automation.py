# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

from datetime import datetime
import qtest
import argparse
import sys
import json
import TestCycleCreator
import logging
import pytz

logging.basicConfig(level=logging.INFO, format='[%(asctime)s]   %(levelname)s: %(message)s', datefmt='%H:%M:%S')

parser = argparse.ArgumentParser()
parser.add_argument("--qtest_token",
                    required=True,
                    help="Provide MP qtest token")
parser.add_argument("--tl_number",
                    default=None,
                    help="Test line number",
                    required=True)
parser.add_argument("--workspace",
                    default=None,
                    help="Jenkins workspace",
                    required=False)
parser.add_argument("--test_suite_id",
                    required=True,
                    help="Provide test suite ID to upload test run")
parser.add_argument("--test_type",
                    required=True,
                    help="Provide test type to create and upload test run")
parser.add_argument("--jira_id",
                    required=False,
                    help="Provide the Jira ID to import into Qtest")
args = parser.parse_args()
QTEST_TOKEN = args.qtest_token
TL_NUMBER = args.tl_number
WORKSPACE = args.workspace
TEST_CYCLE_ID = args.test_suite_id
TEST_TYPE = args.test_type
JIRA_ID = args.jira_id

qTest = qtest.QTest(QTEST_TOKEN,TL_NUMBER,WORKSPACE)
cycleCreator = TestCycleCreator.TestCycleCreator()

def get_week_number(date_str):
    date_obj = datetime.strptime(date_str, "%Y-%m-%d")
    return date_obj.strftime("%U")

def get_weekly_CT_test_cycle_name(next_week):
    DATE_STR = datetime.now().strftime("%Y-%m-%d")
    YEAR = datetime.now().strftime("%Y")
    week_in_year = int(get_week_number(DATE_STR)) + 1
    if next_week:
        week_in_year += 1
    week_in_year = '{:02d}'.format(week_in_year)
    if TEST_TYPE == "longevity":
        return f"{YEAR}-wk{week_in_year}-{TEST_TYPE.capitalize()}"
    return f"{YEAR}-wk{week_in_year}"

def create_test_cycle_with_weekly(test_cycle_id, next_week):
    weekly_test_cycle_name = get_weekly_CT_test_cycle_name(next_week)

    # Get monthly test cycle
    tc_id_month = cycleCreator.get_monthly_test_cycle(QTEST_TOKEN, test_cycle_id)

    # Get weekly test cycle
    all_test_cycle = qTest.get_multiple_test_cycle(tc_id_month)
    for test_cycle in all_test_cycle:
        if test_cycle['name'] == weekly_test_cycle_name:
            logging.info(f"{test_cycle['name']} - {test_cycle['id']} is already exist!")
            if TEST_TYPE == "longevity":
                return test_cycle['id']
            # Get Extra test cycle
            test_cycle_type = is_sub_test_cycle_exists(EXTRA_TEST_NAME, test_cycle['id'])

            if test_cycle_type:
                folder_test_cycle_type_id = test_cycle_type['id']
            else:
                folder_test_cycle_type_id = cycleCreator.create_test_cycle(EXTRA_TEST_NAME, QTEST_TOKEN, parent=test_cycle["id"])

            return folder_test_cycle_type_id
    # If Extra test cycle is not exist => Create
    weekly_id = cycleCreator.create_test_cycle(weekly_test_cycle_name, QTEST_TOKEN, parent=tc_id_month)
    if TEST_TYPE != "longevity":
        folder_test_cycle_type_id = cycleCreator.create_test_cycle(EXTRA_TEST_NAME, QTEST_TOKEN, parent=weekly_id)
        return folder_test_cycle_type_id
    else:
        return weekly_id

def get_current_date_GMT7():
    # Create a timezone object for GMT+7
    gmt7_tz = pytz.timezone('Asia/Ho_Chi_Minh')
    gmt7_time = datetime.now(gmt7_tz)

    # Return the GMT+7 date as a string in the format YYYY-MM-DD
    return gmt7_time.strftime('%Y-%m-%d')

def create_test_cycle_with_daily(test_cycle_id):
    DATE_STR = get_current_date_GMT7()
    test_cycle_name = DATE_STR
    tc_id_month = cycleCreator.get_monthly_test_cycle(QTEST_TOKEN, test_cycle_id)
    all_test_cycle = qTest.get_multiple_test_cycle(tc_id_month)
    is_exist = 0
    for test_cycle in all_test_cycle:
        if test_cycle['name'] == test_cycle_name:
            logging.info(f"{test_cycle['name']} - {test_cycle['id']} is already exist!")
            is_exist = test_cycle['id']
            return is_exist
    if is_exist == 0:
        cycleCreator.create_test_cycle(test_cycle_name, QTEST_TOKEN, parent=tc_id_month)
        all_test_cycle = qTest.get_multiple_test_cycle(tc_id_month)
        for test_cycle in all_test_cycle:
            if test_cycle['name'] == test_cycle_name:
                logging.info(f"{test_cycle['name']} - {test_cycle['id']} created successfully!")
                is_exist = test_cycle['id']
    return is_exist

def create_list_extra_test_suite(list_name_test_suite, folder_test_cycle_id, test_suite_ignore):
    for test_suite_name in list_name_test_suite:
        is_exist = 0
        list_test_suite = qTest.get_test_suite_in_test_cycle(folder_test_cycle_id)
        if list_test_suite:
            for test_suite in list_test_suite:
                if test_suite_name in test_suite['name']:
                    is_exist = test_suite['id']
                    logging.info(f"{test_suite['name']} - {test_suite['id']} is already exist!")
        if test_suite_ignore:
            for ignore in test_suite_ignore:
                if test_suite_name == ignore:
                    is_exist += 1
        if is_exist == 0:
            qTest.create_test_suite(test_suite_name,folder_test_cycle_id)

    return qTest.get_test_suite_in_test_cycle(folder_test_cycle_id)

def create_test_suite(folder_test_cycle_id):
    # Create all test_suite
    test_suite_ignore = []
    list_name_test_suite = qTest.collect_name_all_test_suite_in_module(TEST_DESIGN)
    if TEST_TYPE == "extra_test":
        test_suite_ignore = ["IODT", "Golden Run", "Scalability", "Interoperability", "Upgrade", "Mobility"]
    if TEST_TYPE == "longevity":
        test_suite_ignore = ["Resiliency", "Stress", "Scalability", "Performance", "IODT", "Golden Run (R1.0 Legacy)", "5G Core Interoperability", "Upgrade", "Mobility"]
    list_test_suite_created = create_list_extra_test_suite(list_name_test_suite, folder_test_cycle_id, test_suite_ignore)
    for test_suite_in_list in list_test_suite_created:
        logging.info(f"Test suite created: {test_suite_in_list['name']}")

def create_test_run_with_test_case(folder_test_cycle_id):
    # Create test suite if it is not exist
    if qTest.get_test_suite_in_test_cycle(folder_test_cycle_id):
        logging.info(f"Test suite is already exist!: {folder_test_cycle_id}")
    else:
        create_test_suite(folder_test_cycle_id)

    if TEST_TYPE in ["extra_test", "ft_test"]:
        list_test_cases = qTest.get_all_test_case(TEST_TYPE)
    else:
        list_test_cases = qTest.get_all_test_case_in_robot_result()

    data_in_submodule = qTest.query_all_test_case_in_submodule(TEST_DESIGN, list_test_cases)
    # Create test cases from collected data
    list_test_run_created = []
    for test_case in list_test_cases:
        try:
            # Query test case info to create test run
            test_case = data_in_submodule[test_case]
            # Get test suite id for test run
            test_suite = qTest.get_test_suite_id_in_test_cycle_with_test_suite_name(test_case['sub_module_name'], folder_test_cycle_id)
            # Create test run with test suite id
            if not qTest.is_test_run_exist_in_test_suite(test_suite, test_case['test_case_name'] ):
                if qTest.create_test_run(test_case['test_case_name'], test_suite, test_case['test_case_id']):
                    logging.info(f"Created test case {test_case['test_case_name']} successfully!")
                    list_test_run_created.append(test_case['test_case_name'])
        except Exception as err:
            logging.info(f"Encountering error while getting test_case data: {test_case} - {err}")
    return list_test_run_created

def create_smoke_test_suite(folder_test_cycle_id):
    # Create test_suite for TL_NUMBER_smoke_test
    test_suite_name = f"{TL_NUMBER}_smoke_test"
    is_exist = 0
    list_test_suite = qTest.get_test_suite_in_test_cycle(folder_test_cycle_id)
    if list_test_suite:
        for test_suite in list_test_suite:
            if test_suite_name in test_suite['name']:
                is_exist = test_suite['id']
                logging.info(f"{test_suite['name']} - {test_suite['id']} is already exist!")
    if is_exist == 0:
        qTest.create_test_suite(test_suite_name,folder_test_cycle_id)
        list_test_suite = qTest.get_test_suite_in_test_cycle(folder_test_cycle_id)
        if list_test_suite:
            for test_suite in list_test_suite:
                if test_suite_name in test_suite['name']:
                    is_exist = test_suite['id']
                    logging.info(f"{test_suite['name']} - {test_suite['id']} created successfully!")

    return is_exist

def get_name_test_case_in_test_results():
    list_test_case = []
    with open(f"{WORKSPACE}/robot-result.json", 'r') as file:
        test_data = json.load(file)

        for test_case in test_data['test_case_stats']:
            list_test_case.append(test_case['name'])

    return list_test_case

def create_smoke_test_run(test_suite_id):
    # Folder contain Test case of Smoke test: folderID = 784362
    list_test_case_name = get_name_test_case_in_test_results()
    if list_test_case_name:
        for test_case_name in list_test_case_name:
            test_case = qTest.query_test_case_with_name(test_case_name, "784362")
            try:
                if not qTest.is_test_run_exist_in_test_suite(test_suite_id, test_case_name):
                    qTest.create_test_run(test_case['name'], test_suite_id, test_case['id'])
            except Exception as err:
                logging.info(f"Unable to create test run in test suite - {err}\n{test_case}\n")

def get_weekly_test_cycle_id_by_name(name, test_cycle_id):
    all_test_cycle = qTest.get_test_cycle(test_cycle_id)
    for test_cycle in all_test_cycle:
        all_test_cycle_in_sub_test_cycle = qTest.get_test_cycle(test_cycle['id'])
        for item in all_test_cycle_in_sub_test_cycle:
            if name == item['name']:
                logging.info(f"Found Weekly Test Cycle with name: {item['name']} - {item['id']}")
                return item
    return False

def get_extra_test_id(test_cycle_id):
    all_test_cycle = qTest.get_test_cycle(test_cycle_id)
    for test_cycle in all_test_cycle:
        if EXTRA_TEST_NAME == test_cycle['name']:
            logging.info(f"Found Extra Test Cycle with name: {test_cycle['name']} - {test_cycle['id']}")
            return test_cycle["id"]
    logging.error(f"Could not find containerID with name {EXTRA_TEST_NAME}")
    
    return False

def is_sub_test_cycle_exists(name, test_cycle_id):
    all_test_cycle = qTest.get_test_cycle(test_cycle_id)
    for test_cycle in all_test_cycle:
        if name == test_cycle['name']:
            logging.info(f"Found Test Cycle with name: {test_cycle['name']} - {test_cycle['id']}")
            return test_cycle
    return None

def submit_qtest_with_extra_test_type(test_cycle_id):
    # Get test cycle id
    folder_test_cycle_id = create_test_cycle_with_weekly(test_cycle_id, False)

    percent_tl_test_cycle = qTest.check_percent_tl_test_cycle(folder_test_cycle_id)
    logging.info(f"Test Run Executed in Test Cycle ID {folder_test_cycle_id}: {percent_tl_test_cycle}%")

    create_test_run_with_test_case(folder_test_cycle_id)

    # Upload results test for test run
    qTest.submit_all_test_log_with_test_cycle(folder_test_cycle_id)

def get_test_info(test_type):
    try:
        test_definition = {
            "extra_test": {
                "test_cycle_name": "NFT Regression",
                "test_design": "769251"
            },
            "ft_test": {
                "test_cycle_name": "Functional Tests",
                "test_design": "1000090"
            },
            "longevity": {
                "test_cycle_name": "longevity",
                "test_design": "769251"
            },
            "smoke_test": {
                "test_cycle_name": "",
                "test_design": ""
            }
        }

        test_design = test_definition[test_type]["test_design"]
        test_cycle_name = test_definition[test_type]["test_cycle_name"]
        return test_design, test_cycle_name
    
    except Exception as err:
        logging.info(f"Encountering error while getting test info: {test_type} - {err}")

if __name__ == "__main__":
    # Define global variables
    TEST_DESIGN, EXTRA_TEST_NAME = get_test_info(TEST_TYPE)

    # test_cycle_id is parent_id (Smoke Tests or CT cyclie test)
    test_cycle_id = TEST_CYCLE_ID

    if TEST_TYPE == "smoke_test":
        folder_test_cycle_id = create_test_cycle_with_daily(test_cycle_id)
        test_suite_id = create_smoke_test_suite(folder_test_cycle_id)
        logging.info(f"{TL_NUMBER} smoke test suite - ID:{test_suite_id}")
        create_smoke_test_run(test_suite_id)
        qTest.submit_all_test_log(test_suite_id)
        # Mapping Jira ID to QTest if Jira ID exists
        if JIRA_ID not in ["", "null", None]:
            qTest.mapping_test_log_to_jira_id(qTest.failed_test_log_ids, JIRA_ID)

    if TEST_TYPE in ["extra_test", "ft_test", "longevity"]:
        submit_qtest_with_extra_test_type(test_cycle_id)

