# Copyright © 2024 Dell Inc. or its subsidiaries. All Rights Reserved.
import argparse
import json
import requests
from datetime import datetime, timedelta
import logging
import os
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

logging.basicConfig(level=logging.INFO, format='[%(asctime)s]   %(levelname)s: %(message)s', datefmt='%H:%M:%S')

class QTest:
    def __init__(self, qtest_token, tl_number, work_space):
        self.base_url = "https://qtest.gtie.dell.com/api/v3/projects/138"
        self.headers = {'Authorization': 'Bearer {}'.format(qtest_token),
                        'Content-Type' : 'application/json'}
        self.tl_number = tl_number
        self.work_space = work_space
        self.qtest_token = qtest_token
        self.qtest_status_mapping = {
            "FAIL": {"id": 602, "name": "Failed"},
            "SKIP": {"id": 40259, "name": "Skipped"},
            "PASS": {"id": 601, "name": "Passed"}
        }
        self.failed_test_log_ids = []

    def get_all_test_run(self, test_suite_id):
        list_test_runs = []
        url = f"{self.base_url}/test-runs?parentId={test_suite_id}&parentType=test-suite&pageSize=1000"
        response = requests.get(url, headers=self.headers, verify=False)
        if response.status_code == 200:
            response_json = response.json()
        else:
            url = f"{self.base_url}/test-runs?parentId={test_suite_id}&parentType=test-cycle&pageSize=1000"
            response = requests.get(url, headers=self.headers, verify=False)
            if response.status_code == 200:
                response_json = response.json()
            else:
                response_json = []
                logging.info(f"Could not found container ID: {test_suite_id}")

        if response_json:
            for item in response_json['items']:
                test_run = {}
                test_run['id'] = item['id']
                test_run['name'] = item['name']
                test_run['pid'] = item['pid']
                test_run['test_case_version_id'] = item['test_case_version_id']
                test_run['testCaseId'] = item['testCaseId']
                list_test_runs.append(test_run)

        return list_test_runs

    def get_test_run(self, test_run_id):
        test_run = {}
        url = f"{self.base_url}/test-runs/{test_run_id}"
        response = requests.get(url, headers=self.headers, verify=False)
        if response.status_code == 200:
            response_json = response.json()
            test_run['id'] = response_json['id']
            test_run['name'] = response_json['name']
            test_run['pid'] = response_json['pid']
            test_run['test_case_version_id'] = response_json['test_case_version_id']
            test_run['testCaseId'] = response_json['testCaseId']

        return test_run
    
    def convert_datetime(self, input_datetime):
        dt_obj = datetime.strptime(input_datetime, '%Y%m%d %H:%M:%S.%f')
        formatted_dt = dt_obj.strftime('%Y-%m-%dT%H:%M:%S')
        tz_offset = timedelta(hours=5, minutes=30)
        formatted_dt_with_offset = f'{formatted_dt}+{tz_offset.seconds // 3600:02d}:{(tz_offset.seconds // 60) % 60:02d}'
        return formatted_dt_with_offset
    
    def submit_test_log(self, test_run_id, data):
        logging.info('Submit test log in test run ID ' + str(test_run_id))
        test_run_json = self.get_test_run(test_run_id)
        response = requests.post('{baseUrl}/test-runs/{testRunId}/test-logs'.format(baseUrl=self.base_url, testRunId=test_run_id), json=data, headers=self.headers, verify=False)
        if response.status_code == 201:
            logging.info('Submit test log successful')
            return response.json()
        elif "Please specify an approved version" in response.text:
            requests.put('{baseUrl}/test-cases/{testCaseId}/approve'.format(baseUrl=self.base_url, testCaseId=test_run_json['testCaseId']), headers=self.headers, verify=False)
            response = requests.post('{baseUrl}/test-runs/{testRunId}/test-logs'.format(baseUrl=self.base_url, testRunId=test_run_id), json=data, headers=self.headers, verify=False)
            if response.status_code == 201:
                logging.info('Submit test log successful')
                return response.json()
        else:
            logging.info('Failed at step submit test log')
        return False
    
    def query_test_case_with_name(self, name, parent_id):
        url = "{base_url}/test-cases?page=1&size=1000&expandProps=false"
        if parent_id:    
            url += f"&parentId={parent_id}"

        response = requests.get(url.format(base_url=self.base_url), headers=self.headers, verify=False)
        test_cases_json = response.json()
        for item in test_cases_json:
            if name == item['name']:
                logging.info(f'Found Test Case with name {name} in test design {parent_id}')
                return item
        return False

    def create_test_run(self, test_run_name, test_suite_id, test_case_id):
        logging.info(f'Create test run with name {test_run_name}')
        url = f"{self.base_url}/test-runs?parentId={test_suite_id}&parentType=test-suite"
        param = {
            "name": test_run_name,
            "test_case":{
                "id": test_case_id
            }
        }
        response = requests.post(url, json=param, headers=self.headers, verify=False)
        if response.status_code == 201:
            return response.json()
        return False
    
    def get_all_test_case_in_robot_result(self):
        list_tc = []
        with open(f"{self.work_space}/robot-result.json", 'r') as file:
            test_data = json.load(file)

        for item in test_data['test_case_stats']:
            list_tc.append(item['name'])
        return list_tc
    
    def submit_all_test_log(self, test_suite_id):
        test_data = {}
        try:
            with open(f"{self.work_space}/robot-result.json", 'r') as file:
                test_data = json.load(file)

            all_test_run = self.get_all_test_run(test_suite_id)
            if all_test_run:
                for item in test_data['test_case_stats']:
                    logging.info(f"===================================== {item['name']} =====================================")
                    file_name = f"ran_test_report_{item['name']}.txt"
                    is_test_run_exist = False
                    for test_run in all_test_run:
                        if test_run['name'] == item['name']:
                            is_test_run_exist = True
                            param={}
                            param['exe_start_date'] = self.convert_datetime(item['start_time'])
                            param['exe_end_date'] = self.convert_datetime(item['end_time'])
                            param['status'] = self.qtest_status_mapping[item['status']]

                            version = self.parse_version_from_report_txt(file_name)

                            param['properties'] = [{"field_id": 82847, "field_name": "Build Info", "field_value": version}]
                            param['test_case_version_id'] = test_run['test_case_version_id']
                            #Get the logs path in the FTP and add it to the Test logs
                            with open(f"{self.work_space}/robot-result.json", 'r') as file:
                                test_data = json.load(file)
                            logs_ftp_path = test_data['log_path']
                            param['note'] = f"Build url: {test_data['jenkins_job_url']}\nTest line: {self.tl_number}\nLogs: {logs_ftp_path}"
                            test_logs = self.submit_test_log(test_run['id'], param)
                            # Attach the report
                            self.attach_log(test_logs["id"], "./product_test_5g/report.html")

                            if test_logs:
                                self.attach_log(test_logs["id"], file_name)
                                # Update failed_test_log_ids
                                if item['status'] == "FAIL":
                                    self.failed_test_log_ids.append(test_logs["id"])


                    if not is_test_run_exist:
                        logging.info(f"Could not found test run with name {item['name']} in container {test_suite_id}")

        except Exception as err:
            logging.info(f"Submit test log failed: {err}")

    def parse_version_from_report_txt(self, file_name):
        path = f"{self.work_space}/{file_name}"
        logging.info(f"Get component version from {path}")
        try:
            with open(path, 'r') as file:
                file_content = file.read()
            txt = file_content.split("\n\n")
            for i in txt:
                if "Topology & Versions" in i:
                    logging.info(i.replace("Topology & Versions: \n", ""))
                    return i.replace("Topology & Versions: \n", "")
        except:
            logging.info("Could not found file: " + path)
            return ""

    def attach_log(self, test_log_id, file_name):
        logging.info('Attach log to Test log: ' + str(test_log_id))
        path = f"{self.work_space}/{file_name}"
        try:
            header_upload = {
                'Authorization': 'Bearer {}'.format(self.qtest_token),
                'Content-Type': 'text/plain',
                'File-Name': file_name,
            }
            file_contents = open(path, 'rb').read()
            response = requests.post(f"{self.base_url}/test-logs/{test_log_id}/blob-handles", headers=header_upload, data=file_contents)
            if response.status_code == 201:
                logging.info("Attach log successfully")
                return True
            return False
        except:
            logging.info(f"Could not found file {path} to attach log")

    def create_test_suite(self, test_suite_name, parent_id):
        url = f"{self.base_url}/test-suites?parentId={parent_id}&parentType=test-cycle"
        param = {
            "name": test_suite_name,
            "parentId":parent_id, 
            "type":"2"
        }
        response = requests.post(url, json=param, headers=self.headers, verify=False)
        if response.status_code == 200:
            logging.info('Create succesfully')
            return response.json()
        return False

    def query_test_case_in_sub_module(self, name, module_id):
        url = f"{self.base_url}/modules?parentId={module_id}"
        response = requests.get(url, headers=self.headers, verify=False)
        if response.status_code == 200:
            for sub_module in response.json():
                result = self.query_test_case_with_name(name, sub_module['id'])
                if result:
                    data = {
                        "test_case_name" : result['name'],
                        "test_case_id" : result['id'],
                        "sub_module_name" : sub_module['name'],
                        "sub_module_id" : sub_module['id']
                    }
                    return data
        return False

    def check_percent_tl_test_cycle(self, test_cycle_id):
        total_test_run = 0
        executed = 0
        if self.get_test_suite_in_test_cycle(test_cycle_id):
            for test_suite in self.get_test_suite_in_test_cycle(test_cycle_id):
                if self.get_all_test_run(test_suite['id']):
                    for test_run in self.get_all_test_run(test_suite['id']):
                        total_test_run += 1
                        info_test_suite = self.get_test_log_of_test_run(test_run['id'])
                        if info_test_suite['items']:
                            executed += 1
                else:
                    logging.info(f"Could not found test run ID in test suite : {test_cycle_id}")
        else:
            logging.info(f"Could not found test suite ID in test cycle : {test_cycle_id}")
            return 0
        if total_test_run == 0 :
            return (executed/1)*100
        percent_executed = (executed/total_test_run)*100
        return percent_executed

    def get_test_suite_in_test_cycle(self, test_cycle_id):
        url = f"{self.base_url}/test-suites?parentId={test_cycle_id}&parentType=test-cycle"
        response = requests.get(url, headers=self.headers, verify=False)
        if response.status_code == 200:
            return response.json()
        return False

    def get_test_log_of_test_run(self, test_run_id):
        url = f"{self.base_url}/test-runs/{test_run_id}/test-logs?pageSize=100&page=1"
        response = requests.get(url, headers=self.headers, verify=False)
        if response.status_code == 200:
            return response.json()
        return False

    def get_name_sub_module(self, module_id):
        url = f"{self.base_url}/modules/{module_id}"
        response = requests.get(url, headers=self.headers, verify=False)
        if response.status_code == 200:
            return response.json()['name']
        return False

    def collect_name_all_test_suite_in_module(self, module_id):
        url = f"{self.base_url}/modules?parentId={module_id}"
        response = requests.get(url, headers=self.headers, verify=False)
        list_name = []
        if response.status_code == 200:
            for sub_module in response.json():
                list_name.append(self.get_name_sub_module(sub_module['id']))
            return list_name
        return False

    def get_test_suite_id_in_test_cycle_with_test_suite_name(self, test_suite_name, test_cycle_id):
        all_test_suite = self.get_test_suite_in_test_cycle(test_cycle_id)
        for test_suite_info in all_test_suite:
            if test_suite_info['name'] == test_suite_name :
                return test_suite_info['id']

    def get_test_suite_id_in_test_cycle_with_test_run(self, test_run_name, test_cycle_id):
        for test_suite in self.get_test_suite_in_test_cycle(test_cycle_id):
            for test_run in self.get_all_test_run(test_suite['id']):
                if test_run_name == test_run['name']:
                    return test_suite['id']

    def get_test_cycle(self, test_cycle):
        url = "{base_url}/test-cycles?parentType=test-cycle&page=1&pageSize=100"
        if test_cycle:    
            url += f"&parentId={test_cycle}"
        response = requests.get(url.format(base_url=self.base_url), headers=self.headers, verify=False)
        test_cycle_json = response.json()
        return test_cycle_json

    def submit_all_test_log_with_test_cycle(self, test_cycle_id):
        test_data = {}
        try:
            with open(f"{self.work_space}/robot-result.json", 'r') as file:
                test_data = json.load(file)
                for item in test_data['test_case_stats']:
                    test_suite_id = self.get_test_suite_id_in_test_cycle_with_test_run(item['name'],test_cycle_id)
                    all_test_run = self.get_all_test_run(test_suite_id)
                    logging.info(f"===================================== {item['name']} =====================================")
                    file_name = f"ran_test_report_{item['name']}.txt"
                    is_test_run_exist = False
                    for test_run in all_test_run:
                        if test_run['name'] == item['name']:
                            is_test_run_exist = True
                            param={}
                            param['exe_start_date'] = self.convert_datetime(item['start_time'])
                            param['exe_end_date'] = self.convert_datetime(item['end_time'])

                            param['status'] = self.qtest_status_mapping[item['status']]

                            version = self.parse_version_from_report_txt(file_name)

                            param['properties'] = [{"field_id": 82847, "field_name": "Build Info", "field_value": version}]
                            param['test_case_version_id'] = test_run['test_case_version_id']
                            logs_ftp_path = test_data['log_path']
                            param['note'] = f"Build url: {test_data['jenkins_job_url']}\nTest line: {self.tl_number}\nLogs: {logs_ftp_path}"
                            test_logs = self.submit_test_log(test_run['id'], param)
                            # Attach the report
                            self.attach_log(test_logs["id"], "./product_test_5g/report.html")

                            if test_logs:
                                self.attach_log(test_logs["id"], file_name)
                                # Update failed_test_log_ids
                                if item['status'] == "FAIL":
                                    self.failed_test_log_ids.append(test_logs["id"])

                    if not is_test_run_exist:
                        logging.info(f"Could not found test run with name {item['name']} in container {test_suite_id}")
        except Exception as err:
            logging.info(f"Submit test log failed: {err}")

    def get_multiple_test_cycle(self, test_cycle_id):
        url = f"{self.base_url}/test-cycles?parentId={test_cycle_id}&parentType=test-cycle&page=1&pageSize=100"
        response = requests.get(url, headers=self.headers, verify=False)
        if response.status_code == 200:
            response_json = response.json()
        return response_json
    
    def get_all_test_case(self, test_type):
        list_tc = []
        workspace = self.work_space.replace("/qtestWs", "")
        if test_type == "extra_test":
            folder_name = "non-functional"
        if test_type == "ft_test":
            folder_name = "functional"
        path = f"{workspace}/product_test_5g/resources/CT_Daily/{folder_name}/"
        # r=root, d=directories, f = files
        try:
            for r, d, f in os.walk(path):
                for item in f:
                    with open(path + item, 'r') as file:
                        file_content = file.read()
                        file_content = json.loads(file_content)

                        for block in file_content:
                            for test_script in block["test_script"]:
                                list_tc += test_script["test_cases"]
                    
        except Exception as err:
            logging.info(err)

        return list_tc
    
    def is_test_run_exist_in_test_suite(self, test_suite_id, test_run_name):
        url = f"{self.base_url}/test-runs?parentId={test_suite_id}&parentType=test-suite&pageSize=1000"
        response = requests.get(url, headers=self.headers, verify=False)
        if response.status_code == 200:
            response_json = response.json()
            for item in response_json['items']:
                if item["name"] == test_run_name:
                    return True
        return False
    
    def query_all_test_case_in_submodule(self, module_id, list_test_case_name):
        list_data = {}
        for test_case in list_test_case_name:
            list_data[test_case] = self.query_test_case_in_sub_module(test_case, module_id)
        return list_data
        

    def mapping_test_log_to_jira_id(self, testlogIDs, jiraID):
        try:
            # format of defect ID "MP-XXXXX;106;10004"
            defect_id = jiraID + ";106;10004"
            for logID in testlogIDs:
                url = f"{self.base_url}/test-logs/{logID}/defects"
                response = requests.post(url, json=[defect_id], headers=self.headers, verify=False)
                if response.status_code == 201:
                    logging.info(f"The linking of test log {logID} with Jira {jiraID} was successful.")
                    logging.info(response.json())
                else:
                    logging.info(f"The linking of test log {logID} with Jira {jiraID} was not successful.")
        except Exception as err:
            logging.info(f"The linking between QTest and Jira has encountered an error: {err}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("--qtest_token",
                        required=True,
                        help="Provide MP qtest token")
    parser.add_argument("--test_suite_id",
                        required=True,
                        help="Provide test suite ID to upload test run")
    parser.add_argument("--tl_number",
                        default=None,
                        help="Test line number",
                        required=True)
    parser.add_argument("--workspace",
                        default=None,
                        help="Jenkins workspace",
                        required=False)
    
    args = parser.parse_args()

    qtest = QTest(args.qtest_token, args.tl_number, args.workspace)
    qtest.submit_all_test_log(args.test_suite_id)
