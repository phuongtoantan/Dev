# Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.

import argparse
import requests
import logging
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

logging.basicConfig(level=logging.INFO, format='[%(asctime)s]   %(levelname)s: %(message)s', datefmt='%H:%M:%S')

class AutomationContentUpdater():
    def __init__(self, qtest_token):
        self.base_url = "https://qtest.gtie.dell.com/api/v3/projects/138"
        self.headers = {'Authorization': f'Bearer {qtest_token}'}
        self.qtest_token = qtest_token

    def get_test_case_by_id(self, test_case_id):
        """
        Send request to Qtest server to get test case information by test case id
        Return test_case(dict) or False
        """
        logging.info(f'Get test case properties by id: {test_case_id}')
        endpoint = f'{self.base_url}/test-cases/{test_case_id}'
        response = requests.get(endpoint, headers=self.headers, verify=False)
        if response.status_code == 200:
            test_case = response.json()
        else:
            logging.info(f'Failed to get test case by id: {test_case_id}')
            return False
        return test_case

    def get_list_test_cases_needs_to_be_updated(self, directory_id, directory_size):
        """
        Get list of test case needs to be update in a Test Design directory by directory id
        Return list of test case id(list) or []
        """
        logging.info(f'Get list test cases needs to be be updated by directory id: {directory_id}')
        list_of_test_cases_needs_to_be_updated = []
        total_test_cases = 0 # Total test cases in directory

        # Send request to get list of all test case in a Test Design directory by directory id
        endpoint = f'{self.base_url}/test-cases?parentId={directory_id}&page=1&size={directory_size}&expandProps=true&expandSteps=no'
        logging.info(f"Send get request to endpoint: {endpoint}")
        response = requests.get(endpoint, headers=self.headers, verify=False)
        if response.status_code == 200:
            test_cases = response.json()
            total_test_cases = len(test_cases)
            # Loop through each TC, if the TC needs updating, add its id to the result list
            for test_case in test_cases:
                is_automation = False
                is_automation_content_different_from_name = False
                for prop in test_case.get("properties", []):
                    # Check if Automation Content is different from Test case's name or not 
                    if prop.get("field_name") == "Automation Content" and prop.get("field_value") != test_case.get("name"):
                        is_automation_content_different_from_name = True
                    # Check if it's Automation Test case or not
                    if prop.get("field_name") == "Automation" and prop.get("field_value_name") == "Yes":
                        is_automation = True
                
                if (is_automation and is_automation_content_different_from_name ):
                    list_of_test_cases_needs_to_be_updated.append(test_case['id'])
        else:
            logging.info(f'Failed to get all test cases by directory id: {directory_id}')
            return []

        logging.info(f"Total Test cases: {total_test_cases}")
        logging.info(f"Total test cases need to be updated Automation Content: {len(list_of_test_cases_needs_to_be_updated)}")
        logging.info(f"List test cases need to be updated Automation Content: {list_of_test_cases_needs_to_be_updated}")
        return list_of_test_cases_needs_to_be_updated

    def update_test_case_automation_content_by_id(self, test_case_id):
        """
        Update Automation Content value of test case by test case id
        """
        logging.info(f"Update Automation Content property for test case {test_case_id}")

        # Get test case infomation
        test_case = self.get_test_case_by_id(test_case_id)
        if test_case:
            test_case_properties = test_case["properties"]
            test_case_name = test_case["name"]

            # Get property with field name = "Automation Content"
            new_property = [property for property in test_case_properties if property["field_name"] == "Automation Content"]

            # Update value of Automation Content
            if (len(new_property)) != 0:
                new_property[0]['field_value'] = test_case_name

            # Send request to update test case
            json_payload = {}
            json_payload['properties'] = new_property
            response = requests.put(f'{self.base_url}/test-cases/{test_case_id}', json=json_payload, headers=self.headers)
            if response.status_code == 200:
                logging.info(f"Test case {test_case_id} updated successfully")
                return
            else:
                logging.info(f'Failed to update test case {test_case_id}')
                return

    def update_automation_content_for_all_test_cases_by_directory_id(self, directory_id, directory_size):
        """
        Update Automation Content for all test cases in a Test Design directory by directory id
        """
        logging.info(f"Update Automation Content property for all test cases in Test Design directory {directory_id}")
        list_of_test_cases_needs_to_be_updated = self.get_list_test_cases_needs_to_be_updated(directory_id, directory_size)
        if list_of_test_cases_needs_to_be_updated:
            for test_case_id in list_of_test_cases_needs_to_be_updated:
                self.update_test_case_automation_content_by_id(test_case_id)

    def get_directory_name_by_id(self, directory_id, output_file):
        """
        Get qTest Design directory name by directory id
        """
        logging.info(f'Get directory name by directory id: {directory_id}')
        directory_name = None
        # Send request to get directory name by directory id
        endpoint = f'{self.base_url}/modules/{directory_id}'
        logging.info(f"Send get request to endpoint: {endpoint}")
        response = requests.get(endpoint, headers=self.headers, verify=False)
        if response.status_code == 200:
            directory_info = response.json()
            directory_name = directory_info["name"]
            with open(output_file, 'w') as fh:
                fh.write(directory_name)
        else:
            logging.info(f'Failed to get directory name by directory id {directory_id}')
        
        return directory_name

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--qtest_token",
                        required=True,
                        help="Provide MP qtest token")
    parser.add_argument("--directory_id",
                        required=True,
                        help="Test design directory ID for update Automation Content")
    parser.add_argument("--directory_size",
                        required=True,
                        help="Max number of test cases in Test design directory")
    parser.add_argument("--output_file",
                        required=False,
                        help="Specify output file path")
    
    args = parser.parse_args()
    directory_size = 2000
    try:
        directory_size = int(args.directory_size)
    except ValueError:
        print("Error: The directory_size is not a valid value. Use default value(2000).")
    automation_content_updater = AutomationContentUpdater(args.qtest_token)
    directory_name = automation_content_updater.get_directory_name_by_id(args.directory_id, args.output_file)
    automation_content_updater.update_automation_content_for_all_test_cases_by_directory_id(args.directory_id, directory_size)