# The MP releases metadata

This folder contains metadata for multiple releases/streams

## Stream table

| Stream Name      | Stream Metadata                                                            | Description                                                 |
| ---------------- | -------------------------------------------------------------------------- | ----------------------------------------------------------- |
| developstream    | [developstream_metadata.yaml](./developstream_metadata.yaml)               | Used for DevOps pipeline development and testing activities |
| mainstream (wip) | [not_ready_mainstream_metadata.yaml](./not_ready_mainstream_metadata.yaml) | WIP - Used for mainstream pipelines (top of main branch)    |
| upcoming...      | N/A - Reserved for upcoming stream                                         | N/A - Reserved for upcoming stream                          |
