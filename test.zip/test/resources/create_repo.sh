#!/bin/bash
# File name: create_repo.sh
#
# Authors:
# Copyright (c) 2024 Dell Inc. or its subsidiaries.
# All Rights Reserved.
# Set default values for the repo configuration
baseurl="https://phm.artifactory.cec.lab.emc.com/artifactory/private_wireless_rpm_packages/"
enabled=1
gpgcheck=0
metadata_expire=1
# Add the reposection as an argument with default value
reposection="druid-core-rpm"
name="private_wireless_rpm_packages"
password=""
username=""

# Override values from command line arguments
while [[ "$#" -gt 0 ]]; do
  case $1 in
    -b|--baseurl) baseurl="$2"; shift ;;
    -e|--enabled) enabled="$2"; shift ;;
    -g|--gpgcheck) gpgcheck="$2"; shift ;;
    -m|--metadata_expire) metadata_expire="$2"; shift ;;
    -n|--name) name="$2"; shift ;;
    -r|--reposection) reposection="$2"; shift ;;
    -p|--password) password="$2"; shift ;;
    -u|--username) username="$2"; shift ;;
    *) echo "Unknown parameter: $1"; exit 1 ;;
  esac
  shift
done

# Create the rpm_repos folder
mkdir -p rpm_repos

# Create the ran_druid.repo file
cat <<EOF > rpm_repos/"$reposection".repo
[$reposection]
baseurl = $baseurl
enabled = $enabled
gpgcheck = $gpgcheck
metadata_expire = $metadata_expire
name = $name
password = $password
username = $username
EOF

# Check if file creation was successful
if [ $? -eq 0 ]; then
  echo "Repository file created successfully."
else
  echo "Failed to create repository file."
fi
