import jira_interface
import logging as log
import argparse
import json
import sys
import re


"""
Jira_call version 1.0.0
Author: Abdullah Alzaydi
Parameters:

-Report,--Robot_Report: Require Robot Report File In Json Format
-Pipeline,--Pipeline_Job: Specify Pipline as will act as the main label that the issue will be indexed by,
-Branch,--Pipeline_Branch: Specify Pipline branch or default to Main,
-h (--help): display this help
"""


parser = argparse.ArgumentParser()

parser.add_argument(
    "-gitchange",
    "--git_change",
    help="Require git change",
    required=True,
)

parser.add_argument(
    "-Build",
    "--Build_Id",
    help="Specify Pipline build",
    required=True,
)
parser.add_argument(
    "-Jira_User",
    "--Jira_User",
    help="Jira_User",
    required=False,
)
parser.add_argument(
    "-Jira_Password",
    "--Jira_Password",
    help="Jira_Password",
    required=False,
)

args = parser.parse_args()
try:
    mp_issues = re.findall("MP-[0-9]+", args.git_change)
    
    client = jira_interface.JiraInterface(args.Jira_User, args.Jira_Password)
    for issue in mp_issues:
        if client.issue_exists(str(issue)):
            if client.is_bug(str(issue)):
                res = client.transition_bug_to_verify_resolution(str(issue))
                if res:
                    try:
                        client.update_issue_fix_build(str(issue))
                    except:
                        client.issue_add_comment(str(issue),"Failed to update build fix field")

                else:
                    client.issue_add_comment(str(issue),"Failed to transition to resolution verification")
            else:
                print("Issue %s is not a bug" % str(issue))
        else:
            print("Issue %s is not an valid/existing issue respurce" % str(issue))

except Exception as e:
    print(e)
