# Copyright © 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.

import jira_interface
import argparse
import sys
import datetime  
import re  
import logging as log                                  


"""
whitelisting version 1.0.0
Author: Abdullah Alzaydi
Parameters:
TODO
-h (--help): display this help
"""


specific_targets_r1 = ['main_r1', 'main_R1', 'MAIN_R1', 'Main_r1', 'CU_R1', 'DU_R1']
specific_targets_r2 = ['main_r2', 'main_R2', 'MAIN_R2', 'Main_r2', 'CU_R2', 'DU_R2']

specific_targets = specific_targets_r1 + specific_targets_r2


parser = argparse.ArgumentParser()

parser.add_argument(
    "-branch",
    "--Git_Branch",
    help="Ticket to be whitelisted",
    required=True,
)

parser.add_argument(
    "-target_branch",
    "--Target_Branch",
    help="Target change branch",
    required=True,
)

parser.add_argument(
     "-Jira_User",
     "--Jira_User",
     help="Jira_User",
     required=False,
)

parser.add_argument(
    "-Jira_Password",
    "--Jira_Password",
    help="Jira_Password",
    required=False,
)


args = parser.parse_args()

mp_issue = re.findall("MP-[0-9]+", args.Git_Branch, re.IGNORECASE)

target_branch = args.Target_Branch

# Check if the target_branch is in the specific targets list
if target_branch in specific_targets:
    log.error('Tragte Branch is locked, will be only merged manualy')
    sys.stdout.write('0')
    sys.exit("reach out to the DevOps team for manual intervention")


if not mp_issue:
    log.error('Branch not refrencing a valid Jira ticket')
    sys.stdout.write('0')
    exit("Branch needs to be renamed with the Jira Ticket")


client = jira_interface.JiraInterface(args.Jira_User, args.Jira_Password)

my_date = datetime.date.today()                      

year, current_week, day_of_week = my_date.isocalendar() 

# List of names
names = ["christian_delmas", "vikas_arora1", "vinay_revankar", "trevor_plestid", "libin_jose_meledam", "ved_prajapati"]

# Generate commented by clauses
comment_filter = ' OR '.join([f'issueFunction in commented("by {name}")' for name in names])


# JQL query template
jql_template = 'project = MP AND comment ~ "Hotlisted_RAN2.0" AND labels = Hotlist_Review AND fixVersion in (R2.0, RAN2.1, R2.1) and ({comment_filter})'

# Format the JQL query with the generated clauses
jql = jql_template.format(comment_filter=comment_filter)

# print("Jira Query: {jql}".format(jql=jql))

# log.info('Look up issue: {jql}'.format(jql=jql))
existing_issues = client.look_up_issue(jql=jql)

log.info('Jira Query: {jql}'.format(jql=jql))




existing_issues_list = []
for i in existing_issues:
    existing_issues_list.append(i.key)


log.info('MP Issue: {mp_issue}'.format(mp_issue=mp_issue))
log.info('Existing Issues: {existing_issues_list}'.format(existing_issues_list=existing_issues_list))    
    

if mp_issue[0].upper() in existing_issues_list:
    sys.stdout.write('1')
else:
    sys.stdout.write('0')
