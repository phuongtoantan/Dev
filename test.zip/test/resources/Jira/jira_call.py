import jira_interface
import logging as log
import argparse
import json
import sys


"""
Jira_call version 1.0.0
Author: Abdullah Alzaydi
Parameters:

-Report,--Robot_Report: Require Robot Report File In Json Format
-Pipeline,--Pipeline_Job: Specify Pipline as will act as the main label that the issue will be indexed by,
-Branch,--Pipeline_Branch: Specify Pipline branch or default to Main,
-h (--help): display this help
"""


parser = argparse.ArgumentParser()

parser.add_argument(
    "-Report",
    "--Robot_Report",
    help="Require Robot Report File In Json Format",
    required=True,
)
parser.add_argument(
    "-Pipeline",
    "--Pipeline_Job",
    help="Specify Pipline as will act as the main label that the issue will be indexed by",
    required=True,
)
parser.add_argument(
    "-Branch",
    "--Pipeline_Branch",
    default="main",
    help="Specify Pipline branch or default to Main",
    required=False,
)
parser.add_argument(
     "-Jira_User",
     "--Jira_User",
     help="Jira_User",
     required=False,
)
parser.add_argument(
    "-Jira_Password",
    "--Jira_Password",
    help="Jira_Password",
    required=False,
)


parser.add_argument(
    "-Components",
    "--Issue_Components",
    nargs="*",
    default=["DevOps"],
    help="Specify components for the Jira issue as a list (default: ['DevOps'])",
    required=False,
)


args = parser.parse_args()

with open(args.Robot_Report) as write_file:
    data = json.load(write_file)

FAILED = [i for i in data["test_case_stats"] if i["status"] == "FAIL"]

client = jira_interface.JiraInterface(args.Jira_User, args.Jira_Password)

# log.info("pipline_job"+ args.Pipeline_Job)
# print("pipline_job"+ args.Pipeline_Job)
    

jql = "project = {project} AND issuetype = {issuetype} AND status not in ({status1}, {status2}) AND priority = {priority} AND labels = {pipline} order by createdDate DESC".format(
    project="MP",
    issuetype="Bug",
    status1="Completed",
    status2="Cancelled",
    priority="High",
    pipline=args.Pipeline_Job,
)
# print(jql)


# log.info(jql)

# project = MP AND issuetype = Bug AND status = Open AND priority = High AND labels = CU_UT order by lastViewed DESC

issues = client.look_up_issue(jql=jql)

Description = None

if len(FAILED) > 0:

    # log.info("failes teste casses exist")
    # print("failes teste casses exist")

    Description = """
        Pipeline: {Pipeline}

        Branch: {Branch}

        State: {State}

        job:'<a href={jenkins_job_url}</a>

        Failed test case: 
        """.format(
        Pipeline=args.Pipeline_Job,
        Branch=args.Pipeline_Branch,
        State=("Failures" + str(len(FAILED))),
        jenkins_job_url=data["jenkins_job_url"],
    )

    l = Description.split("\n")

    for v, k in enumerate(FAILED):
        l.append(
            "        Failed test #"
            + str(v + 1)
            + ":"
            + str(json.dumps(k, indent=6, sort_keys=True))
        )
        l.append("")

    Description = "\n".join(l)

created_issue = None

if not issues and Description != None:

    # create issue
    # log.info("issue doesnt exist will open one")

    summary = str(args.Pipeline_Job) + " Automated P1 Tracking Ticket"
    labels = [str(args.Pipeline_Job)]
    priority = {"name": "High"}
    components = args.Issue_Components
    issuetype = {"name": "Bug"}
    Project = "MP"
    created_issue = client.create_issue(
        Project=Project,
        summary=summary,
        description=Description,
        issuetype=issuetype,
        components=components,
        labels=labels,
        priority=priority,
    )
    
    log.info("created the issue " + str(created_issue))
    # print("created the issue " + str(created_issue))
    sys.stdout.write(str(created_issue))

    
elif len(issues) > 0 and len(FAILED) == 0 or Description==None:

    # close issue
    log.info("no failed test casses and no action will be taken")

    print("no failed test casses and no action will be taken")


else:


    
    log.info("add comment to issue")
    
    Description = "Reaccured with the following details/n" + Description

    comment_obj = client.issue_add_comment(issue_id=issues[0], comment=Description)
    # # print(comment_obj,type(comment_obj),issues[0])
    created_issue = issues[0]
    sys.stdout.write(str(created_issue))
