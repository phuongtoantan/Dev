# Copyright © 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.

import jira_interface
import jenkins
import logging as log
import argparse
import json
import sys
from io import StringIO


"""
geberic_Jira_call version 1.0.0
Author: Abdullah Alzaydi
Parameters:

-Pipeline,--Pipeline_Job: Specify Pipline as will act as the main label that the issue will be indexed by,
-Branch,--Pipeline_Branch: Specify Pipline branch or default to Main,
-Description,--Description: The description that will be used as the body of the jira issue,
-summary,--summary: Jira ticket summary,


-h (--help): display this help
"""

# Custom action to parse comma-separated list
class CommaSeparatedListAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, values.split(','))


parser = argparse.ArgumentParser()

parser.add_argument(
    "-Pipeline",
    "--Pipeline_Job",
    help="Specify Pipline as will act as the main label that the issue will be indexed by",
    required=True,
)

parser.add_argument(
    "-Description",
    "--Description",
    help="the description that will be used as the body of the jira issue",
    required=True,
)
parser.add_argument(
    "-Branch",
    "--Pipeline_Branch",
    default="main",
    help="Specify Pipline branch or default to Main",
    required=False,
)

parser.add_argument(
    "-summary",
    "--summary",
    default="Automated Jenkins Tracking Ticket",
    help="Jira ticket summary",
    required=False,
)

parser.add_argument(
    "-Report",
    "--Robot_Report",
    help="Require Robot Report File In Json Format",
    required=False,
)

parser.add_argument(
    "-Jenkins_Password",
    "--Jenkins_Password",
    help="Jenkins_Password",
    required=False,
)

parser.add_argument(
    "-Jenkins_User",
    "--Jenkins_User",
    help="Jenkins_User",
    required=False,
)

parser.add_argument(
    "-Jira_User",
    "--Jira_User",
    help="Jira_User",
    required=False,
)

parser.add_argument(
    "-Jira_Password",
    "--Jira_Password",
    help="Jira_Password",
    required=False,
)

parser.add_argument(
    "-is_multibranch",
    "--is_multibranch",
    help="Flag to Indicate If the Current Job Is a Multibranch Pipeline",
    default=False,
    required=False,
)

# parser.add_argument(
#     "-Components",
#     "--Issue_Components",
#     nargs="*",
#     default=["DevOps"],
#     help="Specify components for the Jira issue as a list (default: ['DevOps'])",
#     required=False,
# )

# Add the argument for the list
parser.add_argument(
    '-Components',
    '--Issue_Components',
    action=CommaSeparatedListAction,
    default=['DevOps'],
    help="Specify components for the Jira issue as a list (default: 'DevOps')",
    required=False
)

parser.add_argument(
    "--degradationTcJiraType",
    help="Enable if the Jira is for degradation test cases.",
    required=False,
)

parser.add_argument(
    "--degradationInfo",
    default="",
    help="Details about the degradation scenario.",
    required=False,
)

args = parser.parse_args()

converted_list = [{"name": item} for item in args.Issue_Components]
log.info(converted_list)

client = jira_interface.JiraInterface(args.Jira_User, args.Jira_Password)

pipeline_branch = args.Pipeline_Job.split('/')

Pipeline_Job=""
if args.is_multibranch == 'true':
    for string in pipeline_branch[0 : len(pipeline_branch)-1]:
        Pipeline_Job += string  
    pipeline_branch = pipeline_branch[-1]
else:
    pipeline_branch = args.Pipeline_Branch

Pipeline_Job = args.Pipeline_Job if Pipeline_Job == "" else Pipeline_Job
pipeline_branch = args.Pipeline_Branch if Pipeline_Job == "" else pipeline_branch

jenkins = jenkins.Jenkins(Pipeline_Job, pipeline_branch, args.Description, args.Robot_Report, args.Jenkins_User, args.Jenkins_Password, args.is_multibranch)

link_build = args.Description.split()[0]
build_number = link_build.split('/')[-2]

jql = 'project = {project} AND issuetype = {issuetype} AND status not in ({status1}, {status2}) AND labels = "{pipline}" AND description ~ "\\"Branch: {branch}\\""'.format(
    project="MP",
    issuetype="Bug",
    status1="Completed",
    status2="Cancelled",
    pipline=Pipeline_Job,
    branch=pipeline_branch
)

jql_search=fail_details=''

if args.Robot_Report == "null" or args.Robot_Report == "":
    jql_search = jenkins.get_info_of_failure_reasons_to_search_jira()
    if jql_search != False:
        jql += jql_search + " order by createdDate DESC"
        fail_details = jenkins.detail_log_of_pipeline()
else:
    jql += jenkins.get_info_of_test_case_failed_to_search_jira() + " order by createdDate DESC"
    fail_details = jenkins.get_name_of_test_case()

log.info('Look up issue: {jql}'.format(jql=jql))

# Cover for case degradation TC jira only
if args.degradationTcJiraType == 'true':
    degradation_info_jql = f' AND description ~ "\\"{args.degradationInfo.split(" [")[0]}\\""'
    fail_details = args.degradationInfo + ".\n\n    NOTE: In case the tc baseline really decreases, the component owners can go to this pipeline and reset the baseline to a new value: https://osj-phm-02-prd.cec.delllabs.net/job/Reset-TcBaseline-Pipeline/"
    if jql_search != False: #non-empty string
        if jql_search:
            jql = jql.replace(jql_search, degradation_info_jql)
        else: #empty string
            jql = jql.replace(" order by createdDate DESC", degradation_info_jql + " order by createdDate DESC")
    else:
        jql += degradation_info_jql + " order by createdDate DESC"
        jql_search = '' # degradationTcJiraType does not search exist ticket by result of jenkins.get_info_of_failure_reasons_to_search_jira()

existing_issues = client.look_up_issue(jql=jql)

summary = str(args.summary)
labels = [str(Pipeline_Job)]
priority = {"name": "Medium"}
components = converted_list # Type is a list
issuetype = {"name": "Bug"}
Project = "MP"

Description = """
    Pipeline: {Pipeline}

    Branch: {Branch}

    Description: {Description}{Parent_Mainstream_Job}

    {Details}
    """.format(
    Pipeline=Pipeline_Job,
    Branch=pipeline_branch,
    Description=args.Description,
    Parent_Mainstream_Job=jenkins.is_triggered_by_mainstream_job,
    Details=fail_details)

l = Description.split("\n")

Description = "\n".join(l)

disable_list = {
    "DU_DEV/main": {
        "show_detail_log": False
    },
    "DU-BUILD-ALL": {
        "show_detail_log": False
    },
    "CU-mainstream-Test": {
        "show_detail_log": True
    }
} #TODO clean up ...

#TODO formalize the jenkins interaction with Jira <MP-60586>
if Pipeline_Job not in disable_list.keys() or args.degradationTcJiraType == 'true': 
    if not existing_issues or jql_search == False:
        #This step will execute when Jira dont have the same issue
        log.info("Create issue - execute when Jira dont have the same issue")
        
        created_issue = client.create_issue(
            Project=Project,
            summary=summary,
            description=Description,
            issuetype=issuetype,
            components=components,
            labels=labels,
            priority=priority,
        )
            
        log.info("created the issue " + str(created_issue))
        sys.stdout.write(str(created_issue))

    else:
        if "Failed step" not in Description or "Failed stage" not in Description:
            if "Failed test cases" not in Description and "Degradation TC numbers of" not in Description:
                #This step will execute when Jira have the same issue but it don't have details log
                log.info("Create issue - execute when Jira have the same issue but it don't have details log")

                created_issue = client.create_issue(
                    Project=Project,
                    summary=summary,
                    description=Description,
                    issuetype=issuetype,
                    components=components,
                    labels=labels,
                    priority=priority,
                )
                    
                log.info("created the issue " + str(created_issue))
                sys.stdout.write(str(created_issue))
            else:
                log.info("Add comment to issue")
                comment_obj = client.issue_add_comment(issue_id=existing_issues[0], comment=Description)
                created_issue = existing_issues[0]
                sys.stdout.write(str(created_issue))

        else:
            log.info("Add comment to issue")
            comment_obj = client.issue_add_comment(issue_id=existing_issues[0], comment=Description)
            created_issue = existing_issues[0]
            sys.stdout.write(str(created_issue))
    
    log.info('Attach log file - Main job')
    full_log = jenkins.get_full_log_of_stage()
    if full_log:
        client.issue_add_attachment(str(created_issue), full_log=full_log, filename=Pipeline_Job + "_" + build_number)  

    log.info('Attach log file - Downstream job')
    downstream_jobs = jenkins.get_full_log_of_downstream_job()
    for name, log in downstream_jobs.items():
        client.issue_add_attachment(str(created_issue), full_log=log, filename=name)

else:
    log.info("Create issue")
    is_show_detail_log = disable_list[Pipeline_Job]["show_detail_log"]
    if not is_show_detail_log:
        Description = """
            Pipeline: {Pipeline}

            Branch: {Branch}

            Description: {Description}
            """.format(
            Pipeline=Pipeline_Job,
            Branch=pipeline_branch,
            Description=args.Description,)

        l = Description.split("\n")

        Description = "\n".join(l)
        
    created_issue = client.create_issue(
        Project=Project,
        summary=summary,
        description=Description,
        issuetype=issuetype,
        components=components,
        labels=labels,
        priority=priority,
    )
        
    log.info("created the issue " + str(created_issue))
    sys.stdout.write(str(created_issue))