# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import re
from ldap3 import Server, Connection, ALL

class LDAP:
    """
    A class representing a LDAP server interface.
    """

    def __init__(self, ldap_username, ldap_password):
        self.ldap_server = "ldaps://appauth.dell.com:636"
        self.ldap_base_dn = "ou=users,dc=dell,dc=com"
        self.ldap_username = ldap_username
        self.ldap_password = ldap_password

    def get_manager_emails(self, list_user_cn):
        """
        This method returns a list of unique email addresses of the managers of the specified users, given a list of user common names (CNs)
        """
        manager_emails = []
        try:
            # Initialize connection to the LDAP server
            server = Server(self.ldap_server, get_info=ALL)
            conn = Connection(server, user=self.ldap_username, password=self.ldap_password, auto_bind=True)

            for user_cn in list_user_cn:
                # Search for the user's manager using their cn
                conn.search(self.ldap_base_dn, '(cn={})'.format(user_cn), attributes=['manager'])

                # Get the manager's DN from the search result
                manager_dn = conn.entries[0].manager.value
                match = re.search(r'CN=([^,]+)', manager_dn)
                if match:
                    manager_user = match.group(1)
                else:
                    print("Not found manager")

                # Search for the manager's information using their CN
                conn.search(self.ldap_base_dn, '(cn={})'.format(manager_user), attributes=['mail'])
                # Get the manager's email from the search result
                manager_emails.append(conn.entries[0].mail.value)
            # Get unique email list
            manager_emails = list(set(manager_emails))
        except Exception as err:
            print("[WARN] Unable to get the manager email, an error occurred: ", err)
        finally:
            # Close the LDAP connection
            conn.unbind()
        return manager_emails

    def get_emails_from_username(self, user_list):
        """
        This method returns a list of unique email addresses of users, given a list of user names (CNs)
        """
        emails = []
        server = Server(self.ldap_server, get_info=ALL)
        conn = Connection(server, user=self.ldap_username, password=self.ldap_password, auto_bind=True)
        try:
            # Initialize connection to the LDAP server
            # conn = Connection(server, user=self.ldap_username, password=self.ldap_password, auto_bind=True)
            for user in user_list:
                # Search for the manager's information using their CN
                conn.search(self.ldap_base_dn, '(cn={})'.format(user), attributes=['mail'])
                emails.append(conn.entries[0].mail.value)
            # Get unique email list
            emails = list(set(emails))
        except Exception as err:
            print("[WARN] Unable to get the email, an error occurred: ", err)
        finally:
            # Close the LDAP connection
            conn.unbind()
        return emails