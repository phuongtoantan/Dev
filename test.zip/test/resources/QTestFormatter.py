import xml.etree.ElementTree as ET
from xml.dom import minidom
import sys
import argparse

class QTestFormatter:

    def parse_report(self, filename):
        print(f'Parsing {filename} which is {type(filename)}')
        tree = ET.parse(filename)
        root = tree.getroot()
        return tree, root

    def print_report(self, tree, filename):
        tree.save(filename)

    def create_master_testsuite(self, source):
        master_testsuite = ET.Element('testsuite')
        keys = source.keys()
        for key in keys:
            master_testsuite.set(key, source.get(key))
        return master_testsuite

    def copy_testcase(self, testcase, dest):
        dest_testcase = ET.SubElement(dest, 'testcase')
        dest_testcase.set('classname', testcase.get('name'))
        dest_testcase.set('name', "")
        if testcase.get('status') is not None:
            dest_testcase.set('status', testcase.get('status'))
        if testcase.get('result') is not None:
            dest_testcase.set('result', testcase.get('result'))
        if testcase.get('time') is not None:
            dest_testcase.set('time', testcase.get('time'))
        if testcase.get('timestamp') is not None:
            dest_testcase.set('timestamp', testcase.get('timestamp'))

        failures = testcase.findall('failure')
        for failure in failures:
            test_failure = ET.SubElement(dest_testcase, 'failure')
            test_failure.set('message', failure.get('message'))

    def copy_testcase_list(self, source, parent_testsuite):
        total_time = 0
        total_failures = 0
        total_tests = 0
        # Copy all test cases into the top level suite
        testcases = source.findall('.//testcase')
        for testcase in testcases:
            self.copy_testcase(testcase, parent_testsuite)
            failures = testcase.findall('failure')
            total_failures += len(failures)
            total_tests += 1
            if testcase.get('time'):
                total_time += float(testcase.get('time'))

        parent_testsuite.set('time', str(round(total_time,3)))
        parent_testsuite.set('failures', str(total_failures))
        parent_testsuite.set('tests', str(total_tests))
        return

    def create_qtest_report(self, input_filename, output_filename):
        print(f'filename {input_filename}')
        orig_tree, orig_root = self.parse_report(input_filename)

        #create new document
        new_root = ET.Element('testsuites')
        master_testsuite = self.create_master_testsuite(orig_root)
        new_root.append(master_testsuite)
        self.copy_testcase_list(orig_root, master_testsuite)

        xmlstr = minidom.parseString(ET.tostring(new_root)).toprettyxml(indent="   ")
        with open(output_filename, 'w') as f:
            f.write(xmlstr)


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--input-file",
                        type=str,
                        required=True,
                        help="Name of xunit report")
    parser.add_argument("--output-file",
                        type=str,
                        required=True,
                        help="Name of reformatted xunit report")
    args = parser.parse_args()

    formatter = QTestFormatter()
    formatter.create_qtest_report(args.input_file, args.output_file)
