# Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
import json
import xmltodict
import time
import datetime
import sys, getopt
import re
from collections import OrderedDict

TEST_SUITES = []

def populate_detail(test):
    detail = OrderedDict()

    detail['name'] = test['@name']

    if 'tags' in test:
        detail['tag'] = test['tags']['tag']
    elif 'tag' in test:
        detail['tag'] = test['tag']

    
    
    
    detail['status'] = test['status']['@status']
    # Robot framework V7 doesn`t support starttime , endtime anymore, it supports start and elapsed
    # if old Robot version:
    if '@starttime' in test['status']:
        detail['start_time'] = test['status']['@starttime']
        detail['end_time'] = test['status']['@endtime']
        detail['elapsed_time'] = get_elapsed_time(test['status']['@starttime'],
                                                    test['status']['@endtime'])  
    else:
        detail['start_time'] = test['status']['@start']
        detail['elapsed_time'] = test['status']['@elapsed']

    # Get message for failure test case
    if '#text' in test['status']:
        detail['message'] = test['status']['#text']

    return detail


def parse_test(tests):
    details = []
    if isinstance(tests, list):
        for test in tests:
            details.append(populate_detail(test))
    else:
        # In case tests is not iterable
        details.append(populate_detail(tests))
    return details


def get_test_cases(suites):
    data = {}
    details = []
    for suite in suites:
        details += parse_test(suite['test'])
    data['details'] = details

    return data

def get_log_path(suites):
    try:
        details = ""
        for suite in suites:
            details += parse_setup(suite['kw'])

        return details
    except:
        print("Could not get log path")
        return ""

def parse_setup(tests):
    if isinstance(tests, list):
        for test in tests:
            log_path = populate_log_path(test)
            if log_path:
                return log_path
    else:
        # In case tests is not iterable
        log_path = populate_log_path(test)
        if log_path:
            return log_path

def populate_log_path(test):
    log_path=""
    if test['@type'] == "SETUP":
        for i in test['kw']:
            if i['@name'] == "Test Log Collection Prep":
                for a in i['msg']:
                    if "Created suite directory" in a['#text']:
                        log_path = a['#text'].split(": ")[-1]
    return log_path


def get_elapsed_time(start_time, end_time):
    
    start = time.mktime(
    datetime.datetime.strptime(start_time,
                                "%Y%m%d %H:%M:%S.%f").timetuple())
    end = time.mktime(
        datetime.datetime.strptime(end_time, "%Y%m%d %H:%M:%S.%f").timetuple())
        
    elapsed_time = time.strftime('%H:%M:%S', time.gmtime(end - start))
    return elapsed_time

def get_total_stat(total_stats):
    total_stat = total_stats

    # Cover case total_stats is a list
    if type(total_stats) is list:
        for stat in total_stats:
            if stat['#text'] == 'All Tests':
                total_stat = stat
                break
    return total_stat


### Example of a test suite format:
# "suite": {
#     "suite": [
#         {
#             "suite": {
#                 "suite": {
#                     "suite": {
#                         "test": [ ]
#  ..................................

### Using recursion approach to find 'test' tags in xml file
def get_test_suites(suite):
    # Check base case
    if 'test' in suite:
        TEST_SUITES.append(suite)
        return
    else:
        if isinstance(suite, list):
            # Case: "suite": [{"suite":...}, ...]
            for sub_suite in suite:
                get_test_suites(sub_suite)
        else:
            # Case: "suite": {"suite":...}
            get_test_suites(suite['suite'])

def parse_xml_file(input_xml_file, jenkins_job_url, is_tl):
    with open(input_xml_file, "r") as xml_file:
        xml_input = xml_file.read().replace('\n', '')

        # Dictionary populated with data from xml file
        all_data = xmltodict.parse(xml_input)['robot']
        get_test_suites(all_data['suite'])
        test_cases = get_test_cases(TEST_SUITES)

        # Prepare result
        result = OrderedDict()
        result['jenkins_job_url'] = jenkins_job_url

        total_stat = get_total_stat(all_data['statistics']['total']['stat'])

        total_pass = int(total_stat['@pass'])
        total_fail = int(total_stat['@fail'])
        total_skip = 0
        if '@skip' in total_stat:
            total_skip = int(total_stat['@skip'])

        result['total'] = total_pass + total_fail + total_skip

        result['pass'] = total_pass
        result['fail'] = total_fail
        result['skip'] = total_skip
        if '@starttime' in all_data['suite']['status']:
            if all_data['suite']['status']['@starttime'] == 'N/A' or all_data['suite']['status']['@endtime'] == 'N/A':
                result['elapsed_time'] = 'N/A'
            else:
                result['elapsed_time'] = get_elapsed_time(
                    all_data['suite']['status']['@starttime'],
                    all_data['suite']['status']['@endtime'])
                
                
        result['test_case_stats'] = test_cases['details']

        if is_tl:
            log_path = get_log_path(TEST_SUITES)
            result['log_path'] = log_path

    return result


def write_json_to_file(data, output_file):
    json_data = json.dumps(data, indent=4)
    with open(output_file, "w") as json_file:
        json_file.write(json_data)


def usage():
    print("""Usage:
    parse-robot-output.py -i <input-xml-file> -o <output-json-file> -j <jenkins-job-url>
    -i, --input-file   xml file generated by robot test (e.g: robot-result/output.xml)
    -o, --output-file   where to store json (e.g: output/output.json)
    -j, --jenkins-url   jenkins job url (e.g: https://osj-phm-02-prd.cec.delllabs.net/job/CU_UT/job/main/17)
    --test-line    Is Test line or not (input: true or false)
    -h, --help  this message
    """)
    sys.exit(2)


def check_input_parameters(argv):
    input_file = ''
    output_file = ''
    jenkins_job_url = ''
    is_tl = ''

    try:
        opts, args = getopt.getopt(argv, 'i:o:j:h:t',
                                   ['input-file=', 'output-file=','jenkins-url', 'help', 'test-line='])
    except getopt.GetoptError:
        usage()

    for opt, arg in opts:
        if opt in ('-h', '--help'):
            usage()
        elif opt in ("-i", "--input-file"):
            input_file = arg
        elif opt in ("-o", "--output-file"):
            output_file = arg
        elif opt in ("-j", "--jenkins-url"):
            jenkins_job_url = arg
        elif opt in ("-t", "--test-line"):
            is_tl = arg
        else:
            usage()

    if not input_file:
        print('Missing input file, please check!')
        usage()

    if not output_file:
        print('Missing output file, please check!')
        usage()

    print('Input file is: ', input_file)
    print('Output file is: ', output_file)

    return input_file, output_file, jenkins_job_url, is_tl


def main(argv):
    print('Checking input parameters ...')
    input_file, output_file, jenkins_job_url, is_tl = check_input_parameters(argv)

    print('Parsing xml file ...')
    data = parse_xml_file(input_file, jenkins_job_url, is_tl)

    print('Saving json data to output file: {} ...'.format(output_file))
    write_json_to_file(data, output_file)


if __name__ == "__main__":
    main(sys.argv[1:])
