# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import requests
import warnings
import json
import re
warnings.filterwarnings("ignore", category=DeprecationWarning)

OFFICIAL_SEM_VERSIONS = {
    "CU": "CU_2.1.0.0",
    "gNB_CU": "CU_2.1.0.0",
    "DU": "DU_2.1.0.0",
    "gNB_DU": "DU_2.1.0.0",
}

class Github:
    """
    A class representing a Github repository.
    """

    def __init__(self, owner, access_token=None):
        self.owner = owner
        self.access_token = access_token
        self.base_api_url = "https://eos2git.cec.lab.emc.com/api/v3/repos"
        self.mp_github_api_url = f"{self.base_api_url}/{owner}"

    def _get_request(self, url):
        """
        Sends a GET request to the specified url and returns the response data as a dictionary.

        Parameters
        ----------
        url : str
            The url to send the GET request to.

        Returns
        -------
        dict
            The response data as a dictionary.
        """
        headers = {}
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        response = requests.get(url, headers=headers, verify=False)
        response.raise_for_status()
        return response.json()

    def get_official_sem_version(self, repo):
        return OFFICIAL_SEM_VERSIONS.get(repo, "")

    def get_all_tags(self, repo, sem_version = "", reverse = False):
        """
        Retrieves all tags in the specified repository and returns the response data as a dictionary.

        Parameters
        ----------
        repo : str
            The repository to retrieve all tags from.

        Returns
        -------
        dict
            The response data as a dictionary.
        """
        all_tags = []
        try:
            if sem_version:
                url = f"{self.mp_github_api_url}/{repo}/git/refs/tags/{sem_version}"
            else:
                url = f"{self.mp_github_api_url}/{repo}/git/refs/tags/"
            all_tags = self._get_request(url)
            # Reverse alphabetical order if 'reverse' flag enabled
            if reverse:
                all_tags.reverse()
        except Exception as err:
            print("[WARN] Unable to get the tags, an error occurred: ", err)

        return all_tags

    def get_previous_tag(self, all_tags, current_tag):
        """
        Returns the previous tag in the given list of tags relative to the current tag.

        Parameters
        ----------
        all_tags : list
            The list of tags to search for the previous tag.
        current_tag : str
            The current tag to find the previous tag for.

        Returns
        -------
        str
            The previous tag relative to the current tag.
        """
        ...
        custom_current_tag = f"refs/tags/{current_tag}"
        current_index = next((i for i, tag in enumerate(
            all_tags) if tag["ref"] == custom_current_tag), None)

        if current_index is None:
            # In case can not find the current tag from all tag list, use the latest tag from that list
            # This is to cover case getting change log for temporary tag
            prev_tag = all_tags[len(all_tags)-1]["ref"]
            return prev_tag.replace("refs/tags/", "")

        if current_index is not None and current_index > 0:
            prev_tag = all_tags[current_index-1]["ref"]
            return prev_tag.replace("refs/tags/", "")
        else:
            return None

    def get_tag_changes(self, repo, tag, target_tag_to_compare=None, report_type=None, max_depth=30):
        """
        Retrieves the changes between the specified tag and the previous tag in the given repository.

        Parameters
        ----------
        repo : str
            The repository to retrieve the changes from.
        tag : str
            The tag to retrieve changes for.
        max_depth : int, optional
            The maximum number of tags to compare, by default 30.

        Returns
        -------
        dict
            The changes between the specified tag and the previous tag as a dictionary.
        """
        changes = []
        # get previous tag outside the loop
        if target_tag_to_compare is not None:
            previous_tag = target_tag_to_compare
            return self.compare_tags_helper(repo, tag, previous_tag)
        else:
            url = f"{self.mp_github_api_url}/{repo}/git/refs/tags/{tag}"
            test_data = self._get_request(url)
            if not test_data["ref"]:
                raise ValueError("Invalid tag name")
            tag_name = test_data["ref"].replace("refs/tags/", "")
            all_tags = self.get_all_tags(repo, self.get_official_sem_version(repo))
            previous_tag = self.get_previous_tag(all_tags, tag_name)

        if report_type == "TEST":
            changes = self.compare_tags_helper(repo, tag_name, previous_tag)
        else:
            for i in range(max_depth):  # set a maximum number of tags to compare
                if previous_tag is not None:
                    changes = self.compare_tags_helper(repo, tag_name, previous_tag)
                    if len(changes["commits"]) > 0:
                        break
                previous_tag = self.get_previous_tag(all_tags, previous_tag)

        return changes

    def compare_tags_helper(self, repo, current_tag, prev_tag):
        """
        Returns a dictionary containing information about changes made between two tags in a repository.
        :param repo: (str) The name of the repository.
        :param current_tag: (str) The name of the current tag.
        :param prev_tag: (str) The name of the previous tag.
        :return: (dict) A dictionary containing information about the changes made between the two tags.
        """
        changes = {
            "commits": [],
            "files_added": [],
            "files_removed": [],
            "files_modified": [],
            "messages": [],
            "committers": [],
            "committer_emails": [],
            "committer_ldap_cns": []
        }
        try:
            url = f"{self.mp_github_api_url}/{repo}/compare/{prev_tag}...{current_tag}"
            compare_result = self._get_request(url)

            if "ahead_by" not in compare_result:
                return {}

            for commit in compare_result["commits"]:
                changes["commits"].append({
                    "message": commit["commit"]["message"],
                    "author": commit["commit"]["author"]["name"],
                    "author_email": commit["commit"]["author"]["email"],
                    "date": commit["commit"]["author"]["date"],
                    "url": commit["html_url"]
                })
                # only get first line of commit message
                changes["messages"].append(
                    commit["commit"]["message"].split('\n')[0])
                changes["committers"].append(commit["commit"]["author"]["name"])
                changes["committer_emails"].append(
                    commit["commit"]["author"]["email"])

                if commit["author"] and commit["author"]["ldap_dn"]:
                    committer_ldap_cn = self.get_ldap_cn(commit["author"]["ldap_dn"])
                    if committer_ldap_cn:
                        changes["committer_ldap_cns"].append(committer_ldap_cn)
        except Exception as err:
            print("[WARN] Unable to compare 2 tags, an error occurred: ", err)

        return changes

    def get_shas_changes(self, repo, current_sha, prev_sha, per_page=100):
        """
        Returns a dictionary containing information about changes made between two SHAs in a repository.
        :param repo: (str) The name of the repository.
        :param current_sha: (str) The current short sha.
        :param prev_sha: (str) The previous short sha.
        :return: (dict) A dictionary containing information about the changes made between the two SHAs.
        """
        url = f"{self.mp_github_api_url}/{repo}/commits?per_page={per_page}"
        compare_result = self._get_request(url)

        changes = {
            "commits": [],
            "files_added": [],
            "files_removed": [],
            "files_modified": [],
            "messages": [],
            "committers": [],
            "committer_emails": [],
            "committer_ldap_cns": []
        }
        is_data_collected = False

        # Return empty in current_sha case equals prev_sha
        if current_sha == prev_sha:
            return changes

        for commit in compare_result:
            if current_sha in commit["sha"]:
                is_data_collected = True
            # Exit loops if find the prev commit
            elif prev_sha in commit["sha"]: 
                break
            if is_data_collected:
                changes["commits"].append({
                    "message": commit["commit"]["message"],
                    "author": commit["commit"]["author"]["name"],
                    "author_email": commit["commit"]["author"]["email"],
                    "date": commit["commit"]["author"]["date"],
                    "url": commit["html_url"]
                })
                # only get first line of commit message
                changes["messages"].append(
                    commit["commit"]["message"].split('\n')[0])
                changes["committers"].append(commit["commit"]["author"]["name"])
                changes["committer_emails"].append(
                    commit["commit"]["author"]["email"])

                if commit["author"] and commit["author"]["ldap_dn"]:
                    committer_ldap_cn = self.get_ldap_cn(commit["author"]["ldap_dn"])
                    if committer_ldap_cn:
                        changes["committer_ldap_cns"].append(committer_ldap_cn)

        return changes
   
    def get_tag_changes_for_send_mail(self, repo, tag, target_tag_to_compare=None, create_json=False, max_depth=30):
        if target_tag_to_compare is not None and target_tag_to_compare != "null":
            previous_tag = target_tag_to_compare
            changes = self.compare_tags_for_send_mail(repo, tag, previous_tag)
        else:
            url = f"{self.mp_github_api_url}/{repo}/git/refs/tags/{tag}"
            test_data = self._get_request(url)
            if not test_data["ref"]:
                raise ValueError("Invalid tag name")
            tag_name = test_data["ref"].replace("refs/tags/", "")
            all_tags = self.get_all_tags(repo, self.get_official_sem_version(repo))
            previous_tag = self.get_previous_tag(all_tags, tag_name)

            for i in range(max_depth):  # set a maximum number of tags to compare
                if previous_tag is not None:
                    changes = self.compare_tags_for_send_mail(repo, tag_name, previous_tag)
                    if len(changes) > 0:
                        break
                previous_tag = self.get_previous_tag(all_tags, previous_tag)

        if create_json:
            changes_json = json.dumps(changes, sort_keys=True, indent=4)
            json_file = open("changes_log.json", "w")
            json_file.write(changes_json)
            json_file.close()

        return changes
    
    def get_submodule_shas(self, repo, tag, hash_only=False):
        """
        Returns a list of the SHAs of the submodules in the specified tag of given repo.
        """
        # Get the SHA of the tag
        print("Get the SHA of the tag")
        url = f"{self.mp_github_api_url}/{repo}/git/refs/tags/{tag}"
        response = self._get_request(url)
        tag_sha = response["object"]["sha"]

        # Get the tree of the tag
        url = f"{self.mp_github_api_url}/{repo}/git/trees/{tag_sha}"
        tag_tree = self._get_request(url)

        # Get the SHAs of the submodules
        submodule_shas = {}
        for item in tag_tree["tree"]:
            # Only submodule paths have the 'commit' type
            if item["type"] == "commit":
                # In super repo, submodule name has the same name with the submodule repo name
                submodule_name = item["path"]
                submodule_sha = item["sha"]
                if hash_only:
                    submodule_shas[submodule_name] = submodule_sha
                else:
                    associated_tag = self.get_associated_tag(
                        submodule_name, submodule_sha, tag)
                    if associated_tag != "":
                        # Using tag if existed
                        submodule_shas[submodule_name] = associated_tag
                    else:
                        submodule_shas[submodule_name] = submodule_sha
        print(f"Submodule SHAs: {submodule_shas}")
        return submodule_shas

    def get_associated_tag(self, repo, commit_sha, app_version = None):
        """
        Retrieves the associated tag of a commit using the GitHub API.
        """
        associated_tag = ""
        all_tags = self.get_all_tags(repo, self.get_official_sem_version(repo))
        for tag in all_tags:
            if tag["object"]["sha"] == commit_sha:
                associated_tag = tag["ref"].replace("refs/tags/", "")
                if associated_tag == app_version:
                    print(f"Found associated tag: {associated_tag}")
                    break
        return associated_tag

    def get_ldap_cn(self, ldap_dn):
        """
        Retrieves the LDAP CN based on given LDAP DN
        """
        ldap_cn = ""
        ldap_cn_match = re.search(r'CN=([^,]+)', ldap_dn)
        if ldap_cn_match:
            ldap_cn = ldap_cn_match.group(1)
        return ldap_cn
    
    def get_submodule_info(self, repo, commit_sha):
        """
        Retrieves the current SHA and the previous SHA of submodule using the GitHub API.
        """
        submodules = {}
        url = f"{self.mp_github_api_url}/{repo}/commits/{commit_sha}"
        commits = self._get_request(url)
        files = commits["files"]
        for file in files:
            hashs_dict = {}
            hashs_dict["current_sha"] = file["sha"]
            # The file["patch"] format: "patch": "@@ -1 +1 @@\n-Subproject commit previous_SHA\n+Subproject commit current_SHA"
            # Split the string to get the previous_SHA
            hashs_dict["prev_sha"] = file["patch"].split("\n")[-2].split(" ")[-1]
            if(file['filename'] not in ['.gitmodules','Jenkinsfile','README.md']):
                submodules[file["filename"]] = hashs_dict

        return submodules
    
    def get_submodule_changes(self, repo, tag, exclude_module_list, target_tag_to_compare=None, report_type="TEST"):
        """
        Retrieves and combine commits of submodules using the GitHub API.
        """
        list_change_info = []
        changes = {
            "commits": [],
            "files_added": [],
            "files_removed": [],
            "files_modified": [],
            "messages": [],
            "committers": [],
            "committer_emails": [],
            "committer_ldap_cns": [],
            "module_names": []
        }
        submodule_changes = self.get_tag_changes( repo, tag, target_tag_to_compare, report_type)
        for commit in submodule_changes['commits']:
            submodule_info = self.get_submodule_info(repo, commit["url"].split("/")[-1])
            # Get the commits of the submodules
            for submodule_name, submodule_hash in submodule_info.items():
                if submodule_name in exclude_module_list:
                    continue
                changes_info = self.compare_tags_helper(submodule_name, submodule_hash["current_sha"], submodule_hash["prev_sha"])
                changes_info["module_names"] = [submodule_name] * len(changes_info["messages"])
                list_change_info.append([changes_info])
                exclude_module_list.append(submodule_name)
        # Combine the commits of the submodules together.
        for index in range(len(list_change_info)):
            dict_info = list_change_info[index][0]
            changes["commits"].extend(dict_info["commits"])
            changes["files_added"].extend(dict_info["files_added"])
            changes["files_removed"].extend(dict_info["files_removed"])
            changes["files_modified"].extend(dict_info["files_modified"])
            changes["messages"].extend(dict_info["messages"])
            changes["committers"].extend(dict_info["committers"])
            changes["committer_emails"].extend(dict_info["committer_emails"])
            changes["committer_ldap_cns"].extend(dict_info["committer_ldap_cns"])
            changes["module_names"].extend(dict_info["module_names"])

        return changes, exclude_module_list
