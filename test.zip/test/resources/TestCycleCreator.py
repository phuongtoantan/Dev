import argparse
import requests
import datetime
import sys

class TestCycleCreator():

    qtest_url = "https://qtest.gtie.dell.com/api/v3/projects/138/test-cycles"

    def create_test_cycle(self, name, auth_token, parent):
        params = {}
        params["name"] = name
        params["description"] = name

        headers = {'Authorization': 'Bearer {}'.format(auth_token),
                   'Content-Type' : 'application/json'}

        response = requests.post(f'{self.qtest_url}?parentId={parent}&parentType=test-cycle', json=params, headers=headers)
        if response.status_code == 200:
            response_json = response.json()
            return response_json["id"]
        else:
            print(f"Could not create test cycle. Status code from qtest: {response.status_code}")
            return parent

    def get_monthly_test_cycle(self, auth_token, parent):

        current_date = datetime.datetime.now()
        current_month_str = current_date.strftime("%Y-%m")
        headers = {'Authorization': 'Bearer {}'.format(auth_token),
                   'Content-Type' : 'application/json'}

        response = requests.get(f'{self.qtest_url}?parentId={parent}&parentType=test-cycle', headers=headers)
        tc_month_id = 0
        if response.status_code == 200:
            response_json = response.json()
            for test_cycle in response_json:
                if test_cycle['name'] == current_month_str:
                    tc_month_id = test_cycle['id']
                    break

        if tc_month_id == 0:
            tc_month_id = self.create_test_cycle(auth_token=auth_token,
                                                 parent=parent,
                                                 name=current_month_str)
        return tc_month_id

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--name",
                        type=str,
                        required=True,
                        help="Name of test cycle to be created")
    parser.add_argument("--auth-token",
                        type=str,
                        required=True,
                        help="Auth token for accessing QTest")
    parser.add_argument("--parent",
                        type=str,
                        required=True,
                        help="Parent test-cycle. The newly created test-cycle will be a child of this test-cycle.")
    parser.add_argument("--use-monthly-structure",
                        type=bool,
                        required=True,
                        help="If True, a test cycle will be created in a folder with the current month. If a folder does not exist for the current month, it will create one.")
    args = parser.parse_args()

    publisher = TestCycleCreator()

    if args.use_monthly_structure:
        tc_id_month = publisher.get_monthly_test_cycle(args.auth_token, args.parent)
        cycle_id = publisher.create_test_cycle(name=args.name, auth_token=args.auth_token, parent=tc_id_month)
    else:
        cycle_id = publisher.create_test_cycle(name=args.name, auth_token=args.auth_token, parent=args.parent)

    with open('cycle_id_file', 'w') as f:
        f.write(str(cycle_id))
    sys.stdout.write(str(cycle_id))

