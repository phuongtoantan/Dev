# Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

#imports
import click
import requests

DEFAULT_TOKEN = 'edb8df6c-a508-45a9-ba04-499a536df2e5'
DEFAULT_PROTECTED_LIST = ['286772', '286773', '182295']
DEFAULT_QTEST_INSTANCE = 'https://qtest.gtie.dell.com'
DEFAULT_PROJECT_ID = '138'

@click.command()
@click.option("--user_token", '-t', default=DEFAULT_TOKEN, help="User token for qTest authentication")
@click.option("--protected_modules", '-p', default=DEFAULT_PROTECTED_LIST, help="List of protected modules")
@click.option("--qtest_instance", '-q', default=DEFAULT_QTEST_INSTANCE, help="Qtest instance")
@click.option("--project_id", '-i', default=DEFAULT_PROJECT_ID, help="Qtest Project ID")

def delete_modules(user_token, protected_modules, qtest_instance, project_id):

    # Authentication
    request_header = {'Authorization': 'Bearer {}'.format(user_token), 'Content-Type': 'application/json'}

    # Retrieve modules under project
    get_modules_url = '{}/api/v3/projects/{}/modules'.format(qtest_instance, project_id)
    click.echo('-' * 25)
    click.echo("Retrieving all modules under instance '{}' project ID '{}'!".format(qtest_instance, project_id))
    click.echo('-' * 25)
    get_modules = requests.get(get_modules_url, headers=request_header)

    # Check for any issue with module get request
    if get_modules.status_code != 200:
        click.echo("\033[31m" + "Error: " + "\033[39m" +"Couldn't retrieve the project modules: '{}'".format(
            get_modules.text))
        return

    # Delete unprotected modules
    for item in get_modules.json():
        if str(item['id']) in protected_modules:
            click.echo("\033[34m" + "Info: " + "\033[39m" + "Module {} with ID: {} is protected!\n".format(
                item['name'], item['id']))
            continue

        # Construct the delete module URL
        delete_module_url = '{}/api/v3/projects/{}/modules/{}?force=true'.format(qtest_instance, project_id, item['id'])

        # Delete the unprotected modules
        delete_module = requests.delete(delete_module_url, headers=request_header)

        # Check for any issue with module delete request
        if delete_module.status_code != 200:
            click.echo("\033[31m" + "Error: " + "\033[39m" +"Couldn't delete module {} with ID {}: '{}'\n".format(
                item['name'], item['id'], delete_module.text))
            continue

        click.echo("\033[92m" + "Pass: " + "\033[39m" + "** Deleted module {} with ID {} successfully!\n".format(
            item['name'], item['id']))

    return

if __name__ == '__main__':
    delete_modules()
