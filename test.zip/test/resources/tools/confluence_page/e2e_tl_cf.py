# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import sys
import os
sys.path.append("ConfluencePage")
import confluence_page

# Loading env data
USERNAME = os.environ["USERNAME"]
PASSWORD = os.environ["PASSWORD"]
ACTION = os.environ["ACTION"]
CONFLUENCE_PAGE_ID = os.environ["CONFLUENCE_PAGE_ID"]
LIST_TL = os.environ["LIST_TL"]

cf = confluence_page.ConfluencePage(USERNAME, PASSWORD, CONFLUENCE_PAGE_ID)

output = []
# find table to get data
table = cf.find_table_in_confluence_page(1)

# find column with name ...
block_test_col_index = cf.find_column_by_name_from_table(table, "Block Test Case")
current_block_col_index = cf.find_column_by_name_from_table(table, "Next run")
name_col_index = cf.find_column_by_name_from_table(table, "TL name")

def get_all_test_runs():
    all_name_test_runs = []
    if block_test_col_index is not None and current_block_col_index is not None:
        # find all rows in table
        table_body_rows = table.find_all('tr')
        for row in table_body_rows:
            # values in each row
            item = row.find_all("td")
            if item:
                list_block_test = item[block_test_col_index].find_all("p")
                # values in block test
                for test_block in list_block_test :
                    info_block = ""
                    info_block += f" {test_block.text.strip()}"
                    test_run = list(filter(None, info_block.split(" -t ")))
                    # remove string containing *.robot file
                    for i in test_run:
                        if ".robot" in i:
                            name,robot = i.split(" ")
                            test_run.remove(i)
                            test_run.append(name)
                    all_name_test_runs += test_run
    return all_name_test_runs    

if ACTION.lower() == "get":
    # Get block TC need to run in this build
    if block_test_col_index is not None and current_block_col_index is not None:
        # find all rows in table
        table_body_rows = table.find_all('tr')
        for row in table_body_rows:
            # values in each row
            item = row.find_all("td")
            if item:
                print(f"name: {item[name_col_index].text}")
                print(f"current block number: {item[current_block_col_index].text}")

                current_block_index = int(item[current_block_col_index].text)-1
                list_block_test = item[block_test_col_index].find_all("p")
                print(f"TC Block: {list_block_test[current_block_index].text}")

                # Adding data into output value
                tl_info = {
                    "extra_test": list_block_test[current_block_index].text,
                    "tl_name": item[name_col_index].text
                }
                output.append(tl_info)  

elif ACTION.lower() == "update":
    # Update and push new value for current_number after pickup test block
    if LIST_TL.strip('[]') != "":
        list_tl_run = LIST_TL.strip('[]').split(', ')
        print(f"Update Next run number for: {str(list_tl_run)}")

        # Find elements with style "color: rgb(0,0,255);" and "color: rgb(255,0,0);"
        list_total_block = cf.find_elements_by_style("color: rgb(0,0,255);")
        list_current_block = cf.find_elements_by_style("color: rgb(255,0,0);")

        # Update current next run value for list_tl_run
        for tl in list_tl_run:
            index = cf.get_row_index(table, name_col_index, tl) - 1
            if list_total_block[index].text == list_current_block[index].text:
                list_current_block[index].string = "1"
            else:
                list_current_block[index].string = str(int(list_current_block[index].text) + 1)

        cf.update_elements_on_confluence_page_by_style("color: rgb(255,0,0);", list_current_block)
    else:
        print("List TL is empty => not update confluence page")

else:
    print("Please check type action again")

with open("output.json", "w") as f:
    f.write(str(output))