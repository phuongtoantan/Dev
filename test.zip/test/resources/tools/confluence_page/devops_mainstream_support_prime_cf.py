# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import sys
import os
import re
sys.path.append("ConfluencePage")
sys.path.append("LDAP")
import confluence_page
import ldap

# Loading env data
USERNAME = os.environ["USERNAME"]
PASSWORD = os.environ["PASSWORD"]
ACTION = os.environ["ACTION"]
CONFLUENCE_PAGE_ID = os.environ["CONFLUENCE_PAGE_ID"]

cf = confluence_page.ConfluencePage(USERNAME, PASSWORD, CONFLUENCE_PAGE_ID)

output = []
user_names = []
email = []
# find table to get data
table = cf.find_table_in_confluence_page(1)

# find column with name ...
prime_col_index = cf.find_column_by_name_from_table(table, "Support Prime")

def get_username_from_keys(keys):
    return [cf.get_username_from_key(key) for key in keys]

def get_user_keys(html):
    return re.findall(r'ri:userkey="(\w+)"', str(html))

if ACTION.lower() == "get":
    # Get block TC need to run in this build
    # if block_test_col_index is not None and current_block_col_index is not None:
    if prime_col_index is not None:
        # find all rows in table
        table_body_rows = table.find_all('tr')
        week1_idx = 0
        week2_idx = 1
        for row in table_body_rows:
            # values in each row
            item = row.find_all("td")
            if item:
                if item[prime_col_index].text == 'Week 1':
                    for index, th in enumerate(item):
                        if th.text.strip() == 'Week 1':
                            week1_idx = index
                        if th.text.strip() == 'Week 2':
                            week2_idx = index
                else:
                    for x in 0, 1:
                        name = get_username_from_keys(get_user_keys(item[x]))
                        if name:
                            user_names.append(name[0])
    print(f"DevOps Support Primes: {user_names}")
    LDAP = ldap.LDAP(USERNAME,PASSWORD)
    emails = LDAP.get_emails_from_username(user_names)
    print(f"Emails: {emails}")
    output = emails

else:
    print("Please check type action again")

with open("output.json", "w") as f:
    f.write(str(output))