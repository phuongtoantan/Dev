# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

from jinja2 import Environment, FileSystemLoader
import os
import sys
import pandas as pd

###########################################################################
### Base class for HTML template render
### This class serves as a base for specific HTML template render implementations
###########################################################################

class TemplateRender():
    """Render HTML template"""

    def __init__(self, html_template_name):
        """Load the template from ./html_templates"""
        root = os.path.dirname(os.path.abspath(__file__))
        templates_dir = os.path.join(root, './html_templates')
        env = Environment(loader=FileSystemLoader(templates_dir))
        self.template = env.get_template(html_template_name)

    def render(self):
        """Render the data."""
        raise NotImplementedError

class MainstreamHTMLRender(TemplateRender):
    """Render the contents to the mainstream html-based template.
    HTML template contains 5G RAN results.
    """
    MAINSTREAM_SANITY_DASHBOARD = "http://mp-elk-00-p-dur.cec.lab.emc.com/goto/a16bd2bf5e2ab576f55114870b1322de"  # nosecret


    def __init__(self, mainstream_data, html_output, html_template="mainstream_template.html"):
        """Load the mainstream report template.
           Templates location: ./html_templates
        """
        super().__init__(html_template)
        self.html_output = html_output
        self.mainstream_data = mainstream_data
        self.contents = {}
        if not mainstream_data:
            raise ("No data available.")  

#####################################################
### Main classes for mainstream HTML template render
### These classes may reuse the supporter classes
#####################################################

class OfficialMainstreamHTMLRender(MainstreamHTMLRender):
    """Render the contents to the mainstream basic template."""

    def __init__(self, mainstream_data, html_output):
        """Load the official_mainstream template.
           Templates location: ./html_templates
        """
        super().__init__(mainstream_data, html_output, "official_mainstream_template_multistream.html")

        # Initialize the supporter classes
        self.RenderHTMLForBuild = RenderHTMLForBuild()
        self.RenderHTMLForTest = RenderHTMLForTest()
        self.RenderHTMLForChecker = RenderHTMLForChecker()
        self.RenderHTMLForChangelog = RenderHTMLForChangelog()


    def prepare_official_mainstream_content(self):
        """Prepare HTML content for further proccessing.
        See: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.to_html.html
        """
        changelog_table = self.RenderHTMLForChangelog.get_change_log_table(self.mainstream_data)
        version = self.mainstream_data['version']
        version_list = [[key.upper(), value] for key, value in version.items()]
        print(f"[INFO] Value of version_list: {version_list}")
        official_mainstream_build_table = self.RenderHTMLForBuild.build_official_mainstream_build_table(self.mainstream_data, "official_mainstream")
        official_mainstream_unit_test_table = self.RenderHTMLForTest.build_official_mainstream_testing_table(self.mainstream_data, "unit_test")
        official_mainstream_component_test_table = self.RenderHTMLForTest.build_official_mainstream_testing_table(self.mainstream_data, "component_test")
        official_mainstream_sanity_test_table = self.RenderHTMLForTest.build_official_mainstream_testing_table(self.mainstream_data, "sanity_test")
        official_mainstream_test_result_summary_table = self.RenderHTMLForTest.build_official_mainstream_testing_table(self.mainstream_data, "test_result_summary")
        official_mainstream_cov_check_table = self.RenderHTMLForTest.build_official_mainstream_testing_table(self.mainstream_data, "cov_check")
        official_mainstream_cbanned_check_table = self.RenderHTMLForTest.build_official_mainstream_testing_table(self.mainstream_data, "cbanned_check")
        official_mainstream_blackduck_check_table = self.RenderHTMLForChecker.build_official_mainstream_dynamic_checker_table(self.mainstream_data, "blackduck_check")

        # Load contentss
        self.contents["is_success"] = self.mainstream_data['is_success']
        self.contents["changelog_table"] = changelog_table
        self.contents["current_version_table"] = version_list
        self.contents["build_overview"] = official_mainstream_build_table
        self.contents["unit_test"] = official_mainstream_unit_test_table
        self.contents["component_test"] = official_mainstream_component_test_table
        self.contents["sanity_test"] = official_mainstream_sanity_test_table
        self.contents["test_result_summary"] = official_mainstream_test_result_summary_table
        self.contents["build_url"] = self.mainstream_data['build_url']
        self.contents["job_name"] = self.mainstream_data['job_name']
        self.contents["mainstream_sanity_dashboard"] = self.MAINSTREAM_SANITY_DASHBOARD
        self.contents["cov_check_table"] = official_mainstream_cov_check_table
        self.contents["cbanned_check_table"] = official_mainstream_cbanned_check_table
        self.contents["blackduck_check_table"] = official_mainstream_blackduck_check_table
        self.contents["rpm_list"] = self.mainstream_data['rpm_list']
        self.contents["release_rpm"] = self.mainstream_data['release_rpm']
        self.contents["build_number"] = self.mainstream_data['build_number']
        self.contents["flag_checker"] = self.mainstream_data['flag_checker']
        self.contents["greenlight_log"] = self.mainstream_data['greenlight_log']
        mainstream_info = self.mainstream_data.get('mainstream_info', '') or ''
        # Ensure 'mainstream_info' is not None or the string "null"
        if mainstream_info in [None, 'None', 'null']:
            mainstream_info = ''
        self.contents["mainstream_info"] = mainstream_info
        self.contents["stream_name"] = self.mainstream_data['stream_name']

    def render(self):
        # Render official mainstream report
        print("Render official mainstream report")
        self.prepare_official_mainstream_content()
        with open(self.html_output, 'w') as fh:
            fh.write(self.template.render(
                is_success=self.contents["is_success"],
                changelog_table=self.contents["changelog_table"],
                build_overview=self.contents["build_overview"],
                unit_test_overview=self.contents["unit_test"],
                component_test_overview=self.contents["component_test"],
                sanity_test_overview=self.contents["sanity_test"],
                test_result_summary=self.contents["test_result_summary"],
                build_url=self.contents["build_url"],
                job_name=self.contents["job_name"],
                current_version_table=self.contents["current_version_table"],
                mainstream_sanity_dashboard=self.contents["mainstream_sanity_dashboard"],
                cov_check_overview=self.contents["cov_check_table"],
                cbanned_check_overview=self.contents["cbanned_check_table"],
                blackduck_check_overview=self.contents["blackduck_check_table"],
                rpm_list=self.contents["rpm_list"],
                release_rpm=self.contents["release_rpm"],
                build_number=self.contents["build_number"],
                flag_checker=self.contents["flag_checker"],
                greenlight_log=self.contents["greenlight_log"],
                mainstream_info=self.contents["mainstream_info"],
                stream_name=self.contents["stream_name"]
            ))

class InterimMainstreamBuildHTMLRender(MainstreamHTMLRender):
    """Render the contents to the interim mainstream build template."""

    def __init__(self, mainstream_data, html_output):
        """Load the interim_mainstream_build template.
            Template location: ./html_template
            """
        super().__init__(mainstream_data, html_output, "interim_build_report_multistream.html")

        # Initialize the supporter classes
        self.RenderHTMLForBuild = RenderHTMLForBuild()
        self.RenderHTMLForChangelog = RenderHTMLForChangelog()


    def prepare_interim_mainstream_build_content(self):
        """Prepare HTML content for further proccessing.
        See: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.to_html.html
        """
        changelog_table = self.RenderHTMLForChangelog.get_change_log_table(self.mainstream_data)
        version = self.mainstream_data['version']
        version_list = [[key.upper(), value] for key, value in version.items()]
        interim_mainstream_build_table = self.RenderHTMLForBuild.build_official_mainstream_build_table(self.mainstream_data, "interim_build")

        # Load contentss
        self.contents['build_number'] = self.mainstream_data['build_number']
        self.contents["is_success"] = self.mainstream_data['is_success']
        self.contents["changelog_table"] = changelog_table
        self.contents["current_version_table"] = version_list
        self.contents["build_overview"] = interim_mainstream_build_table
        self.contents["stream_name"] = self.mainstream_data['stream_name']

    def render(self):
        self.prepare_interim_mainstream_build_content()
        print("Render interim mainstream build report")
        with open(self.html_output, 'w') as fh:
            fh.write(self.template.render(
                is_success=self.contents["is_success"],
                changelog_table=self.contents["changelog_table"],
                build_overview=self.contents["build_overview"],
                current_version_table=self.contents["current_version_table"],
                build_number=self.contents["build_number"],
                stream_name=self.contents["stream_name"]
            ))


class InterimMainstreamSanityRender(MainstreamHTMLRender):
    """Render the contents to the interim mainstream build template."""

    def __init__(self, mainstream_data, html_output):
        """Load the interim_mainstream_build template.
            Template location: ./html_template
            """
        super().__init__(mainstream_data, html_output, "interim_sanity_report_multistream.html")

        # Initialize the supporter classes
        self.RenderHTMLForChangelog = RenderHTMLForChangelog()
        self.RenderHTMLForTest = RenderHTMLForTest()

    def prepare_interim_sanity_content(self):
        """Prepare HTML content for further proccessing.
        See: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.to_html.html
        """
        changelog_table = self.RenderHTMLForChangelog.get_change_log_table(self.mainstream_data)
        version = self.mainstream_data['version']
        version_list = [[key.upper(), value] for key, value in version.items()]
        official_mainstream_sanity_test_table = self.RenderHTMLForTest.build_official_mainstream_testing_table(self.mainstream_data, "interim_sanity_test")

        # Load contentss
        self.contents["changelog_table"] = changelog_table
        self.contents["current_version_table"] = version_list
        self.contents["interim_sanity_test"] = official_mainstream_sanity_test_table
        self.contents["build_number"] = self.mainstream_data['build_number']
        self.contents["is_success"] = self.mainstream_data['is_success']
        self.contents["stream_name"] = self.mainstream_data['stream_name']

    def render(self):
        """Render the mainstream data."""
        self.prepare_interim_sanity_content()
        print("Render interim mainstream build report")
        with open(self.html_output, 'w') as fh:
            fh.write(self.template.render(
                changelog_table=self.contents["changelog_table"],
                sanity_test_overview=self.contents["interim_sanity_test"],
                current_version_table=self.contents["current_version_table"],
                build_number=self.contents["build_number"],
                is_success=self.contents["is_success"],
                stream_name=self.contents["stream_name"]
            ))


#############################################################
### Supporter classes for mainstream HTML template render
### These classes facilitate the render of various data type
### Such as 'Changelog', 'Build', 'Test', 'Checker', ...
#############################################################
class RenderHTMLForBuild():
    """
    Related methods for Build HTML render
    """
    def __init__(self) -> None:
        pass

    def build_official_mainstream_build_table(self, mainstream_data, component_table):
        """Build official mainstream build table."""
        if component_table in mainstream_data:
            if mainstream_data[component_table] is None or len(mainstream_data[component_table]) == 0:
                return "<h4 style='color: red; text-align: center'>No data from Official Mainstream Builds Overview table.</h4>"

            columns_mapping = {
                "component": "Component",
                "componentName": "Component Name",
                "description": "Description",
                "overallStatus": "Overall status",
                "url": "URL",
                "executionTime": "Execution Time"
            }
            build_stages_value = mainstream_data[component_table]
            build_stages_df = pd.DataFrame(build_stages_value)
            build_stages_df = RenderHTMLUtils.brief_url(build_stages_df, 'url')

            build_stages_df = build_stages_df.fillna('-')
            build_stages_df = build_stages_df.drop(columns=['id'])
            build_stages_df.rename(columns=columns_mapping, inplace=True)

            return build_stages_df.to_html(
                justify='center',
                render_links=True,
                index=False, # Remove index column
                classes='new_table',
                na_rep='-',
                escape=False
            )
        return ""

class RenderHTMLForChangelog():
    """
    Related methods for Changelog HTML render
    """
    def __init__(self) -> None:
        pass

    def get_changes_and_culprits_table(self, mainstream_data, component_names=[]):
        """Get Changes and culprits table from mainstream data"""
        changelog_table = {}
        changes_dict = mainstream_data['changes']
        culprits_dict = mainstream_data['culprits']
        for repo_name in changes_dict.keys():
            component_changes = {}
            repository = ""
            # Correct names for repos in the changelog table
            if (repo_name == "mplane"):
                repository = "gNB_FH_MPLANE"
            elif (repo_name == "l1fw"):
                repository = "L1-Core"
            elif (repo_name == "l1dr"):
                repository = "l1-marvell-drivers"
            elif (repo_name == "ngp"):
                repository = "gNB_ngp"
            elif (repo_name == "transport"):
                repository = "transport"
            elif (repo_name == "noded"):
                repository = "gNB_node_controller"
            elif (repo_name == "oam"):
                repository = "gNB_OAM"
            elif (repo_name == "uesim"):
                repository = "gNB_UESIM"
            elif (repo_name == "devops"):
                repository = "mp-jenkins-shared-lib"
            elif (repo_name == "radio"):
                repository = "radiosw-src"
            elif (repo_name == "rate"):
                repository = "product_test_5g"
            elif (repo_name == "acm"):
                repository = "gNB_ACM"
            else:
                repository = repo_name
            if (len(component_names) == 0):
                pass
            else:
                if (len(changes_dict[repo_name]) == 0 or
                    repo_name not in component_names):
                    continue
            for index in range(len(changes_dict[repo_name])):
                application_name = repo_name.upper()
                changeid = changes_dict[repo_name][index]
                blame_user = culprits_dict[repo_name][index]
                component_changes[index] = [application_name, changeid, blame_user]
                # Only get version in changelog for test daily report
                if mainstream_data['report_type'] in ["test", "mainstream", "mainstream_basic", "official_mainstream", "interim_build", "interim_sanity_test"]:
                    submodule_names_dict = mainstream_data['submodule_names']
                    if (repo_name in ["cu", "du"]):
                        repository = submodule_names_dict[repo_name][index]
                    version = mainstream_data['version'][repo_name]
                    component = self.get_component_name_from_repo_name(repository)
                    component_changes[index] = [component, repository, changeid, version, blame_user]

            # Create a row with value '-' when application doesn't have changelogs
            if len(changes_dict[repo_name]) == 0:
                component = self.get_component_name_from_repo_name(repository)
                if (repo_name in ["cu", "du"]):
                    component_changes[0] = [component,  "-", "-", "-", "-"]
                else:
                    component_changes[0] = [component,  repository, "-", "-", "-"]
            
            changelog_table[repo_name] = component_changes

        return changelog_table

    def get_component_name_from_repo_name(self, repo):
        """Gent component name from repository name"""
        component = ""
        print(f"[INFO] Value of repo {repo}")
        if repo in ["gNB_DU", "gNB_DU_TEST_SIM", "gNB_DU_TEST_SIM", "gNB_DU_TEST", "du"]:
            component = "DU"
        elif repo in ["gNB_CU", "gNB_CU_TEST", "cu"]:
            component = "CU"
        elif repo in ["gNB_OAM", "yang_model", "oam"]:
            component = "OAM"
        elif repo in ["mplane", "gNB_FH_MPLANE", "gNB_API"]:
            component = "MPLANE"
        elif repo in ["l1fw", "l1dr", "L1-Core", "l1-marvell-drivers"]:
            component = "L1"
        elif repo in ["gNB_ngp"]:
            component = "NGP"
        elif repo in ["gNB_platform"]:
            component = "PLATFORM"
        elif repo in ["gNB_node_controller"]:
            component = "NODED"
        elif repo in ["transport"]:
            component = "TRANSPORT"    
        elif repo in ["gNB_UESIM", "uesim"]:
            component = "UESIM"    
        elif repo in ["rdc_client", "rdc_service"]:
            component = "RDC"
        elif repo in ["mp-jenkins-shared-lib"]:
            component = "DEVOPS"
        elif repo in ["radiosw-src"]:
            component = "RADIO"
        elif repo in ["product_test_5g"]:
            component = "RATE"
        elif repo in ["gNB_ACM"]:
            component = "ACM"
        else:
            component = "Unknown"
        print(f"[INFO] Value of component: {component}")
        return component

    def get_change_log_table(self, mainstream_data):
        """Convert change log data from dict to table"""
        changelog_table = ""
        if mainstream_data['report_type'] == 'build':
            changelog_table = self.get_changes_and_culprits_table(
                mainstream_data, [mainstream_data['application_name'].lower()])
        else:
            changelog_table = self.get_changes_and_culprits_table(mainstream_data)
            changelog_table = self.reformat_submodules_data(changelog_table)
        return changelog_table

    def reformat_submodules_data(self, changelog_table, exclude_components = ["gNB_FH_MPLANE"]):
        """Remove duplicate data from the submodules of cu and du"""
        cu_components = changelog_table["cu"].values()
        du_components = changelog_table["du"].values()
        sub_components = {"cu": cu_components, "du": du_components}
        # Remove duplicated values in cu_components
        for component_name, _ in sub_components.items():
            sub_components[component_name] = [tuple(sublist) for sublist in sub_components[component_name]]
            sub_components[component_name] = set(sub_components[component_name])
            sub_components[component_name] = [list(subtuple) for subtuple in sub_components[component_name]]
        # Search for the removed components.
        cu_remove_components = set()
        du_remove_components = set()
        for cu_component in sub_components["cu"]:
            # cu_component, du_component are variables storing the change information of a commit on cu and du
            # including 4 elements [Component, Changes, Version, Accountable team member]
            if cu_component[0] in exclude_components:
                cu_remove_components.add(tuple(cu_component))
            for du_component in sub_components["du"]:
                if du_component[0] in exclude_components:
                    du_remove_components.add(tuple(du_component))
                if du_component[0] == cu_component[0] and du_component[1] == cu_component[1]:
                    if du_component[2] in cu_component[2]:
                        du_remove_components.add(tuple(du_component))
                        continue
                    cu_component[2] = cu_component[2] + "/" + du_component[2]
                    du_remove_components.add(tuple(du_component))
        # Remove exclude components
        for component in cu_remove_components:
            sub_components["cu"].remove(list(component))
        for component in du_remove_components:
            sub_components["du"].remove(list(component))
        # Reformat data and sort for all components
        combined_components = sub_components["cu"] + sub_components["du"]
        all_combined_components = sorted(combined_components, key=lambda x: x[0])
        all_combined_components = all_combined_components + \
            list(changelog_table["mplane"].values()) + \
            list(changelog_table["l1fw"].values()) + \
            list(changelog_table["l1dr"].values()) + \
            list(changelog_table["ngp"].values()) + \
            list(changelog_table["transport"].values()) + \
            list(changelog_table["noded"].values()) + \
            list(changelog_table["oam"].values()) + \
            list(changelog_table["uesim"].values()) + \
            list(changelog_table["devops"].values()) + \
            list(changelog_table["radio"].values()) + \
            list(changelog_table["rate"].values()) + \
            list(changelog_table["acm"].values()) + \
            list(changelog_table["rdc_service"].values())

        return all_combined_components


class RenderHTMLForTest():
    """
    Related methods for Test HTML render
    """
    def __init__(self) -> None:
        pass

    def build_official_mainstream_testing_table(self, mainstream_data, testing_table_name):
        """Build official mainstream testing table."""
        if testing_table_name in mainstream_data:
            if mainstream_data[testing_table_name] is None or len(mainstream_data[testing_table_name]) == 0:
                return None
            colums_mapping = {
                "url": "URL",
                "jiraURL": "Jira URL",
                "overallStatus": "Status",
                "component": "Component"
            }
            official_mainstream_test_list = mainstream_data[testing_table_name]
            official_mainstream_test_df = pd.DataFrame(official_mainstream_test_list)
            official_mainstream_test_df.rename(columns=colums_mapping, inplace=True)
            if testing_table_name in ["unit_test", "component_test", "sanity_test", "cov_check", "cbanned_check", "interim_sanity_test"]:
                official_mainstream_test_df = RenderHTMLUtils.brief_url(official_mainstream_test_df, 'URL')
                official_mainstream_test_df = RenderHTMLUtils.brief_url(official_mainstream_test_df, 'Jira URL')
                if testing_table_name in ["unit_test", "component_test", "sanity_test"]:
                    official_mainstream_test_df = RenderHTMLUtils.brief_url(official_mainstream_test_df, 'Removed TCs Jira')
            official_mainstream_test_df = official_mainstream_test_df.fillna('-')
            official_mainstream_test_df.replace('', '-', inplace=True)
            # Convert all float values in the DataFrame to integers
            int_columns = ["Total Tests", "Baseline", "Passed", "Failed", "Skipped", "Missed"]
            if testing_table_name in ["unit_test", "component_test", "sanity_test", "interim_sanity_test"]:
                for column in int_columns:
                    official_mainstream_test_df[column] = official_mainstream_test_df[column].map(lambda x: int(x) if isinstance(x, float) else x)

            return official_mainstream_test_df.to_html(
                justify='center',
                render_links=True,
                index=False, # Remove index column
                classes='new_table',
                na_rep='-',
                escape=False
            )
        return None


class RenderHTMLForChecker():
    """
    Related methods for checkers HTML render
    """

    def __init__(self) -> None:
        pass

    def build_official_mainstream_dynamic_checker_table(self, mainstream_data, testing_table_name):
        """Build official mainstream dynamic table."""
        if testing_table_name in mainstream_data:
            if mainstream_data[testing_table_name] is None or len(mainstream_data[testing_table_name]) == 0:
                return None

            colums_mapping = {
                "url": "URL",
                "jiraURL": "Jira URL",
                "overallStatus": "Status",
                "variant": "Variant",
                "component": "Component"
            }
            official_mainstream_test_list = mainstream_data[testing_table_name]
            official_mainstream_test_df = pd.DataFrame(official_mainstream_test_list)
            official_mainstream_test_df = RenderHTMLUtils.brief_url(official_mainstream_test_df, 'url')
            official_mainstream_test_df = RenderHTMLUtils.brief_url(official_mainstream_test_df, 'jiraURL')
            official_mainstream_test_df = official_mainstream_test_df.fillna('-')
            official_mainstream_test_df.replace('', '-', inplace=True)
            official_mainstream_test_df.rename(columns=colums_mapping, inplace=True)

            return official_mainstream_test_df.to_html(
                justify='center',
                render_links=True,
                index=False, # Remove index column
                classes='new_table',
                na_rep='-',
                escape=False
            )
        return None


class RenderHTMLUtils():
    """
    RenderHTMLUtils is a utility class designed to encapsulate common functions for reusability across various classes
    and methods within a data collection and processing context.
    """

    @classmethod
    def hyperlink_texts(cls, url):
        """get short link texts for URL"""
        if "https://osj-phm-02-prd.cec.delllabs.net" in url:
            parts = url.split('/')
            return parts[-3] + " #" + parts[-2]
        elif "https://jira.cec.lab.emc.com" in url:
            return url.split('/')[-1]
        else:
            return url

    @classmethod
    def brief_url(cls, df, column):
        """displaying short link texts for all URLs in column instead of full"""
        df[column] = df[column].apply(lambda x: f'<a href="{x}" title="{x}" target="_blank">{RenderHTMLUtils.hyperlink_texts(x)}</a>' if x and type(x) == str else '-')
        return df
