# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import sys
sys.path.append("../../Github")
sys.path.append("../../LDAP")
sys.path.append("../../elasticsearch")
import json
import yaml
import ldap
import github
import re
import warnings
import es_interface
from es_fields import FieldDefinitions
import sys
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from urllib.parse import unquote
import traceback
# Disable the insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

###########################################################################
### Base class for data collector
### This class serves as a base for specific data collector implementations
###########################################################################

class DataCollectorMultibranch:
    """
    Data collection tool designed to load, extract, and transform data from multiple sources.

    This class serves as a base for specific data collector implementations.
    """

    def __init__(
        self,
        github_token,
        ldap_username,
        ldap_password,
        build_url,
        build_number,
        flag_checker,
        greenlight_log,
        mainstream_info
    ):
        self.TL_DEFINITION = FieldDefinitions.DEFAULT_TEST_LINES_DEFINITION
        self.DEPLOY_FIELDS = FieldDefinitions.DEPLOY_FIELDS
        self.TEST_FIELDS = FieldDefinitions.TEST_FIELDS
        self.build_url = build_url
        self.job_name = unquote(build_url.split("/")[4])
        self.build_number = build_number
        self.flag_checker = flag_checker
        self.greenlight_log = greenlight_log
        self.mainstream_info = mainstream_info

        # External interfaces init
        self.ESInterface = es_interface.ESInterface()
        self.MPGithub = github.Github("Mobile-Phoenix", github_token)
        self.LDAP = ldap.LDAP(ldap_username, ldap_password)

#####################################################
### Main classes for mainstream report data collector
### These classes may reuse the supporter classes
#####################################################

class DataCollectorOfficialMainstream(DataCollectorMultibranch):
    """
    Specialized data collector for gathering information related to the Official Mainstream Report Email.

    This class inherits from the base 'DataCollectorMultibranch' and may utilize supporter classes for specific data types.
    """

    def __init__(
        self,
        github_token,
        ldap_username,
        ldap_password,
        build_url,
        input_mainstream_data,
        rpm_list,
        release_rpm,
        build_number,
        flag_checker,
        greenlight_log,
        mainstream_info,
        pass_rate_data,
        stream_name
    ):
        super().__init__(
            github_token,
            ldap_username,
            ldap_password,
            build_url,
            build_number,
            flag_checker,
            greenlight_log,
            mainstream_info
        )


        self.input_mainstream_data = input_mainstream_data
        self.pass_rate_data = pass_rate_data
        self.MPDataCollectorForChangelog = DataCollectorForChangelog(github_token, ldap_username, ldap_password, input_mainstream_data, stream_name)
        self.MPDataCollectorForBuild = DataCollectorForBuild(input_mainstream_data, stream_name)
        self.MPDataCollectorForChecker = DataCollectorForChecker(input_mainstream_data, stream_name)
        self.MPDataCollectorForTest = DataCollectorForTest(input_mainstream_data, pass_rate_data, stream_name)

        if rpm_list:
            self.rpm_list = rpm_list = rpm_list.split(",")
        else:
            self.rpm_list = None
        self.release_rpm = release_rpm


    def collect_official_mainstream_data(self, stream_name = ""):
        """Main function to collect and proccess all test lines data from Elasticsearch.
        :return: Returns either mainstream data in dict or ``{}``
        """
        report_type = "official_mainstream"
        is_build_success = False
        is_test_success = False
        is_success = False
        mainstream_unit_test_results = None
        mainstream_component_test_results = None
        mainstream_sanity_test_results = None
        test_result_summary = {"Total Tests": 0, "Total Passed": 0, "Total Failed": 0, "Total Skipped" : 0, "Total Unexecuted" : 0}

        ru_version = {}
        print(f"Collecting {report_type} data")
        mainstream_data = {}

        try:
            input_mainstream_data = json.loads(self.input_mainstream_data)
            print(f"[INFO] [input_mainstream_data]: {input_mainstream_data}")
            current_versions, changes, culprits, committer_emails, manager_emails, submodule_names  = self.MPDataCollectorForChangelog.get_change_log()

            build_id = input_mainstream_data["mainstreamData"]["buildID"]
            test_id = input_mainstream_data["mainstreamData"]["testID"]

            static_check_id = input_mainstream_data["mainstreamData"]["staticCheckID"]
            dynamic_check_id = input_mainstream_data["mainstreamData"]["dynamicCheckID"]
            print("before collecting data")
            # Get mainstream build data from ELK
            is_build_success, build_stages = self.MPDataCollectorForBuild.get_mainstream_build_data(build_id)
            print("collecting cov")
            # Get mainstream cov check data from ELK
            cov_check_stages = self.MPDataCollectorForChecker.get_mainstream_checkers_data(static_check_id, 'staticCheckStages')
            print("collecting cban")
            # Get mainstream cbanned check data from ELK
            cbanned_check_stages = self.MPDataCollectorForChecker.get_mainstream_checkers_data(static_check_id, 'cbannedCheckStages')
            print("collecting blackduck")
            # Get mainstream dynamic check data from ELK
            blackduck_check_stages = self.MPDataCollectorForChecker.get_mainstream_dynamic_checkers_data(dynamic_check_id, 'dynamicCheckStages')
            print("collecting test data")
            # Get mainstream test data from ELK
            if test_id is not None:
                is_test_success, \
                mainstream_unit_test_results, \
                mainstream_component_test_results, \
                mainstream_sanity_test_results, \
                test_result_summary, \
                ru_version = self.MPDataCollectorForTest.get_mainstream_test_results(test_id)

            # Mainstream is Stable when Mainstream Build Success and Mainstream Test Success
            is_success = is_build_success and is_test_success

            # Adding RU version
            # NOTE: RU version is a special case because we can only get that version after E2E-TL pipeline executed completed
            if ru_version.get('ru_baseline'):
                current_versions["ru_baseline"] = ru_version.get('ru_baseline')
            if ru_version.get('ru_albus'):
                current_versions["ru_albus"] = ru_version.get('ru_albus')
            if ru_version.get('ru_foxconn'):
                current_versions["ru_foxconn"] = ru_version.get('ru_foxconn')

            mainstream_data.update(
                {
                    "version": current_versions,
                    "changes": changes,
                    "culprits": culprits,
                    "committer_emails": committer_emails,
                    "manager_emails": manager_emails,
                    "official_mainstream": build_stages,
                    "unit_test": mainstream_unit_test_results,
                    "component_test": mainstream_component_test_results,
                    "sanity_test": mainstream_sanity_test_results,
                    "cov_check": cov_check_stages,
                    "cbanned_check": cbanned_check_stages,
                    "blackduck_check": blackduck_check_stages,
                    "test_result_summary": [test_result_summary],
                    "rpm_list": self.rpm_list,
                    "release_rpm": self.release_rpm,
                    "submodule_names": submodule_names,
                    "is_success": is_success,
                    "build_url": self.build_url,
                    "job_name": self.job_name,
                    "report_type": report_type,
                    "build_number": self.build_number,
                    "flag_checker": self.flag_checker,
                    "greenlight_log": self.greenlight_log,
                    "mainstream_info": self.mainstream_info,
                    "stream_name": stream_name
                }
            )
            print(f"[INFO] Value of mainstream_data: {mainstream_data}")
        except Exception as err:
            print("Error while collecting data:")
            print(err)
            traceback.print_tb(err.__traceback__)
            sys.exit()
        return mainstream_data

class DataCollectorInterimMainstreamBuild(DataCollectorMultibranch):
    """Collect related information for Interim Build Report Email"""

    def __init__(
            self,
            github_token,
            ldap_username,
            ldap_password,
            build_url,
            build_number,
            input_mainstream_data,
            stream_name
            ):
        super().__init__(
            github_token,
            ldap_username,
            ldap_password,
            build_url,
            build_number,
            None,
            None,
            None,
            )
        self.input_mainstream_data = input_mainstream_data
        self.MPDataCollectorForChangelog = DataCollectorForChangelog(github_token, ldap_username, ldap_password, input_mainstream_data, stream_name)
        self.MPDataCollectorForBuild = DataCollectorForBuild(input_mainstream_data, stream_name)

    def collect_mainstream_build_data(self, stream_name = ""):
        report_type = "interim_build"
        is_build_success = False
        print(f"Collecting {report_type} data")
        mainstream_data = {}
        try:
            # CU/DU/MPLANE/L1 changes

            #### Changelog collection
            current_versions, changes, culprits, committer_emails, manager_emails, submodule_names  = self.MPDataCollectorForChangelog.get_change_log()

            ### Build data collection
            build_data = json.loads(self.input_mainstream_data)
            build_id = build_data["mainstreamData"]["buildID"]
            is_build_success, build_stages = self.MPDataCollectorForBuild.get_mainstream_build_data(build_id)

            ### Mainstream data updates
            mainstream_data.update(
                {
                    "version": current_versions,
                    "interim_build":  build_stages,
                    "changes": changes,
                    "culprits": culprits,
                    "committer_emails": committer_emails,
                    "manager_emails": manager_emails,
                    "submodule_names": submodule_names,
                    "is_success": is_build_success,
                    "build_number": build_id,
                    "report_type": report_type,
                    "stream_name": stream_name
                }
            )
        except Exception as err:
            print("Error while collecting data:")
            print(err)
            traceback.print_tb(err.__traceback__)
            sys.exit()
        return mainstream_data

class DataCollectorInterimMainstreamSanity(DataCollectorMultibranch):
    """Collect related information for Interim Sanity Report Email"""
    def __init__(
            self,
            github_token,
            ldap_username,
            ldap_password,
            build_url,
            build_number,
            input_mainstream_data,
            stream_name
            ):
        super().__init__(
            github_token,
            ldap_username,
            ldap_password,
            build_url,
            build_number,
            None,
            None,
            None,
            )

        self.input_mainstream_data = input_mainstream_data
        self.MPDataCollectorForChangelog = DataCollectorForChangelog(github_token, ldap_username, ldap_password, input_mainstream_data, stream_name)
        self.MPDataCollectorForTest = DataCollectorForTest(input_mainstream_data, stream_name=stream_name)

    def collect_interim_sanity_data(self, stream_name = ""):
        report_type = "interim_sanity_test"
        is_test_success = False
        ru_version = {}
        print(f"Collecting {report_type} data")
        mainstream_data = {}
        try:
            # CU/DU/MPLANE/L1 changes

            #### Changelog collection
            current_versions, changes, culprits, committer_emails, manager_emails, submodule_names  = self.MPDataCollectorForChangelog.get_change_log()

            ### Sanity data collection
            build_data = json.loads(self.input_mainstream_data)
            build_id = build_data["mainstreamData"]["testID"]
            is_test_success, interim_sanity_data, ru_version = self.MPDataCollectorForTest.get_interim_sanity_test_results(build_id)

            ### Adding RU version
            # NOTE: RU version is a special case because we can only get that version after E2E-TL pipeline executed completed
            if ru_version.get('ru_baseline'):
                current_versions["ru_baseline"] = ru_version.get('ru_baseline')
            if ru_version.get('ru_albus'):
                current_versions["ru_albus"] = ru_version.get('ru_albus')
            if ru_version.get('ru_foxconn'):
                current_versions["ru_foxconn"] = ru_version.get('ru_foxconn')

            ### Mainstream data updates
            mainstream_data.update(
                {
                    "version": current_versions,
                    "interim_sanity_test":  interim_sanity_data,
                    "changes": changes,
                    "culprits": culprits,
                    "committer_emails": committer_emails,
                    "manager_emails": manager_emails,
                    "submodule_names": submodule_names,
                    "is_success": is_test_success,
                    "build_number": build_id,
                    "report_type": report_type,
                    "stream_name": stream_name
                }
            )
        except Exception as err:
            print("Error while collecting data:")
            print(err)
            traceback.print_tb(err.__traceback__)
            sys.exit()
        return mainstream_data


###########################################################
### Supporter classes for mainstream report data collector
### These classes facilitate the collection of various data
### Such as 'Changelog', 'Build', 'Test', 'Checker', ...
###########################################################

class DataCollectorForChangelog():
    """
    Specialized data collector for gathering 'Changelog' information for the Mainstream Report Email.

    This class is part of a modular approach where different data collectors focus on specific types of information.
    """

    def __init__(
        self,
        github_token,
        ldap_username,
        ldap_password,
        input_mainstream_data="",
        stream_name=""
    ):
        # External interfaces init
        self.ESInterface = es_interface.ESInterface()
        self.MPGithub = github.Github("Mobile-Phoenix", github_token)
        self.LDAP = ldap.LDAP(ldap_username, ldap_password)
        self.input_mainstream_data = input_mainstream_data
        self.streamMetadata = DataCollectorUtils.convert_yaml_to_dict(f"{stream_name}_metadata.yaml")
        self.elk_mainstream_version_index = self.streamMetadata["elk"]["streaminfo"]["streaminfo_version"]

    def get_module_changes(self, module_name, current_version, previous_version, exclude_module_list):
        change_info = {}
        super_repos = ["CU", "DU"]
        non_tag_repos = ["mp-jenkins-shared-lib", "radiosw-src", "product_test_5g"]
        exclude_modules = exclude_module_list
        try:
            print(f"[INFO] [Changelog] [{module_name}] Collecting data...")
            if module_name in super_repos:
                change_info, exclude_modules = self.MPGithub.get_submodule_changes(module_name, current_version, exclude_module_list, previous_version)
            elif module_name in non_tag_repos:
                change_info = self.MPGithub.get_shas_changes(module_name, current_version, previous_version)
            else:
                change_info = self.MPGithub.get_tag_changes(module_name, current_version, previous_version)
        except Exception as ex:
            print(f"[Changelog] Error while getting data: {ex}")
            change_info = {}
        return change_info, exclude_modules

    def get_change_log(self):
        print("[INFO] [Changelog] Collecting data...")
        input_mainstream_data = json.loads(self.input_mainstream_data)

        default_fault_value = {
            "cu": "",
            "du": "",
            "mplane": "",
            "l1fw": "",
            "l1dr": "",
            "ngp": "",
            "transport": "",
            "noded": "",
            "oam": "",
            "uesim": "",
            "devops":"",
            "radio": "",
            "rate":"",
            "rdc_service": "",
            "acm": "",
        }

        # Return empty changelog data in case not found mainstreamID
        if not "mainstreamID" in input_mainstream_data["mainstreamData"]:
            return default_fault_value, default_fault_value, default_fault_value, default_fault_value, default_fault_value, default_fault_value

        mainstreamID = input_mainstream_data["mainstreamData"]["mainstreamID"]

        # Getting current mainstream versions
        current_mainstream_versions = self.ESInterface.get_official_mainstream_version_by_id(self.elk_mainstream_version_index, mainstreamID)
        print("INFO: current_mainstream_versions")
        print(current_mainstream_versions)

        # Getting previous mainstream versions
        prev_mainstream_id = int(mainstreamID) - 1
        previous_mainstream_versions = self.ESInterface.get_official_mainstream_version_by_id(self.elk_mainstream_version_index, str(prev_mainstream_id))
        print("INFO: previous_mainstream_versions")
        print(previous_mainstream_versions)

        modules = {
            "CU": "CU",
            "DU": "DU",
            "MPLANE": "gNB_FH_MPLANE",
            "l1fw": "L1-Core",
            "l1dr": "l1-marvell-drivers",
            "NGP": "gNB_ngp",
            "Transport": "transport",
            "NODED" : "gNB_node_controller",
            "OAM" : "gNB_OAM",
            "UESIM" : "gNB_UESIM",
            "DEVOPS" : "mp-jenkins-shared-lib",
            "RATE" : "product_test_5g",
            "RADIO" : "radiosw-src",
            "RDC_service": "rdc_service",
            "ACM" : "acm",
        }

        current_versions = {module: current_mainstream_versions[module]["version"] if module in current_mainstream_versions else None for module in modules}

        # Using lower case to work with curent HTML render class, sample:
        # VERSIONS = {
        #     "cu": CU_VERSION,
        #     "du": DU_VERSION,
        #     "mplane": MPLANE_VERSION,
        #     "l1fw": L1FW_VERSION,
        #     "l1dr": L1DR_VERSION,
        #     "ngp": NGP_VERSION,
        #     "transport": TRANSPORT_VERSION,
        #     "noded": NODED_VERSION,
        #     "oam": OAM_VERSION,
        #     "uesim": UESIM_VERSION,
        # }
        fmt_current_versions = {module.lower(): current_mainstream_versions[module]["version"] if module in current_mainstream_versions else None for module in modules}
        exclude_modules=list(modules.values())

        previous_versions = {module: previous_mainstream_versions[module]["version"] if module in previous_mainstream_versions else None for module in modules}

        # Use the function below to avoid errors when the previous version has `None` values.
        def check_previous_version(previous_version, current_version):
            updated_previous_version = {}
            for key, value in previous_version.items():
                if value is None:
                    updated_previous_version[key] = current_version.get(key)
                else:
                    updated_previous_version[key] = value
            return updated_previous_version

        previous_versions_offical = check_previous_version(previous_versions, current_versions)

        default_change_info = {
            "messages": [],
            "committers": [],
            "committer_emails": None,
            "committer_ldap_cns": [],
        }

        change_infos = {}
        for module, repo in modules.items():
            if current_versions[module] is not None:
                module_changes, exclude_modules = self.get_module_changes(repo,current_versions[module], previous_versions_offical[module], exclude_modules)

                # Checking the result
                if not module_changes:
                    print(f"[INFO] Change info of '{module}' is empty")
                    change_infos[module] = default_change_info.copy()
                else:
                    change_infos[module] = module_changes
            else:
                # Cover non-existing case
                print(f"Change info of '{module}' is empty")
                change_infos[module] = default_change_info.copy()

        manager_emails = {module: self.LDAP.get_manager_emails(change_infos[module]["committer_ldap_cns"]) for module in modules}

        changes = {module.lower(): change_infos[module]["messages"] for module in modules}
        culprits = {module.lower(): change_infos[module]["committers"] for module in modules}
        committer_emails = {module.lower(): change_infos[module]["committer_emails"] for module in modules}
        manager_emails = {module.lower(): manager_emails[module] for module in modules}

        submodule_names = {
            "cu": change_infos["CU"]["module_names"],
            "du": change_infos["DU"]["module_names"],
            "mplane": "mplane",
            "l1fw": "l1fw",
            "l1dr": "l1dr",
            "ngp": "ngp",
            "transport": "transport",
            "noded": "noded",
            "oam": "oam",
            "uesim": "uesim",
            "devops":"devops",
            "radio":"radio",
            "rate":"rate",
            "rdc_service": "rdc_service",
            "ACM" : "acm",
        }

        return fmt_current_versions, changes, culprits, committer_emails, manager_emails, submodule_names

class DataCollectorForBuild():
    """
    Specialized data collector for gathering 'Build' information for the Mainstream Report Email.

    This class is part of a modular approach where different data collectors focus on specific types of information.
    """

    def __init__(
        self,
        input_mainstream_data="",
        stream_name=""
    ):
        # External interfaces init
        self.ESInterface = es_interface.ESInterface()
        self.input_mainstream_data = input_mainstream_data
        self.streamMetadata = DataCollectorUtils.convert_yaml_to_dict(f"{stream_name}_metadata.yaml")
        self.elk_stream_build_index = self.streamMetadata["elk"]["streaminfo"]["streaminfo_build"]

    def get_mainstream_build_data(self, build_id):
        """"
            Collect mainstream build data with mainstream build_id
            If any component has no build data, get its latest build data and add to the results
        """
        print("[INFO] [Build] Collecting data...")
        components_list = [key.upper() for key in self.streamMetadata["elk"]["components"].keys()]
        is_build_success = False
        build_stages = []
        # If there is no buildID, get the latest build data of all components
        if build_id is not None:
            mainstream_build_df = self.ESInterface.get_mainstream_data_by_id(self.streamMetadata["elk"]["streaminfo"]["streaminfo_build"], build_id)
            if mainstream_build_df is not None:
                build_stages = mainstream_build_df.iloc[0]['buildStages']
                # Loop through each component
                for component in components_list:
                    try:
                        have_data = next((build_stage for build_stage in build_stages if build_stage["component"] == component), None)
                    except StopIteration:
                        have_data = None
                    # If component has no build data, get its latest build data
                    if not have_data:
                        # For now, we do not build L1 in mainstream pipeline, but need to add it in the build section in mainstream report as NOT-READY for special case
                        latest_mainstream_build_data = self.ESInterface.get_latest_mainstream_build_data(self.elk_stream_build_index, component)
                        if latest_mainstream_build_data is None:
                            component_name = f"{component}-mainstream-Build"
                            latest_mainstream_build_data = f'{{"component": "{component}", "componentName": "{component_name}", "description": null, "overallStatus": "NOT-READY", "url": null, "id": null, "executionTime": null}}'
                            latest_mainstream_build_data = json.loads(latest_mainstream_build_data)
                        build_stages.append(latest_mainstream_build_data)

                # Check overall status of mainstream build pipeline
                mainstream_build_overall_status = mainstream_build_df.iloc[0]['overallstatus']
                if mainstream_build_overall_status == "SUCCESS":
                    is_build_success = True
        else:
            for component in components_list:
                latest_mainstream_build_data = self.ESInterface.get_latest_mainstream_build_data(self.elk_stream_build_index, component)
                build_stages.append(latest_mainstream_build_data)

        # Convert execution time to HH:MM:SS format
        print("[INFO] [Build] Converting execution time format...")
        for build_stage in build_stages:
            if "executionTime" in build_stage:
                build_stage["executionTime"] = DataCollectorUtils.convert_execution_time(build_stage["executionTime"])

        print("[INFO] [Build] Collect data completed!")

        return is_build_success, sorted(build_stages, key=lambda x: x.get("component", ""))

class DataCollectorForChecker():
    """
    Specialized data collector for gathering 'Checker' information for the Mainstream Report Email.

    This class is part of a modular approach where different data collectors focus on specific types of information.
    """

    def __init__(
        self,
        input_mainstream_data="",
        stream_name=""
    ):
        # External interfaces init
        self.ESInterface = es_interface.ESInterface()
        self.input_mainstream_data = input_mainstream_data
        self.streamMetadata = DataCollectorUtils.convert_yaml_to_dict(f"{stream_name}_metadata.yaml")
        self.elk_stream_build_index = self.streamMetadata["elk"]["streaminfo"]["streaminfo_build"]
        self.elk_stream_static_check_index = self.streamMetadata["elk"]["streaminfo"]["streaminfo_static_check"]
        self.elk_stream_dynamic_check_index = self.streamMetadata["elk"]["streaminfo"]["streaminfo_dynamic_check"]

    def get_mainstream_checkers_data(self, mainstream_check_id, value_field):
        """"
            Collect mainstream check data with ELK Checker index and build ID
        """
        print("[INFO] [Checker] Collecting data...")
        components_list = [key.upper() for key in self.streamMetadata["elk"]["components"].keys()]
        CheckStages = []
        if mainstream_check_id is not None:
            mainstream_static_check_df = self.ESInterface.get_mainstream_data_by_id(self.elk_stream_static_check_index , mainstream_check_id)
            if mainstream_static_check_df is not None:
                CheckStages = mainstream_static_check_df.iloc[0].get(value_field)
                if CheckStages is None:
                    return None
                # Loop through each component
                for component in components_list:
                    have_data = next((CheckStage for CheckStage in CheckStages if CheckStage["component"] == component), None)
                    # If component has no check data, generate empty result
                    if not have_data:
                        official_mainstream_checker_result = {}
                        official_mainstream_checker_result.setdefault("component", component)
                        official_mainstream_checker_result.setdefault("overallStatus", "NOT-READY")
                        official_mainstream_checker_result.setdefault("url", None)
                        official_mainstream_checker_result.setdefault("jiraURL", None)
                        CheckStages.append(official_mainstream_checker_result)

        # The returned list is sorted by Component names
        return sorted(CheckStages, key=lambda x: x.get("component", ""))

    def get_mainstream_dynamic_checkers_data(self, mainstream_check_id, value_field):
        """"
            Collect mainstream check data with ELK Checker index and build ID
        """
        components_list = [key.upper() for key in self.streamMetadata["elk"]["components"].keys()]
        CheckStages = []
        if mainstream_check_id is not None:
            mainstream_static_check_df = self.ESInterface.get_mainstream_data_by_id(self.elk_stream_dynamic_check_index , mainstream_check_id)
            if mainstream_static_check_df is not None:
                CheckStages = mainstream_static_check_df.iloc[0].get(value_field)
                if CheckStages is None:
                    return None
                # Loop through each component
                for component in components_list:
                    have_data = next((CheckStage for CheckStage in CheckStages if CheckStage["component"] == component), None)
                    # If component has no check data, generate empty result
                    if not have_data:
                        official_mainstream_dynamic_checker_result = {}
                        official_mainstream_dynamic_checker_result.setdefault("component", component)
                        official_mainstream_dynamic_checker_result.setdefault("variant", None)
                        official_mainstream_dynamic_checker_result.setdefault("overallStatus", "NOT-READY")
                        official_mainstream_dynamic_checker_result.setdefault("url", None)
                        official_mainstream_dynamic_checker_result.setdefault("jiraURL", None)
                        CheckStages.append(official_mainstream_dynamic_checker_result)

        # The returned list is sorted by Component names
        return sorted(CheckStages, key=lambda x: x.get("component", ""))

class DataCollectorForTest():
    """
    Specialized data collector for gathering 'Test' information for the Mainstream Report Email.

    This class is part of a modular approach where different data collectors focus on specific types of information.
    """

    def __init__(
        self,
        input_mainstream_data="",
        pass_rate_data="",
        stream_name=""
    ):
        # External interfaces init
        self.ESInterface = es_interface.ESInterface()
        self.input_mainstream_data = input_mainstream_data
        self.pass_rate_data = pass_rate_data
        self.test_result_summary = {"Total Tests": 0, "Total Passed": 0, "Total Failed": 0, "Total Skipped" : 0, "Total Unexecuted" : 0}
        self.streamMetadata = DataCollectorUtils.convert_yaml_to_dict(f"{stream_name}_metadata.yaml")
        self.elk_stream_build_index = self.streamMetadata["elk"]["streaminfo"]["streaminfo_build"]
        self.elk_mainstream_test_index = self.streamMetadata["elk"]["streaminfo"]["streaminfo_test"]

    def get_component_test_results(self, test_stage):
        """
            Iterate through each component's test type, generate official mainstream test result
            Component test data on ELK(component_test_df) have the following structure:
            {
                "testResults": [
                    {
                        "testType": string,
                        "testName": string,
                        "total": string,
                        "fail": string,
                        "skip": string,
                        "pass": string,
                        "testStatus":string,
                        "failedStages": string,
                        "jiraID": string,
                        "jiraURL": string
                    },
                    ...
                ],
                "component": string,
                "testID": string,
                "testName": string,
                "testStatus": string,
                "url": string,
                "date_created": string
            }

        """
        print("[INFO] [Component-Test] Collecting data...")
        pass_rate_data = json.loads(self.pass_rate_data)
        required_pass_rate_component_for_ct = pass_rate_data["passRateData"]["ComponentTest"]
        required_pass_rate_component_for_ut = pass_rate_data["passRateData"]["UnitTest"]

        component_test_id = test_stage["id"]
        component_name = test_stage["component"]
        test_types = ["Unit-Test", "Component-Test"]
        jira_ignored_status = ["SUCCESS", "NOT-READY", "SKIP"]

        official_mainstream_ut_results = [] # List of Unit Test result of component
        official_mainstream_ct_results = [] # List of Component Test result of component

        # Get component test result data from ELK
        component_test_df = self.ESInterface.get_mainstream_test_data_by_id(self.streamMetadata["elk"]["components"][component_name.lower()]["test"], component_test_id)

        # If component not have test data in ELK with component_test_id: it means the component's test stage has been run but the test data has not been uploaded to ELK
        # Return empty test result with status NO-DATA
        if component_test_df is None:
            official_mainstream_ut_results.append(self.generate_empty_test_results(component_name, "NO-DATA", "Unit-Test"))
            official_mainstream_ct_results.append(self.generate_empty_test_results(component_name, "NO-DATA", "Component-Test"))
            return official_mainstream_ut_results, official_mainstream_ct_results

        component_test_results = component_test_df.iloc[0]['testResults']
        for test_type in test_types:
            # matching_results is a list of result which have "testType" = test_type(UNIT-TEST/COMPONENT-TEST)
            matching_results = [test_result for test_result in component_test_results if test_result["testType"] == test_type]
            if matching_results:
                for test_result in matching_results:
                    official_mainstream_test_result = {} # Test data of each component's test type
                    official_mainstream_test_result["Component"] = component_name
                    # official_mainstream_test_result["Test Type"] = test_type
                    official_mainstream_test_result["Test Name"] = test_result.get("testName", test_type)
                    #official_mainstream_test_result["Test Status"] = test_result.get("testStatus", "NOT-READY")
                    #return test status for each component's test type to base on passrate requirements
                    component_test_status = test_result.get("testStatus", "NOT-READY")
                    if component_test_status != "NOT-READY" and component_test_status != "NO-DATA":
                        if "Unit-Test" in official_mainstream_test_result["Test Name"]:
                            component_test_status = self.set_component_test_status(test_result.get("pass", None), test_result.get("baseline", None), required_pass_rate_component_for_ut)
                        elif "Component-Test" in official_mainstream_test_result["Test Name"]:
                            component_test_status = self.set_component_test_status(test_result.get("pass", None), test_result.get("baseline", None), required_pass_rate_component_for_ct)
                    official_mainstream_test_result["Test Status"] = component_test_status
                    official_mainstream_test_result["URL"] = test_result.get("url", None) if component_name == "DU" else component_test_df.iloc[0].get("url", None)
                    official_mainstream_test_result["Baseline"] = test_result.get("baseline", None)
                    official_mainstream_test_result["Total Tests"] = test_result.get("total", None)
                    official_mainstream_test_result["Passed"] = test_result.get("pass", None)
                    official_mainstream_test_result["Failed"] = test_result.get("fail", None)
                    official_mainstream_test_result["Skipped"] = test_result.get("skip", None)
                    official_mainstream_test_result["Missed"] = test_result.get("miss", None)
                    official_mainstream_test_result["Failed Stages"] = component_test_df.iloc[0].get("failedStages", None)
                    official_mainstream_test_result["Jira URL"] = test_result.get("jiraURL", None)
                    official_mainstream_test_result["Removed TCs Jira"] = test_result.get("removedTCsJira", None)
                    official_mainstream_test_result["Execution Time"] = DataCollectorUtils.convert_execution_time(test_result.get("executionTime", None))

                    # Even though the test status is success, Jira can still be created if other stages of Downstream fail
                    # Only show Jira URL and Failed Stages if the Test Status not in the test status list will ignore Jira URL
                    if test_result.get("testStatus", "NOT-READY") in jira_ignored_status:
                        official_mainstream_test_result["Jira URL"] = ""
                        official_mainstream_test_result["Failed Stages"] = ""
                    # If the upstream generates Jira, display the upstream's Jira as priority
                    elif component_test_df.iloc[0].get("jiraURL", "") != "":
                        official_mainstream_test_result["Jira URL"] = component_test_df.iloc[0].get("jiraURL")

                    # Update Test result summary
                    self.test_result_summary["Total Tests"] += self.get_test_case_stat(official_mainstream_test_result, "Baseline")
                    self.test_result_summary["Total Passed"] += self.get_test_case_stat(official_mainstream_test_result, "Passed")
                    self.test_result_summary["Total Failed"] += self.get_test_case_stat(official_mainstream_test_result, "Failed")
                    self.test_result_summary["Total Skipped"] += self.get_test_case_stat(official_mainstream_test_result, "Skipped")
                    self.test_result_summary["Total Unexecuted"] += self.get_test_case_stat(official_mainstream_test_result, "Missed")

                    if official_mainstream_test_result.get("Test Status", '') == "NO-DATA":
                        self.test_result_summary["Total Unexecuted"] += self.get_test_case_stat(official_mainstream_test_result, "Baseline")

                    # If test type of this test result is Component Test, return it as component test result
                    if test_type == "Component-Test":
                        official_mainstream_ct_results.append(official_mainstream_test_result)

                    # If test type of this test result is Unit Test, return it as unit test result
                    if test_type == "Unit-Test":
                        official_mainstream_ut_results.append(official_mainstream_test_result)

            # If matching_results = [], the component does not have this test type yet
            # Return empty test result with status NOT-READY
            else:
                if test_type == "Component-Test":
                        official_mainstream_ct_results.append(self.generate_empty_test_results(component_name, "NOT-READY", test_type))
                if test_type == "Unit-Test":
                    official_mainstream_ut_results.append(self.generate_empty_test_results(component_name, "NOT-READY", test_type))
            print("test type: " + test_type)

        return official_mainstream_ut_results, official_mainstream_ct_results

    def getTcBaseline(self, component_name, testName):
        baseline = None
        oam_baseline = 0
        latest_baseline = self.ESInterface.get_latest_es_component_data(self.streamMetadata["elk"]["streaminfo"]["streaminfo_testcase_baseline"])
        for component_baseline in latest_baseline["baselines"]:
            # One special case is that OAM have 2 TestNames for "Component-Test" TestType. In case OAM_mainstream_test pipeline is skipped, OAM baseline of "Component-Test" TestType will be the sum of both testName.
            if component_baseline["component"] == component_name == "OAM" and component_baseline["testType"] == testName == "Component-Test":
                oam_baseline += component_baseline["baseline"]
                baseline = oam_baseline
            #Other than OAM
            elif component_baseline["component"] == component_name and component_baseline["testName"] == testName:
                baseline = component_baseline["baseline"]
                break
        return baseline

    def generate_empty_test_results(self, component_name, test_status, test_type):
        print(f"[INFO] [Fill-Empty-Test] [{component_name}] [{test_type}] Collecting data...")

        official_mainstream_test_result = None

        official_mainstream_test_result = {} # Test data of each component's test type
        official_mainstream_test_result["Component"] = component_name
        # official_mainstream_test_result["Test Type"] = test_type
        official_mainstream_test_result["Test Name"] = None
        official_mainstream_test_result["Test Status"] = test_status
        official_mainstream_test_result["URL"] = None
        official_mainstream_test_result["Baseline"] = self.getTcBaseline(component_name, test_type)# test_types is also test_name for all cases, only except OAM-Component Test
        official_mainstream_test_result["Total Tests"] = None
        official_mainstream_test_result["Passed"] = None
        official_mainstream_test_result["Failed"] = None
        official_mainstream_test_result["Skipped"] = None
        official_mainstream_test_result["Missed"] = None
        official_mainstream_test_result["Failed Stages"] = None
        official_mainstream_test_result["Jira URL"] = None
        official_mainstream_test_result["Removed TCs Jira"] = None
        official_mainstream_test_result["Execution Time"] = None
        # Update Total Tests and Total Unexecuted in case test result is empty
        if official_mainstream_test_result["Baseline"] is not None:
            self.test_result_summary["Total Tests"] += int(official_mainstream_test_result["Baseline"])
            self.test_result_summary["Total Unexecuted"] += int(official_mainstream_test_result["Baseline"])


        return official_mainstream_test_result

    def get_test_case_stat(self, test_data, field):
        # Default test case statistic is 0
        test_case_stat = 0
        if test_data.get(field, 0) not in ["", "null", None]:
            test_case_stat = int(test_data.get(field, 0))
        return test_case_stat

    def get_sanity_test_results(self, mainstream_test_stages, enable_sanity_test=["E2E", "AIO"]):
        """
            Generate official mainstream test result of AIO and E2E test
            E2E and AIO test data on ELK (input_mainstream_data) have the following structure:
            {
                "component": string,
                "componentName": string,
                "description": string,
                "overallStatus": string,
                "url": string,
                "id": string,
                "testData": {
                    "testResults": {
                    "total": int,
                    "fail": int,
                    "skip": int,
                    "pass": int,
                    "testStatus": string,
                    "jiraID": string,
                    "jiraURL": string,
                    "failedStages": string,
                    },
                    "component": string,
                    "testName": string,
                    "url": string,
                }
            }
        """

        print("[INFO] [Sanity-Test] Collecting data...")
        sanity_test_list = ["E2E", "AIO"]
        keys_to_include = ["testStatus", "baseline", "total", "pass", "fail", "skip", "miss", "failedStages", "jiraURL", "removedTCsJira", "executionTime"] # List of keys will show in report
        sanity_result_list = []
        pass_rate_data = json.loads(self.pass_rate_data)
        required_pass_rate_aio = pass_rate_data["passRateData"]["AIO"]
        required_pass_rate_e2e = pass_rate_data["passRateData"]["E2E"]
        ru_version = {}

        matches_test_stage = [test_stage for test_stage in mainstream_test_stages if test_stage["component"] in sanity_test_list]
        for test_stage in matches_test_stage:
            test_result = test_stage["testData"]["testResults"]
            # Get the values ​​corresponding to keys_to_include
            sanity_test_result = {}
            for key in keys_to_include:
                if key == "executionTime":
                    sanity_test_result[key] = DataCollectorUtils.convert_execution_time(test_result.get(key, None))
                elif key == "testStatus":
                    if test_stage["component"] == "E2E":
                        sanity_test_result[key] = self.set_component_test_status(test_result.get("pass", 0), test_result.get("baseline", 0), required_pass_rate_e2e)
                    else:
                        sanity_test_result[key] = self.set_component_test_status(test_result.get("pass", 0), test_result.get("baseline", 0), required_pass_rate_aio)
                else:
                    sanity_test_result[key] = test_result.get(key, None)
            official_mainstream_test_result = {
                "component": test_stage["component"],
                "testName": test_stage["testData"]["testName"],
                "url": test_stage["url"]
            }
            print(official_mainstream_test_result)
            official_mainstream_test_result.update(sanity_test_result)

            # Update Test result summary value
            print("Update test summary")
            self.test_result_summary["Total Tests"] += self.get_test_case_stat(official_mainstream_test_result, "baseline")
            self.test_result_summary["Total Passed"] += self.get_test_case_stat(official_mainstream_test_result, "pass")
            self.test_result_summary["Total Failed"] += self.get_test_case_stat(official_mainstream_test_result, "fail")
            self.test_result_summary["Total Skipped"] += self.get_test_case_stat(official_mainstream_test_result, "skip")
            self.test_result_summary["Total Unexecuted"] += self.get_test_case_stat(official_mainstream_test_result, "miss")

            if test_stage["component"] == "E2E":
                if "ruBaseline" in test_result:
                    if test_result["ruBaseline"] != None and test_result["ruBaseline"] != "":
                        ru_version['ru_baseline'] = test_result["ruBaseline"]
                if "ruAlbus" in test_result:
                    if test_result["ruAlbus"] != None and test_result["ruAlbus"] != "":
                        ru_version['ru_albus'] = test_result["ruAlbus"]
                if "ruFoxconn" in test_result:
                    if test_result["ruFoxconn"] != None and test_result["ruFoxconn"] != "":
                        ru_version['ru_foxconn'] = test_result["ruFoxconn"]
            sanity_result_list.append(official_mainstream_test_result)

        missing_sanity_test = set(sanity_test_list) - {item["component"] for item in matches_test_stage}
        # If there is no sanity test data, create an empty test result
        for sanity in missing_sanity_test:
            print("Update missing sanity test")
            official_mainstream_test_result = official_mainstream_test_result = {
                "component": sanity,
                "testName": None,
                "url": None
            }
            official_mainstream_test_result.update({field_name: None for field_name in keys_to_include})
            #if no sanity test data, but the sanity test is enable that mean there was failed in somewhere, set test status to "NOT-EXECUTED", else the sanity test is disable set status to "NOT-READY"
            if sanity in enable_sanity_test:
                official_mainstream_test_result["testStatus"] = "NOT-EXECUTED"
            else:
                official_mainstream_test_result["testStatus"] = "NOT-READY"
            official_mainstream_test_result["baseline"] = self.getTcBaseline(sanity, sanity)#the second param is for testName, AIO and E2E don't have multiple testName, just input "sanity" as testName to reuse the fuction.
            sanity_result_list.append(official_mainstream_test_result)

            # Update Total Tests and Total Unexecuted in case sanity test result is empty
            print("Update Total Tests and Total Unexecuted in case sanity test result is empty")
            if official_mainstream_test_result["baseline"] is not None:
                self.test_result_summary["Total Tests"] += int(official_mainstream_test_result.get("baseline", 0))
                self.test_result_summary["Total Unexecuted"] += int(official_mainstream_test_result.get("baseline", 0))
        return self.rename_columns(sanity_result_list), ru_version

    def rename_columns(self, test_result_list):
        column_name_mapping = {
            "component": "TL Type",
            "url": "URL",
            "testName": "Test Name",
            "testStatus": "Test Status",
            "baseline": "Baseline",
            "total": "Total Tests",
            "pass": "Passed",
            "fail": "Failed",
            "skip": "Skipped",
            "miss": "Missed",
            "failedStages": "Failed Stages",
            "jiraURL": "Jira URL",
            "removedTCsJira": "Removed TCs Jira",
            "executionTime": "Execution Time"
        }
        result = []
        for test_result in test_result_list:
            renamed_test = {column_name_mapping[key]: value for key, value in test_result.items()}
            result.append(renamed_test)

        return result

    def get_mainstream_test_results(self, test_id):
        """
            Download test result data from ELK and generate official mainstream test data
            Get Mainstream test data from ELK
            Mainstream test data on ELK (all_component_test_df) have the following structure
            We need to iterate through each item in testStages, using componentName and id to get test data corresponding to each component.
            {
                "testStages": [
                    {
                        "component": string,
                        "componentName": string,
                        "description": string,
                        "overallStatus": string,
                        "url": string,
                        "id": string
                    },
                    ...
                ],
                "overallstatus": string,
                "buildID": string,
                "date_created": string
            }
        """
        print("[INFO] [Test] Collecting data...")

        components_list = [key.upper() for key in self.streamMetadata["elk"]["components"].keys()]
        mainstream_unit_test_results = []
        mainstream_component_test_results = []
        mainstream_sanity_test_results = []
        is_test_success = False
        ru_version = {}

        all_component_test_df = self.ESInterface.get_mainstream_data_by_id(self.elk_mainstream_test_index, test_id)

        if all_component_test_df is not None:
            mainstream_test_stages = all_component_test_df.iloc[0]['testStages']
            overall_status = all_component_test_df.iloc[0]['overallstatus']

            if overall_status == "SUCCESS":
                is_test_success = True

            # Check which Component test stage has data in mainstream_test_stages
            matches_test_stage = [test_stage for test_stage in mainstream_test_stages if test_stage["component"] in components_list]
            for test_stage in matches_test_stage:
                # Get component test data
                component_unit_tests, component_component_tests = self.get_component_test_results(test_stage)
                mainstream_unit_test_results.extend(component_unit_tests)
                mainstream_component_test_results.extend(component_component_tests)

            # If there is no component test data in mainstream_test_stages, it means that component's testing is disabled or failed to excuted test
            # Add empty test result with status NOT-READY or NOT-EXECUTED
            #enable_test_components: List of components enabled testing stage.
            enable_test_components = [component_test for component_test in all_component_test_df.iloc[0]['enableTestStages']]
            missing_components = set(components_list) - {item["component"] for item in matches_test_stage}
            for component in missing_components:
                if component not in enable_test_components:
                        mainstream_unit_test_results.append(self.generate_empty_test_results(component, "NOT-READY", "Unit-Test"))
                        mainstream_component_test_results.append(self.generate_empty_test_results(component, "NOT-READY", "Component-Test"))
                else:
                    #There is no component test data in mainstream_test_stages, the component test has enable test stage but it doesn't have CT or UT test yet,
                    #the UT or CT test status should be NOT-READY
                    if self.getTcBaseline(component, "Unit-Test") is None:
                        mainstream_unit_test_results.append(self.generate_empty_test_results(component, "NOT-READY", "Unit-Test"))
                    else:
                        mainstream_unit_test_results.append(self.generate_empty_test_results(component, "NOT-EXECUTED", "Unit-Test"))
                    if self.getTcBaseline(component, "Component-Test") is None:
                        mainstream_component_test_results.append(self.generate_empty_test_results(component, "NOT-READY", "Component-Test"))
                    else:
                        mainstream_component_test_results.append(self.generate_empty_test_results(component, "NOT-EXECUTED", "Component-Test"))
            mainstream_sanity_test_results, ru_version = self.get_sanity_test_results(mainstream_test_stages, enable_test_components)

        print("[INFO] [Test] Data collection completed")

        return is_test_success, \
            sorted(mainstream_unit_test_results, key=lambda x: x.get("Component", "")), \
            sorted(mainstream_component_test_results, key=lambda x: x.get("Component", "")), \
            sorted(mainstream_sanity_test_results, key=lambda x: x.get("Component", "")), \
            self.test_result_summary, \
            ru_version

    def get_interim_sanity_test_results(self, build_id):
        """
            Generate official mainstream test result of AIO and E2E test
            E2E and AIO test data on ELK (input_mainstream_data) have the following structure:
            {
                "component": string,
                "componentName": string,
                "description": string,
                "overallStatus": string,
                "url": string,
                "id": string,
                "testData": {
                    "testResults": {
                    "total": int,
                    "fail": int,
                    "skip": int,
                    "pass": int,
                    "testStatus": string,
                    "jiraID": string,
                    "jiraURL": string,
                    "failedStages": string,
                    },
                    "component": string,
                    "testName": string,
                    "url": string,
                }
            }
        """
        print("get sanity data")
        keys_to_include = ["testStatus", "baseline", "total", "pass", "fail", "skip", "miss", "failedStages", "jiraURL", "removedTCsJira", "executionTime"] # List of keys will show in report
        sanity_test_list = []
        sanity_result_list = []
        missing_sanity_test = ["AIO", "E2E"]
        is_success = False
        failure_found = False
        tl_test_df = self.ESInterface.get_sanity_test_data_by_id(build_id, self.streamMetadata["elk"]["streaminfo"]["streaminfo_interim_sanity"])
        ru_version = {}

        for test_stage in tl_test_df["testStages"]:
            test_result = test_stage["testData"]["testResults"]
            # Get the values ​​corresponding to keys_to_include
            sanity_test_result = {}
            for key in keys_to_include:
                if key == "executionTime":
                    sanity_test_result[key] = DataCollectorUtils.convert_execution_time(test_result.get(key, None))
                else:
                    sanity_test_result[key] = test_result.get(key, None)
            official_mainstream_test_result = {
                "component": test_stage["component"],
                "testName": test_stage["testData"]["testName"],
                "url": test_stage["url"]
            }
            official_mainstream_test_result.update(sanity_test_result)

            if test_stage["component"] == "E2E":
                if "ruBaseline" in test_result:
                    if test_result["ruBaseline"] != None and test_result["ruBaseline"] != "":
                        ru_version['ru_baseline'] = test_result["ruBaseline"]
                if "ruAlbus" in test_result:
                    if test_result["ruAlbus"] != None and test_result["ruAlbus"] != "":
                        ru_version['ru_albus'] = test_result["ruAlbus"]
                if "ruFoxconn" in test_result:
                    if test_result["ruFoxconn"] != None and test_result["ruFoxconn"] != "":
                        ru_version['ru_foxconn'] = test_result["ruFoxconn"]
            sanity_result_list.append(official_mainstream_test_result)
            sanity_test_list.append(test_stage["component"])

            # Check sanity is success or not
            if test_result["testStatus"] == "FAILURE":
                is_success = False
                failure_found = True
            else:
                if failure_found:
                    is_success = False
                else:
                    is_success = True
        for tl in sanity_test_list:
            print(tl)
            missing_sanity_test.remove(tl)
        # If there is no sanity test data, create an empty test result
        for sanity in missing_sanity_test:
            official_mainstream_test_result = official_mainstream_test_result = {
                "component": sanity,
                "testName": None,
                "url": None
            }
            official_mainstream_test_result.update({field_name: None for field_name in keys_to_include})
            official_mainstream_test_result["testStatus"] = "NOT-READY"
            official_mainstream_test_result["baseline"] = self.getTcBaseline(sanity, sanity)#the second param is for testName, AIO and E2E don't have multiple testName, just input "sanity" as testName to reuse the fuction.
            sanity_result_list.append(official_mainstream_test_result)

        return is_success, self.rename_columns(sanity_result_list), ru_version

    def set_component_test_status(sefl, number_tc_passed, number_baseline, passed_rate):
        """This function to set test status"""
        test_status = "FAIL"
        try :
            number_tc_passed = int(number_tc_passed) if number_tc_passed else 0
            number_baseline = int(number_baseline) if number_baseline else 0
            passed_rate = float(passed_rate)
            if number_baseline == 0:
                return "NO-DATA"
            if (number_tc_passed / number_baseline)*100 == 100:
                test_status = "PASS"
            elif (number_tc_passed / number_baseline)*100 >= passed_rate:
                test_status = "CONDITIONAL"
        except ValueError:
            return "NO-DATA"
        return test_status

class DataCollectorUtils():
    """
    DataCollectorUtils is a utility class designed to encapsulate common functions for reusability across various classes
    and methods within a data collection and processing context.
    """

    @classmethod
    def convert_execution_time(cls, timestamp_in_milliseconds):
        convert_result = 'N/A'
        try:
            total_seconds = int(timestamp_in_milliseconds) / 1000
            total_minutes = total_seconds / 60
            hours = total_minutes / 60
            remaining_minutes = int(total_minutes % 60)
            remaining_seconds = int(total_seconds % 60)

            formatted_hours = "{:02d}".format(int(hours))
            formatted_minutes = "{:02d}".format(remaining_minutes)
            formatted_seconds = "{:02d}".format(remaining_seconds)
            convert_result = f"{formatted_hours}:{formatted_minutes}:{formatted_seconds}"
        except Exception as err:
            print("Error while converting timestamp: ", err)

        return convert_result

    @classmethod
    def convert_yaml_to_dict(cls, file_path):
        with open(file_path, 'r') as yaml_file:
            yaml_data = yaml.safe_load(yaml_file)
        
        return yaml_data
