# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import argparse


class MainstreamParser:
    def __init__(self):
        self.parser = argparse.ArgumentParser()

        self.parser.add_argument(
            "-output_html",
            "--output-html",
            help="Specify the output HTML file",
            required=True,
        )
        self.parser.add_argument(
            "-mainstream_json",
            "--mainstream-json",
            help="Specify the output mainstream data json file",
            default=None,
            required=False,
        )
        self.parser.add_argument(
            "-github_token",
            "--github-token",
            help="Provide MP github token",
            default=None,
            required=True,
        )
        self.parser.add_argument(
            "-input_mainstream_data",
            "--input-mainstream-data",
            default=None,
            help="Specify the input mainstream data (containing the mainstreamID, buildID, testID, checkerID)",
            required=False,
        )
        self.parser.add_argument(
            "-report_type",
            "--report-type",
            default=None,
            help="Specify the report",
            required=False,
        )
        self.parser.add_argument(
            "-application_data",
            "--application-data",
            default=None,
            help="Specify the application data (name, version)",
            required=False,
        )
        self.parser.add_argument(
            "-ldap_username",
            "--ldap-username",
            default=None,
            help="Provide LDAP username",
            required=False,
        )
        self.parser.add_argument(
            "-ldap_password",
            "--ldap-password",
            default=None,
            help="Provide LDAP password",
            required=False,
        )
        self.parser.add_argument(
            "-build_url",
            "--build-url",
            default=None,
            help="Provide BUILD URL",
            required=False,
        )
        self.parser.add_argument(
            "-mainstream_data",
            "--mainstream-data",
            default=None,
            help="Specify the mainstream data (build ID, test ID)",
            required=False,
        )
        self.parser.add_argument(
            "-rpm_list",
            "--rpm-list",
            default=None,
            help="Specify the RPM list",
            required=False,
        )
        self.parser.add_argument(
            "-release_rpm",
            "--release-rpm",
            default=None,
            help="Specify if RPM release is available",
            required=False,
        )
        self.parser.add_argument(
            "-build_number",
            "--build-number",
            default=None,
            help="Specify the mainstream number",
            required=False,
        )
        self.parser.add_argument(
            "-flag_checker",
            "--flag-checker",
            default=None,
            help="Show test quality by color",
            required=False,
        )
        self.parser.add_argument(
            "-greenlight_log",
            "--greenlight-log",
            default=None,
            help="Green Light Log",
            required=False,
        )
        self.parser.add_argument(
            "-mainstream_info",
            "--mainstream-info",
            default=None,
            help="Show the information about mainstream pipeline",
            required=False,
        )
        self.parser.add_argument(
            "-pass_rate_data",
            "--pass-rate-data",
            default=None,
            help="Show the information about required passrate components test",
            required=False,
        )

    def parse_args(self):
        args = self.parser.parse_args()
        return args
