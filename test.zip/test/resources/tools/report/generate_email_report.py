# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import sys
sys.path.append("../../html_templates")
import json
import re
import warnings
import render_html
import mainstream_parser
import data_collector


# Create an instance of MainstreamParser
MainstreamParser = mainstream_parser.MainstreamParser()

# Parse input arguments
args = MainstreamParser.parse_args()
BUILD_URL = args.build_url
BUILD_NUMBER = args.build_number
MAINSTREAM_INFO = args.mainstream_info 
FLAG_CHECKER = args.flag_checker
OUTPUT_HTML = args.output_html
INPUT_MAINSTREAM_DATA = args.input_mainstream_data
REPORT_TYPE = args.report_type
APPLICATION_DATA = args.application_data
MAINTREAM_DATA = args.mainstream_data
GITHUB_TOKEN = args.github_token
LDAP_USERNAME = args.ldap_username
LDAP_PASSWORD = args.ldap_password
OUTPUT_MAINSTREAM_JSON = args.mainstream_json
RPM_LIST = args.rpm_list
RELEASE_RPM = args.release_rpm
PASS_RATE_DATA = args.pass_rate_data

GREENLIGHT_LOG = []
try:
    # Open the file in read mode and read only the first 50 lines
    with open(args.greenlight_log, "r") as log_file:
        # Filter out empty lines and limit to the first 50 non-empty lines
        GREENLIGHT_LOG = [line.strip() for line in log_file if line.strip()][:50]
except FileNotFoundError:
    print(f"Error: File '{args.greenlight_log}' not found.")
except IOError as err:
    print(f"Error when reading file: {err}")
except Exception as err:
    print("Error when parsing greenlight log")
    print(err)

print(GREENLIGHT_LOG)

# Ignore warnings log
warnings.filterwarnings("ignore", category=DeprecationWarning)


def main():
    MainstreamHTMLRender = None

    if REPORT_TYPE == "official_mainstream":
        DataCollector = data_collector.DataCollectorOfficialMainstream(
            GITHUB_TOKEN,
            LDAP_USERNAME,
            LDAP_PASSWORD,
            BUILD_URL,
            INPUT_MAINSTREAM_DATA,
            RPM_LIST,
            RELEASE_RPM,
            BUILD_NUMBER,
            FLAG_CHECKER,
            GREENLIGHT_LOG,
            MAINSTREAM_INFO,
            PASS_RATE_DATA
        )
        official_mainstream_data = DataCollector.collect_official_mainstream_data()
        official_mainstream_data_for_json = official_mainstream_data.copy()
        if OUTPUT_MAINSTREAM_JSON is not None:
            # Write the dictionary to the file in JSON format for further use
            with open(OUTPUT_MAINSTREAM_JSON, "w") as f:
                json_data = json.dumps(official_mainstream_data_for_json, default=str)
                f.write(json_data)
        MainstreamHTMLRender = render_html.OfficialMainstreamHTMLRender(
            official_mainstream_data, OUTPUT_HTML
        )
    elif REPORT_TYPE == "interim_build":
        DataCollector = data_collector.DataCollectorInterimMainstreamBuild(
            GITHUB_TOKEN,
            LDAP_USERNAME,
            LDAP_PASSWORD,
            BUILD_URL,
            BUILD_NUMBER,
            INPUT_MAINSTREAM_DATA,
        )
        interim_mainstream_build_data = DataCollector.collect_mainstream_build_data()
        interim_mainstream_build_data_json = interim_mainstream_build_data.copy()
        if OUTPUT_MAINSTREAM_JSON is not None:
            # Write the dictionary to the file in JSON format for further use
            with open(OUTPUT_MAINSTREAM_JSON, "w") as f:
                json_data = json.dumps(interim_mainstream_build_data_json, default=str)
                f.write(json_data)
        MainstreamHTMLRender = render_html.InterimMainstreamBuildHTMLRender(
            interim_mainstream_build_data, OUTPUT_HTML
        )
    elif REPORT_TYPE == "interim_sanity_test":
        DataCollector = data_collector.DataCollectorInterimMainstreamSanity(
            GITHUB_TOKEN,
            LDAP_USERNAME,
            LDAP_PASSWORD,
            BUILD_URL,
            BUILD_NUMBER,
            INPUT_MAINSTREAM_DATA,
        )
        interim_sanity_test_data = DataCollector.collect_interim_sanity_data()
        interim_sanity_test_data_json = interim_sanity_test_data.copy()
        if OUTPUT_MAINSTREAM_JSON is not None:
            # Write the dictionary to the file in JSON format for further use
            with open(OUTPUT_MAINSTREAM_JSON, "w") as f:
                json_data = json.dumps(interim_sanity_test_data_json, default=str)
                f.write(json_data)
        MainstreamHTMLRender = render_html.InterimMainstreamSanityRender(
            interim_sanity_test_data, OUTPUT_HTML
        )
    else:
        print("Invalid report type: ", REPORT_TYPE)
        sys.exit()

    # Start rendering to generate HTML report file
    MainstreamHTMLRender.render()


if __name__ == "__main__":
    main()