# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

from jinja2 import Environment, FileSystemLoader
import os
import sys
import pandas as pd

class TemplateRenderFromJson():
    """Render HTML template"""

    def __init__(self, html_template_name):
        """Load the template from ./html_templates"""
        root = os.path.dirname(os.path.abspath(__file__))
        templates_dir = os.path.join(root, './html_templates')
        env = Environment(loader=FileSystemLoader(templates_dir))
        self.template = env.get_template(html_template_name)

    def render(self):
        """Render the data."""
        raise NotImplementedError

class jsonHTMLReport(TemplateRenderFromJson):
    def __init__(self, data_from_json, html_output, html_template="continuous_test_template.html"):
        super().__init__(html_template)
        self.html_output = html_output
        self.data_from_json = data_from_json
        self.contents = {}
        if not data_from_json:
            raise ("No data available.")

    def brief_url(self, df, column):
        """displaying short link texts for all URLs in column instead of full"""
        df[column] = df[column].apply(lambda x: f'<a href="{x}" title="{x}" target="_blank">{self.hyperlink_texts(x)}</a>' if x and type(x) == str else '-')
        return df

    def hyperlink_texts(self, url):
        """get short link texts for URL"""
        if "https://osj-phm-02-prd.cec.delllabs.net" in url:
            parts = url.split('/')
            return parts[-3] + " #" + parts[-2]
        elif "https://jira.cec.lab.emc.com" in url:
            return url.split('/')[-1]
        else:
            return url   

    def prepare_data_frame_continuous_test(self, tls_test):
        """
            rows_data=[{
                "tl_name": "",
                "testType": "",
                "total": "",
                "pass": "",
                "fail": "",
                "overallStatus" : "",
                "url": "",
                "executionTime": ""
            }]
        """
        rows_data = []
        for tl_test in tls_test:
            if isinstance(tl_test, dict) and 'tlName' in tl_test:
                for test_type in tl_test['testResults']:
                    row_data = {}
                    row_data['tl_name'] = tl_test['tlName']
                    row_data['testType'] = test_type['testType']
                    row_data['total'] = test_type['testResults']['total']
                    row_data['pass'] = test_type['testResults']['pass']
                    row_data['fail'] = test_type['testResults']['fail']
                    if row_data['total'] or row_data['pass'] or row_data['fail'] != None :
                        row_data['overallStatus'] = test_type['overallstatus']
                    row_data['url'] = test_type['url']
                    row_data['executionTime'] = self.convert_execution_time(test_type['testResults']['executiontime'])
                    rows_data.append(row_data)
        return rows_data

    def convert_execution_time(self, timestamp_in_milliseconds):
        convert_result = 'N/A'
        try:
            total_seconds = int(timestamp_in_milliseconds) / 1000
            total_minutes = total_seconds / 60
            hours = total_minutes / 60
            remaining_minutes = int(total_minutes % 60)
            remaining_seconds = int(total_seconds % 60)
            formatted_hours = "{:02d}".format(int(hours))
            formatted_minutes = "{:02d}".format(remaining_minutes)
            formatted_seconds = "{:02d}".format(remaining_seconds)
            convert_result = f"{formatted_hours}:{formatted_minutes}:{formatted_seconds}"
        except Exception as err:
            print("Error while converting timestamp: ", err)
        return convert_result

    def prepare_data_frame_tl_deployment_status(self, tls_test):
        """
            rows_data=[{
                "tl_name": "",
                "deploymentStatus" : "",
                "url": ""
            }]
        """
        rows_data = []
        for tl_test in tls_test:
            
            if isinstance(tl_test, dict) and 'tlName' in tl_test:
                if 'deployResults' in tl_test or "url" in tl_test:
                    for tl_info in tl_test['deployResults']:
                        row_data = {}
                        row_data['tl_name'] = tl_test['tlName']
                        row_data['deploymentStatus'] = tl_info['deploymentStatus']
                        row_data['url'] = tl_info['url']
                        rows_data.append(row_data)
                else:
                    return None
        return rows_data

    def prepare_data_frame_tl_overall_ct_status(self, tls_test):
        """
            rows_data=[{
                "tl_name": "TL Name",
                "deploymentStatus": "Deploy Status",
                "smokeTC": "Smoke Test To Run",
                "extraTC": "Extra Test To Run"
            }]
        """
        rows_data = []
        for tl_test in tls_test:
            if isinstance(tl_test, dict) and 'tlName' in tl_test:
                row_data = {}
                row_data['tl_name'] = tl_test['tlName']
                # Check enable stage in TL pipeline
                if 'deploy' in tl_test['stages']:
                    row_data['deploymentStatus'] = "ENABLED"
                else:
                    row_data['deploymentStatus'] = "SKIP"
                if 'smoke_test' in tl_test['stages']:
                    for test_type in tl_test['testResults']:
                        if test_type['testType'] == "smokeTest" :
                            row_data['smokeTC'] = test_type['testResults']['total']
                else:
                    row_data['smokeTC'] = "SKIP"
                if 'extra_tests' in tl_test['stages']:
                    for test_type in tl_test['testResults']:
                        if test_type['testType'] == "extraTests" :
                            row_data['extraTC'] = test_type['testResults']['total']
                else:
                    row_data['extraTC'] = "SKIP"
                rows_data.append(row_data)
        return rows_data

    def build_continuous_test_table(self, testing_table_name):
        if testing_table_name in self.data_from_json:
            if self.data_from_json[testing_table_name] is None or len(self.data_from_json[testing_table_name]) == 0:
                return None
            continuous_test_list = self.prepare_data_frame_continuous_test(self.data_from_json[testing_table_name])
            colums_mapping = {
                "tl_name": "TL Name",
                "testType": "Test Type",
                "total": "Total Tests",
                "pass": "Passed",
                "fail": "Failed",
                "overallStatus" : "Status",
                "url": "URL",
                "executionTime": "Execution Time"
            }
            continuous_test_list_df = pd.DataFrame(continuous_test_list)
            continuous_test_list_df = self.brief_url(continuous_test_list_df,'url')
            continuous_test_list_df = continuous_test_list_df.fillna('-')
            continuous_test_list_df.replace('', '-', inplace=True)
            continuous_test_list_df.rename(columns=colums_mapping, inplace=True)

            return continuous_test_list_df.to_html(
                justify='center',
                render_links=True,
                index=False,
                classes='new_table',
                na_rep='-',
                escape=False
            )
        return None

    def build_tl_deployment_status_table(self, testing_table_name):
        if testing_table_name in self.data_from_json:
            if self.data_from_json[testing_table_name] is None or len(self.data_from_json[testing_table_name]) == 0:
                return None
            continuous_test_list = self.prepare_data_frame_tl_deployment_status(self.data_from_json[testing_table_name])
            if continuous_test_list is None :
                return None
            colums_mapping = {
                "tl_name": "TL Name",
                "deploymentStatus": "Deploy Status",
                "url": "URL"
            }
            continuous_test_list_df = pd.DataFrame(continuous_test_list)
            continuous_test_list_df = self.brief_url(continuous_test_list_df,'url')
            continuous_test_list_df = continuous_test_list_df.fillna('-')
            continuous_test_list_df.replace('', '-', inplace=True)
            continuous_test_list_df.rename(columns=colums_mapping, inplace=True)

            return continuous_test_list_df.to_html(
                justify='center',
                render_links=True,
                index=False,
                classes='new_table',
                na_rep='-',
                escape=False
            )
        return None

    def build_tl_overall_ct_status_table(self, testing_table_name):
        if testing_table_name in self.data_from_json:
            if self.data_from_json[testing_table_name] is None or len(self.data_from_json[testing_table_name]) == 0:
                return None
            continuous_test_list = self.prepare_data_frame_tl_overall_ct_status(self.data_from_json[testing_table_name])
            if continuous_test_list is None :
                return None
            colums_mapping = {
                "tl_name": "TL Name",
                "deploymentStatus": "Deploy Status",
                "smokeTC": "Smoke Test To Run",
                "extraTC": "Extra Test To Run"
            }
            continuous_test_list_df = pd.DataFrame(continuous_test_list)
            continuous_test_list_df = continuous_test_list_df.fillna('-')
            continuous_test_list_df.replace('', '-', inplace=True)
            continuous_test_list_df.rename(columns=colums_mapping, inplace=True)

            return continuous_test_list_df.to_html(
                justify='center',
                render_links=True,
                index=False,
                classes='new_table',
                na_rep='-',
                escape=False
            )
        return None

    def prepare_continuous_test_content(self):
        continuous_test_table = self.build_continuous_test_table("continuous_test_results")
        tl_deployment_status_table = self.build_tl_deployment_status_table("continuous_test_results")
        tl_overall_ct_status_table = self.build_tl_overall_ct_status_table("continuous_test_results")
        # Load contentss
        self.contents["continuous_test_table"] = continuous_test_table
        self.contents["tl_deployment_status"] = tl_deployment_status_table
        self.contents["tl_overall_ct_status"] = tl_overall_ct_status_table

    def rendertemplate(self):
        """Render the mainstream data."""
        if self.data_from_json["report_type"] == "continuous_test":
            # Render build report
            print("Render email report from json data")
            self.prepare_continuous_test_content()
            with open(self.html_output, 'w') as fh:
                fh.write(self.template.render(
                    continuous_test=self.contents["continuous_test_table"],
                    tl_deployment_status=self.contents["tl_deployment_status"],
                    tl_overall_ct_status=self.contents["tl_overall_ct_status"],
                    build_number=self.data_from_json["build_number"],
                    build_url=self.data_from_json["build_url"]
                ))

class ContinuousTestHTMLRender(jsonHTMLReport):
    """Render the contents to the test template."""

    def __init__(self, data_from_json, html_output):
        """Load the test template.
           Templates location: ./html_templates
        """
        super().__init__(data_from_json, html_output, "continuous_test_template.html")