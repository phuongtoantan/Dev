# Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.
import argparse

class ArgParser:
    def __init__(self):
        self.parser = argparse.ArgumentParser()

        self.parser.add_argument(
            "-output_html",
            "--output-html",
            help="Specify the output HTML file",
            required=True,
        )
        self.parser.add_argument(
            "-report_type",
            "--report-type",
            default=None,
            help="Specify the report",
            required=False,
        )
        self.parser.add_argument(
            "-json_result",
            "--json-result",
            default=None,
            help="Specify the json data",
            required=False,
        )
        self.parser.add_argument(
            "-build_number",
            "--build-number",
            default=None,
            help="Specify the build number",
            required=False,
        )
        self.parser.add_argument(
            "-build_url",
            "--build-url",
            default=None,
            help="Specify the build url",
            required=False,
        )


    def parse_args(self):
        args = self.parser.parse_args()
        return args
