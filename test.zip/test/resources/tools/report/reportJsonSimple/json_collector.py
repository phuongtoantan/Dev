# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import sys
import json

class JsonDataCollector:
    """Data collect tool to load, extract and tranform data from multiple sources"""
    def __init__(self,json,build_number,build_url):
        self.json = json
        self.build_number = build_number
        self.build_url = build_url

class DataCollectorContinuousTest(JsonDataCollector):
    """Collect data from json related information for Email Simple"""

    def __init__(
            self,
            json,
            build_number,
            build_url
        ):
        super().__init__(
            json,
            build_number,
            build_url
        )

    def collect_continuous_test_data(self):
        report_type = "continuous_test"
        results_data = {}
        continuous_test_results = json.loads(self.json)
        build_number = self.build_number
        build_url = self.build_url
        try:
            results_data.update(
                {
                    "report_type": report_type,
                    "continuous_test_results": continuous_test_results,
                    "build_number": build_number,
                    "build_url": build_url
                }
            )
        except Exception as err:
            print("Error while collecting data:")
            print(err)
            sys.exit()
        print(f"Value of results_data: {results_data}")

        return results_data

    