# Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.

import sys

sys.path.append("../../html_templates")
import json
import json_report_parser
import json_collector
import render_html_from_json


# Parse input arguments
ArgParser = json_report_parser.ArgParser()
args = ArgParser.parse_args()
OUTPUT_HTML = args.output_html
REPORT_TYPE = args.report_type
OUTPUT_JSON = args.json_result
BUILD_NUMBER = args.build_number
BUILD_URL = args.build_url
def main():
    if REPORT_TYPE == "continuous_test":
        if OUTPUT_JSON is not None:
            JsonDataCollector = json_collector.DataCollectorContinuousTest(
                OUTPUT_JSON, 
                BUILD_NUMBER,
                BUILD_URL
            )
            data_from_json = JsonDataCollector.collect_continuous_test_data()
            HTMLRender = render_html_from_json.ContinuousTestHTMLRender(
                data_from_json, 
                OUTPUT_HTML
            )
    else:
        print("Invalid report type: ", REPORT_TYPE)
        sys.exit()

    HTMLRender.rendertemplate()

if __name__ == "__main__":
    main()