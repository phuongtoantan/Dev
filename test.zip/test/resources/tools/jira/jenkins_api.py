# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
import jenkins
import requests
import json
import time
import logging

import os

JENKINS_USERNAME = os.environ["JENKINS_USERNAME"]
JENKINS_PASSWORD = os.environ["JENKINS_PASSWORD"]

class Jenkins:
    def __init__(self):
        self.hostname = 'https://osj-phm-02-prd.cec.delllabs.net'
        self.username = JENKINS_USERNAME
        self.password = JENKINS_PASSWORD
        self.jenkins = jenkins.Jenkins(self.hostname, username=self.username, password=self.password)

    def request(self, url, type_file):
        for times in range (3):
            try:
                if "json" in type_file.lower():
                    pipeline_info = requests.get(url, verify=False, auth = (self.username, self.password)).json()
                    return pipeline_info
                if "text" in type_file.lower():
                    pipeline_info = requests.get(url, verify=False, auth = (self.username, self.password)).text
                    return pipeline_info
            except:
                logging.warning('Failed to connect url {url}\n'.format(url=url))
                time.sleep(30)
        return False
    
    def get_build_artifact(self, job_name, build_number, file_name):
        info = ""
        url = f'{self.hostname}/job/{job_name}/{build_number}/api/json'
        pipeline_info = self.request(url, 'json')
        for artifact in pipeline_info['artifacts']:
            if artifact['fileName'] == file_name:
                info = self.jenkins.get_build_artifact(job_name, build_number, artifact['relativePath'])
        return info
    
    def get_job_info(self, job_name, build_number):
        build_info = {
            "is_multibranch": False,
            "branch": "",
            "build_url": "",
            "job_name": job_name,
            "build_number": build_number,
            "url_console_log": ""
        }

        pipeline_data = self.jenkins.get_build_info(job_name, build_number)
        build_info['build_url'] = pipeline_data['url']

        if "»" in pipeline_data['fullDisplayName']:
            build_info["is_multibranch"] = True
            build_info["branch"] = pipeline_data['fullDisplayName'].split(" ")[-2]

        return build_info

        