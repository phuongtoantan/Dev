# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import os
import jira_interface
import jenkins_api
import jenkins_blue_ocean
import logging as log
import argparse
import sys
import yaml

# Loading env data
PIPELINE_JOB_NAME = os.environ["PIPELINE_JOB_NAME"]
PIPELINE_BUILD_NUMBER = os.environ["PIPELINE_BUILD_NUMBER"]
SUMMARY = os.environ["SUMMARY"]
COMPONENT = os.environ["COMPONENT"]
DEGRADATION_TC_JIRA_TYPE = os.environ["DEGRADATION_TC_JIRA_TYPE"]
DEGRADATION_INFO = os.environ["DEGRADATION_INFO"]
STREAM_NAME = os.environ["STREAM_NAME"]
JIRA_INFO = {}

# Read file metadata
with open(f'./releases/{STREAM_NAME}_metadata.yaml', 'r') as f:
    data = yaml.load(f, Loader=yaml.SafeLoader)
    JIRA_INFO = data["jira"]
log.info(JIRA_INFO)

# Custom action to parse comma-separated list
class CommaSeparatedListAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, values.split(','))

COMPONENT = COMPONENT.split(",")
converted_list = [{"name": item} for item in COMPONENT]
log.info(converted_list)

jira_server = jira_interface.JiraInterface()
jenkins_server = jenkins_api.Jenkins()

build_info = jenkins_server.get_job_info(PIPELINE_JOB_NAME, PIPELINE_BUILD_NUMBER)
log.info(build_info)
# Return Json format for rebot_report_json
robot_report_json = jenkins_server.get_build_artifact(PIPELINE_JOB_NAME, PIPELINE_BUILD_NUMBER, "robot-result.json")

jenkins_blue_ocean = jenkins_blue_ocean.JenkinsBlueOcean(build_info, robot_report_json)

jql = f'project = {JIRA_INFO["project"]} AND issuetype = {JIRA_INFO["type"]} AND status not in (Completed, Cancelled, Closed, Resolved) AND labels = "{build_info["job_name"]}" AND description ~ "\\"Branch: {build_info["branch"]}\\""'

jql_search=fail_details=''

if not robot_report_json:
    jql_search = jenkins_blue_ocean.get_info_of_failure_reasons_to_search_jira()
    if jql_search != False:
        jql += jql_search + " order by createdDate DESC"
        fail_details = jenkins_blue_ocean.detail_log_of_pipeline()
else:
    jql += jenkins_blue_ocean.get_info_of_test_case_failed_to_search_jira() + " order by createdDate DESC"
    fail_details = jenkins_blue_ocean.get_name_of_test_case()

log.info('Look up issue: {jql}'.format(jql=jql))

# Cover for case degradation TC jira only
if DEGRADATION_TC_JIRA_TYPE == 'true':
    degradation_info_jql = f' AND description ~ "\\"{DEGRADATION_INFO.split(" [")[0]}\\""'
    fail_details = DEGRADATION_INFO + ".\n\n    NOTE: In case the tc baseline really decreases, the component owners can go to this pipeline and reset the baseline to a new value: https://osj-phm-02-prd.cec.delllabs.net/job/Reset-TcBaseline-Pipeline/"
    if jql_search != False: #non-empty string
        if jql_search:
            jql = jql.replace(jql_search, degradation_info_jql)
        else: #empty string
            jql = jql.replace(" order by createdDate DESC", degradation_info_jql + " order by createdDate DESC")
    else:
        jql += degradation_info_jql + " order by createdDate DESC"
        jql_search = '' # degradationTcJiraType does not search exist ticket by result of jenkins_blue_ocean.get_info_of_failure_reasons_to_search_jira()

existing_issues = jira_server.look_up_issue(jql=jql)

summary = str(SUMMARY)

Description = """
    Pipeline: {Pipeline}

    Branch: {Branch}

    Description: {Description}{Parent_Mainstream_Job}

    {Details}
    """.format(
    Pipeline=build_info["job_name"],
    Branch=build_info["branch"],
    Description=f"{build_info['build_url']} is unsuccessful",
    Parent_Mainstream_Job=jenkins_blue_ocean.is_triggered_by_mainstream_job,
    Details=fail_details)

l = Description.split("\n")

Description = "\n".join(l)

disable_list = {
    "DU_DEV/main": {
        "show_detail_log": False
    },
    "DU-BUILD-ALL": {
        "show_detail_log": False
    },
    "CU-mainstream-Test": {
        "show_detail_log": True
    }
} #TODO clean up ...

#TODO formalize the jenkins interaction with Jira <MP-60586>
if build_info["job_name"] not in disable_list.keys() or DEGRADATION_TC_JIRA_TYPE == 'true': 
    if not existing_issues or jql_search == False:
        #This step will execute when Jira dont have the same issue
        log.info("Create issue - execute when Jira dont have the same issue")
        
        created_issue = jira_server.create_defect_ticket(
            jira_info=JIRA_INFO,
            summary=summary,
            description=Description,
            components=converted_list,
            labels=[build_info["job_name"]],
        )
            
        log.info("created the issue " + str(created_issue))
        sys.stdout.write(str(created_issue))

    else:
        if "Failed step" not in Description or "Failed stage" not in Description:
            if "Failed test cases" not in Description and "Degradation TC numbers of" not in Description:
                #This step will execute when Jira have the same issue but it don't have details log
                log.info("Create issue - execute when Jira have the same issue but it don't have details log")

                created_issue = jira_server.create_defect_ticket(
                    jira_info=JIRA_INFO,
                    summary=summary,
                    description=Description,
                    components=converted_list,
                    labels=[build_info["job_name"]],
                )
                    
                log.info("created the issue " + str(created_issue))
                sys.stdout.write(str(created_issue))
            else:
                log.info("Add comment to issue")
                comment_obj = jira_server.issue_add_comment(issue_id=existing_issues[0], comment=Description)
                created_issue = existing_issues[0]
                sys.stdout.write(str(created_issue))

        else:
            log.info("Add comment to issue")
            comment_obj = jira_server.issue_add_comment(issue_id=existing_issues[0], comment=Description)
            created_issue = existing_issues[0]
            sys.stdout.write(str(created_issue))
    
    log.info('Attach log file - Main job')
    full_log = jenkins_blue_ocean.get_full_log_of_stage()
    if full_log:
        jira_server.issue_add_attachment(str(created_issue), full_log=full_log, filename=build_info["job_name"] + "_" + build_info["build_number"])  

    log.info('Attach log file - Downstream job')
    downstream_jobs = jenkins_blue_ocean.get_full_log_of_downstream_job()
    for name, log in downstream_jobs.items():
        jira_server.issue_add_attachment(str(created_issue), full_log=log, filename=name)

else:
    log.info("Create issue")
    is_show_detail_log = disable_list[build_info["job_name"]]["show_detail_log"]
    if not is_show_detail_log:
        Description = """
            Pipeline: {Pipeline}

            Branch: {Branch}

            Description: {Description}
            """.format(
            Pipeline=build_info["job_name"],
            Branch=build_info["branch"],
            Description=f"{build_info['build_url']} is unsuccessful",)

        l = Description.split("\n")

        Description = "\n".join(l)
        
    created_issue = jira_server.create_defect_ticket(
        jira_info=JIRA_INFO,
        summary=summary,
        description=Description,
        components=converted_list,
        labels=[build_info["job_name"]],
    )
        
    log.info("created the issue " + str(created_issue))
    sys.stdout.write(str(created_issue))

with open("output.json", "w") as f:
    f.write(str(created_issue))