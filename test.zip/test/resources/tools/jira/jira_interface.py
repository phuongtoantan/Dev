# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
import logging as log
from jira import JIRA
import urllib3
from io import StringIO
import os

JIRA_USERNAME = os.environ["JIRA_USERNAME"]
JIRA_PASSWORD = os.environ["JIRA_PASSWORD"]

urllib3.disable_warnings()  # TODO create a proper system user and use otha token or certificate


class JiraInterface:

    """
    The Jira Interface object allows for a consilidated and flexiblble interaction with the Jira server

    """

    def __init__(self):
        # TODO implement the crediantial fetching
        # ,log, jira_server, jira_user, jira_password:
        self.jira_user = JIRA_USERNAME
        self.jira_password = JIRA_PASSWORD
        pass

    def _connect_jira(self):

        """
         Connect to the JIRA server using the service account

        Args:


        Raises:
            ConnectionError: Failed to coonnect to JIRA

        Returns:

            jira: A Jira client object

        """

        jira_options = {"server": "https://jira.cec.lab.emc.com", "verify": False}

        try:
            log.info("Connecting to JIRA: %s" % jira_options["server"])
            jira = JIRA(basic_auth=(self.jira_user, self.jira_password), options=jira_options)
            return jira

        except Exception as e:
            log.error("Failed to connect to JIRA: %s" % e)
            return None

    def look_up_jira_projects(self, **kwargs):

        """
         Allows looking up through the Jira server Projects

        Args:
            **kwargs: NONE or A specific project

        Raises:
            RuntimeError: Failed to retrive specified project

        Returns:

            project: list of projects or project

        """
        auth_jira = self._connect_jira()

        if kwargs is None:
            log.info("returning all projects")
            projects = auth_jira.projects()
            return projects
        else:
            try:
                log.info("returning specified project")
                # return the specified dictionary
                # if project is part of the dictionary i.e: key value pair then
                # kwarg is the dictionary and so value is Kwarg[project] and key is project
                project = auth_jira.project(kwargs)
                return project

            except Exception as e:
                log.error("Unable to retrive specified prject: %s" % e)
                return None

    def look_up_componets(self):
        # TODO
        """
         Allows looking up through the Jira server components

        Args:


        Raises:
            RuntimeError: Failed to retrive Jira Components

        Returns:

            Components: list of Components or component

        """
        pass

    def look_up_issue(self, issue_key=None, jql=None, project="MP"):

        """
         Allows looking up through the Jira server Issues

        Args:
            issue_key(str): Issue Key

            OR

            jql(str): Jira query language query

            OR

            project(str):Jira project label


        Raises:
            RuntimeError: Failed to retrive Jira Issues

        Returns:

            Components: list of Components objects or component object

        """

        # santization to the imputs
        auth_jira = self._connect_jira()

        if issue_key is None and jql is None:
            log.info("returning all issues")

            issues = auth_jira.search_issues("project=" + project, maxResults=200)
            return issues

        else:
            try:
                if issue_key:
                    log.info("returning specified issue given the key")
                    issues = auth_jira.issue(issue_key)
                    return issues
                elif jql:
                    log.info("returning specified issue given the jql")
                    issues = auth_jira.search_issues(jql, maxResults=200)
                    return issues

            except Exception as e:
                log.error("Unable to retrive specified issue: %s" % e)
                return None

    def issue_exists(self, search_issue):

        """
         checks if a Jira issue Exists in the Jira server

        Args:
            search_issue(str): Issue Id


        Raises:
            RuntimeError: Failed to retrive Jira Issues

        Returns:

            Boolean: If the issue exists or not

        """
        try:
            issues = self.look_up_issue(search_issue)
            print(issues)

            return issues != None
        except:
            return False

    def create_issue(
        self,
        Project="MP",
        summary="New issue from jira-python",
        description="Look into this one",
        issuetype={"name": "Bug"},
        components=["DevOps"],
        labels=["testLabel"],
        priority={"name": "P1"},
        assignee=None,
        fix_versions=[{"name": "RAN2.1"}],
    ):

        """

         Creates a Jira issue

        Args:

            Project(str): Project Id, default: MP

            summary(str): Issue Summary feild, default: issue from jira-python

            description(str): Issue Description feild, default: Look into this one

            issuetype(dict): Issue type default: {'name': 'Bug'}

            components(list of dicts): Issue components default:[{"name": "DevOps"}]

            labels(list): Issue associated Labels default:["testLabel"]


        Raises:
            RuntimeError: Failed to Create Jira Issue

        Returns:

            new_issue: Jira Issue object

        """

        # TODO apply input santization and validation, Implemnt _lookupComponets/Custom feilds for dynamic feild modification

        auth_jira = self._connect_jira()

        try:
            log.info("creating an issue with argunmnets")

            #TODO validation of components during run time 
            #MP-60585

            # component_dicts = [{"name": component} for component in components]

            # # Check if components exist and remove non-existent components
            # existing_components = []
            # for component_dict in component_dicts:
            #     component_name = component_dict["name"]
            #     if auth_jira.component(id=component_name) is not None:
            #         existing_components.append(component_dict)
            #     else:
            #         log.warning(f"Component '{component_name}' does not exist. Skipping...")

            new_issue = auth_jira.create_issue(
                project=Project,
                summary=summary,
                description=description,
                issuetype=issuetype,
                components=components,
                labels=labels,
                priority=priority,
                assignee=assignee,
                fixVersions=fix_versions,
            )

            return new_issue

        except Exception as e:
            log.error("Unable to create an issue: %s" % e)
            return None


    def issue_add_comment(self, issue_id=None, comment="to be updated"):

        """

         Adds a coment to a Jira issue

        Args:

            issue_id(str): issue Id

            comment(str): Issue comment to be added, default: 'to be updated'

        Raises:
            RuntimeError: Failed to Add comment to Jira Issue

        Returns:

            comment: Jira resource comment object

        """
        auth_jira = self._connect_jira()
        try:
            log.info("adding a commert to issue")
            comment = auth_jira.add_comment(issue_id, comment)
            return comment
        except Exception as e:
            log.error("Unable to add the comment to the issue: %s" % e)
            return None


    def search_failed_issue(self, test_case=None, test_labels=None):

        """

         search_issue a Jira issue assoaited with a failed automated test case(s)

        Args:

            test_case(list of strs): failed automated test case(s)

            labels(list of strs): failed automated test case(s) labels/tags

        Raises:

            RuntimeError: Failed to search the Jira Issue(s)

        Returns:

            new_issue: Jira Issue object

        """
        pass


    def close_issue(self, issue=None):

        """

         search_issue a Jira issue assoaited with a failed automated test case(s)

        Args:

            test_case(list of strs): failed automated test case(s)

            labels(list of strs): failed automated test case(s) labels/tags

        Raises:

            RuntimeError: Failed to search the Jira Issue(s)

        Returns:

            new_issue: Jira Issue object

        """
        if issue:
            auth_jira = self._connect_jira()
            auth_jira.transition_issue(issue, transition="131")
        else:
            return None


    def get_assignee(self,issue_key):
        auth_jira = self._connect_jira()

        try:
            data = auth_jira.issue(issue_key).raw['fields']['assignee']
            return data
        except Exception as e:
            log.error("faced an issue and Unable to get issue assignee")
            print(e)
            return False


    def is_bug(self,issue_key):

        auth_jira = self._connect_jira()

        try:
            return auth_jira.issue(issue_key).raw['fields']['issuetype']['name'] == 'Bug'
        except:
            log.error("faced an issue and Unable to validate issue type")

            return False

    def transition_bug_to_verify_resolution(self, issue_key):

        """

         search_issue a Jira issue assoaited with a failed automated test case(s)

        Args:

            test_case(list of strs): failed automated test case(s)

            labels(list of strs): failed automated test case(s) labels/tags

        Raises:

            RuntimeError: Failed to search the Jira Issue(s)

        Returns:

            new_issue: Jira Issue object

        """
        try:

            auth_jira = self._connect_jira()
            auth_jira.transition_issue(issue_key, transition="241") # verify resolution for a bug
            log.info("Transition to verify resolution state")
            return True
        except:
            print("Not transition, Invalid Issue key")
            log.info("Not transition, Invalid Issue key")
            return False


    def update_issue_fix_build(self,issue_key, build):
        auth_jira = self._connect_jira()
        try:
            issue = auth_jira.issue(issue_key)
            issue.update(fields={'customfield_12433': str(build)})
        except Exception as e:
            print(e)


    def issue_add_attachment(self, issue_id, full_log, filename="log.txt"):

        """

         Upload attachment to a Jira issue

        Args:

            issue_id(str): issue Id

            attachment(file): Attachment to be uploaded

            filename(str): The name will be display on Jira

        """
        auth_jira = self._connect_jira()
        try:
            log.info("Upload attachment")

            attachment = StringIO()
            attachment.write(full_log)

            auth_jira.add_attachment(issue_id, attachment=attachment, filename=filename)
        except Exception as e:
            log.error("Unable to upload attachment to the issue: %s" % e)
            return None
    
    def create_defect_ticket(self,
        jira_info,
        summary="New issue from jira-python",
        description="Look into this one",
        components=["DevOps"],
        labels=["testLabel"]
    ):
        auth_jira = self._connect_jira()

        try:
            log.info("creating an issue with argunmnets")

            new_issue = auth_jira.create_issue(
                project=jira_info["project"],
                summary=summary,
                description=description,
                issuetype=jira_info["type"],
                customfield_12451={'value': jira_info["customer_impact"]}, # Customer Impact
                customfield_10501={'value': jira_info["where_found"]}, # Where Found
                customfield_12453={'value': jira_info["likelihood"]}, # Likelihood 
                customfield_15514={'name': jira_info["fix_version"]}, # Found in Version
                customfield_12452={'value': jira_info["product_impact"]}, # Product Impact
                components=components,
                labels=labels
            )

            return new_issue

        except Exception as e:
            log.error("Unable to create an issue: %s" % e)
            return None
