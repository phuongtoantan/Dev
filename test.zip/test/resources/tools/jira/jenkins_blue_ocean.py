# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
import requests
import json
import time
import logging
import os

JIRA_USERNAME = os.environ["JIRA_USERNAME"]
JIRA_PASSWORD = os.environ["JIRA_PASSWORD"]

logging.basicConfig(level=logging.INFO, format='[%(asctime)s]   %(levelname)s: %(message)s', datefmt='%H:%M:%S')

# Some of pipelines are not in All view ...
SPECIAL_DOWNSTREAM = {
    "ngp": "gNB_ngp", #ngp => pipeline name, gNB_ngp => folder contain pipeline"
    "gnb": "gNB_ngp",
}

class JenkinsBlueOcean:
    def __init__(self, build_info, robotResultText):
        self.special_chars = ["\\", "\"", "\'"]
        self.job_name = build_info["job_name"]
        self.build_number = build_info["build_number"]
        self.jenkins_user = JIRA_USERNAME
        self.jenkins_pass = JIRA_PASSWORD
        self.branch = build_info["branch"]
        if build_info["is_multibranch"]:
            self.url_pipeline_json = 'https://osj-phm-02-prd.cec.delllabs.net/blue/rest/organizations/jenkins/pipelines/{job_name}/branches/{Pipeline_Branch}/runs/{build_number}/nodes/'.format(
                job_name=self.job_name, 
                Pipeline_Branch=self.branch, 
                build_number=self.build_number)
            self.url_full_log = 'https://osj-phm-02-prd.cec.delllabs.net/view/all/job/{job_name}/job/{Pipeline_Branch}/{build_number}/consoleText'.format(
                job_name=self.job_name, 
                Pipeline_Branch=self.branch, 
                build_number=self.build_number)
        else:
            self.url_pipeline_json = 'https://osj-phm-02-prd.cec.delllabs.net/blue/rest/organizations/jenkins/pipelines/{job_name}/runs/{build_number}/nodes/'.format(
                job_name=self.job_name,
                build_number=self.build_number)
            self.url_full_log = 'https://osj-phm-02-prd.cec.delllabs.net/view/all/job/{job_name}/{build_number}/consoleText'.format(
                job_name=self.job_name,  
                build_number=self.build_number)

        for name, folder in SPECIAL_DOWNSTREAM.items():    
            if name in self.job_name.lower() or name in self.job_name.lower():
                term_txt = f'https://osj-phm-02-prd.cec.delllabs.net/job/{folder}/job'
                self.url_downstream_job = term_txt + '/{job_name}/{build_number}/'
                self.url_full_log_downstream_job = self.url_downstream_job + 'consoleText'
                term_txt = f'https://osj-phm-02-prd.cec.delllabs.net/blue/rest/organizations/jenkins/pipelines/{folder}/pipelines'
                self.url_downstream_job_json = term_txt + '/{job_name}/runs/{build_number}/nodes/'
                self.build_info = term_txt + '/{job_name}/runs/{build_number}/'
                break
            else: 
                self.url_downstream_job = 'https://osj-phm-02-prd.cec.delllabs.net/view/all/job/{job_name}/{build_number}/'
                self.url_downstream_job_json = ' https://osj-phm-02-prd.cec.delllabs.net/blue/rest/organizations/jenkins/pipelines/{job_name}/runs/{build_number}/nodes/'
                self.build_info = ' https://osj-phm-02-prd.cec.delllabs.net/blue/rest/organizations/jenkins/pipelines/{job_name}/runs/{build_number}'
                self.url_full_log_downstream_job = 'https://osj-phm-02-prd.cec.delllabs.net/view/all/job/{job_name}/{build_number}/consoleText'
        self.list_tc_failed = {}
        if robotResultText:
            for test_case in robotResultText["test_case_stats"]:
                if test_case["status"] == "FAIL":
                    self.list_tc_failed[test_case["name"]]=test_case["message"]
            try:
                self.log_path = robotResultText["log_path"]
            except:
                self.log_path = None

        self.is_triggered_by_mainstream_job = self.is_triggered_by_mainstream_job(self.url_full_log)
        self.all_downstreams = self.get_all_downstream_jobs(self.url_full_log)
        self.downstreams = self.get_downstream_job_failed(self.url_full_log, is_first_downstream=True)

    def request(self, url, type_file):
        for times in range (3):
            try:
                if "json" in type_file.lower():
                    pipeline_info = requests.get(url, verify=False, auth = (self.jenkins_user, self.jenkins_pass)).json()
                    return pipeline_info
                if "text" in type_file.lower():
                    pipeline_info = requests.get(url, verify=False, auth = (self.jenkins_user, self.jenkins_pass)).text
                    return pipeline_info
            except:
                logging.warning('Failed to connect url {url}\n'.format(url=url))
                time.sleep(30)
        return False
    
    def get_fail_stage_log(self, url):
        pipeline_info = self.request(url, 'json')
        fail_details = ''
        old_step_name=[]
        old_downstream_name=[]

        for stage in pipeline_info:
            if stage['result'] == "FAILURE" and stage['type'] != "PARALLEL":
                url_step_json = url + stage['id'] + "/steps/"
                step_info = self.request(url_step_json, 'json')
                step_detail = ''
                log_details = ''
                is_step_name_existing = False

                if stage["displayDescription"] == None:
                    stage_name = stage["displayName"]
                else:
                    stage_name = stage["displayDescription"]

                for step in step_info:
                    if step['result'] == "FAILURE":
                        url_log = url_step_json + step["id"] + '/log'
                        step_fail = self.request(url_log, 'text')
                        # If downstream job failed => skip
                        if "Starting building:" in step_fail:
                            continue
                        # Get 15 lines log
                        lines = step_fail.splitlines()
                        if len(lines) <= 0:
                            continue
                        if len(lines) > 15:
                            lines = lines[-15:]
                        for line in lines:
                            log_details += line + "\n"
                        # Get name of step failed
                        if step['displayDescription'] == None:
                            txt = " ".join(step['displayName'].split())
                        else:
                            txt = " ".join(step['displayDescription'].split())
                        if [stage_name, txt] in old_step_name:
                            is_step_name_existing = True
                            continue
                        else:
                            old_step_name.append([stage_name, txt])
                        step_detail += '- ' + txt + "\n" + log_details
                        break
                if is_step_name_existing:
                    continue
                if step_detail != '':
                    if "Downstream" in step_detail and "failed!" in step_detail:
                        for downstream in self.all_downstreams:
                            if downstream[0] in step_detail:
                                link_build = self.url_downstream_job.format(
                                    job_name=downstream[0],
                                    build_number=downstream[1]
                                )
                                url_build_info = self.build_info.format(
                                    job_name=downstream[0],
                                    build_number=downstream[1]
                                )
                                build_info = self.request(url_build_info, "json")
                                if build_info["result"] != "FAILURE":
                                    continue
                                if not downstream in old_downstream_name:
                                    old_downstream_name.append(downstream)
                                    url_downstream = self.url_full_log_downstream_job.format(
                                        job_name=downstream[0],
                                        build_number=downstream[1]
                                    )
                                    url_downstream_json = self.url_downstream_job_json.format(
                                        job_name=downstream[0],
                                        build_number=downstream[1]
                                    )
                                    log = self.get_downstream_job_failed(url_downstream)[0]
                                    if log:
                                        fail_details += log
                                    else:
                                        fail_details += "\n" + f"Downstream failed: {link_build}\n"
                                        fail_details += self.get_fail_stage_log(url_downstream_json)
                    else:
                        fail_details += "Failed stage: {stage}\nFailed step:\n{step}\n\n".format(stage=stage_name, step=step_detail)

        return fail_details

    def get_full_log_of_stage(self):
        logging.info('Get full log of build')
        log = self.request(self.url_full_log, 'text')
        if "Error 404 Not Found" in log:
            return False
        return log
        
    def get_fail_stage_and_step_name(self, url):
        logging.info('Get failed stage name and failed step name')
        pipeline_info = self.request(url, 'json')
        fail_stage_name = []
        fail_step_name = []
        for stage in pipeline_info:
            if stage["result"] == "FAILURE" and stage['type'] != "PARALLEL":
                url_step_json = url + stage['id'] + "/steps/"
                step_info = self.request(url_step_json, 'json')
                for step in step_info:
                    if step["result"] == "FAILURE":
                        if step['displayDescription'] == None:
                            txt = " ".join(step['displayName'].split())
                        else:
                            txt = " ".join(step['displayDescription'].split())
                        fail_step_name.append(txt)
                        fail_stage_name.append(stage["displayName"])
                        break

        return fail_stage_name, fail_step_name

    def get_info_of_stage_fail_to_search_jira(self, url):
        logging.info('Get information of failed stage to search JIRA')
        stage_name_arr, step_name_arr = self.get_fail_stage_and_step_name(url)
        jql = ''
        if len(stage_name_arr) == len(step_name_arr):
            for index in range (len(stage_name_arr)):
                step_name_clear_text = step_name_arr[index]
                for char in self.special_chars:
                    step_name_clear_text = step_name_clear_text.replace(char, "\\" + char)
                jql += ' AND description ~ "\\"Failed stage: {stage_name}\\""'.format(
                # jql += ' AND description ~ "\\"{stage_name}\\"" AND description ~ "\\"{step_name}\\""'.format(
                    stage_name=stage_name_arr[index],
                    step_name=step_name_clear_text )
        return jql
    
    def detail_log_of_pipeline(self):
        logging.info('Get detail log')
        detail_log = self.get_fail_stage_log(self.url_pipeline_json)
        if "Downstream failed" not in detail_log:
            return detail_log + "\n" + self.downstreams[0]
        else:
            return detail_log

    def get_full_log_of_downstream_job(self):
        logging.info('Get full log of downstream job')
        fail_downstreams = self.downstreams[1]
        log_downstream_job_dictionary = {}
        for name, build_number in fail_downstreams.items():
            name_log_file = name + "_" + build_number
            url_downstream = self.url_full_log_downstream_job.format(
                job_name=name,
                build_number=build_number
            )
            full_log = requests.get(url_downstream, verify=False, auth = (self.jenkins_user, self.jenkins_pass)).text
            log_downstream_job_dictionary[name_log_file] = full_log

        return log_downstream_job_dictionary


    def get_info_of_failure_reasons_to_search_jira(self):
        logging.info('Get information of failure reasons to search JIRA')
        try:
            jql = ''
            fail_downstreams = self.downstreams[1]
            for name, build_number in fail_downstreams.items():
                url_downstream = self.url_downstream_job_json.format(
                    job_name=name,
                    build_number=build_number
                )
                jql += self.get_info_of_stage_fail_to_search_jira(url_downstream)
            if self.get_fail_stage_log(self.url_pipeline_json) == "":
                return jql
            return jql + self.get_info_of_stage_fail_to_search_jira(self.url_pipeline_json)
        except:
            logging.error('Can not get failure reasons to search JIRA')
            return False

    def get_info_of_test_case_failed_to_search_jira(self):
        logging.info('Get information of failed test case to search JIRA')
        jql = ''
        for name, message in self.list_tc_failed.items():
            jql += ' AND description ~ "\\"Test case: {tc_name}\n- Error: {message}\\""'.format(tc_name=name, message=message)
        return jql
    
    def get_name_of_test_case(self):
        logging.info('Get name of failed test case to search JIRA')
        if self.log_path:
            text = f"Log path in FTP server: {self.log_path}\n\n"
        else:
            text = ""

        text += 'Failed test cases: \n\n'
        for name, message in self.list_tc_failed.items():
            text += 'Test case: {name}\n- Error: {message}\n\n'.format(name=name, message=message)
        return text
    
    def is_triggered_by_mainstream_job(self, url):
        logging.info('Checking if triggered by mainstream job...')
        try:
            full_log = self.request(url, "text")
            upstream_mainstream = 'Started by upstream project "5G RAN - Mainstream" build number '

            if upstream_mainstream in full_log:
                build_number = self.extract_build_number(full_log, upstream_mainstream)
                return self.format_mainstream_job_url(build_number)
            else:
                logging.info('No parent mainstream job found')
                return ""
        except Exception as e:
            logging.warning(f'Error during check upstream job: {e}')
            return ""

    def extract_build_number(self, full_log, upstream_mainstream):
        try:
            build_number = full_log.split(upstream_mainstream)[1].split("\n")[0]
            return build_number.strip()
        except IndexError:
            logging.warning('Failed to extract build number from log')
            return ""

    def format_mainstream_job_url(self, build_number):
        if build_number:
            return f'\n\n    Parent mainstream job: https://osj-phm-02-prd.cec.delllabs.net/view/all/job/5G%20RAN%20-%20Mainstream/{build_number}/'
        else:
            logging.warning('Build number is empty')
            return ""
        
    def get_all_downstream_jobs(self, url):
        logging.info('Get all downstream jobs in pipeline: ' + url)
        full_log = self.request(url, "text")
        downstream_job = []

        lines = full_log.splitlines()
        for line in lines:
            if "Starting building" in line:
                downstream_job_name = line.split(" ")[-2]
                downstream_job_build_number = line.split(" ")[-1].replace("#", "")
                downstream_job.append([downstream_job_name,downstream_job_build_number])
        return downstream_job
       
    def get_downstream_job_failed(self, url, is_first_downstream=False):
        if not is_first_downstream:
            all_downstream_job = self.get_all_downstream_jobs(url)
        else:
            all_downstream_job = self.all_downstreams
        downstream_job_failed = {}
        fail_details = ""
        try:
            for downstream in all_downstream_job:
                url_build_info = self.build_info.format(
                    job_name=downstream[0],
                    build_number=downstream[1]
                )
                build_info = self.request(url_build_info, "json")
                if build_info["result"] == "FAILURE":
                    downstream_job_failed[downstream[0]] = downstream[1]
                    if downstream[1].isnumeric():
                        url_downstream = self.url_downstream_job.format(
                            job_name=downstream[0],
                            build_number=downstream[1]
                        )
                        url_downstream_json = self.url_downstream_job_json.format(
                            job_name=downstream[0],
                            build_number=downstream[1]
                        )
                        fail_details += "Failed downstream job: {link}\n".format(link=url_downstream)
                        fail_details += self.get_fail_stage_log(url_downstream_json) + "\n\n"
                    else:
                        fail_details += "Failed downstream job: {name_job}. Build: {number}\n\n".format(name_job=downstream[0], number=downstream[1])
            return fail_details, downstream_job_failed
        except:
            logging.error('Failed at get downstream job')
            return fail_details,  downstream_job_failed