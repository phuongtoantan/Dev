# Copyright © 2024 Dell Inc. or its subsidiaries. All Rights Reserved.

import requests
import json
import os
from operator import itemgetter
from elasticsearch import Elasticsearch
from datetime import datetime  # Import datetime module
import threading

from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable the InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Loading env data
USERNAME = os.environ["RT_USERNAME"]
PASSWORD = os.environ["RT_PASSWORD"]
ARTIFACTORY_URL = os.environ["ARTIFACTORY_URL"]
ELASTICSEARCH_HOST = os.environ["ELASTICSEARCH_HOST"]

# Max depth when processing Artifactory repo, set higher would make the script take more time to run. Recommend value: 2
MAX_DEPTH = 2
ARTIFACTORY_USAGE_INDEX = "artifactory_usage"


class Utils:
    @staticmethod
    def convert_data_size(input):
        """
        Converts a string representing data size to gigabytes (GB).

        Args:
            input (str): The input string representing data size, e.g., "2.5 GB".

        Returns:
            float: The data size in gigabytes (GB) as a floating-point number.
        """
        # Replace commas with dots
        input = input.replace(",", ".")
        # Remove non-numeric characters (including commas and dots)
        cleaned_input = "".join(filter(str.isdigit, input))

        # Divide by 100 to account for the two decimal places
        value = float(cleaned_input) / 100
        unit = input.split()[1]

        if unit == "bytes":
            converted = value / 1024 / 1024 / 1024
        elif unit == "KB":
            converted = value / 1024 / 1024
        elif unit == "MB":
            converted = value / 1024
        elif unit == "GB":
            converted = value
        elif unit == "TB":
            converted = value * 1024
        else:
            raise ValueError("Invalid unit. Supported units: KB, MB, GB, TB.")

        return round(converted, 2)  # Rounded to 2 decimal places

    @staticmethod
    def calculate_depth(path):
        """
        Calculates the depth of a directory path.

        Args:
            path (str): The directory path to calculate the depth of.

        Returns:
            int: The depth of the directory path.
        """
        try:
            elements = [element for element in path.split("/") if element]
            depth = len(elements)
            return depth
        except ValueError:
            raise ValueError("Invalid path format.")

    @staticmethod
    def standardize_path(input_path):
        """
        Standardizes a file path by removing extra slashes and normalizing it.

        Args:
            input_path (str): The input file path to standardize.

        Returns:
            str: The standardized file path.
        """
        try:
            input_path = input_path.replace("//", "/")
            input_path = os.path.normpath(input_path)
            return input_path
        except Exception as e:
            raise ValueError("Error while standardizing path: " + str(e))


# Extend the Elasticsearch client with additional functionality for data manipulation.


class MPElasticsearch(Elasticsearch):
    def __init__(self, elasticsearch_host):
        """
        Initializes an instance of MPElasticsearch, a custom Elasticsearch client.

        :param elasticsearch_host: The host of the Elasticsearch cluster to connect to.
        """
        super().__init__([elasticsearch_host])
        self.utils = Utils()

    def upload_to_elasticsearch(self, index_name, elastic_docs):
        """
        Uploads a batch of documents to a specified Elasticsearch index.

        :param index_name: The name of the Elasticsearch index to upload documents to.
        :param elastic_docs: A list of Elasticsearch documents to upload.
        """
        try:
            for doc in elastic_docs:
                self.index(index=index_name, body=doc)
            print(
                f"Uploaded documents to Elasticsearch index '{index_name}' successfully."
            )
        except Exception as e:
            raise Exception(f"Failed to upload documents to Elasticsearch: {str(e)}")

    def create_elastic_doc(self, target_repo, relative_path, artifact_size):
        """
        Creates an Elasticsearch document representing information about a data artifact.

        :param target_repo: The name of the repository containing the artifact.
        :param relative_path: The relative path of the artifact within the repository.
        :param artifact_size: The size of the artifact in bytes.

        :return: A dictionary representing the Elasticsearch document.
        """
        now = datetime.utcnow().isoformat()
        depth = self.utils.calculate_depth(relative_path)

        elastic_doc = {
            "repository_name": target_repo,
            "repository_path": target_repo + relative_path,
            "relative_path": relative_path,
            "artifact_size": artifact_size,
            "depth": depth,
            "timestamp": now,
        }
        return elastic_doc


class Artifactory:
    def __init__(self, username, password, artifactory_url):
        """
        Initializes an instance of the Artifactory class.

        :param username: The username for Artifactory authentication.
        :param password: The password for Artifactory authentication.
        :param artifactory_url: The URL of the Artifactory server.
        """
        self.username = username
        self.password = password
        self.artifactory_url = artifactory_url
        self.mpelasticsearch = MPElasticsearch(ELASTICSEARCH_HOST)
        self.max_depth = MAX_DEPTH

    def analyze_repo_size(self, target_repo, relative_path):
        """
        Analyzes the size of a specific repository or subpath within a repository in Artifactory.

        :param target_repo: The name of the target repository.
        :param relative_path: The relative path within the repository to analyze.

        :return: The size of the repository or subpath in a human-readable format or None if the analysis fails.
        """

        try:
            url = f"{self.artifactory_url}/artifactory/ui/artifactgeneral/artifactsCount?no_spinner=true"
            headers = {"Content-Type": "application/json"}
            data = {"repositoryPath": f"{target_repo}{relative_path}/"}
            auth = (self.username, self.password)

            response = requests.post(
                url, headers=headers, data=json.dumps(data), auth=auth, verify=False
            )

            if response.status_code == 200:
                data = response.json()
                artifact_size = data.get("artifactSize")
                if artifact_size:
                    converted_size = Utils.convert_data_size(artifact_size)
                    elastic_doc = self.mpelasticsearch.create_elastic_doc(
                        target_repo, relative_path, converted_size
                    )
                    self.upload_to_elasticsearch(ARTIFACTORY_USAGE_INDEX, elastic_doc)
                    return converted_size
            return None
        except Exception as e:
            print(f"Error checking repository size: {str(e)}")
            return None

    def upload_to_elasticsearch(self, index_name, elastic_doc):
        """
        Uploads an Elasticsearch document to a specified Elasticsearch index.

        :param index_name: The name of the Elasticsearch index to upload the document to.
        :param elastic_doc: The Elasticsearch document to upload.
        """
        try:
            self.mpelasticsearch.index(index=index_name, body=elastic_doc)
            print(elastic_doc)
            print(f"Uploaded document to Elasticsearch successfully.")
        except Exception as e:
            print(f"Failed to upload document to Elasticsearch: {str(e)}")

    def get_repo_structure(self, repo_name, depth=1):
        """
        Retrieves the structure of a repository by listing its subfolders and subpaths.

        :param repo_name: The name of the repository to analyze.
        :param depth: The maximum depth of subfolders to retrieve.

        :return: A list of tuples containing subfolder URIs and their corresponding relative paths.
        """

        def fetch_subfolders(url, depth, current_path=""):
            auth = (self.username, self.password)
            response = requests.get(url, auth=auth, verify=False)
            uri_and_path_array = []
            # Send request to artifactory get url and children url with format json 
            if response.status_code == 200:
                data = response.json()
                uri_array = [
                    child["uri"]
                    for child in data.get("children", [])
                    if child.get("folder")
                ]
                current_path = data["path"]
                uri_and_path_array.extend(
                    [
                        (
                            child_uri,
                            Utils.standardize_path(current_path + child_uri),
                        )
                        for child_uri in uri_array
                    ]
                )
                # Use recursion to traverse the directory tree with the end condition when depth <= 1 (depth starts with MAX_DEPTH)
                if depth > 1:
                    for child in data.get("children", []):
                        if child.get("folder"):
                            full_child_uri = Utils.standardize_path(current_path + child["uri"])
                            subfolder_url = f"{self.artifactory_url}/artifactory/api/storage/{repo_name}/{full_child_uri}"
                            uri_and_path_array.extend(
                                fetch_subfolders(subfolder_url, depth - 1, current_path)
                            )

            return uri_and_path_array

        root_url = f"{self.artifactory_url}/artifactory/api/storage/{repo_name}"
        uri_and_path_array = fetch_subfolders(root_url, depth)
        return uri_and_path_array

    def analyze_repo(self, repo_name, results):
        """
        Analyzes a specific repository, its size, and the size of its subpaths.

        :param repo_name: The name of the repository to analyze.
        :param results: A list to store the analysis results.

        :return: The total size of the analyzed repository
        """
        try:
            print(f"Analyzing mobile-phoenix repo {repo_name} ...")
            converted_size = self.analyze_repo_size(repo_name, "/")

            if converted_size:
                results.append(converted_size)

                # Getting repo tree
                uri_array = self.get_repo_structure(repo_name, self.max_depth)

                # Checking repo usage in depth via 'uri'
                for uri in uri_array:
                    uri_rel_path = uri[1]
                    self.analyze_repo_size(repo_name, uri_rel_path)

            print(f"Size for {repo_name}: {converted_size}")
            return converted_size
        except Exception as e:
            print(f"Error processing repo {repo_name}: {str(e)}")
            return 0

    def check_usage(self):
        """
        Checks and analyzes the usage of Mobile Phoenix repositories in Artifactory.

        This function retrieves a list of Mobile Phoenix repositories, analyzes their sizes and subpaths,
        calculates the total size, and publishes the total data to Elasticsearch.

        """
        try:
            total_size = 0
            threads = []
            results = []

            # Get the repository list
            url = f"{self.artifactory_url}/artifactory/api/repositories?type=local"
            auth = (self.username, self.password)

            response = requests.get(url, auth=auth, verify=False)

            # get the repo list for federated repos
            url = f"{self.artifactory_url}/artifactory/api/repositories?type=federated"

            response_fed = requests.get(url, auth=auth, verify=False)

            if response.status_code == 200:
                data = response.json()
                mp_repos = [
                    repo["key"] for repo in data if "mobile-phoenix" in repo["key"]
                ]
                if response_fed.status_code == 200:
                    data_fed = response_fed.json()
                    mp_repos += [
                        repo["key"] for repo in data_fed if "mobile-phoenix" in repo["key"]
                    ]

                print("Start analyzing data...")
                # Analyzing using multi-threading
                for repo in mp_repos:
                    print(f"Working on {repo}")
                    thread = threading.Thread(
                        target=self.analyze_repo, args=(repo, results)
                    )
                    threads.append(thread)
                    thread.start()

                for thread in threads:
                    thread.join()

                # Summarize the total size of mobile-phoenix* repositories
                total_size = sum(results)
                print("Total size for all repositories: ", total_size)

                # Publish the total data to Elastic
                total_repo_name = "total-mobile-phoenix"
                total_size_doc = self.mpelasticsearch.create_elastic_doc(
                    total_repo_name, "/", total_size
                )
                self.upload_to_elasticsearch(ARTIFACTORY_USAGE_INDEX, total_size_doc)

        except Exception as e:
            print(f"Error during analysis: {str(e)}")


def main():
    artifactory = Artifactory(USERNAME, PASSWORD, ARTIFACTORY_URL)
    print("Start checking repository usage...")
    artifactory.check_usage()


if __name__ == "__main__":
    main()
