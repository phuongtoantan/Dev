# Artifactory usage monitoring

## Build artifactory tool

```
git clone -b main git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git mp-jenkins-shared-lib
cd mp-jenkins-shared-lib/resources/tools/monitoring/artifactory
buildah build --layers -t artifactory_monitoring_tool -f artifactory_monitoring_tool.dockerfile .
```

## Start the script in container

```
podman run --network host --privileged --rm \
-e "RT_USERNAME=${your_artifactory_user}" \
-e "RT_PASSWORD=${your_artifactory_password}" \
-e "ARTIFACTORY_URL=https://phm.artifactory.cec.lab.emc.com" \
-e "ELASTICSEARCH_HOST=mp-elk-00-p-dur.cec.lab.emc.com" \
artifactory_monitoring_tool
```
