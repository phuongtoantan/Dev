import requests
import json
import os
from operator import itemgetter
from elasticsearch import Elasticsearch
from datetime import datetime  # Import datetime module
import threading
import argparse


from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable the InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Loading env data
ELASTICSEARCH_HOST = os.environ["ELASTICSEARCH_HOST"]
JENKINS_OVERALL_USAGE_INDEX = "jenkins_overall_usage"
JENKINS_JOB_USAGE_INDEX = "jenkins_job_usage"

# Create an argument parser
parser = argparse.ArgumentParser(
    description="Process files for overall status and Jenkins job usage"
)

# Define command-line arguments
parser.add_argument(
    "-overall_status",
    "--overall-status",
    help="Specify the file for overall status",
    required=True,
)

parser.add_argument(
    "-job_usage",
    "--job-usage",
    help="Specify the file for Jenkins job usage",
    required=True,
)

# Parse the arguments
args = parser.parse_args()

# Assign arguments to variables
overall_status_file = args.overall_status
jenkins_job_usage_file = args.job_usage


class Utils:
    @staticmethod
    def convert_data_size(input):
        """
        Converts a string representing data size to gigabytes (GB).

        Args:
            input (str): The input string representing data size, e.g., "2.5 GB".

        Returns:
            float: The data size in gigabytes (GB) as a floating-point number.
        """
        # Replace commas with dots
        input = input.replace(",", ".")
        value = float(input[:-1])
        unit = input[
            -1
        ]  # Get the last character to determine the unit (K, M, G, T, etc.)

        if unit == "B":
            converted = value / 1024 / 1024 / 1024
        elif unit == "K":
            converted = value / 1024 / 1024
        elif unit == "M":
            converted = value / 1024
        elif unit == "G":
            converted = value
        elif unit == "T":
            converted = value * 1024
        else:
            raise ValueError("Invalid unit. Supported units: K, M, G, T.")

        return round(converted, 2)  # Rounded to 2 decimal places

    @staticmethod
    def read_text_file_to_array(file):
        overall_status_result = []
        try:
            with open(file, "r") as log_file:
                overall_status_result = log_file.readlines()
        except FileNotFoundError:
            print(f"Error: File '{file}' not found.")
        except IOError as err:
            print(f"Error when reading file: {err}")
        except Exception as err:
            print("Error when parsing greenlight log")
            print(err)

        return overall_status_result


# Extend the Elasticsearch client with additional functionality for data manipulation.
class MPElasticsearch(Elasticsearch):
    def __init__(self, elasticsearch_host):
        """
        Initializes an instance of MPElasticsearch, a custom Elasticsearch client.

        :param elasticsearch_host: The host of the Elasticsearch cluster to connect to.
        """
        super().__init__([elasticsearch_host])
        self.utils = Utils()

    def upload_to_elasticsearch(self, index_name, elastic_doc):
        """
        Uploads a batch of documents to a specified Elasticsearch index.
        """
        try:
            self.index(index=index_name, body=elastic_doc)
            print(
                f"Body '{elastic_doc}'",
                f"Uploaded documents to Elasticsearch index '{index_name}' successfully.",
            )
        except Exception as e:
            raise Exception(f"Failed to upload documents to Elasticsearch: {str(e)}")


class JenkinsMonitoring:
    def __init__(self, overall_status_file, jenkins_job_usage_file):
        """
        Initializes an instance of the Jenkins monitoring
        """
        self.mpelasticsearch = MPElasticsearch(ELASTICSEARCH_HOST)
        self.overall_status_file = overall_status_file
        self.jenkins_job_usage_file = jenkins_job_usage_file
        self.jenkins_overall_usage_index = JENKINS_OVERALL_USAGE_INDEX
        self.jenkins_job_usage_index = JENKINS_JOB_USAGE_INDEX

    def parse_overall_data(self, overall_status_file):
        """
        Sample data:
        Filesystem                           Size  Used Avail Use% Mounted on
        devtmpfs                              24G     0   24G   0% /dev
        tmpfs                                 24G   36K   24G   1% /dev/shm
        tmpfs                                 24G  138M   24G   1% /run
        tmpfs                                 24G     0   24G   0% /sys/fs/cgroup
        /dev/mapper/centos-root               48G   31G   17G  66% /
        /dev/sda1                            497M  201M  297M  41% /boot
        storagedev.gtie.dell.com:/bldaas-rr   13T  5.5T  7.6T  43% /var/backups
        /dev/mapper/jenkins_vg-jenkins_lv    2.0T  1.1T  940G  55% /var/lib/jenkins
        tmpfs                                4.8G     0  4.8G   0% /run/user/495
        """

        print("Parsing overall usage...")
        overall_status = Utils.read_text_file_to_array(overall_status_file)
        parsed_data = []
        for line in overall_status[1:]:
            elements = line.split()
            filesystem = elements[0]
            size = elements[1]
            used = elements[2]
            avail = elements[3]
            percentage = int(elements[4][:-1])  # Extract integer part without '%'
            mounted_on = " ".join(elements[5:])
            converted_size = Utils.convert_data_size(size)
            now = datetime.utcnow().isoformat()

            parsed_data.append(
                {
                    "type": "overall",
                    "path": mounted_on,
                    "percentage": percentage,
                    "filesystem": filesystem,
                    "size": converted_size,
                    "used": used,
                    "avail": avail,
                    "timestamp": now,
                }
            )
        return parsed_data

    def parse_job_usage_data(self, jenkins_job_usage_file):
        """
        Sample data:
        1.1T	.
        64G	./OAM_Nightly_Regression
        56G	./stop_and_fix_checker
        46G	./RUN-CU-TEST
        44G	./nearRT-RIC
        43G	./DU-Integration-Test
        41G	./gNB_ngp
        35G	./OAM-mainstream-Test
        ...
        """
        print("Parsing job usage...")
        job_usage_data = Utils.read_text_file_to_array(jenkins_job_usage_file)
        result_list = []
        for line in job_usage_data:
            if line.strip():  # Making sure the line isn't empty
                size, job_name = line.split(
                    "\t"
                )  # Splitting the line by tab (\t) into size and path
                job_name = job_name.replace("./", "")  # Removing './' from the path
                job_name = job_name.replace("\n", "")  # Removing '\n' from the path

                now = datetime.utcnow().isoformat()
                converted_size = Utils.convert_data_size(size)
                jenkins_job_data = {
                    "type": "jenkins_job",
                    "size": converted_size,
                    "job_name": job_name,
                    "timestamp": now,
                }

                result_list.append(jenkins_job_data)
        return result_list

    def process_overall_usage_data(self):
        # Parse input overall data text
        overall_status_result = self.parse_overall_data(self.overall_status_file)

        for overall_status in overall_status_result:
            # Upload to ES
            self.mpelasticsearch.upload_to_elasticsearch(
                self.jenkins_overall_usage_index, overall_status
            )

    def process_jenkins_job_usage_data(self):
        # Parse input overall data text
        jenkins_usage_result = self.parse_job_usage_data(self.jenkins_job_usage_file)
        for jenkins_job_usage in jenkins_usage_result:
            # Upload to ES
            self.mpelasticsearch.upload_to_elasticsearch(
                self.jenkins_job_usage_index, jenkins_job_usage
            )


def main():
    MPJenkinsMonitoring = JenkinsMonitoring(overall_status_file, jenkins_job_usage_file)

    # Process overall status
    MPJenkinsMonitoring.process_overall_usage_data()

    # Process job usage status
    MPJenkinsMonitoring.process_jenkins_job_usage_data()


if __name__ == "__main__":
    main()
