import argparse
import requests

"""
This script will update the AutomationContent field in all test cases executed 
by the specified test suite.
The AutomationContent will be updated to include ONLY the test case name.
So, if the Automation Content was set to:
Robotframework.Test-Suite.ASSERT.Assert Suite#Trigger To Send Invalid Meas Gap

The script will set it to:
Trigger To Send Invalid Meas Gap
"""
class AutomationContentUpdater():

    qtest_url = "https://qtest.gtie.dell.com/api/v3/projects/138/"

    def update_test_case_automation_content(self, auth_token, test_case_id):

        headers = {'Authorization': 'Bearer {}'.format(auth_token),
                   'Content-Type' : 'application/json'}

        response = requests.get(f'{self.qtest_url}test-cases/{test_case_id}', headers=headers)
        if response.status_code == 200:
            response_json = response.json()
            properties = response_json['properties']
            for property in properties:
                if property['field_name'] == "Automation Content":
                    automation_content = property['field_value']
                    if '#' in automation_content:
                        parts = automation_content.split("#")
                        if len(parts) > 0:
                            testcase_name = parts[1]
                            property['field_value'] = testcase_name
                            params = {}
                            params['properties'] = [property]

                            response = requests.put(f'{self.qtest_url}test-cases/{test_case_id}', json=params, headers=headers)
                            if response.status_code == 200:
                                print(f"Could not update test case with id {test_case_id}")

        else:
            print(f'Failed to update test case {test_case_id}')

    def get_test_case_ids(self, auth_token, test_suite):

        headers = {'Authorization': 'Bearer {}'.format(auth_token),
                   'Content-Type' : 'application/json'}
        response = requests.get(f'{self.qtest_url}test-runs?parentId={test_suite}&parentType=test-suite', headers=headers)

        test_case_ids = []
        if response.status_code == 200:
            response_json = response.json()

            total = response_json['total']
            page_size = response_json['page_size']
            total_pages = ( total // page_size ) + 2

            for page in range(total_pages):
                response = requests.get(f'{self.qtest_url}test-runs?parentId={test_suite}&parentType=test-suite&page={page}',
                                        headers=headers)
                if response.status_code == 200:
                    response_json = response.json()
                    if 'items' in response_json.keys():
                        for item in response_json['items']:
                            if 'test_case' in item.keys():
                                if 'id' in item['test_case'].keys():
                                    test_case_ids.append(item['test_case']['id'])

        return test_case_ids

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--auth-token",
                        type=str,
                        required=True,
                        help="Auth token for accessing QTest")
    parser.add_argument("--test-suite",
                        type=str,
                        required=True,
                        help="Parent test-cycle. The newly created test-cycle will be a child of this test-cycle.")
    args = parser.parse_args()

    updater = AutomationContentUpdater()
    test_case_ids = updater.get_test_case_ids(auth_token=args.auth_token,
                                              test_suite=args.test_suite)
    for test_case_id in test_case_ids:
        updater.update_test_case_automation_content(auth_token=args.auth_token,
                                                    test_case_id=test_case_id)

