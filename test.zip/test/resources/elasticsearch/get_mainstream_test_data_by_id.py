import es_interface
import argparse
import json

parser = argparse.ArgumentParser()

parser.add_argument(
    "-output_json",
    "--output-json",
    help="Specify the target output json path",
    required=True,
)
parser.add_argument(
    "-component_test_id",
    "--component-test-id",
    help="Specify the component",
    required=True,
)
parser.add_argument(
    "-index_name",
    "--index-name",
    help="Specify the Index name",
    required=True,
)

# Parse input arguments
args = parser.parse_args()
OUTPUT_JSON = args.output_json
COMPONENT_TEST_ID = args.component_test_id
INDEX_NAME = args.index_name

def main():
    ESInterface = es_interface.ESInterface()
    component_test_dict = ESInterface.get_mainstream_test_data_by_id(INDEX_NAME, COMPONENT_TEST_ID, True)
    # Saving result to json file
    with open(OUTPUT_JSON, 'w') as json_file:
        json_file.write(json.dumps(component_test_dict))

if __name__ == "__main__":
    main()
