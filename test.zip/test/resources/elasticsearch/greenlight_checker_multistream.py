# Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
import json
import es_query
import argparse

parser = argparse.ArgumentParser()
parser.add_argument(
    "--greenLight_CU",
    help="Check passrate for CU",
    required=False,
)
parser.add_argument(
    "--greenLight_DU",
    help="Check passrate for DU",
    required=False,
)
parser.add_argument(
    "--greenLight_MPLANE",
    help="Check passrate for MPLANE",
    required=False,
)
parser.add_argument(
    "--greenLight_TRANSPORT",
    help="Check passrate for TRANSPORT",
    required=False,
)
parser.add_argument(
    "--greenLight_L1",
    help="Check passrate for L1",
    required=False,
)
parser.add_argument(
    "--greenLight_RADIO",
    help="Check passrate for RADIO",
    required=False,
)
parser.add_argument(
    "--greenLight_OAM",
    help="Check passrate for OAM",
    required=False,
)
parser.add_argument(
    "--greenLight_NGP",
    help="Check passrate for NGP",
    required=False,
)
parser.add_argument(
    "--required_pass_rate_component_for_CT",
    help="Required passrate for other component for Component Test",
    required=True,
)
parser.add_argument(
    "--required_pass_rate_component_for_UT",
    help="Required passrate for other component for Unit Test",
    required=True,
)

parser.add_argument(
    "--mainstream_test_build_number",
    help="Mainstream build number",
    required=True,
)

parser.add_argument(
    "--greenLight_AIO",
    help="Check passrate for AIO",
    required=False,
)

parser.add_argument(
    "--required_pass_rate_AIO",
    help="Required passrate for AIO",
    required=True,
)

parser.add_argument(
    "--greenLight_E2E",
    help="Check passrate for E2E",
    required=False,
)

parser.add_argument(
    "--required_pass_rate_E2E",
    help="Required passrate for E2E",
    required=True,
)

parser.add_argument(
    "--skipGreenlightCheckForAIOTestCase",
    help="AIO's list Test cases will be skipped check result",
    required=False,
)

parser.add_argument(
    "--skipGreenlightCheckForE2ETestCase",
    help="E2E's list Test cases will be skipped check result",
    required=False,
)

parser.add_argument(
    "--workspace",
    help="Jenkins workspace",
    required=True,
)

parser.add_argument(
    "--streamTestIndex",
    help="Stream test index",
    required=True,
)
args = parser.parse_args()

list_greenlight = []
if args.greenLight_CU:
    list_greenlight.append("CU")
if args.greenLight_DU:
    list_greenlight.append("DU")
if args.greenLight_L1:
    list_greenlight.append("L1")
if args.greenLight_MPLANE:
    list_greenlight.append("MPLANE")
if args.greenLight_TRANSPORT:
    list_greenlight.append("TRANSPORT")
if args.greenLight_RADIO:
    list_greenlight.append("RADIO")
if args.greenLight_OAM:
    list_greenlight.append("OAM")
if args.greenLight_NGP:
    list_greenlight.append("NGP")
if args.greenLight_AIO:
    list_greenlight.append("AIO")
if args.greenLight_E2E:
    list_greenlight.append("E2E")

ESQuery = es_query.ESQuery()

# =============================== FUNCTION ===============================
def check_condition(dict_result, list_greenlight):
    checker_result = "GREEN"
    component_checker_result = "GREEN"
    red_component_found = False

    for item in list_greenlight:
        if not any(item in key for key in dict_result.keys()):
            print("{:<25} {:>20}: {:^20}  => not satisfied ".format(item, "", "NOT-READY"))
    for component, component_info in dict_result.items():
        if component == "AIO":
            required_pass_rate = args.required_pass_rate_AIO
        elif component == "E2E":
            required_pass_rate = args.required_pass_rate_E2E
        elif "Unit-Test" in component:
            required_pass_rate = args.required_pass_rate_component_for_UT
        elif "Component-Test" in component:
            required_pass_rate = args.required_pass_rate_component_for_CT
        else:
            required_pass_rate = 100

        if not isinstance(component_info['passrate'], str):
            if component_info['passrate'] < float(required_pass_rate):
                print("{:<25} {:>20}: {:^20}% => not satisfied ".format(component, component_info['detail'], component_info['passrate']))
                checker_result = "RED"
                red_component_found = True
            else:
                if component_info['passrate'] < 100.0:
                    component_checker_result = "YELLOW"
                print("{:<25} {:>20}: {:^20}% => satisfied ".format(component, component_info['detail'], component_info['passrate']))
        else:
            print("{:<25} {:>20}: {:^20}  => not satisfied ".format(component, "", component_info['passrate']))
            checker_result = "RED"
            red_component_found = True

    # if missing AIO result or E2E result or both of them => greenlight checker will be RED
    if "AIO" not in dict_result.keys() and "AIO" in list_greenlight:
        checker_result = "RED"
        red_component_found = True
    if "E2E" not in dict_result.keys() and "E2E" in list_greenlight:
        checker_result = "RED"
        red_component_found = True

    if (not red_component_found and component_checker_result == "YELLOW"):
        checker_result = "YELLOW"

    return checker_result

def percent_passrate(component, component_name, component_id, component_test_type=None, is_tl=False, list_test_case=[]):
    if is_tl:
        component_name = component_name.lower()
        data = ESQuery.get_test_line_data(component_name, component_id)
    else:
        component_name = component_name.lower().replace('-', "_")
        data = ESQuery.get_component_test_data(component_name, component_id)

    total_tc_pass = 0
    total_tc = 0

    if is_tl:
        total_tc = data["totaltests"] - len(list_test_case)
        if list_test_case:
            with open(f"{args.workspace}/{component}/robot-result.json", 'r') as f:
                data = json.load(f)
            for test_case in data['test_case_stats']:
                if test_case['name'] not in list_test_case and test_case['status'] == "PASS":
                    total_tc_pass += 1
        else:
            if "totaltests" in data.keys():
                total_tc_pass = data["testpass"]
    else:
        if data:
            for test_type in data['testResults']:
                if test_type['testType'] == component_test_type:
                    if 'total' in test_type:
                        total_tc += int(test_type['total'])
                        total_tc_pass += int(test_type['pass'])
                    else:
                        return {"passrate": test_type["testStatus"], 
                                "detail": "NO-DATA"}
        else:
            return {"passrate": "NO-DATA", 
                    "detail": "NO-DATA"}

    if total_tc_pass:
        percent_passrate = (total_tc_pass/total_tc)*100
        return {"passrate": round(percent_passrate, 2), 
                "detail": f"({total_tc_pass}/{total_tc})"}
    
    else:
        return {"passrate": 0, 
                "detail": f"({total_tc_pass}/{total_tc})"}

# ========================================================================

# =============================== MAIN ===================================

try:
    latest_mainstream_test = ESQuery.get_mainstream_test_data(args.mainstream_test_build_number, args.streamTestIndex)

    checker_result = "GREEN"
    component_checker_result = "GREEN"
    red_component_found = False
    dict_result = {}

    print(f"Components are applied passrate check: {str(list_greenlight)}\n")
    green_build_criteria_info  = ""
    for item in list_greenlight:
        if item == "AIO":
            green_build_criteria_info  += f"AIO's pipeline is required to be passed: {args.required_pass_rate_AIO}%\n"
            if args.skipGreenlightCheckForAIOTestCase:
                green_build_criteria_info  += f"List test cases (AIO) do not need to check the result: {args.skipGreenlightCheckForAIOTestCase}\n\n"
        if item == "E2E":
            green_build_criteria_info  += f"E2E's pipeline is required to  be passed: {args.required_pass_rate_E2E}%\n"
            if args.skipGreenlightCheckForE2ETestCase:
                green_build_criteria_info  += f"List test cases (E2E) do not need to check the result: {args.skipGreenlightCheckForE2ETestCase}\n\n"
    
    green_build_criteria_info += f"Other components are required passrate for CT: {args.required_pass_rate_component_for_CT}% and UT: {args.required_pass_rate_component_for_UT}%\n"
    print(green_build_criteria_info)

    if latest_mainstream_test:
        for component_test in latest_mainstream_test['testStages']:
            if component_test['component'] == "E2E" or component_test['component'] == "AIO":
                if component_test['component'] in list_greenlight:
                    list_test_case = []
                    if component_test['component'] == "AIO" and args.skipGreenlightCheckForAIOTestCase:
                        list_test_case = args.skipGreenlightCheckForAIOTestCase.split(",")
                    if component_test['component'] == "E2E" and args.skipGreenlightCheckForE2ETestCase:
                        list_test_case = args.skipGreenlightCheckForE2ETestCase.split(",")
                    dict_result[component_test['component']] = percent_passrate(component_test['component'], component_test['componentName'], component_test['id'], is_tl=True, list_test_case=list_test_case)
            else:
                if component_test['component'] in list_greenlight:
                    component_name = component_test['componentName'].lower().replace('-', "_")
                    test_data = ESQuery.get_component_test_data(component_name, component_test['id'])
                    list_type_component_test = [item['testType'] for item in test_data['testResults']]
                    for type_component_test in list_type_component_test:
                        dict_result[f"{component_test['component']} {type_component_test}"] = percent_passrate(component_test['component'], component_test['componentName'], component_test['id'], type_component_test)

        print()

        checker_result = check_condition(dict_result, list_greenlight)
            
    else:
        checker_result = "RED"
        
except Exception as err:
    print(err)
    checker_result = "RED"

with open("result_greenlight.txt", "w") as f:
    f.write(checker_result)