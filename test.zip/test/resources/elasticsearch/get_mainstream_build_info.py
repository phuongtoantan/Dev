# Copyright (c) 2023-2024 Dell Inc. or its subsidiaries. All rights reserved.

import sys
sys.path.append("../../elasticsearch")
import argparse
import json
import es_interface

class MainstreamBuildInfo():
    def __init__(self, args):
        self.output_file = args.output_file
        self.build_id = args.build_id
        self.ESInterface = es_interface.ESInterface()
        if not args.elk_id:
            self.elk_build_index = 'mainstream_build'
        else:
            self.elk_build_index = args.elk_id

    def get_list_component_build_success(self):
        build_pass = []
        components_list = ["NGP", "CU", "DU", "L1", "MPLANE", "RADIO", "OAM", "TRANSPORT", "UESIM", "NODED", "ACM"]
        if self.build_id is not None:
            mainstream_build_df = self.ESInterface.get_mainstream_data_by_id(self.elk_build_index, self.build_id)
            if mainstream_build_df is not None:
                build_stages = mainstream_build_df.iloc[0]['buildStages']
                # Loop through each component
                for component in components_list:
                    try:
                        have_data = next((build_stage for build_stage in build_stages if build_stage["component"] == component), None)
                    except StopIteration:
                        have_data = None
                    # If component has no build data, get its latest build data
                    if not have_data:
                        # Now enabling concurment mainstream run so the step useing to get latest data from elk is not necessary
                        # Contruct data as NOT-READY if there is no data on ELK for special cases
                        # TBD consider another way to determine which component is NO-DATA or NOT-READY instead depending data on ELK
                        print("Missing component: " + component)
                        if component in ('L1', 'RADIO'):
                            component_name = f"{component}-mainstream-Build"
                            latest_mainstream_build_data = f'{{"component": "{component}", "componentName": "{component_name}", "description": null, "overallStatus": "NOT-READY", "url": null, "id": null}}'
                            latest_mainstream_build_data = json.loads(latest_mainstream_build_data)
                            build_stages.append(latest_mainstream_build_data)
                
                # The list of failure built Components
                build_not_success = [component["component"] for component in build_stages
                                     if component and component.get("overallStatus") != "SUCCESS"]
                print("Unsuccessful components: " + str(list(set(build_not_success))))
                # All Components whose status is Success or Skip build will be counted as build passes
                build_pass = list(set(components_list) - set(build_not_success))
        if build_pass:
            with open(self.output_file, 'w') as file:
                file.write(",".join(build_pass))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--build_id",
                        required=True,
                        help="Provide Build number")
    parser.add_argument("--elk_id",
                        default="",
                        help="Provide ELK ID")
    parser.add_argument("--output_file",
                        required=True,
                        help="Provide output file path")
    parser.add_argument("--list_success",
                        action="store_true",
                        help="Get list component build success")
    args = parser.parse_args()
    mainstream_build_info = MainstreamBuildInfo(args)
    if args.list_success:
        mainstream_build_info.get_list_component_build_success()