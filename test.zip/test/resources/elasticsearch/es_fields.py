class FieldDefinitions:
    DEFAULT_TEST_LINES_DEFINITION = {
        # Define TLs target here.
        # Format:
        # "tl_name": {
        #     "dataframe": None,
        #     "show_test_result": True/False, --> (Optional) If enabled, the script will add test result to testing part.
        #     "impact_overall_status": True/False, --> (Optional) If enabled, the rest result of TL will impact to overall status
        # }
        "tl57_nightly_e2e_ota": {
            "dataframe": None,
            "show_test_result": True,
            "impact_overall_status": True,
        },
        "aio-tl24": {
            "dataframe": None,
            "show_test_result": True,
            "impact_overall_status": True,
        },
        # E2E TLs
        "tl-8_nightly_e2e_keysight": {
            "dataframe": None,
        },
        "tl-10_nightly_e2e_ota": {
            "dataframe": None,
            "show_test_result": False,
        },
        "tl25_nightly_e2e_conducted": {
            "dataframe": None,
        },
        "tl51_nightly_e2e_simnovus": {
            "dataframe": None,
        },
        "tl-26_nightly_ota_conducted": {
            "dataframe": None,
        },
        # AIO TLs
        "aio-tl15": {
            "dataframe": None,
        },
        "aio-tl16": {
            "dataframe": None,
        },
        "aio-tl18": {
            "dataframe": None,
        },
        "aio-tl19": {
            "dataframe": None,
        },
        "aio-tl20": {
            "dataframe": None,
        },
        "aio-tl21": {
            "dataframe": None,
        },
        "aio-tl22": {
            "dataframe": None,
        },
        "aio-tl17": {
            "dataframe": None,
        },
        "aio-tl23": {
            "dataframe": None,
        },
        "aio-tl32": {
            "dataframe": None,
        },
        "aio-tl33": {
            "dataframe": None,
        },
        "aio-tl34": {
            "dataframe": None,
        },
        "tl59-nightly": {
            "dataframe": None,
        },
        "tl27_nightly_e2e_ota": {
            "dataframe": None,
        },
        "tl51_nightly_e2e_simnovus": {
            "dataframe": None,
        },
        "tl28_nightly_e2e_ota": {
            "dataframe": None,
        },
    }

    # Target deployment fields for TL pipeline
    DEPLOY_FIELDS = [
        "testLine",
        "deploymentStatus",
        "testLineType",
        "buildVariantCU",
        "buildVariantDU",
        "latestVerCU",
        "latestVerDU",
        "latestVerMPLANE",
        "latestVerL1FW",
        "latestVerL1DRV",
        "date_created",
    ]

    # Target test fields for TL pipeline
    TEST_FIELDS = [
        "testLine",
        "latestVerCU",
        "latestVerDU",
        "latestVerMPLANE",
        "latestVerL1FW",
        "latestVerL1DRV",
        "Test status",
        "url",
        "totaltests",
        "testpass",
        "testfail",
        "date_created",
        "jiraaIssueRef",
        "jiraaIssueRefUrl",
    ]
