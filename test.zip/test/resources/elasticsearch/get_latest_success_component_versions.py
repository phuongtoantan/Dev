# Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.

import es_interface
import argparse
import json

parser = argparse.ArgumentParser()

parser.add_argument(
    "-output_json",
    "--output-json",
    help="Specify the target output json path",
    required=True,
)
parser.add_argument(
    "-index_name",
    "--index-name",
    help="Specify the Index name",
    required=True,
)

parser.add_argument(
    "-components",
    "--components",
    help="Specify the Component names",
    required=True,
)

# Parse input arguments
args = parser.parse_args()
OUTPUT_JSON = args.output_json
INDEX_NAME = args.index_name
COMPONENTS = args.components

def main():
    ESInterface = es_interface.ESInterface()
    latest_es_component_data = ESInterface.get_latest_success_component_versions(INDEX_NAME, COMPONENTS)
    # Saving result to json file
    with open(OUTPUT_JSON, 'w') as json_file:
        json_file.write(json.dumps(latest_es_component_data))

if __name__ == "__main__":
    main()
