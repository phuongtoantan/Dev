# from datetime import datetime


from elasticsearch import Elasticsearch
import logging as log
import argparse
import json
import sys
import os
import datetime

"""
Jira_call version 1.0.0
Author: Abdullah Alzaydi
Parameters:

-Report,--Robot_Report: Require Robot Report File In Json Format
-Pipeline,--Pipeline_Job: Specify Pipline as will act as the main label that the issue will be indexed by,
-Branch,--Pipeline_Branch: Specify Pipline branch or default to Main,
-h (--help): display this help
"""

parser = argparse.ArgumentParser()

parser.add_argument(
    "-doc",
    "--Document",
    help="Require ES document File In Json Format",
    required=True,
)
parser.add_argument(
    "-type",
    "--Type",
    help="doc type",
    default="tags",
    required=True,
)
parser.add_argument(
    "-tag",
    "--Tag",
    help="doc type",
    default="tags",
    required=True,
)
parser.add_argument(
    "-index",
    "--Index",
    help="index es",
    required=True,
)

args = parser.parse_args()

print("those are the args")
print(args)
log.info(args)

with open(args.Document) as write_file:
    data = json.load(write_file)

# create_or_update(args.Index,args.Tag,args.Type,data)

es = Elasticsearch(
    ['mp-elk-00-p-dur.cec.lab.emc.com'],
    port=9200,
    verify_certs=False,
)

data["date_created"] = datetime.datetime.now()
#converte doc from json to dict

if es.exists(index=args.Index, id=args.Tag,doc_type =args.Type):
    try:
        print("update")
        log.info("update")
        #make sure body is a proper dict and is FLAT(we can apply faltting policy) to avoid reverse indexing/aggregation issue as the mapping is not set 
        if type(data) is dict:
            print("dict ")
            log.info("dict")
            dic = {"doc":data}
            res = es.update(index=args.Index, doc_type=args.Type, id=args.Tag, body=dic)
        else:
            pass
                #throw an exception 
    except Exception as e:
        print(e)
else:
    try:
        res = es.index(

            index = args.Index,

            doc_type=args.Type,

            id=args.Tag,

            body = data,

            request_timeout=45

            )
        print(res['result'])
    except:
        print(f" Failed creating {args.Index} index with {data}")










