import sys
import json
import requests
from elasticsearch import Elasticsearch
from datetime import datetime
import math
import time
import urllib3
from threading import Thread
import os

urllib3.disable_warnings()
es = Elasticsearch(
    ['mp-elk-00-p-dur.cec.lab.emc.com'],
    port=9200,
    verify_certs=False,
)

jenkins_user = 'leonn_paiva'
# jenkins_pass = '1141ec14bfadf6fe13185be3212c785f07'
jenkins_pass = '11edd0ffc05fb4417615c2b66ffef1423d'

def es_index(index, data):
    id = data.get('fullName', None)
    if id is None:
        id = data.get('fullDisplayName', None)
    try:
        if es.exists(index=index, id=id):
            es.update(index=index, id=id, body={'doc': data}, doc_type='_doc')
        else:
            es.index(index=index, body=data, id=id, doc_type='_doc')
    except Exception as e:
        print(e)
        print(data)

def process_files(job, directory, base_url):
    job['directory_name']= directory
    url=base_url + '/' + directory +'/index.html'
    job_data = requests.get(url, verify=False, auth=(jenkins_user,jenkins_pass))
    dir_data = open('lcov_data/'+ directory.replace('/','-') + str(job['build']) +job['application'] + ".html", "w")
    if (job_data.status_code != 200 ):
        return
    dir_data.write(job_data.text)
    dir_data.close()
   
    os.system("python3 parse-lcov.py -i lcov_data/"+ directory.replace('/','-') + str(job['build']) +job['application'] + ".html -o lcov_data/"+   directory.replace('/','-') + str(job['build']) + job['application'] +".json -j "+ job['url'] +"  --a " +  job['application'] + ' -f true')    
    os.remove('lcov_data/'+ directory.replace('/','-') + str(job['build']) +job['application'] + ".html")
    
    jsonFile= open('lcov_data/'+ directory.replace('/','-') + str(job['build']) + job['application'] + ".json",'r')
    files = json.load(jsonFile)
    jsonFile.close()
    os.remove('lcov_data/'+ directory.replace('/','-') + str(job['build']) + job['application'] + ".json")
    files = files['files']
    for f in files:
        job['file_name']= f['name']
        job['lines_hit']= f['lines_hit']
        job['lines_total']= f['lines_total']
        job['lines_coverage_percentage']= f['lines_coverage_percentage']
        job['functions_hit']= f['functions_hit']
        job['functions_total']= f['functions_total']
        job['functions_coverage_percentage']= f['functions_coverage_percentage']
        job['coverage_level'] = 'file'
        jsonFile = open('lcov_data/'+ directory.replace('/','-') + str(job['build']) + job['application'] + f['name'] + ".json", "w")
        jsonFile.write(json.dumps(job))
        jsonFile.close()
        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+ directory.replace('/','-') + str(job['build']) + job['application'] + f['name'] + ".json > /dev/null")
        os.remove('lcov_data/'+ directory.replace('/','-') + str(job['build']) + job['application'] + f['name'] + ".json")

def process_directories(job, directories, base_url, should_process_files=True):
    for directory in directories:
        job['directory_name']= directory['name']
        job['lines_hit']= directory['lines_hit']
        job['lines_total']= directory['lines_total']
        job['lines_coverage_percentage']= directory['lines_coverage_percentage']
        job['functions_hit']= directory['functions_hit']
        job['functions_total']= directory['functions_total']
        job['functions_coverage_percentage']= directory['functions_coverage_percentage']
        job['coverage_level'] = 'directory'
        jsonFile = open('lcov_data/' + str(job['build']) + directory['name'].replace('/','-') +".json", "w")
        jsonFile.write(json.dumps(job))
        jsonFile.close()

        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['build']) + directory['name'].replace('/','-') +".json > /dev/null")
        
        os.remove('lcov_data/' + str(job['build']) + directory['name'].replace('/','-') +".json")
        if should_process_files:
            print('==== START FILES PROCESSING ====')
            process_files(job, directory['name'], base_url)
            print('==== END FILES PROCESSING ====')

print('==== GET CU ALL JOBS ====')
data = requests.get('https://osj-phm-02-prd.cec.delllabs.net/job/RUN-CU-TEST/api/json', verify=False, auth=(jenkins_user,jenkins_pass))
data = data.json()

builds = data['builds']
tc = 0
threads = []

def process_cu_build(job):
    base_url = 'https://osj-phm-02-prd.cec.delllabs.net/job/RUN-CU-TEST/' + str(job['number']) 
    job_data = requests.get(base_url + '/api/json', verify=False, auth=(jenkins_user,jenkins_pass))
    job_params_jenkins = job_data.json()
    job_params = {}
    for action in job_params_jenkins['actions']:
        if action.get('_class','') == 'hudson.model.ParametersAction':
            for param in action['parameters']:
                job_params[param['name']] = param['value']
            break

    cuup_job_data = requests.get(base_url + '/CUUP_20UT_20Report/index.html', verify=False, auth=(jenkins_user,jenkins_pass))
    cucp_job_data = requests.get(base_url + '/CUCP_20UT_20Report/index.html', verify=False, auth=(jenkins_user,jenkins_pass))
    if cucp_job_data.status_code != 200 or cuup_job_data.status_code!=200:
        return
    cucpFile = open('lcov_data/' + str(job['number']) + "cucp.html", "w")
    cucpFile.write(cucp_job_data.text)
    cucpFile.close()
    cuupFile = open('lcov_data/' + str(job['number']) + "cuup.html", "w")
    cuupFile.write(cuup_job_data.text)
    cuupFile.close()
    os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"cucp.html -o lcov_data/"+ str(job['number']) +"cucp.json -j "+ job['url'] +"  --a cucp")
    os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"cuup.html -o lcov_data/"+ str(job['number']) +"cuup.json -j "+ job['url'] +"  --a cuup")
    
    os.remove('lcov_data/' + str(job['number']) + "cuup.html")
    os.remove('lcov_data/' + str(job['number']) + "cucp.html")

    jsonFile= open('lcov_data/' + str(job['number']) + "cucp.json",'r')
    app_json = json.load(jsonFile)
    app_json['params'] = job_params
    dirs = app_json['directories']
    del app_json['directories']
    process_directories(app_json.copy(), dirs, base_url + '/CUCP_20UT_20Report')
    app_json['coverage_level'] = 'application'
    jsonFile = open('lcov_data/' + str(job['number']) + "cucp-final.json", "w")
    jsonFile.write(json.dumps(app_json))
    jsonFile.close()

    jsonFile= open('lcov_data/' + str(job['number']) + "cuup.json",'r')
    app_json = json.load(jsonFile)
    app_json['params'] = job_params
    dirs = app_json['directories']
    del app_json['directories']
    process_directories(app_json.copy(), dirs, base_url + '/CUUP_20UT_20Report')
    app_json['coverage_level'] = 'application'
    jsonFile = open('lcov_data/' + str(job['number']) + "cuup-final.json", "w")
    jsonFile.write(json.dumps(app_json))
    jsonFile.close()

    os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "cucp-final.json > /dev/null")
    os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "cuup-final.json > /dev/null")
    
    os.remove('lcov_data/' + str(job['number']) + "cuup.json")
    os.remove('lcov_data/' + str(job['number']) + "cucp.json")
    os.remove('lcov_data/' + str(job['number']) + "cuup-final.json")
    os.remove('lcov_data/' + str(job['number']) + "cucp-final.json")

print('==== START CU JOBS PROCESSING ====')
for job in builds:
    t = Thread(target=process_cu_build, args=(job,))
    t.start()
    threads.append(t)
    tc+=1
    if tc>64:
        time.sleep(.5)
        tc=0
for t in threads:
    t.join()

print('==== END CU JOBS CUPROCESSING ====')

print('==== GET OAM ALL JOBS ====')
data = requests.get('https://osj-phm-02-prd.cec.delllabs.net/view/OAM/job/OAM_Pipeline/job/main/api/json', verify=False, auth=(jenkins_user,jenkins_pass))
data = data.json()

builds = data['builds']
tc = 0
threads = []

def process_oam_build(job):
    base_url = 'https://osj-phm-02-prd.cec.delllabs.net/view/OAM/job/OAM_Pipeline/job/main/' + str(job['number'])
    oam_job_data = requests.get(base_url + '/OAM_20lcov_20Report/index.html', verify=False, auth=(jenkins_user,jenkins_pass))
    oam_du_job_data = requests.get(base_url + '/OAM_20lcov_20Report_20-_20DU_20Component_20Tests/index_du.html', verify=False, auth=(jenkins_user,jenkins_pass))
    oam_cuup_job_data = requests.get(base_url + '/OAM_20lcov_20Report_20-_20CUUP_20Component_20Tests/index_cuup.html', verify=False, auth=(jenkins_user,jenkins_pass))
    oam_cucp_job_data = requests.get(base_url + '/OAM_20lcov_20Report_20-_20CUCP_20Component_20Tests/index_cucp.html', verify=False, auth=(jenkins_user,jenkins_pass))
    if (oam_job_data.status_code == 200 ):
        oamFile = open('lcov_data/' + str(job['number']) + "oam.html", "w")
        oamFile.write(oam_job_data.text)
        oamFile.close()
        os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"oam.html -o lcov_data/"+ str(job['number']) +"oam.json -j "+ job['url'] +"  --a oam")
        os.remove('lcov_data/' + str(job['number']) + "oam.html")
        jsonFile= open('lcov_data/' + str(job['number']) + "oam.json",'r')
        app_json = json.load(jsonFile)
        dirs = app_json['directories']
        del app_json['directories']
        app_json['coverage_level'] = 'application'
        jsonFile = open('lcov_data/' + str(job['number']) + "oam-final.json", "w")
        jsonFile.write(json.dumps(app_json))
        jsonFile.close()

        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "oam-final.json > /dev/null")
        os.remove('lcov_data/' + str(job['number']) + "oam.json")
        os.remove('lcov_data/' + str(job['number']) + "oam-final.json")
        
        print('==== START OAM DIR PROCESSING ====')
        process_directories(app_json.copy(), dirs, base_url + '/OAM_20lcov_20Report', False)
        print('==== END OAM DIR PROCESSING ====')

    if (oam_du_job_data.status_code == 200 ):
        oamFile = open('lcov_data/' + str(job['number']) + "oam.html", "w")
        oamFile.write(oam_du_job_data.text)
        oamFile.close()
        os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"oam.html -o lcov_data/"+ str(job['number']) +"oam.json -j "+ job['url'] +"  --a oam_du")
        os.remove('lcov_data/' + str(job['number']) + "oam.html")
        jsonFile= open('lcov_data/' + str(job['number']) + "oam.json",'r')
        app_json = json.load(jsonFile)
        dirs = app_json['directories']
        del app_json['directories']
        app_json['coverage_level'] = 'application'
        jsonFile = open('lcov_data/' + str(job['number']) + "oam-final.json", "w")
        print(app_json)
        jsonFile.write(json.dumps(app_json))
        jsonFile.close()

        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "oam-final.json > /dev/null")
        os.remove('lcov_data/' + str(job['number']) + "oam.json")
        os.remove('lcov_data/' + str(job['number']) + "oam-final.json")
        
        print('==== START OAM DIR PROCESSING ====')
        process_directories(app_json.copy(), dirs, base_url + '/OAM_20lcov_20Report_20-_20DU_20Component_20Tests', False)
        print('==== END OAM DIR PROCESSING ====')
    
    if (oam_cuup_job_data.status_code == 200 ):
        oamFile = open('lcov_data/' + str(job['number']) + "oam.html", "w")
        oamFile.write(oam_cuup_job_data.text)
        oamFile.close()
        os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"oam.html -o lcov_data/"+ str(job['number']) +"oam.json -j "+ job['url'] +"  --a oam_cuup")
        os.remove('lcov_data/' + str(job['number']) + "oam.html")
        jsonFile= open('lcov_data/' + str(job['number']) + "oam.json",'r')
        app_json = json.load(jsonFile)
        dirs = app_json['directories']
        del app_json['directories']
        app_json['coverage_level'] = 'application'
        jsonFile = open('lcov_data/' + str(job['number']) + "oam-final.json", "w")
        jsonFile.write(json.dumps(app_json))
        jsonFile.close()

        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "oam-final.json > /dev/null")
        os.remove('lcov_data/' + str(job['number']) + "oam.json")
        os.remove('lcov_data/' + str(job['number']) + "oam-final.json")
        
        print('==== START OAM DIR PROCESSING ====')
        process_directories(app_json.copy(), dirs, base_url + '/OAM_20lcov_20Report_20-_20CUUP_20Component_20Tests', False)
        print('==== END OAM DIR PROCESSING ====')

    if (oam_cucp_job_data.status_code == 200 ):
        oamFile = open('lcov_data/' + str(job['number']) + "oam.html", "w")
        oamFile.write(oam_cucp_job_data.text)
        oamFile.close()
        os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"oam.html -o lcov_data/"+ str(job['number']) +"oam.json -j "+ job['url'] +"  --a oam_cucp")
        os.remove('lcov_data/' + str(job['number']) + "oam.html")
        jsonFile= open('lcov_data/' + str(job['number']) + "oam.json",'r')
        app_json = json.load(jsonFile)
        dirs = app_json['directories']
        del app_json['directories']
        app_json['coverage_level'] = 'application'
        jsonFile = open('lcov_data/' + str(job['number']) + "oam-final.json", "w")
        jsonFile.write(json.dumps(app_json))
        jsonFile.close()

        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "oam-final.json > /dev/null")
        os.remove('lcov_data/' + str(job['number']) + "oam.json")
        os.remove('lcov_data/' + str(job['number']) + "oam-final.json")
        
        print('==== START OAM DIR PROCESSING ====')
        process_directories(app_json.copy(), dirs, base_url + '/OAM_20lcov_20Report_20-_20CUCP_20Component_20Tests', False)
        print('==== END OAM DIR PROCESSING ====')

print('==== START OAM JOBS PROCESSING ====')
for job in builds:
    t = Thread(target=process_oam_build, args=(job,))
    t.start()
    threads.append(t)
    tc+=1
    if tc>64:
        time.sleep(.5)
        tc=0
for t in threads:
    t.join()

print('==== END OAM JOBS PROCESSING ====')

print('==== GET NGP ALL JOBS ====')
data = requests.get('https://osj-phm-02-prd.cec.delllabs.net/view/OAM/job/OAM_Pipeline/job/main/api/json', verify=False, auth=(jenkins_user,jenkins_pass))
data = data.json()

builds = data['builds']
tc = 0
threads = []

def process_ngp_build(job):
    base_url = 'https://osj-phm-02-prd.cec.delllabs.net/view/OAM/job/OAM_Pipeline/job/main/' + str(job['number'])
    oam_job_data = requests.get(base_url + '/OAM_20lcov_20Report/index.html', verify=False, auth=(jenkins_user,jenkins_pass))
    oam_du_job_data = requests.get(base_url + '/OAM_20lcov_20Report_20-_20DU_20Component_20Tests/index_du.html', verify=False, auth=(jenkins_user,jenkins_pass))
    oam_cuup_job_data = requests.get(base_url + '/OAM_20lcov_20Report_20-_20CUUP_20Component_20Tests/index_cuup.html', verify=False, auth=(jenkins_user,jenkins_pass))
    oam_cucp_job_data = requests.get(base_url + '/OAM_20lcov_20Report_20-_20CUCP_20Component_20Tests/index_cucp.html', verify=False, auth=(jenkins_user,jenkins_pass))
    if (oam_job_data.status_code == 200 ):
        oamFile = open('lcov_data/' + str(job['number']) + "oam.html", "w")
        oamFile.write(oam_job_data.text)
        oamFile.close()
        os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"oam.html -o lcov_data/"+ str(job['number']) +"oam.json -j "+ job['url'] +"  --a oam")
        os.remove('lcov_data/' + str(job['number']) + "oam.html")
        jsonFile= open('lcov_data/' + str(job['number']) + "oam.json",'r')
        app_json = json.load(jsonFile)
        dirs = app_json['directories']
        del app_json['directories']
        app_json['coverage_level'] = 'application'
        jsonFile = open('lcov_data/' + str(job['number']) + "oam-final.json", "w")
        jsonFile.write(json.dumps(app_json))
        jsonFile.close()

        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "oam-final.json > /dev/null")
        os.remove('lcov_data/' + str(job['number']) + "oam.json")
        os.remove('lcov_data/' + str(job['number']) + "oam-final.json")
        
        print('==== START OAM DIR PROCESSING ====')
        process_directories(app_json.copy(), dirs, base_url + '/OAM_20lcov_20Report', False)
        print('==== END OAM DIR PROCESSING ====')

    if (oam_du_job_data.status_code == 200 ):
        oamFile = open('lcov_data/' + str(job['number']) + "oam.html", "w")
        oamFile.write(oam_du_job_data.text)
        oamFile.close()
        os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"oam.html -o lcov_data/"+ str(job['number']) +"oam.json -j "+ job['url'] +"  --a oam_du")
        os.remove('lcov_data/' + str(job['number']) + "oam.html")
        jsonFile= open('lcov_data/' + str(job['number']) + "oam.json",'r')
        app_json = json.load(jsonFile)
        dirs = app_json['directories']
        del app_json['directories']
        app_json['coverage_level'] = 'application'
        jsonFile = open('lcov_data/' + str(job['number']) + "oam-final.json", "w")
        print(app_json)
        jsonFile.write(json.dumps(app_json))
        jsonFile.close()

        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "oam-final.json > /dev/null")
        os.remove('lcov_data/' + str(job['number']) + "oam.json")
        os.remove('lcov_data/' + str(job['number']) + "oam-final.json")
        
        print('==== START OAM DIR PROCESSING ====')
        process_directories(app_json.copy(), dirs, base_url + '/OAM_20lcov_20Report_20-_20DU_20Component_20Tests', False)
        print('==== END OAM DIR PROCESSING ====')
    
    if (oam_cuup_job_data.status_code == 200 ):
        oamFile = open('lcov_data/' + str(job['number']) + "oam.html", "w")
        oamFile.write(oam_cuup_job_data.text)
        oamFile.close()
        os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"oam.html -o lcov_data/"+ str(job['number']) +"oam.json -j "+ job['url'] +"  --a oam_cuup")
        os.remove('lcov_data/' + str(job['number']) + "oam.html")
        jsonFile= open('lcov_data/' + str(job['number']) + "oam.json",'r')
        app_json = json.load(jsonFile)
        dirs = app_json['directories']
        del app_json['directories']
        app_json['coverage_level'] = 'application'
        jsonFile = open('lcov_data/' + str(job['number']) + "oam-final.json", "w")
        jsonFile.write(json.dumps(app_json))
        jsonFile.close()

        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "oam-final.json > /dev/null")
        os.remove('lcov_data/' + str(job['number']) + "oam.json")
        os.remove('lcov_data/' + str(job['number']) + "oam-final.json")
        
        print('==== START OAM DIR PROCESSING ====')
        process_directories(app_json.copy(), dirs, base_url + '/OAM_20lcov_20Report_20-_20CUUP_20Component_20Tests', False)
        print('==== END OAM DIR PROCESSING ====')

    if (oam_cucp_job_data.status_code == 200 ):
        oamFile = open('lcov_data/' + str(job['number']) + "oam.html", "w")
        oamFile.write(oam_cucp_job_data.text)
        oamFile.close()
        os.system("python3 parse-lcov.py -i lcov_data/"+ str(job['number']) +"oam.html -o lcov_data/"+ str(job['number']) +"oam.json -j "+ job['url'] +"  --a oam_cucp")
        os.remove('lcov_data/' + str(job['number']) + "oam.html")
        jsonFile= open('lcov_data/' + str(job['number']) + "oam.json",'r')
        app_json = json.load(jsonFile)
        dirs = app_json['directories']
        del app_json['directories']
        app_json['coverage_level'] = 'application'
        jsonFile = open('lcov_data/' + str(job['number']) + "oam-final.json", "w")
        jsonFile.write(json.dumps(app_json))
        jsonFile.close()

        os.system('curl -s -XPOST http://mp-elk-00-p-dur.cec.lab.emc.com:9200/lcov/_doc -H "Content-Type: application/json" -d @lcov_data/'+str(job['number']) + "oam-final.json > /dev/null")
        os.remove('lcov_data/' + str(job['number']) + "oam.json")
        os.remove('lcov_data/' + str(job['number']) + "oam-final.json")
        
        print('==== START OAM DIR PROCESSING ====')
        process_directories(app_json.copy(), dirs, base_url + '/OAM_20lcov_20Report_20-_20CUCP_20Component_20Tests', False)
        print('==== END OAM DIR PROCESSING ====')

print('==== START OAM JOBS PROCESSING ====')
for job in builds:
    t = Thread(target=process_ngp_build, args=(job,))
    t.start()
    threads.append(t)
    tc+=1
    if tc>64:
        time.sleep(.5)
        tc=0
for t in threads:
    t.join()

print('==== END OAM JOBS PROCESSING ====')
