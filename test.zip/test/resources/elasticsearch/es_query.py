# Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
import warnings
import elasticsearch
warnings.filterwarnings("ignore", category=DeprecationWarning)


class ESQuery:
    """Query data from Elasticsearch"""
    def __init__(self):
        self.es = elasticsearch.Elasticsearch(
            ['mp-elk-00-p-dur.cec.lab.emc.com'],
            port=9200,
            verify_certs=False,
        )

    def get_list_of_success_data(self, tl_name, size=30):
        """Get list of last success TLs data  (Default is latest 30 success builds result)"""

        query_results = self.es.search(index=tl_name,  body={
            "sort": {"date_created": "desc"},
            "size": size,
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "overallstatus": "SUCCESS"
                            }
                        }
                    ]
                }
            }
        })

        # Get list of TL data query results
        tl_list = query_results['hits']['hits']
        return tl_list

    def get_latest_success_data(self, tl_name):
        """Get latest success build data"""
        tl_success_list = self.get_list_of_success_data(tl_name)
        if not tl_success_list:
            return {}
        latest_tl_success = {}
        for tl in tl_success_list:
            tl_src = tl["_source"]
            # Checking 'latestVerCU' and 'latestVerDU' as they are the most important fields for triggering TL pipelines
            if (not "latestVerCU" in tl_src) or (not "latestVerDU" in tl_src):
                continue
            # Skip if the build is missing any test data fields
            if (not "totaltests" in tl_src) or (not "testpass" in tl_src) or (not "testfail" in tl_src):
                continue
            # Pick up the build with no test cases failed
            if (tl_src["totaltests"] != 0 and (tl_src["totaltests"] == tl_src["totaltests"])):
                latest_tl_success = tl_src
                break
        return latest_tl_success
    
    def get_component_test_data(self, component_test_name, test_id):
        try:
            component_data = self.es.search(index=component_test_name,
                                    body={"query": {"match_phrase": {"testID": test_id}}})
            component_data = component_data['hits']['hits'][0]['_source']
            return component_data
        except:
            return False

    def get_mainstream_test_data(self, build_number, index="mainstream_test"):
        try:
            mainstream_test = self.es.search(index=index, body={"query": {"match_phrase": {"buildID": build_number}}})
            
            return mainstream_test['hits']['hits'][0]['_source']
        except:
            return False

    def get_test_line_data(self, tl_name, build_id):
        id = f'#{build_id}'
        try:
            tl_data = self.es.search(index=tl_name,
                                     body={"query": {"match_phrase": {"_id": id}}})
            return tl_data['hits']['hits'][0]['_source']
        except:
            return False

    def get_baseline_tc_for_component(self, component, index="mainstream_testcase_baseline"):
        try:
            baseline_data = self.es.search(index=index, body={
                                                "sort": {"date_created": "desc"},
                                                "size": 1,
                                            })['hits']['hits'][0]["_source"]["baselines"]
            
            total_test_case = 0
            for item in baseline_data:
                if item["component"] == component:
                    total_test_case += item["baseline"]
            return total_test_case
        except:
            return False

    def get_baseline_tc_for_component_test_type(self, component, test_type, index="mainstream_testcase_baseline"):
        try:
            baseline_data = self.es.search(index=index, body={
                                                "sort": {"date_created": "desc"},
                                                "size": 1,
                                            })['hits']['hits'][0]["_source"]["baselines"]

            number_baseline_test_case = 0
            for item in baseline_data:
                if item["component"] == component and item["testType"] == test_type:
                    number_baseline_test_case += item["baseline"]
            return number_baseline_test_case
        except:
            return False
