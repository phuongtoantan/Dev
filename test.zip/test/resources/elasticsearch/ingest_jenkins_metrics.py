import sys
import json
import requests
from elasticsearch import Elasticsearch
from datetime import datetime
import math
import time
import urllib3
import argparse
from threading import Thread
import logging as log

log.basicConfig(
    level=log.INFO, format='[%(asctime)s]   %(levelname)s: %(message)s', datefmt='%H:%M:%S')

parser = argparse.ArgumentParser()

parser.add_argument(
    "-jenkins_id",
    "--jenkins-id",
    help="Provide the Jenkins user ID",
    required=True,
)
parser.add_argument(
    "-jenkins_token",
    "--jenkins-token",
    help="Provide the Jenkins API token, refer to 'https://stackoverflow.com/a/45466184' to create new API token",
    required=True,
)
parser.add_argument(
    "-target_job_name",
    "--target_job_name",
    help="Provide the target job name to be uploaded. Upload all if not specified",
    default=None,
    required=False,
)

# Parse input arguments
args = parser.parse_args()
# Init variables
JENKINS_USER_ID = args.jenkins_id
JENKINS_API_TOKEN = args.jenkins_token
TARGET_JOB_NAME = args.target_job_name
JENKINS_BASE_URL = "osj-phm-02-prd.cec.delllabs.net"
JENKINS_API_AUTH_PREFIX = f"https://{JENKINS_USER_ID}:{JENKINS_API_TOKEN}@"
JENKINS_API_REQUEST_URL = JENKINS_API_AUTH_PREFIX + JENKINS_BASE_URL

urllib3.disable_warnings()
es = Elasticsearch(
    ['mp-elk-00-p-dur.cec.lab.emc.com'],
    port=9200,
    verify_certs=False,
)

job_status = {
    'aborted': 'ABORTED',
    'aborted_anime': 'IN_PROGRESS',
    'blue': 'SUCCESS',
    'blue_anime': 'IN_PROGRESS',
    'disabled': 'DISABLED',
    'disabled_anime': 'IN_PROGRESS',
    'grey': 'PENDING',
    'grey_anime': 'IN_PROGRESS',
    'notbuilt': 'NOTBUILT',
    'notbuilt_anime': 'IN_PROGRESS',
    'red': 'FAILED',
    'red_anime': 'IN_PROGRESS',
    'yellow': 'UNSTABLE',
    'yellow_anime': 'IN_PROGRESS'
}


def es_index(index, data):
    id = data.get('fullName', None)
    if id is None:
        id = data.get('fullDisplayName', None)
    log.info("Processing es_index ID: " + id)
    try:
        if es.exists(index=index, id=id):
            es.update(index=index, id=id, body={'doc': data}, doc_type='_doc')
        else:
            es.index(index=index, body=data, id=id, doc_type='_doc')
    except Exception as e:
        log.info(e)
        log.info(data)


def process_job(job):
    job_data = requests.get(
        f"{JENKINS_API_REQUEST_URL}/job/{job['name']}/api/json", verify=False)
    job_data = job_data.json()
    now = datetime.utcnow()
    job_doc = {
        'name': job_data['name'],
        'fullName': job_data['fullName'],
        'concurrentBuild': job_data.get('concurrentBuild', False),
        'datetime': now,
        'description': job_data['description'],
        'url': job_data['url'],
        'type': 'JOB',
    }

    if job.get('color', None) is not None:
        job_doc['buildable'] = job_data.get('buildable', False)
        job_doc['status'] = job_status[job['color']],
        job_w_builds.append(job_data)
    else:
        repositories.append(job_data)
        job_doc['buildable'] = False
        job_doc['type'] = 'REPOSITORY'
    es_index('jenkins_jobs', job_doc)


def process_build(job, build):
    build_data = requests.get(
        build['url'].replace('https://', JENKINS_API_AUTH_PREFIX)+'/api/json',
        verify=False)
    if build_data.status_code != 200:
        log.info(build['url'].replace(
            'https://', JENKINS_API_AUTH_PREFIX)+'/api/json')
        return
    build_data = build_data.json()
    build_doc = {
        'name': build_data['displayName'],
        'fullDisplayName': build_data['fullDisplayName'],
        'displayName': build_data['displayName'],
        'concurrentBuild': job['concurrentBuild'],
        'url': build_data['url'],
        'description': build_data['description'],
        'artifacts': build_data['artifacts'],
        'building': build_data['building'],
        'job': job['fullName'],
        'culprits': build_data['culprits'],
        'timestamp': build_data['timestamp'],
        'datetime': datetime.fromtimestamp(build_data['timestamp']/1000),
        'result': build_data['result']
    }

    if build_data.get('changeSets', None) is not None:
        for change in build_data['changeSets']:
            if build_doc.get('changeSets', None) is None:
                build_doc['changeSets'] = []
            build_doc['changeSets'] = build_doc['changeSets'] + change['items']

    for action in build_data['actions']:
        if action.get('_class', '') == 'jenkins.metrics.impl.TimeInQueueAction':
            build_doc['waitingTimeMillis'] = action['waitingTimeMillis']
            build_doc['blockedTimeMillis'] = action['blockedTimeMillis']
            build_doc['buildableTimeMillis'] = action['buildableTimeMillis']
            build_doc['buildingDurationMillis'] = action['buildingDurationMillis']

        if action.get('_class', '') == 'hudson.model.ParametersAction':
            build_doc['parameters'] = action['parameters']

    es_index('jenkins_builds', build_doc)


def process_job_w_builds(job):
    if job.get('builds', None) is not None:
        sub_tc = 0
        build_threads = []
        for build in job['builds']:
            t = Thread(target=process_build, args=(job, build))
            t.start()
            build_threads.append(t)
            sub_tc += 1
            if sub_tc > 64:
                time.sleep(1)
                sub_tc = 0
        for t in build_threads:
            t.join()


def process_sub_job(job):
    for sub_job in job['jobs']:
        sub_job_data = requests.get(
            f"{JENKINS_API_REQUEST_URL}/job/{job['name']}/job/{sub_job['name']}/api/json", verify=False)
        now = datetime.utcnow()
        sub_job_data = sub_job_data.json()
        sub_job_doc = {
            'name': sub_job_data['displayName'],
            'fullName': sub_job_data['fullName'],
            'concurrentBuild': sub_job_data.get('concurrentBuild', False),
            'url': sub_job_data['url'],
            'description': sub_job_data['description'],
            'buildable': sub_job_data.get('buildable', False),
            'parent_name': job['displayName'],
            'datetime': now,
            'type': 'REPOSITORY_JOB',
            'status': job_status[sub_job_data['color']] if job.get('color', None) is not None else '',
        }
        job_w_builds.append(sub_job_data)
        es_index('jenkins_jobs', sub_job_doc)


threads = []
log.info('==== GET ALL JOBS ====')
data = requests.get(
    f"{JENKINS_API_REQUEST_URL}/view/all/api/json", verify=False)
log.info("Jenkins response data: " + str(data))
data = data.json()
jobs = data['jobs']
repositories = []
job_w_builds = []


log.info('==== START JOBS PROCESSING ====')
tc = 0
for job in jobs:
    # filter job name that matches TARGET_JOB_NAME
    if (TARGET_JOB_NAME is not None) and (job['name'] != TARGET_JOB_NAME):
        continue

    t = Thread(target=process_job, args=(job,))
    t.start()
    threads.append(t)
    tc += 1
    if tc > 64:
        time.sleep(.5)
        tc = 0
for t in threads:
    t.join()
log.info('==== END JOBS PROCESSING ====')


log.info('==== START SUB_JOBS PROCESSING ====')
threads = []
for job in repositories:
    t = Thread(target=process_sub_job, args=(job,))
    t.start()
    threads.append(t)
    tc += 1
    if tc > 64:
        time.sleep(.5)
        tc = 0
for t in threads:
    t.join()
log.info('==== END SUB_JOBS PROCESSING ====')

log.info('==== START BUILDS PROCESSING ====')
for job in job_w_builds:
    process_job_w_builds(job)
log.info('==== END BUILDS PROCESSING ====')
