# Copyright © 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.

import elasticsearch
from pandasticsearch import Select
import pandas as pd
import json

class ESInterface:
    """An intreface to collect Jenkins builds information from Elasticsearch"""

    # Class variables
    CU_DU_FIELDS = ['displayName', 'description', 'buildVariant',
                    'overallstatus', 'url', 'date_created']

    def __init__(self):
        self.es = elasticsearch.Elasticsearch(
            ['mp-elk-00-p-dur.cec.lab.emc.com'],
            port=9200,
            verify_certs=False,
        )

    def get_tl_data_frame_by_version(self, tl_name, cu_version, du_version):
        """Get test lines data by CU/DU version.
        :type tl_name: str
        :param tl_name: The name of test line.
        :type cu_version: str
        :param cu_version: The CU version to query.
        :type du_version: str
        :param du_version: The DU version to query.
        """

        print("Working on TL: " + tl_name)
        tl_dict = self.es.search(index=tl_name,  body={
            "sort": {"date_created": "desc"},
            "size": 1,
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "latestVerCU": cu_version
                            }
                        },
                        {
                            "match_phrase": {
                                "latestVerDU": du_version
                            }
                        }
                    ]
                }
            }
        })
        tl_df = Select.from_dict(tl_dict).to_pandas()
        return tl_df

    def get_latest_tl_data(self, tl_name, must_have_cudu=False):
        """Get latest test lines data by date created.
        :type tl_name: str
        :param tl_name: The name of test line.
        """

        print("Working on TL: " + tl_name)
        tl_dict = self.es.search(index=tl_name,  body={
            "sort": {"date_created": "desc"},
            "query": {
                "bool": {
                    "must": [
                        {
                            "exists": {
                                "field": "testLine"
                            }
                        }
                    ]
                }
            },
            "size": 1
        })

        tl_df = Select.from_dict(tl_dict).to_pandas()

        return tl_df
    
    def get_ct_data_by_id(self, ct_id):
        """Get the CT data by ID
        :type ct_id: str
        :param ct_id: ID of the CT.
        :type job_name: str
        :param job_name: Name of the CT
        """
        previous_ct_dict = self.es.search(index="mobile_phoenix_sanity_-_continuous",  body={
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "id": ct_id
                            }
                        }
                    ]
                }
            },
            "size": 1
        })

        previous_ct_df = Select.from_dict(previous_ct_dict).to_pandas()

        return previous_ct_df
    
    def get_previous_ct_status(self, test_data):
        """Get the previous CT data by test data
        :type test_data: str
        :param test_data: include ct_job_id and tl_job_ids
        """
        test_data = json.loads(test_data)
        current_ct_id = test_data["ct_job_id"]
        ct_status = None
        previous_ct_id = int(current_ct_id) - 1
        previous_ct_df = self.get_ct_data_by_id(str(previous_ct_id))
        previous_ct_dict = previous_ct_df.to_dict(orient='records')
        for ct_object in previous_ct_dict:
            if ct_object["id"] == str(previous_ct_id):
                ct_status = ct_object["overallstatus"]
                break
        return ct_status

    def get_current_ct_status(self, current_id):
        current_ct_df = self.get_ct_data_by_id(current_id)
        current_ct_dict = current_ct_df.to_dict(orient='records')
        for ct_object in current_ct_dict:
            if ct_object["id"] == current_id:
                ct_status = ct_object["overallstatus"]
                break
        return ct_status

    def get_ct_success_data(self, filter_status=None, size=2):
        """Get list of last success CTs data  (Default is latest 2 success builds result)"""
        if filter_status:
            ct_dict = self.es.search(index="mobile_phoenix_sanity_-_continuous",  body={
                "sort": {"date_created": "desc"},
                "size": size,
                "query": {
                    "bool": {
                        "must": [
                            {
                                "match_phrase": {
                                    "overallstatus": filter_status
                                }
                            }
                        ]
                    }
                }
            })
        else:
            ct_dict = self.es.search(index="mobile_phoenix_sanity_-_continuous",  body={
                "sort": {"date_created": "desc"},
                "size": size
            })
        return ct_dict['hits']['hits']

    def get_previous_versions(self, current_ct_id, list_ct_data):
        """Get the previous CT data by test data
        :type test_data: str
        :param test_data: include ct_job_id and tl_job_ids
        """
        application_versions = {
            "CU_VERSION": None,
            "DU_VERSION": None,
            "MPLANE_VERSION": None,
            "L1FWVERSION": None,
            "L1DRVERSION": None
        }
        try:
            for ct_item in list_ct_data:
                if int(ct_item["_source"]["id"]) < int(current_ct_id):
                    if (
                        ct_item["_source"]["CU_VERSION"] == "" or 
                        ct_item["_source"]["DU_VERSION"] == "" or 
                        ct_item["_source"]["MPLANE_VERSION"] == "" or 
                        ct_item["_source"]["L1FWVERSION"] == "" or 
                        ct_item["_source"]["L1DRVERSION"] == ""
                    ):
                        continue
                    application_versions["CU_VERSION"] = ct_item["_source"]["CU_VERSION"]
                    application_versions["DU_VERSION"] = ct_item["_source"]["DU_VERSION"]
                    application_versions["MPLANE_VERSION"] = ct_item["_source"]["MPLANE_VERSION"]
                    application_versions["L1FWVERSION"] = ct_item["_source"]["L1FWVERSION"]
                    application_versions["L1DRVERSION"] = ct_item["_source"]["L1DRVERSION"]
                    break
        except Exception as err:
            print("Could not get application's version. Error: ", err)
            application_versions = {
                "CU_VERSION": None,
                "DU_VERSION": None,
                "MPLANE_VERSION": None,
                "L1FWVERSION": None,
                "L1DRVERSION": None
            }
            return application_versions
        return application_versions   
    
    def get_tl_data_by_id(self, tl_name, tl_id):
        """Get test line by lest line ID.
        :type tl_name: str
        :param tl_name: The name of test line.
        :type tl_id: str
        :param tl_id: The ID of test line.
        """
        tl_id = "#" + tl_id
        print("Working on TL: " + tl_name)
        tl_dict = self.es.search(index=tl_name,  body={
            "sort": {"date_created": "desc"},
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "_id": tl_id
                            }
                        }
                    ]
                }
            },
            "size": 1
        })

        tl_df = Select.from_dict(tl_dict).to_pandas()
        return tl_df

    def get_mainstream_data_by_id(self, index, build_id):
        """Get mainstream data by buildID.
        :type index: str
        :param index: The index of data.
        :type build_id: str
        :param build_id: The ID of mainstream build
        """
        print(f"Get mainstream data by id: {build_id}")
        mainstream_dict = self.es.search(index=index,  body={
            "sort": {"date_created": "desc"},
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "buildID": build_id
                            }
                        }
                    ]
                }
            },
            "size": 1
        })

        mainstream_df = Select.from_dict(mainstream_dict).to_pandas()
        return mainstream_df

    def get_latest_mainstream_build_data(self, index, component):
        """Get latest mainstream build data.
        :type index: str
        :param index: The index of build data.
        :type component: str
        :param component: name of component.
        """
        mainstream_dict = self.es.search(index=index,  body={
            "sort": {"buildID": "desc"},
            "query": {
                "bool": {
                    "must": [
                        {
                            "match": {
                                "buildStages.component": component
                            }
                        }
                    ]
                }
            },
            "size": 1
        })

        mainstream_df = Select.from_dict(mainstream_dict).to_pandas()
        if mainstream_df is not None:
            result = next((buildStage for buildStage in mainstream_df.iloc[0]['buildStages'] if buildStage["component"] == component), None)
            return result
        return None

    def get_mainstream_test_data_by_id(self, index, test_id, return_dict_type=False):
        """Get mainstream test data by testdID.
        :type index: str
        :param index: The index of data.
        :type test_id: str
        :param test_id: The ID of mainstream test
        """
        mainstream_test_data = None
        try:
            mainstream_test_dict = self.es.search(index=index,  body={
                "sort": {"date_created": "desc"},
                "query": {
                    "bool": {
                        "must": [
                            {
                                "match_phrase": {
                                    "testID": test_id
                                }
                            }
                        ]
                    }
                },
                "size": 1
            })

            if return_dict_type == True:
                mainstream_test_data = mainstream_test_dict
            else:
                mainstream_test_df = Select.from_dict(mainstream_test_dict).to_pandas()
                mainstream_test_data = mainstream_test_df
        except Exception as err:
            print("Encountering error while getting mainstream test data by ID: ", err)
        
        return mainstream_test_data

    def get_tl_success_data(self, tl_name, size=30):
        """Get list of last success TLs data  (Default is latest 30 success builds result)"""

        tl_dict = self.es.search(index=tl_name,  body={
            "sort": {"date_created": "desc"},
            "size": size,
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "overallstatus": "SUCCESS"
                            }
                        }
                    ]
                }
            }
        })

        # Get list of TL data query results
        tl_list = tl_dict['hits']['hits']
        return tl_list

    def get_latest_version(self, job_name):
        """Get latest version of a job.
        :type job_name: str
        :param job_name: The Jenkins job name
        :return: Returns either a latest version in string or ``None``
        """
        latest_version = None
        try:
            job_metadata = self.es.search(index=job_name.lower(), body={
                "sort": {"date_created": "desc"},
                "size": 1,
            })
            latest_version = job_metadata['hits']['hits'][0]["_source"]["applicationVersion"]
        except Exception as err:
            print("Encountering error while getting latest application version: ", err)
        return latest_version

    def query_jenkins_job(self, job_name, description):
        """Get information of a Jenkins job based on name and description.
        :type job_name: str
        :param job_name: The Jenkins job name
        :type description: str
        :param description: The description of Jenkins job
        :return: Returns either job metadata in dict or ``None``
        """
        metadata = self.es.search(index="jenkins_builds", body={
            "query": {
                "bool": {
                    "must": [{
                        # Using term query to find exact value (job_name in this case)
                        "term": {
                            "job.keyword": job_name
                        }
                    },
                        {
                        "match_phrase": {"description": description}
                    }]
                }
            }})
        return metadata

    def get_cu_df(self, cu_version):
        """Get CU datafame by version.
        :type cu_version: str
        :param cu_version: The CU version to query.
        :return: Returns either CU dataframe in pandas or ``None``
        """
        cu_df = None
        cu_dict = self.es.search(index="cu-build-variant",
                                 body={"query": {"match_phrase": {"description": cu_version}}})
        cu_df = Select.from_dict(cu_dict).to_pandas()
        if cu_df is not None:
            cu_df = cu_df.sort_values(by=['date_created'], ascending=False)
            cu_df = cu_df.sort_values(by=['displayName'])
            cu_df = cu_df.filter(self.CU_DU_FIELDS, axis=1)
        return cu_df

    def get_du_df(self, du_version):
        """Get DU datafame by version.
        :type du_version: str
        :param du_version: The DU version to query.
        :return: Returns either DU dataframe in pandas or ``None``
        """
        du_dict = self.es.search(index="du-builds",
                                 body={"query": {"match_phrase": {"description": du_version}}})
        du_df = Select.from_dict(du_dict).to_pandas()
        if du_df is not None:
            du_df = du_df.sort_values(by=['date_created'], ascending=False)
            du_df = du_df.sort_values(by=['displayName'])
            du_df = du_df.filter(self.CU_DU_FIELDS, axis=1)
        return du_df

    def get_mplane_df(self, mplane_version):
        """Get MPLANE datafame by version.
        :type mplane_version: str
        :param mplane_version: The MPLANE version to query.
        :return: Returns either MPLANE dataframe in pandas or ``None``
        """
        mplane_dict = self.es.search(index="fh_mplane_main",
                                     body={"query": {"match_phrase": {"description": mplane_version}}})
        mplane_df = Select.from_dict(mplane_dict).to_pandas()
        if mplane_df is not None:
            mplane_df = mplane_df.sort_values(
                by=['date_created'], ascending=False)
            mplane_df = mplane_df.sort_values(by=['displayName'])
            mplane_df = mplane_df.filter(self.CU_DU_FIELDS, axis=1)
        return mplane_df

    def get_app_data(self, job_name_lowercase, app_name, app_version):
        """Retreiving application build data"""
        src_app_data = {}
        try:
            app_data = self.es.search(index=job_name_lowercase, body={
                "sort": {"date_created": "desc"},
                "query": {
                    "bool": {
                        "must": [
                            {
                                "match_phrase": {
                                    "applicationName": app_name
                                }
                            },
                            {
                                "match_phrase": {
                                    "applicationVersion": app_version
                                }
                            }
                        ]
                    }
                },
                "size": 1
            })
            src_app_data = app_data['hits']['hits'][0]["_source"]
        except Exception as err:
            print("Encountering error while getting application data: ", err)
        return src_app_data

    def get_es_component_data(self, job_name_lowercase, hash):
        """Retreiving test results from submodule data"""
        src_submodule_data = {}
        try:
            submodule_data = self.es.search(index=job_name_lowercase, body={
                "sort": {"date_created": "desc"},
                "query": {
                    "bool": {
                        "must": [{
                                "match_phrase": {
                                    "hash": hash
                                }
                            }]
                    }
                },
                "size": 1
            })
            src_submodule_data = submodule_data['hits']['hits'][0]["_source"]
        except Exception as err:
            print("Encountering error while getting test results from submodule data: ", err)
        return src_submodule_data

    def get_latest_es_component_data(self, job_name_lowercase):
        """Retreiving test results from submodule data"""
        src_submodule_data = {}
        try:
            submodule_data = self.es.search(index=job_name_lowercase, body={
                "sort": {"date_created": "desc"},
                "size": 1
            })
            src_submodule_data = submodule_data['hits']['hits'][0]["_source"]
        except Exception as err:
            print("Encountering error while getting test results from submodule data: ", err)
        return src_submodule_data

    def get_build_overall_status(self, component_df):
        """Get build status for CU/DU/MPLANE"""
        overall_status = True
        try:
            for i in range(len(component_df)):
                print(f"Index: {i}, Values: {component_df.loc[i, 'overallstatus']}")
                if component_df.loc[i, "overallstatus"] != "SUCCESS":
                    overall_status = False
                    break
        except Exception as err:
            overall_status = False
            print("Encounting error: ", err)
        return overall_status

    def get_last_success_data(self):
        """Get last success data by CU/DU version."""

        last_success_data = {
            "latestVerCU": "N/A",
            "latestVerDU": "N/A",
            "latestVerMPLANE": "N/A",
            "latestVerL1FW": "N/A",
            "latestVerL1DRV": "N/A",
            "date_created": "N/A",
        }

        # Capture latest success data based on tl57 and tl24 data
        e2etl_success_list = self.get_tl_success_data(
            "tl57_nightly_e2e_ota", 1000
        )
        aiotl_success_list = self.get_tl_success_data("aio-tl24", 1000)

        for aiotl_success in aiotl_success_list:
            aiotl_src = aiotl_success["_source"]
            if (not "latestVerCU" in aiotl_src) or (not "latestVerDU" in aiotl_src):
                continue
            for e2etl_success in e2etl_success_list:
                e2etl_src = e2etl_success["_source"]
                if (not "latestVerCU" in e2etl_src) or (not "latestVerDU" in e2etl_src):
                    continue
                # Check if both CU/DU version are matched
                if (aiotl_src["latestVerCU"] == e2etl_src["latestVerCU"]) and (
                    e2etl_src["latestVerDU"] == aiotl_src["latestVerDU"]
                ):
                    print("Found latest successed versions!")
                    last_success_data["latestVerCU"] = aiotl_src["latestVerCU"]
                    last_success_data["latestVerDU"] = aiotl_src["latestVerDU"]
                    last_success_data["latestVerMPLANE"] = e2etl_src["latestVerMPLANE"]
                    last_success_data["latestVerL1FW"] = e2etl_src["latestVerL1FW"]
                    last_success_data["latestVerL1DRV"] = e2etl_src["latestVerL1DRV"]
                    last_success_data["date_created"] = aiotl_src["date_created"]
                    return last_success_data
        return last_success_data

    def combine_deploy_df(self, deploy_fields, target_deploy_df):
        """Create a combined deploy dataframe.
        :type target_deploy_df: dict
        :param target_deploy_df: The dict of test lines dataframe.
        """
        tl_df_values = []
        for _, tl_df_obj in target_deploy_df.items():
            tl_df_values.append(tl_df_obj["dataframe"])

        deploy_df = pd.concat(tl_df_values, axis=0)
        deploy_df = deploy_df.filter(deploy_fields, axis=1)
        return deploy_df

    def get_current_versions_from_test_df(self, target_test_df, test_tl_name=""):
        """Get current CU/DU/MPLANE versions from test dataframe"""
        component_version = {}
        target_test_df = target_test_df.to_dict(orient="records")
        for tl_object in target_test_df:
            if len(test_tl_name) == 0 or tl_object["testLine"] == test_tl_name:
                component_version["latestVerCU"] = tl_object["latestVerCU"]
                component_version["latestVerDU"] = tl_object["latestVerDU"]
                component_version["latestVerMPLANE"] = tl_object["latestVerMPLANE"]
                break
        return component_version

    def get_test_df(self, all_tl_df):
        """Filter target test dataframes."""
        # Extract subset target test df
        target_tl_test = []
        impacted_tl_test = []
        for tl_name, tl_df_obj in all_tl_df.items():
            # Collecting TLs which enabled show_test_result flag
            if ("show_test_result" in tl_df_obj) and tl_df_obj[
                "show_test_result"
            ] == True:
                target_tl_test.append(tl_name)
                # Collecting TLs which enabled impact_overall_status flag
                if ("impact_overall_status" in tl_df_obj) and tl_df_obj[
                    "impact_overall_status"
                ] == True:
                    impacted_tl_test.append(tl_name)

        target_test_df = dict(
            (k, all_tl_df[k]) for k in target_tl_test if k in all_tl_df
        )

        impacted_test_df = dict(
            (k, all_tl_df[k]) for k in impacted_tl_test if k in all_tl_df
        )

        return target_test_df, impacted_test_df

    def combine_test_df(self, test_fields, target_test_df):
        """Create a combined test dataframe.
        :type target_test_df: dict
        :param target_test_df: The dict of test lines dataframe.
        """
        tl_df_values = []
        for _, tl_df_obj in target_test_df.items():
            tl_df_values.append(tl_df_obj["dataframe"])

        test_df = pd.concat(tl_df_values, axis=0)
        test_df = test_df.rename(columns={"overallstatus": "Test status"})
        test_df = test_df.filter(test_fields, axis=1)
        return test_df


    def get_overall_status(self, tl_definiton, target_test_df):
        """Determine overall status based.
        :param target_test_df (dict): The dict of test lines dataframe.
        """
        is_success = True

        sanity_tls_keys = set(
            key
            for key, value in tl_definiton.items()
            if value.get("impact_overall_status")
        )

        if set(sanity_tls_keys) != set(target_test_df.keys()):
            print(f"Does not have data for all Sanity TLs {sanity_tls_keys}")
            return False

        for _, tl_df_obj in target_test_df.items():
            tl_df = tl_df_obj["dataframe"]
            # Mark the whole result as False if one of the TLs data not available
            if (
                (tl_df is None)
                or ("overallstatus" not in tl_df)
                or (tl_df["overallstatus"].values[0] != "SUCCESS")
            ):
                is_success = False
                break
        return is_success

    def get_all_tl_df(self, tl_definiton, cu_version, du_version):
        """Get all test lines dataframe.
        :type cu_version: str
        :param cu_version: The CU version to query.
        :type du_version: str
        :param du_version: The DU version to query.
        """
        # Labs information could be found at: https://confluence.cec.lab.emc.com/display/MP/RHEL+AIO+Labs+%3A+Booking+Space
        # and: https://osj-phm-02-prd.cec.delllabs.net/view/AIO/

        # For pipelines using candidate builds (like tl24, tl57), collect by input versions
        # For pipelines using greenload builds with 'use_green_load enabled' (like TL8, TL10, ...), collect latest data on ES server
        all_tl_df = tl_definiton
        # Query TL data
        for tl_name, _ in all_tl_df.items():
            # Get latest available TL data
            all_tl_df[tl_name]["dataframe"] = self.get_latest_tl_data(
                tl_name
            )
            print(f"{tl_name}: ", all_tl_df[tl_name]["dataframe"])

        return all_tl_df

    def get_test_tl_df(self, tl_definiton, test_data):
        """Get all test lines dataframe.
        :type test_data: str
        :param test_data: The test data to query.
        """
        test_data = json.loads(test_data)
        tl_job_ids = test_data["tl_job_ids"]
        all_tl_df = {}
        # Query TL data
        for tl_name, tl_id in tl_job_ids.items():
            if tl_name in tl_definiton:
                all_tl_df[tl_name] = tl_definiton[tl_name]
                all_tl_df[tl_name]["dataframe"] = self.get_tl_data_by_id(
                    tl_name, tl_id
                )
                print(f"{tl_name}: ", all_tl_df[tl_name]["dataframe"])

        return all_tl_df

    def get_component_data(self, component_name, branch):
        """Get all test lines dataframe.
        :type job_name_lowercase: string
        :param job_name_lowercase: the index of component in ES.
        :type hash_code: string
        :param hash_code: current hash for each build.
        """
        job_name_lowercase = None
        converted_component_name = None
        if component_name == "ngp":
            converted_component_name = "NGP"
            if branch == "R1":
                job_name_lowercase = "gnb_ngp_main_r1"
            else:
                job_name_lowercase = "gnb_ngp_main"
                component_name = "gNB_ngp"
        elif component_name == "gNB_OAM":
            converted_component_name = "OAM"
            job_name_lowercase = "oam_nightly_regression"
        component_data = self.get_latest_es_component_data(
            job_name_lowercase
        )
        component_data["component_name"] = converted_component_name
        return component_data

    def get_latest_success_component_versions(self, index, components, loop = 50):
        """Get latest mainstream build data.
        :type index: str
        :param index: The index of build data.
        :type components: str
        :param component: list of components.
        """
        components_list = components.strip('[]').split(', ')
        component_dict = {component: '' for component in components_list}
        mainstream_build_dict = self.es.search(index=index,  body={
            "sort": {"buildID": "desc"},
            "size": loop
        })

        mainstream_build_dict = Select.from_dict(mainstream_build_dict).to_pandas()
        if mainstream_build_dict is not None:
            for component in component_dict.keys():
                for index in range(loop):
                    for buildStage in mainstream_build_dict.iloc[index]['buildStages']:
                        if buildStage["component"] == component and buildStage["overallStatus"] == "SUCCESS":
                            print(buildStage["description"])
                            # Retrieve only the version number excluding the prefixes 'CU_, DU_...'
                            split_result = buildStage["description"].split("_")
                            # Convert pattern from 2.1.0.0_0012 to 2.1.0.0-0012
                            component_dict[component] = "-".join(split_result[1:])
                            break
                    if component_dict[component] != "":
                        break
            return component_dict
        return None

    def get_official_mainstream_version_by_id(self, index, mainstream_id):
        """Get mainstream versions data by buildID.
        :type index: str
        :param index: The index of data.
        :type mainstream_id: str
        :param mainstream_id: The ID of mainstream run
        """

        mainstream_versions = {}
        try:
            print(f"Get mainstream data by index: {index}")
            print(f"Get mainstream data by id: {mainstream_id}")
            mainstream_dict = self.es.search(index=index,  body={
                "sort": {"date_created": "desc"},
                "query": {
                    "bool": {
                        "must": [
                            {
                                "match_phrase": {
                                    "mainstreamID": mainstream_id
                                }
                            }
                        ]
                    }
                },
                "size": 1
            })
            if mainstream_dict is not None:
                mainstream_versions = mainstream_dict["hits"]["hits"][0]["_source"]['data']
        except Exception as err:
            print("[Mainstream Versions] Encounting error: ", err)
        return mainstream_versions

    def get_sanity_test_data_by_id(self, build_id, index="interim_sanity"):
        """Get mainstream data by buildID.
        :type index: str
        :param index: The index of data.
        :type build_id: str
        :param build_id: The ID of mainstream build
        """
        print(f"Get mainstream data by id: {build_id}")
        mainstream_sanity_test_dict = self.es.search(index=index, body={
            "sort": {"date_created": "desc"},
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "buildID": build_id
                            }
                        }
                    ]
                }
            },
            "size": 1
        })

        return mainstream_sanity_test_dict['hits']['hits'][0]['_source']
