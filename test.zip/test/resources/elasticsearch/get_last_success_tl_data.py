import es_query
import argparse
import json

parser = argparse.ArgumentParser()

parser.add_argument(
    "-output_json",
    "--output-json",
    help="Specify the target output json path",
    required=True,
)
parser.add_argument(
    "-tl_name",
    "--tl-name",
    help="Specify the TL name",
    required=True,
)

# Parse input arguments
args = parser.parse_args()
OUTPUT_JSON = args.output_json
TL_NAME = args.tl_name

def main():
    # Query TL results
    ESQuery = es_query.ESQuery()
    last_success_tl_data = ESQuery.get_latest_success_data(TL_NAME)
    # Saving result to json file
    with open(OUTPUT_JSON, 'w') as json_file:
        json_file.write(json.dumps(last_success_tl_data))

if __name__ == "__main__":
    main()
