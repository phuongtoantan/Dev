# Loading resources

External libraries may load adjunct files from a resources/ directory using the libraryResource step. The argument is a relative pathname, akin to Java resource loading:

```sh
def request = libraryResource 'com/mycorp/pipeline/somelib/request.json'
```

The file is loaded as a string, suitable for passing to certain APIs or saving to a workspace using ```writeFile```.

It is advisable to use an unique package structure so you do not accidentally conflict with another library.

Folder Structure
```
+- resources               # resource files (external libraries only)
|   +- org
|       +- foo
|           +- bar.json    # static helper data for org.foo.Bar
```

## Python Example
 check it out under [python] 

 [python]: <>
 