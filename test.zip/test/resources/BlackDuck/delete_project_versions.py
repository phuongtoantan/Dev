# Copyright © 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.
'''
Delete list of blackduck project version by csv file
'''
import argparse
import csv
import logging
import sys
import re

from blackduck.HubRestApi import HubInstance

#Check if blackduck version is in exception list
def isInExceptionList(version_name, exception_list):
    for exception in exception_list:
        pattern = re.compile(exception)
        m = pattern.match(version_name)
        if m:
            return True
    return False

parser = argparse.ArgumentParser("A program that will delete multiple project-versions listed in a file")
parser.add_argument("--project_versions_file", required=True, help="A comma separated list of project-versions, one project-version per line")
parser.add_argument("--exception_list", default=None, help="A comma separated list of project-versions won't to remove")
args = parser.parse_args()

if args.exception_list:
    args.exception_list = args.exception_list.replace("[","").replace("]","").split(", ")
else:
    args.exception_list = []

logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

hub = HubInstance()

with open(args.project_versions_file) as csvfile:
    project_versions_reader = csv.reader(csvfile)
    for row in project_versions_reader:
        project_name = row[0]
        version_name = row[1]
        if not isInExceptionList(version_name, args.exception_list):
            print ("Removing: ", version_name)
            hub.delete_project_version_by_name(project_name, version_name)
        else:
            print (version_name, "--- Project version matched to exception list. Skipped")