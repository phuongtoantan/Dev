# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import requests
import json
import urllib3
from bs4 import BeautifulSoup

urllib3.disable_warnings()

class ConfluencePage:
    """This tool will support to get and update data in confluence page"""
    def __init__(self, user_name, password, page_id):
        self.headers = {'Content-Type' : 'application/json'}
        self.username = user_name
        self.password = password
        self.page_id = page_id
        self.cf_value = self.get_page_value()
        self.soup_cf_value = BeautifulSoup(self.cf_value, "html.parser")
        self.page_title = self.get_page_title()

    def get_page_value(self):
        """Get data from confluence page"""
        url = f'https://confluence.cec.lab.emc.com/rest/api/content/{self.page_id}?expand=body.storage'

        response = requests.get(url, verify=False, auth=(self.username, self.password))
        if response.status_code == 200:
            page_data = response.json()
            return page_data['body']['storage']['value'] #Return a string and it has the format of html
        else:
            print(response.status_code)
            return False
        
    def get_page_version(self):
        """Get current page version"""
        url = f'https://confluence.cec.lab.emc.com/rest/api/content/{self.page_id}'
        response = requests.get(url, verify=False, auth=(self.username, self.password))
        if response.status_code == 200:
            page_data = response.json()
            return int(page_data['version']['number'])
        else:
            print(response.status_code)
            return False
        
    def get_page_title(self):
        """Get page title"""
        url = f'https://confluence.cec.lab.emc.com/rest/api/content/{self.page_id}'
        response = requests.get(url, verify=False, auth=(self.username, self.password))
        if response.status_code == 200:
            page_data = response.json()
            return page_data['title']
        else:
            print(response.status_code)
            return False
        
    def update_value_on_page(self):
        """
            Update new value on confluence page

            Note: update self.soup_cf_version before using this function
        """
        url = f"https://confluence.cec.lab.emc.com/rest/api/content/{self.page_id}"
        
        new_data = {
            "version": {
                "number": self.get_page_version() + 1,
            },
            "title": self.page_title,
            "type": "page",
            "body": {
                "storage": {
                    "value": str(self.soup_cf_value),
                    "representation": "storage"
                }
            }
        }

        put_response = requests.put(url, auth=(self.username, self.password), data=json.dumps(new_data),verify=False, headers=self.headers)
        if put_response.status_code == 200:
            print("Page content updated successfully.")
        else:
            print(put_response)
            print("Failed to update page content.")

    def find_column_by_name_from_table(self, table, column_name):
        """
            Finding column by name in the table

            table (bs4 object): table contain column which it is needed to find
            column_name (str): column name
        """
        table_headers = table.find_all('th')

        for index, th in enumerate(table_headers):
            if th.text.strip() == column_name:
                return index
            
    def find_elements_by_style(self, value):
        """
            Finding elements have the same style in confluence page 

            value (str): style elements. Example: "color: rgb(0,0,255);"
        """
        return self.soup_cf_value.find_all(style=value) # Return list elements
            
    def find_table_in_confluence_page(self, table_number):
        """
            Finding table in confluence page 

            table_number (int): Table's number
        """
        try:
            return self.soup_cf_value.find_all('tbody')[table_number-1]
        except:
            print("Please check the table's number again!!!")
            return BeautifulSoup("", "html.parser")
    
    def update_elements_on_confluence_page_by_style(self, style, new_values):
        """
            Updating elements have the same style in confluence page 

            style (str): style elements. Example: "color: rgb(0,0,255);"
            new_values (listt bs4 object): new value
        """
        try:
            if len(self.soup_cf_value.find_all(style=style)) == len(new_values):
                for old_item, new_item in zip(self.soup_cf_value.find_all(style=style), new_values):
                    old_item = new_item
                self.update_value_on_page()
                return True
            else:
                print("Cannot update elements: Size of new value is not equal with cf")
                return False
        except:
            print("Update elements is failed")
            return False
    
    def get_row_index(self, table, col_index, name):
        """
            Getting row has column name is inputted

            table (bs4 object): What table contain row is wanted to find
            name (str): 
            col_index (int):
        """
        table_body_rows = table.find_all('tr')
        for index, row in enumerate(table_body_rows):
                item = row.find_all("td")
                if item:
                    if item[col_index].text.strip() == name:
                        return index

    def get_username_from_key(self, userkey):
        """
            Get username from userkey
            userkey (str): The userkey
        """
        user_name = ""
        url = f'https://confluence.cec.lab.emc.com/rest/api/user?key={userkey}'
        response = requests.get(url, verify=False, auth=(self.username, self.password))
        if response.status_code == 200:
            user_data = response.json()
            user_name = user_data['username']
        else:
            print(response.status_code)
        return user_name