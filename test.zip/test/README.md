# mp-jenkins-shared-lib

This repository houses Jenkins pipelines.

## Repo structure

```bash
.
├── CODEOWNERS
├── jenkins
├── Jenkinsfile
├── jenkins_job_builder
├── pull_request_template.md
├── README.md
├── resources
├── src
├── tools
└── vars
```

### Jenkins pipelines

- [**vars**](./vars/): Contains the Jenkins pipelines groovy scripts

### Jenkins libraries

- [**src**](./src/): Holds a collection of reusable libraries for Jenkins pipelines.

### Integration resources

- [**resources**](./resources/): Contains Python scripts/libraries for seamless integration with various services like GitHub, Jira, Elasticsearch, LDAP, Report, etc.

### Jenkins Job Builder

- [**jenkins_job_builder**](./jenkins_job_builder/): Stores Jenkins pipeline configurations as code in YAML.

### CI pipelines for DevOps repo

- [**Jenkinsfile**](./Jenkinsfile): Stores Jenkins CI pipeline for this repository

### Documentation

- [**docs**](./docs): Contains document for this repository
