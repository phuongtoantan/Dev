# Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
JJB_WORKSPACE="testing_jjb" # Change to your own value
JJB_CONTAINER_NAME="testing_jjb_cnt" # Change to your own value

# Clone code
cd $JJB_WORKSPACE
git clone -b main git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git mp-jenkins-shared-lib
cd mp-jenkins-shared-lib/jenkins/jobs/job_builder

# Pull latest code
git pull origin main

# Running buildah
buildah build --layers jjb_podman:latest .

# start container
podman run --privileged --rm --name $JJB_CONTAINER_NAME \
    -v $(pwd):/job_builder -it jjb_podman:latest bash

### Run these commands inside container

## ignore ssl
export PYTHONHTTPSVERIFY=0

cd /job_builder

## Review/Test Jenkins Jobs
jenkins-jobs --conf config/dev_jenkins.ini test jobs/example/test-pp.yaml

## Update Jenkins Jobs
jenkins-jobs -l debug --conf config/dev_jenkins.ini update jobs/example/sample-job.yaml
jenkins-jobs --conf config/dev_jenkins.ini update jobs/example/hello-pipeline.yaml

## List Jenkins jobs
jenkins-jobs -l debug --conf config/dev_jenkins.ini list "my-job"
jenkins-jobs -l debug --conf config/dev_jenkins.ini list "an*"
