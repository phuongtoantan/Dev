# Jenkins Job Builder Getting Started

## Overview

Jenkins Job Builder takes simple descriptions of Jenkins jobs in YAML or JSON format and uses them to configure Jenkins. You can keep your job descriptions in human readable text format in a version control system to make changes and auditing easier. It also has a flexible template system, so creating many similarly configured jobs is easy.

## Document

- Overview: https://jenkins-job-builder.readthedocs.io/en/latest/
- Install: https://jenkins-job-builder.readthedocs.io/en/latest/installation.html
- Usage: https://jenkins-job-builder.readthedocs.io/en/latest/execution.html#running
- See more documents at: [docs](../docs/)

## Quick start guide

- https://jenkins-job-builder.readthedocs.io/en/stable/quick-start.html

## Run Jenkins job builder

- On your machine: [run-jenkins-job-builder-vm.md](../docs/run-jenkins-job-builder-vm.md)
- With podman: [run-jenkins-job-builder-with-podman.md](../docs/run-jenkins-job-builder-with-podman.md)

## How to define the Jenkins job in YAML?

- See document: [Howto define a Jenkins job?](../docs/how-to.md)
