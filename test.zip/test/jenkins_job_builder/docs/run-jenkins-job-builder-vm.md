## Use Jenkins job builder on your machine
### Prerequisite

- python3 and pip installed
- jenkins-job-builder>=6.0.0 installed
- valid credential/server definition in `../config/*.ini`

### Clone code

```
cd $JJB_WORKSPACE
git clone -b main git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git mp-jenkins-shared-lib
cd mp-jenkins-shared-lib/jenkins_job_builder
```

#### Review/Test Jenkins Jobs

Run Jenkins Job Builder with `--conf config/dev_jenkins.ini` configuration to specify the target Jenkins server

```
jenkins-jobs --conf config/dev_jenkins.ini test jobs/example/test-pp.yaml
```

#### Update Jenkins Jobs

```
jenkins-jobs -l debug --conf config/dev_jenkins.ini update jobs/example/sample-job.yaml
jenkins-jobs --conf config/dev_jenkins.ini update jobs/example/hello-pipeline.yaml
```

#### List Jenkins jobs

```
jenkins-jobs -l debug --conf config/dev_jenkins.ini list "my-job"
jenkins-jobs -l debug --conf config/dev_jenkins.ini list "any*"
```

### Trouble shooting

#### ignore ssl

```export PYTHONHTTPSVERIFY=0
cd /job_builder
```
