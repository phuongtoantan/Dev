# Frequently Asked Questions

## Where do I find the job definitions document?

- Visit [docs/how-to-define-job.md](./docs/how-to-define-job.md)
- Job Definitions guide: https://jenkins-job-builder.readthedocs.io/en/stable/definition.html
