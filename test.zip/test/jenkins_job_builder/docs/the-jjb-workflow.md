## Jenkins job creation flow with JJB

Job configration flow for a normal Jenkins pipeline: `jenkins_job_builder/jobs`(job definition) -> `vars`(job logic)

1. Define the JJB YAML file under `mp-jenkins-shared-lib/jenkins_job_builder/jobs`
   ![](../docs/images/jjb_definition.png)
2. Define core pipeline steps via groovy script under `mp-jenkins-shared-lib/vars`
   ![](../docs/images/groovy-definition.png)
3. The DevOps CI pipeline will automatically pick up new change and update the Jenkins Jobs configuration whenever there has a new change in `jenkins_job_builder` folder merged to main
