# How to create/update Jenkins Jobs and Jenkins Views?

## Jobs

### 1. Define parameters with Jenkins job builder

- Doc: https://jenkins-job-builder.readthedocs.io/en/stable/parameters.html
- Example: [jobs/example/demo-params.yaml](../jobs/example/demo-params.yaml)

### 2. Define Jenkins pipeline job with Jenkins job builder

- Doc: https://jenkins-job-builder.readthedocs.io/en/stable/definition.html
- Example: [jobs/example/demo-pipeline.yaml](../jobs/example/demo-pipeline.yaml)

### 3. Define Jenkins freestyle job with Jenkins job builder

- Doc: https://jenkins-job-builder.readthedocs.io/en/stable/definition.html
- Example: [jobs/example/demo-freestyle.yaml](../jobs/example/demo-freestyle.yaml)

### 4. Define Jenkins multi-pipeline job with Jenkins job builder (work in progress)

- Doc: https://jenkins-job-builder.readthedocs.io/en/stable/definition.html
- (NOT READY) Example: [jobs/example/demo-multibranch-pipeline.yaml](../jobs/example/demo-multibranch-pipeline.yaml)

## Views

### 1. Define Jenkins View with Jenkins job builder

- Doc: https://jenkins-job-builder.readthedocs.io/en/stable/definition.html#views
- Example: [views/example/demo_view.yaml](../views/example/demo_view.yaml)
