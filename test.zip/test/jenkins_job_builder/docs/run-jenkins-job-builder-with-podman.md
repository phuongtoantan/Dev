## Use Jenkins job builder with podman

### Prerequisite

- podman and buildah installed
- valid credential/server definition in `../config/*.ini`

### Clone code and build the image

```
cd $JJB_WORKSPACE
git clone -b main git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git mp-jenkins-shared-lib
cd mp-jenkins-shared-lib/jenkins_job_builder

git pull origin main
buildah build --layers jjb_podman:latest .
```

### Start container

```
podman run --privileged --rm --name $JJB_CONTAINER_NAME \
 -v $(pwd):/jenkins_job_builder -it jjb_podman:latest bash
```

### Run these commands inside container

#### ignore ssl

```export PYTHONHTTPSVERIFY=0
cd /jenkins_job_builder
```

#### Review/Test Jenkins Jobs

Run Jenkins Job Builder with `--conf config/dev_jenkins.ini` configuration to specify the target Jenkins server

```
jenkins-jobs --conf config/dev_jenkins.ini test jobs/example/test-pp.yaml
```

#### Update Jenkins Jobs

```
jenkins-jobs -l debug --conf config/dev_jenkins.ini update jobs/example/sample-job.yaml
jenkins-jobs --conf config/dev_jenkins.ini update jobs/example/hello-pipeline.yaml
```

#### List Jenkins jobs

```
jenkins-jobs -l debug --conf config/dev_jenkins.ini list "my-job"
jenkins-jobs -l debug --conf config/dev_jenkins.ini list "any*"
```
