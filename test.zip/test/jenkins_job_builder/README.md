# Jenkins Job Builder

Jenkins jobs configuration as code for MP project

## What is Jenkins Job Builder?

Jenkins Job Builder takes simple descriptions of Jenkins jobs in YAML or JSON format and uses them to configure Jenkins. You can keep your job descriptions in human readable text format in a version control system to make changes and auditing easier. It also has a flexible template system, so creating many similarly configured jobs is easy.

## Getting started

- Official website: [**jenkins-job-builder.readthedocs.io**](https://jenkins-job-builder.readthedocs.io/en/stable/)
- Repository: https://opendev.org/jjb/jenkins-job-builder
- To get started with Jenkins Job builder, visit [**docs/getting_started.md**](./docs/getting_started.md)

## Project tree

```bash
jenkins_job_builder
├───config
├───docs
├───jobs
│   ├───cu # for CU jobs
│   ├───devops # for DevOps jobs
│   ├───du # for DU jobs
│   ├───example  # for example/demo jobs
│   ├───...  # for other jobs
│   └───release # for jobs in multiple streams
│       ├───mainstream # Mainstream jobs
│       └───sidestream_1 # Another stream jobs
│       └───sidestream_2 # Another stream jobs
├───template
└───views
    ├───cu # for CU views
    ├───devops # for DevOps views
    ├───du # for DU views
    ├───example # for example views
    └───release # for jobs in multiple stream/release views
```

Project tree description

- [**config**](./config/): Contains the configuration to integrate with Jenkins server (both dev and prod Jenkins instances)
- [**jobs**](./jobs/): Contains all the Jenkins job definitions for MP projects. Separated by components/area/stream (e.g: cu/du/release/...)
- [**views**](./views/): Contains all the Jenkins views for MP projects. Separated by components/area (e.g: cu/du/release/...)
- [**docs**](./docs/): Contains document for the Jenkins Job Builder usage

## Jenkins pipeline flow with JJB

- Pipeline configurations: `mp-jenkins-shared-lib/jenkins_job_builder/jobs` -> Pipeline logic: `mp-jenkins-shared-lib/vars`
- Detailed at: [docs/the-jjb-workflow.md](./docs/the-jjb-workflow.md)

## Jenkins Job Builder CI pipelines

To understand the automated workflow, read this Confluence page: https://confluence.cec.lab.emc.com/x/7c8cXw

## How to define/update a Jenkins job in YAML?

- Visit [docs/how-to-define-job.md](./docs/how-to-define-job.md)
- Job Definitions guide: https://jenkins-job-builder.readthedocs.io/en/stable/definition.html

## How to propose change in Jenkins jobs/views configuration?

1. Create or update the JJB YAML file under [**jenkins_job_builder/jobs**](./jobs/) or [**jenkins_job_builder/views**](./views/)
2. Update related code under [**vars**](../vars/) if needed
3. Create a new pull request on `mp-jenkins-shared-lib` repo

The `Jenkins-Job-Builder` job will the validate the job definition on PR, and update the Jenkins jobs on merge event in to main branch. Visit this Confluence page: https://confluence.cec.lab.emc.com/x/7c8cXw

## How to test the change in jenkins_job_builder?

To make sure we don't accidentally mess up all the important Jenkins jobs with changes from our private work, we've put a rule in place. Now, when someone uses the Jenkins-Job-Builder-ForTesting on their private branch, it will only update jobs that start with "TRIAL-". This way, only the test jobs get updated, keeping our main jobs safe from any accidental changes. Please follow these steps to test your pipeline change:

1. **Naming Convention Adjustment**:

   - Add the prefix "TRIAL-" to the official job name in the YAML file. For example, if the original job name is "Job-Official" in the YAML, adjust it to "TRIAL-Job-Official".

2. **Pipeline Update**:

   - Update any related pipelines to accommodate the trial job, if necessary.

3. **Triggering Jenkins Job Builder**:

   - Trigger the [**Jenkins-Job-Builder-ForTesting**](https://osj-phm-02-prd.cec.delllabs.net/job/Jenkins-Job-Builder-ForTesting/) job using your PR branch.
   - Select the `update` action to initiate the process.

4. **Creation of Test Job**:

   - The triggered Jenkins job will create a new test job for you. You can then commence testing the new changes using this job.

5. **Result Attachment**:

   - Once testing is completed, attach the test results to the corresponding Pull Request (PR).

6. **Review Process**:

   - After the review process is concluded, revert the trial job name ("TRIAL-Job-Official") back to its original name ("Job-Official") before merging.

7. **Merging and Post-Merge Cleanup**:
   - Merge the PR into the `main` branch.
   - Upon successful merge, delete the trial job ("TRIAL-Job-Official") to maintain job consistency.

## Frequently Asked Questions

Visit [**docs/faq.md**](./docs/faq.md)
