# MP Jenkins Jobs

This folder contains all Jenkins jobs using in MP project

## Document

- Visit [**this document**](../docs/) to see how to define/update a Jenkins job

## Testing your change

- Add the "**TRIAL**" prefix to the job that you want to test, for example: `RUN-CU-TEST` -> `TRIAL-RUN-CU-TEST`
- Then trigger job [**Jenkins-Job-Builder-ForTesting**](https://osj-phm-02-prd.cec.delllabs.net/job/Jenkins-Job-Builder-ForTesting/) with your PR branch and choose the `update` action
  ![trigger_test_job](../assets/trigger_test_job.png)
- It will create a new test job for you then you can start to testing the new changes
- Once the review process is completed, revert back to official name, for example: `TRIAL-RUN-CU-TEST` -> `RUN-CU-TEST`. Then merge the PR
- Remember to delete the `TRIAL-RUN-CU-TEST` job when the PR is merged
