# Sample JJB definition

## Overview

- To get started with Jenkins job builder

## Start

Navigate to jenkins\jobs\jjb, then

```
cd jjb
jenkins-jobs --conf ./jenkins-server-config.yaml update example "poc_pipeline_project*"
```

## Example

- https://jenkins-job-builder.readthedocs.io/en/latest/project_pipeline.html

### List jobs

- `jenkins-jobs --conf ./jenkins_jobs.ini list example/test-pp.yaml my-job`

## Ignore SSL

`export PYTHONHTTPSVERIFY=0`
## Enable debug log
jenkins-jobs -l debug --conf ./jenkins_jobs.ini update example my-job
