# Release stream pipelines

This folder contains all the Jenkins pipelines for multiple streams.

## Structure

All pipelines for each stream are grouped into separate folders.

- [developstream](./developstream/): Contains all pipelines for the DevlopStream
- [mainstream](./mainstream/): Contains all pipelines for the Mainstream

## Logic

- All jobs with the same responsibility under the stream will use the same Groovy scripts that support multi-stream functionality.
- For example, `CU_Developstream_Build` and `CU_Mainstream_Build` will call the script `CU_Multistream_Build.groovy` with different `STREAM_NAME` parameters.
