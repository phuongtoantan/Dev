# Installation and Setup Guide for Ansible and Metricbeat

## 1. Install Ansible (if not already installed)

Refer to the official Ansible installation guide for detailed instructions: [Ansible Installation Guide](https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html)

You can install Ansible using `pip` with the following command:

```bash
pip install --user ansible
```

## 2. Prepare the Inventory File

### For Manual Execution

1. Create a new `inventory.ini` file.
2. Copy the contents of `inventory.ini.sample` into the new `inventory.ini` file.
3. Adjust the host and credential settings in the `inventory.ini` file according to your requirements.

### For Jenkins Pipeline Execution

The Jenkins pipeline will automatically generate the inventory file based on Jenkins agent information, so there's no need to perform this step manually.

## 3. Execute Ansible Playbook

Ensure that the `inventory.ini` file is properly configured, and then run the following command:

```bash
ansible-playbook -v install_metric_beat.yml -i inventory.ini \
-e jenkins_agent_name=FR-R740-VM-1164 -e 'jenkins_agent_labels=[CU-UT-RHEL8,debug_monitoring]'
```

## 4. Alerting configuration

Visit [tools/elastalert](../../../../../tools/elastalert/)

## Metricbeat Reference

For more information about Metricbeat configuration, consult the official Metricbeat reference documentation: [Metricbeat Reference](https://www.elastic.co/guide/en/beats/metricbeat/current/metricbeat-reference-yml.html)

## Debugging a Service

If you encounter issues with Metricbeat, you can view its logs for troubleshooting. Run the following command to display the last 100 log entries without paging:

```bash
sudo journalctl -u metricbeat.service -n 100 --no-pager
```
