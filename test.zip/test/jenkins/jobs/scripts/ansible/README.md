# Jenkins agent provisioning using Ansible

## Prerequisites:

### Ansible code:

- Checkout ansible-playbook: `git clone git@eos2git.cec.lab.emc.com:Mobile-Phoenix/mp-jenkins-shared-lib.git`
- Navigate to ansible working directory: `cd mp-jenkins-shared-lib/jenkins/jobs/scripts/ansible`

### Tool and dependencies:

- Install ansible:
  `sudo yum install epel-release; sudo yum install ansible`
- Install community.general plugin by execute command:
  `ansible-galaxy collection install community.general`
- Compose your own inventory file and organize hosts as groups, refer to: `jenkins-agent/terryfox.ini`
- Install posix.mount for mounting to NFS:
  `ansible-galaxy collection install ansible.posix`
## 1-Install necessary dependencies and tools for new jenkins agent.

- Navigate to your target agent folder: `cd jenkins-agent/common`
- Update password for jenkins user in provision_jenkins_node.yaml file (replace "PASSWORD HERE" to password string that you would like to set for jenkins user)
- Execute below command to install libraries: `ansible-playbook -v provision_jenkins_node.yaml -i inventory.init`

## 2-Install extra dependencies for specific jenkins agent labels (e.g: e2e-test, cu-ut, du-ct, ...).

- Navigate to your target agent folder: `cd jenkins-agent/e2e-test`
- Update agent IP/username/password inventory file (for example: e2e_test_inventory.init)
- Execute below command to install extra dependencies: `ansible-playbook -v e2e_test_playbook.yaml -i e2e_test_inventory.init`

## 3-Install extra modules and modify OS kernel settings for oam jenkins agents.

- Navigate to your target agent folder: `cd jenkins-agent/oam`
- Update agent IP/username/password inventory file (for example: oam_inventory.init)
- Execute below command to install extra dependencies:  `ansible-playbook -v oam_playbook.yaml -i oam_inventory.init`

## 4-CU UT agent provisioning

- Utilize ansible-playbook to provision CUUT agents, navigate to `jenkins-agent` dir then run:  
  ```
  ansible-playbook -i terryfox.ini -v provision_cuut.yaml -l <Agent-Name>
  ```
- Mount CUUT workspace to NFS:
  ```
  ansible-playbook -i terryfox.ini -v NFS-CUUT.yaml -l <Agent-Name>
  ```
  For `Agent-Name`, refer to terryfox.ini file
## 5-Radiosw yocto agent provisioning - don't need to run common function
- Navigate to your target agent folder: `cd jenkins-agent/radiosw-yocto`
- Update agent IP/username/password inventory file (for example: radiosw_inventory.init)
- Execute below command to install extra dependencies:  `ansible-playbook -v radiosw_yocto_playbook.yaml -i radiosw_inventory.init`