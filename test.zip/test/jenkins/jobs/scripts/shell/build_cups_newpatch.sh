
#!/bin/bash
set -ex
########################################################################################################
# Name     : build_cups_newpatch.sh
# Usage    : ./build_cups_newpatch.sh <Jenkins Workspacke/Git Repo Clone> <Build Variants> <Branch> [GNB_CU_CP_IMAGE] [GNB_CU_UP_IMAGE]
# Example  : ./build_cups_newpatch.sh /home/jenkins/gNB_CU dpdk main
########################################################################################################

usage() {
        echo "Usage   : $0 <Jenkins Workspacke/Git Repo Clone> <Build Variants> <Branch> [GNB_CU_CP_IMAGE] [GNB_CU_UP_IMAGE]"
        echo "Example : ./build_cups_newpatch.sh /home/jenkins/gNB_CU dpdk main"
        echo "Supported build variants are no_dpdk, nodpdk_crypto & dpdk"
        exit 1
}

#Prepare env for build and run build
if [ $# -lt 3 ]; then
        echo "Error: Invocation of script '$0' requires 3 mandatory parameters."
        usage
fi

if [ ! -d "$1" ]; then
        echo "Error: No such file or directory $1"
        usage
fi

if [ "$2" = "" ];then
        echo "Parameter 2: dpdk or no_dpdk manadatory"
        usage
fi

export DOCKER_BUILDKIT=1
eval "$(ssh-agent -s)"

#Add key for specific host
ssh-add

timeStamp=$(date +%s)

#Setup tag
DOCKER_TAG=""

if [ "$3" != "main" ];then
        DOCKER_TAG=":$3"
        #Change to lower case and replace / with _ in the branch tag
        DOCKER_TAG=`echo $DOCKER_TAG | awk '{print tolower($0)}'| sed -e "s/\//_/g"`
        echo "Docker tag : $DOCKER_TAG"
fi


cd $1/containers
pwd

#Copy confd
wget -r -np -R 'index.html*' --no-check-certificate -nH --cut-dirs=4 \
     https://phm.artifactory.cec.lab.emc.com/artifactory/list/mobile-phoenix-ran-external/confd-basic-7.3.3/confd-basic-7.3.3.linux.x86_64.zip

ls -ltr;pwd

#Build GCC
docker build --target=gcc_5.4 -t gcc_5.4 -f build_cu.dockerfile .
#Build cu_tools
docker build --target=cu_tools -t cu_tools -f build_cu.dockerfile .

case "$2" in
        "dpdk")
                #Run build commands dpdk - default
                echo "Building dpdk...."

                #CUCP
                docker build --ssh default --build-arg KERNEL_VER=3.10.0-693.2.2.rt56.623.el7.x86_64 --build-arg BRANCH=$3 --build-arg CU_FLAGS="-o -c -d" --build-arg USECACHE=$(date +%s) --target=build_cu_cp -t gnb_cu_cp_crypto_fpp_dev$DOCKER_TAG -f build_cu.dockerfile .
                #Extract tar file
                docker create --name cu_cp_dpdk_prod$timeStamp gnb_cu_cp_crypto_fpp_dev$DOCKER_TAG
                docker cp cu_cp_dpdk_prod$timeStamp:/phoenix/5gran/cu/build/cucp_build.tar.gz $1
                docker cp cu_cp_dpdk_prod$timeStamp:/phoenix/5gran/cu/build/cucp_time.txt $1
                if grep 'build_cucp.log' build_cu.dockerfile; then
                        docker cp cu_cp_dpdk_prod$timeStamp:/phoenix/5gran/cu/build/build_cucp.log $1
                fi
                docker rm cu_cp_dpdk_prod$timeStamp

                #CUUP
                docker build --ssh default --build-arg KERNEL_VER=3.10.0-693.2.2.rt56.623.el7.x86_64 --build-arg BRANCH=$3 --build-arg CU_FLAGS="-o -c -d" --build-arg USECACHE=$(date +%s) --target=build_cu_up -t gnb_cu_up_crypto_fpp_dev$DOCKER_TAG -f build_cu.dockerfile .

                docker create --name cu_up_dpdk_prod$timeStamp gnb_cu_up_crypto_fpp_dev$DOCKER_TAG
                docker cp cu_up_dpdk_prod$timeStamp:/phoenix/5gran/cu/build/cuup_build.tar.gz $1
                docker cp cu_up_dpdk_prod$timeStamp:/phoenix/5gran/cu/build/cuup_time.txt $1
                if grep 'build_cuup.log' build_cu.dockerfile; then
                        docker cp cu_up_dpdk_prod$timeStamp:/phoenix/5gran/cu/build/build_cuup.log $1
                fi
                docker rm cu_up_dpdk_prod$timeStamp

                ls -ltr
        ;;
        "no_dpdk")
                DOCKER_CU_CP_IMAGE_NAME="${4:-gnb_cu_cp_dev}"
                DOCKER_CU_UP_IMAGE_NAME="${5:-gnb_cu_up_dev}"

                #Run build commands no dpdk
                echo "Building no_dpdk...."

                #CUCP
                docker build --ssh default --build-arg KERNEL_VER=3.10.0-693.2.2.rt56.623.el7.x86_64 --build-arg BRANCH=$3 --build-arg CU_FLAGS="-o -s -l" --build-arg USECACHE=$(date +%s) --target=build_cu_cp -t $DOCKER_CU_CP_IMAGE_NAME$DOCKER_TAG -f build_cu.dockerfile .

                #Extract tar file
                docker create --name cu_cp_prod$timeStamp $DOCKER_CU_CP_IMAGE_NAME$DOCKER_TAG
                docker cp cu_cp_prod$timeStamp:/phoenix/5gran/cu/build/cucp_build.tar.gz $1
                docker cp cu_cp_prod$timeStamp:/phoenix/5gran/cu/build/cucp_time.txt $1
                if grep 'build_cucp.log' build_cu.dockerfile; then
                        docker cp cu_cp_prod$timeStamp:/phoenix/5gran/cu/build/build_cucp.log $1
                fi
                docker rm cu_cp_prod$timeStamp

                #CUUP
                docker build --ssh default --build-arg KERNEL_VER=3.10.0-693.2.2.rt56.623.el7.x86_64 --build-arg BRANCH=$3 --build-arg CU_FLAGS="-o -s -l" --build-arg USECACHE=$(date +%s) --target=build_cu_up -t $DOCKER_CU_UP_IMAGE_NAME$DOCKER_TAG -f build_cu.dockerfile .

                #Extract tar file
                docker create --name cu_up_prod$timeStamp $DOCKER_CU_UP_IMAGE_NAME$DOCKER_TAG
                docker cp cu_up_prod$timeStamp:/phoenix/5gran/cu/build/cuup_build.tar.gz $1
                docker cp cu_up_prod$timeStamp:/phoenix/5gran/cu/build/cuup_time.txt $1
                if grep 'build_cuup.log' build_cu.dockerfile; then
                        docker cp cu_up_prod$timeStamp:/phoenix/5gran/cu/build/build_cuup.log $1
                fi
                docker rm cu_up_prod$timeStamp

                ls -ltr
        ;;
        "nodpdk_crypto")
                echo "Building cu with only crypto.."

                #CUCP
                docker build --ssh default --build-arg KERNEL_VER=3.10.0-693.2.2.rt56.623.el7.x86_64 --build-arg BRANCH=$3 --build-arg CU_FLAGS="-o -c" --build-arg USECACHE=$(date +%s) --target=build_cu_cp -t gnb_cu_cp_crypto_dev$DOCKER_TAG -f build_cu.dockerfile .
                #Extract tar file
                docker create --name cu_cp_prod$timeStamp gnb_cu_cp_crypto_dev$DOCKER_TAG
                docker cp cu_cp_prod$timeStamp:/phoenix/5gran/cu/build/cucp_build.tar.gz $1
                docker cp cu_cp_prod$timeStamp:/phoenix/5gran/cu/build/cucp_time.txt $1
                docker rm cu_cp_prod$timeStamp


                #CUUP
                docker build --ssh default --build-arg KERNEL_VER=3.10.0-693.2.2.rt56.623.el7.x86_64 --build-arg BRANCH=$3 --build-arg CU_FLAGS="-o -c" --build-arg USECACHE=$(date +%s) --target=build_cu_up -t gnb_cu_up_crypto_dev$DOCKER_TAG -f build_cu.dockerfile .

                #Extract tar file
                docker create --name cu_up_prod$timeStamp gnb_cu_up_crypto_dev$DOCKER_TAG
                docker cp cu_up_prod$timeStamp:/phoenix/5gran/cu/build/cuup_build.tar.gz $1
                docker cp cu_up_prod$timeStamp:/phoenix/5gran/cu/build/cuup_time.txt $1
                docker rm cu_up_prod$timeStamp

                ls -ltr
        ;;
esac
