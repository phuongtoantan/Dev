#!/bin/bash
# File name: build_oam_ib.sh
#
# Authors:
#    Suditi Antahal
#
# Copyright (c) 2023-2024 Dell Inc. or its subsidiaries.
# All Rights Reserved.
#
# This software contains the intellectual property of Dell Inc. or is licensed to Dell
# Inc. from third parties. Use of this software and the intellectual property contained
# therein is expressly limited to the terms and conditions of the License Agreement
# under which it is provided by or on behalf of Dell Inc. or its subsidiaries.
#
set -ex

helpFunction() {
    echo ""
    echo "Usage: $0 -w <Jenkins Workspacke/Git Repo Clone> -v <UBI base version> -n <NGP branch> -o <OAM branch> -y <yang model branch> -N <Node Controller branch> -t <image tag> -a"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-v Specify the oam_ubi base version"
    echo -e "\t-b Specify the PR branch"
    echo -e "\t-s Specify the SIMULATOR branch"
    echo -e "\t-i Specify the API branch"
    echo -e "\t-d Specify the DU branch"
    echo -e "\t-c Specify the CU branch"
    echo -e "\t-n Specify the NGP branch"
    echo -e "\t-o Specify the OAM branch"
    echo -e "\t-y Specify the yang model branch"
    echo -e "\t-N Specify the Node Controller branch"
    echo -e "\t-t Specify the image tag"
    echo -e "\t-a To setup OAMA deployment environment"
    echo -e "\t-C To setup container name"
    echo ""
    exit 1
}

build_args=
build_oama=false
container_name="oam_dev_img"
# Get input parameters
while getopts "w: v: s: b: i: d: c: n: o: y: N: t: C:: a" opt; do
    case "$opt" in
    w) WORKSPACE="$OPTARG" ;;
    v) [ -z "$OPTARG" ] || build_args+=" --build-arg UBI_VERSION=$OPTARG" ;;
    b) [ -z "$OPTARG" ] || build_args+=" --build-arg BRANCH=$OPTARG" ;;
    s) [ -z "$OPTARG" ] || build_args+=" --build-arg OAM_NODE_SIMULATOR_BRANCH=$OPTARG" ;;
    i) [ -z "$OPTARG" ] || build_args+=" --build-arg API_BRANCH=$OPTARG" ;;
    d) [ -z "$OPTARG" ] || build_args+=" --build-arg DU_BRANCH=$OPTARG" ;;
    c) [ -z "$OPTARG" ] || build_args+=" --build-arg CU_BRANCH=$OPTARG" ;;
    n) [ -z "$OPTARG" ] || build_args+=" --build-arg NGP_BRANCH=$OPTARG" ;;
    o) [ -z "$OPTARG" ] || build_args+=" --build-arg OAM_BRANCH=$OPTARG" ;;
    y) [ -z "$OPTARG" ] || build_args+=" --build-arg YANG_MODEL_BRANCH=$OPTARG" ;;
    N) [ -z "$OPTARG" ] || build_args+=" --build-arg NODE_CONTROLLER_BRANCH=$OPTARG" ;;
    t) TMP_IMAGE_TAG="$OPTARG" ;;
    a) build_oama=true ;;
    C) container_name="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ ! -d "$WORKSPACE" ]; then
    echo "Error: No such file or directory $WORKSPACE"
    helpFunction
fi

cd $WORKSPACE/gNB_platform/containers/oam
#TIME_STAMP=$(date +%N)
CACHE_OPTION="--no-cache"
GBI_IMAGE=${GBI_IMAGE:='phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gbi:latest'}

ls -ltr
pwd
echo -n "$GIT_ACCOUNT" >gitsecret.txt

#Pull required base images
podman pull "${GBI_IMAGE}"

#setup OAM environment
echo "Building OAM environment stage..."

rm -rf "$WORKSPACE"/oam-node-simulator
mkdir -p "$WORKSPACE"/oam-node-simulator

#Update OAM UBI base image in buildah_oam.dockerfile
if [ -n "$OAM_UBI_IMAGE" ] ; then
    sed -i "s|FROM .* AS oam_env|FROM $OAM_UBI_IMAGE AS oam_env|" buildah_oam.dockerfile
fi

buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --volume "$WORKSPACE"/oam-node-simulator:/phoenix \
    $build_args \
    --target oam_env -t oam_env:$TMP_IMAGE_TAG \
    -f buildah_oam.dockerfile .

echo "Building ib compilation stage..."
buildah containers
buildah images

pwd; ls -ltr;

/opt/incredibuild/bin/ib_podman run --privileged --rm --name ${container_name}_${TMP_IMAGE_TAG} \
    --volume "$WORKSPACE"/oam-node-simulator:/phoenix \
    oam_env:$TMP_IMAGE_TAG \
    bash -c "cd /phoenix; chmod +x build.sh; ib_console --no-cgroups ./build.sh -j200 -c"

if [ "$build_oama" = true ]; then
    echo "Building OAMA deployment environment..."
    buildah images
    buildah build --no-cache --from oam_env:$TMP_IMAGE_TAG --format docker \
        --volume "$WORKSPACE"/oam-node-simulator:/phoenix \
        --target oama_deployment_env -t oama_deployment_env:$TMP_IMAGE_TAG \
        -f buildah_oama_deployment_env.dockerfile .
    buildah from --name oama_deployment_env_$TMP_IMAGE_TAG oama_deployment_env:$TMP_IMAGE_TAG
    buildah copy oama_deployment_env_$TMP_IMAGE_TAG $WORKSPACE/oam-node-simulator /phoenix
    buildah copy oama_deployment_env_$TMP_IMAGE_TAG $WORKSPACE/gNB_platform/containers/oam/SoftwareVersionData.h /phoenix/gNB_ngp/version/gen/SoftwareVersionData.h
    buildah commit oama_deployment_env_$TMP_IMAGE_TAG oama_deployment_env:$TMP_IMAGE_TAG
    buildah images | egrep "oama_deployment_env +$TMP_IMAGE_TAG"
    echo "oama_deployment_env stage built successfully."
    buildah rm oama_deployment_env_$TMP_IMAGE_TAG
    buildah rmi oam_env:$TMP_IMAGE_TAG
fi


buildah containers
buildah images
