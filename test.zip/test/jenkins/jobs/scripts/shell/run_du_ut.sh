## Copyright (c) 2017-2023 Dell Inc. or its subsidiaries. All Rights Reserved.
#!/bin/bash
set -ex

helpFunction() {
    echo ""
    echo "Usage: $0 -w <Jenkins Workspace>  -i <DU UT container Image> -c <Container name> --pre-ci"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-i Specify the DU UT container image"
    echo -e "\t-c Specify the container name"
    echo -e "\t--pre-ci To execute only pre-ci test cases"
    echo ""
    exit 1
}

PRE_CI_OPT=""
# Get input parameters
while getopts "w: i: c: -:" opt; do
    case "$opt" in
    w) WORKSPACE="$OPTARG" ;;
    i) DU_UT_IMAGE="$OPTARG" ;;
    c) DU_UT_CONTAINER="$OPTARG" ;;
    -)  [[ "$OPTARG" == "pre-ci" ]] && PRE_CI_OPT="--$OPTARG" || helpFunction ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ ! -d "$WORKSPACE" ]; then
    echo "Error: No such file or directory $WORKSPACE"
    helpFunction
fi

if [ -z "$DU_UT_IMAGE" ]; then
    echo "DU docker image name is manadatory"
    helpFunction
fi

if [ -z "$DU_UT_CONTAINER" ]; then
    echo "DU UT container name is manadatory"
    helpFunction
fi

# Identify DU UT build path
du_ut_path=/phoenix/gNB_DU/build/du_ut
sudo podman run --rm --privileged --security-opt label=disable --name $DU_UT_CONTAINER $DU_UT_IMAGE bash -c "[[ -d /phoenix/gNB_DU/build/ut ]]" && du_ut_path=/phoenix/gNB_DU/build/ut
echo "value of du_ut_path: $du_ut_path"
sudo podman run -d --privileged --ulimit core=-1 --security-opt label=disable --name $DU_UT_CONTAINER \
    $DU_UT_IMAGE /usr/sbin/init
# Define coredump location in core_pattern file
sudo podman exec $DU_UT_CONTAINER bash -c  "echo "$du_ut_path/du_bin/bin/coredump/core-%e-%p" | tee /proc/sys/kernel/core_pattern"
cat /proc/sys/kernel/core_pattern
sudo podman ps
# Create coredump directory on container to store core files
sudo podman exec $DU_UT_CONTAINER bash -c "cd $du_ut_path/du_bin/bin; mkdir coredump"
cat /proc/sys/kernel/core_pattern
# Run ConfD and start UT TCs
sudo podman exec -t $DU_UT_CONTAINER bash /phoenix/gNB_DU/tools/scripts/start_du_ut.sh $PRE_CI_OPT
echo "Test completed!"
exit 0
