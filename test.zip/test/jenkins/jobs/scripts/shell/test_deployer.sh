#!/bin/bash
# File name: deploy.sh
#
# Authors:
#
# Copyright (c) 2024 Dell Inc. or its subsidiaries.
# All Rights Reserved.

set -ex

helpFunction() {
    echo ""
    echo "Usage: $0 -h <target list> -t <testline name> -g <tags> -s"
    echo -e "\t-h Specify list of target hosts"
    echo -e "\t-t Specify testline name"
    echo -e "\t-g Specify tags"
    echo -e "\t-s In case of skipping undeploy"
    echo -e "\t-d In case of skipping deploy"
    echo ""
    exit 1
}
SKIP_UNDEPLOY="false"
SKIP_DEPLOY="false"
TAGS="install_only"

# USER and PASSWORD should be exported as environment variables

while getopts "h:t:g:sd" opt; do
    case "$opt" in
    t) TL_NUMBER="$OPTARG" ;;
    h) HOST_TARGET_LIST="$OPTARG" ;;
    g) TAGS="$OPTARG" ;;
    s) SKIP_UNDEPLOY="true" ;;
    d) SKIP_DEPLOY="true" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ -z "$TL_NUMBER" ]; then
    echo "No TL number specified"
    helpFunction
fi

# Update known host file and configure SSH connection
for TARGET in $HOST_TARGET_LIST; do
    ssh-keyscan -H $TARGET >> ~/.ssh/known_hosts
    sshpass -p $PASSWORD ssh -o StrictHostKeyChecking=no $USER_NAME@$TARGET "sudo chown -R svc_jenkins:svc_jenkins /home/svc_jenkins && chmod 700 /home/svc_jenkins && chmod 700 /home/svc_jenkins/.ssh && chmod 600 /home/svc_jenkins/.ssh/authorized_keys"
    sshpass -p $PASSWORD ssh-copy-id -o ConnectTimeout=60 -o StrictHostKeyChecking=no -i ~/.ssh/id_ed25519.pub $USER_NAME@$TARGET
    scp -o StrictHostKeyChecking=no -i ~/.ssh/id_ed25519 ~/.ssh/netconf.rsa $USER_NAME@$TARGET:~/netconf.rsa
    scp -o StrictHostKeyChecking=no -i ~/.ssh/id_ed25519 ~/.ssh/netconf.rsa.pub $USER_NAME@$TARGET:~/netconf.rsa.pub
    ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_ed25519 $USER_NAME@$TARGET "sudo mkdir -p /data/E2E/netconf/ && sudo mv ~/netconf.rsa ~/netconf.rsa.pub /data/E2E/netconf/ && sudo chmod 755 /data/E2E/netconf && sudo chmod 755 /data/E2E/netconf/netconf.rsa /data/E2E/netconf/netconf.rsa.pub"
done

# Prepare netconf keys for deployer too
cd deployer/gNB_deployer
cp ~/.ssh/netconf.rsa configs/keys/netconf/rsa
cp ~/.ssh/netconf.rsa.pub configs/keys/netconf/rsa.pub

# Undeploy
cat inventory/$TL_NUMBER.yml
if [ "$SKIP_UNDEPLOY" == "true" ] || [ "$TAGS" == "run_only" ]; then
   echo "Skip undeploy...."
else
   ansible-playbook -i inventory/$TL_NUMBER.yml -v undeploy.yml
fi

# Deploy
if [ "$SKIP_DEPLOY" == "true" ]; then
   echo "Skip deploy...."
else
   if [ "$TAGS" == "run_only" ]; then
      
      ansible-playbook -i inventory/$TL_NUMBER.yml -v deploy.yml
   else
      ansible-playbook -i inventory/$TL_NUMBER.yml --tags "$TAGS" -v deploy.yml
   fi
fi