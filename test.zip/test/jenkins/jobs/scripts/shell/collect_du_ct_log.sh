## Copyright (c) 2017-2023 Dell Inc. or its subsidiaries. All Rights Reserved.

#!/bin/bash
helpFunction() {
    echo ""
    echo "Usage: $0 -w <Jenkins Workspace>  -c <Container name>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-c Specify the container name"
    echo ""
    exit 1
}

# Get input parameters
while getopts "w: c:" opt; do
    case "$opt" in
    w) WORKSPACE="$OPTARG" ;;
    c) DU_CT_CONTAINER="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done
set +ex
#Collect DU CT logs and coredump from running container
sudo podman exec $DU_CT_CONTAINER bash -c 'pwd;ls -l'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l $PATH_TO_DU_TEST_CODE/lib/5gtools/DU_TESTER/'
sudo podman exec $DU_CT_CONTAINER bash -c 'mkdir -p /upperstub_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l $PATH_TO_DU_TEST_CODE/lib/5gtools/DU_TESTER/UpperStub/build/; cp $PATH_TO_DU_TEST_CODE/lib/5gtools/DU_TESTER/UpperStub/build/Upperstub_*.log /upperstub_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'mkdir -p /lowerstub_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l $PATH_TO_DU_TEST_CODE/lib/5gtools/DU_TESTER/LowerStub/; cp $PATH_TO_DU_TEST_CODE/lib/5gtools/DU_TESTER/LowerStub/Lowerstub_*.log /lowerstub_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'mkdir -p /du_log'
echo "finding the binary for corefile"
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -ltr $PATH_TO_DU_CODE/5gran/du/build/pal/'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l $PATH_TO_DU_CODE/5gran/du/build/pal/du_bin'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l $PATH_TO_DU_CODE/5gran/du/build/pal/du_bin/bin/duStatsLog_*.csv; cp $PATH_TO_DU_CODE/5gran/du/build/pal/du_bin/bin/duStatsLog_*.csv /du_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l $PATH_TO_DU_CODE/5gran/du/build/pal/du_bin/bin/duStatsLog_*.txt; cp $PATH_TO_DU_CODE/5gran/du/build/pal/du_bin/bin/duStatsLog_*.txt /du_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l /var/log/gnb; \
                                            [ -d /var/log/gnb/O-RAN/O-DU/OT/L2/DU/Logs ] \
                                            && cp -r /var/log/gnb/O-RAN/O-DU/OT/L2/DU/Logs/DU_1_1_* /du_log \
                                            || cp -r /var/log/gnb/DU_1_1_* /du_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l /phoenix/gNB_DU/build/pal/du_bin/bin/gnb_du;cp /phoenix/gNB_DU/build/pal/du_bin/bin/gnb_du /du_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'mkdir -p /mplane_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -ltr /var/log/gnb;\
                                            [ -d /var/log/gnb/O-RAN/O-MPlane/OT/L2/MPlane/Logs ] \
                                              && cp -r /var/log/gnb/O-RAN/O-MPlane/OT/L2/MPlane/Logs/MPlane_1_1_* /mplane_log \
                                              || cp -r /var/log/gnb/MPLANE_1_1 /mplane_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l /phoenix/gNB_DU/build/pal/du_bin/bin'
if sudo podman exec $DU_CT_CONTAINER bash -c 'compgen -G "/phoenix/gNB_DU/build/pal/du_bin/bin/backtrace*"' > /dev/null; then
    sudo podman exec $DU_CT_CONTAINER bash -c 'cp /phoenix/gNB_DU/build/pal/du_bin/bin/backtrace.dump /du_log/backtrace_du.dump'
else
    echo "There is NO backtrace.dump file under /phoenix/gNB_DU/build/pal/du_bin/bin"
fi
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l /opt/gnb/mplane/bin'
if sudo podman exec $DU_CT_CONTAINER bash -c 'compgen -G "/opt/gnb/mplane/bin/backtrace*"' > /dev/null; then
    sudo podman exec $DU_CT_CONTAINER bash -c 'cp /opt/gnb/mplane/bin/backtrace.dump /du_log/backtrace_mplane.dump'
else
    echo "There is NO backtrace.dump file under /opt/gnb/mplane/bin/"
fi
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l /du_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l /mplane_log'
mkdir $WORKSPACE/du_log
mkdir $WORKSPACE/mplane_log
sudo podman cp $DU_CT_CONTAINER:/du_log/. $WORKSPACE/du_log
sudo podman cp $DU_CT_CONTAINER:/mplane_log/. $WORKSPACE/mplane_log
ls -lrt /var/lib/systemd/coredump/core*
if compgen -G "/var/lib/systemd/coredump/core*" > /dev/null; then
    sudo cp /var/lib/systemd/coredump/core* $WORKSPACE/du_log
    sudo rm -f /var/lib/systemd/coredump/core*
else
    echo "There is NO coredump files"
fi
sudo zip -r -q $WORKSPACE/du_ct_log.tar.gz $WORKSPACE/du_log $WORKSPACE/mplane_log
ls -ltr 
rm -rf $WORKSPACE/du_log
rm -rf $WORKSPACE/mplane_log
ls -lrt $WORKSPACE
sudo podman exec $DU_CT_CONTAINER bash -c 'cd /du_test && tar -czvf pcap_logs.tar.gz *.pcap'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l /du_test'
sudo podman exec $DU_CT_CONTAINER bash -c 'cd /upperstub_log && tar -czvf upperstub_log.tar.gz *.log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l /upperstub_log'
sudo podman exec $DU_CT_CONTAINER bash -c 'cd /lowerstub_log && tar -czvf lowerstub_log.tar.gz *.log'
sudo podman exec $DU_CT_CONTAINER bash -c 'ls -l /lowerstub_log'
sudo podman cp $DU_CT_CONTAINER:/du_test/upper_stub_console_logs.txt $WORKSPACE
sudo podman cp $DU_CT_CONTAINER:/du_test/uesim_console_logs.txt $WORKSPACE
sudo podman cp $DU_CT_CONTAINER:/du_test/gnb_du_console_logs.txt $WORKSPACE
sudo podman cp $DU_CT_CONTAINER:/du_test/pcap_logs.tar.gz $WORKSPACE
sudo podman cp $DU_CT_CONTAINER:/upperstub_log/upperstub_log.tar.gz $WORKSPACE
sudo podman cp $DU_CT_CONTAINER:/lowerstub_log/lowerstub_log.tar.gz $WORKSPACE
