## Copyright (c) 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
#!/bin/bash
set -ex

helpFunction()
{
    echo ""
    echo "Usage: $0 -w <Jenkins Workspacke/Git Repo Clone>  -v <Build Variants> -b <Branch>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-v Specify the build variants. Supported build variants are dpdk & nodpdk_crypto"
    echo -e "\t-b Specify the CU branch"
    echo -e "\t-t Specify the CU type, must be 'cp' or 'up'"
    echo -e "\t-s Specify the SEM VERSION, e.g 2.1.0.0"
    echo ""
    exit 1
}

NGP_BRANCH="HEAD"
GBI_TAG="latest"

# Get input parameters
while getopts "w: v: b: n: g:: t: s:" opt
do
    case "$opt" in
        w ) WORKSPACE="$OPTARG" ;;
        v ) BUILD_VARIANT="$OPTARG" ;;
        b ) CU_BRANCH="$OPTARG" ;;
        n ) NGP_BRANCH="$OPTARG" ;;
        g ) GBI_TAG="$OPTARG" ;;
        t ) CU_TYPE="$OPTARG" ;;
        s ) SEM_VERSION="$OPTARG" ;;
        ? ) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ ! -d "$WORKSPACE" ]; then
    echo "Error: No such file or directory $WORKSPACE"
    helpFunction
fi
if [ -z "$BUILD_VARIANT" ]; then
    echo "Build variant is manadatory"
    helpFunction
fi

if [ -z "$CU_BRANCH" ]; then
    echo "CU branch is manadatory"
    helpFunction
fi

# Prepare extra parameters
# DOCKER_TAG is latest in case CU_BRANCH is main
# Supporting for parallel CU-BUILD-ALL job, this pipeline is triggered by new commit, not for nightly only
# In case CU_BRANCH is passed as tag version (Ex: CU_TMP_2.1.0.0_0780), the DOCKER_TAG is also tag version
DOCKER_TAG=":latest"
if [[ "$CU_BRANCH" != "main" ]] &&  [[ ! "$CU_BRANCH" =~ [cC][uU]_[tT][mM][pP]_.* ]];then
    CU_LATEST_TAG=$(git -C $WORKSPACE/CU tag --list "CU_${SEM_VERSION}_*" | tail -n 1)

    DOCKER_TAG=":$CU_BRANCH"
    # Change to lower case and replace / with _ in the branch tag
    DOCKER_TAG=`echo $DOCKER_TAG | awk '{print tolower($0)}'| sed -e "s/\//_/g"`
    echo "Docker tag : $DOCKER_TAG"
else
    if [[ "$CU_BRANCH" =~ [cC][uU]_[tT][mM][pP]_.* ]];then
        DOCKER_TAG=":$CU_BRANCH"
        DOCKER_TAG=`echo $DOCKER_TAG | awk '{print tolower($0)}'`
        CU_LATEST_TAG=`echo $CU_BRANCH | sed -e "s/TMP_//"`
    else
        CU_LATEST_TAG=$(git -C $WORKSPACE/CU tag --list "CU_${SEM_VERSION}_*" | tail -n 1)
    fi
fi

if [[ "$NGP_BRANCH" != "HEAD" ]] && [[ "$NGP_BRANCH" != "main" ]];then
    DOCKER_TAG=":$NGP_BRANCH"
    # Change to lower case and replace / with _ in the branch tag
    DOCKER_TAG=`echo $DOCKER_TAG | awk '{print tolower($0)}'| sed -e "s/\//_/g"`
    echo "Docker tag : $DOCKER_TAG"
fi

TIME_STAMP=$(date +%s)
CACHE_OPTION="--no-cache"
GBI_IMAGE="phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/gbi:$GBI_TAG"
CU_UBI_IMAGE=${CU_UBI_IMAGE:='phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker-local/artifactory/platform/cu_ubi:latest'}

## Add key for specific host
# eval "$(ssh-agent -s)"
# ssh-add

# Using build steps from: https://eos2git.cec.lab.emc.com/Mobile-Phoenix/gNB_platform/blob/main/containers/cu/README.md
cd $WORKSPACE/CU/gNB_platform/containers/cu
echo -n "$GIT_ACCOUNT" > gitsecret.txt

# Build gNB Base Image
# buildah build --layers --format docker --secret id=gitsecret,src=gitsecret.txt --target gbi -t gbi -f buildah_cu.dockerfile .
podman pull $GBI_IMAGE
podman pull $CU_UBI_IMAGE
# Create set_cu_env stage
buildah build $CACHE_OPTION --format docker --build-arg GBI_TAG=$GBI_TAG --build-arg BRANCH=$CU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg USECACHE=$TIME_STAMP --target=set_cu_env -t gbi-cu$DOCKER_TAG -f buildah_set_env.dockerfile .

case "$BUILD_VARIANT" in
    "dpdk")
        echo "Building CU DPDK..."
        #CUCP
        if [[ -z "$CU_TYPE" ]] || [[ "$CU_TYPE" == 'cp' ]]; then
            echo "\t Building CU_CP"
            podman tag gbi-cu$DOCKER_TAG cu_cp_dpdk_dev$DOCKER_TAG  
            cd ${WORKSPACE}
            ls -ltr          

            ## Using the above image and compiling with incredibuild
            container_name=cu_cp_dpdk_dev_$RANDOM
            /opt/incredibuild/bin/ib_podman run --name $container_name --privileged -v $WORKSPACE/CU:/phoenix_mnt \
                -e TAR_OPTIONS="--no-same-owner" -e BUILD_VARIANT="variant01" -e VARIANT="cucp_dpdk" -e SEM_VERSION="$SEM_VERSION" -e DOCKER_TAG="$DOCKER_TAG" -e CU_FLAGS="-o -d" -e CU_VERSION=$CU_LATEST_TAG cu_cp_dpdk_dev$DOCKER_TAG \
                bash -c  "/phoenix_mnt/compile_cups_ib_multistream.sh"

            #Copy RPM from container to VM agent
            podman cp $container_name:/root/rpmbuild/RPMS/x86_64/. $WORKSPACE
            podman cp $container_name:/root/rpmbuild/SPECS/cu_cp_rpm.spec $WORKSPACE
            
            ls -ltR $WORKSPACE/CU/gNB_CU/build/
	        cp $WORKSPACE/CU/gNB_CU/build/cucp_bin/config/{mem,sys}_config_cu_cp.txt $WORKSPACE/
	        ls -lah $WORKSPACE/
            buildah commit --format docker $container_name $CUCP_TARGET
            
            cd $WORKSPACE/CU/ && ls -ltr
            ## Build production images
            buildah build $CACHE_OPTION --format docker --build-arg SRC_IMG=$CUCP_TARGET --target gnb_cu_cp -t $CUCP_TARGET_PROD \
                -f $WORKSPACE/CU/gNB_platform/containers/cu/buildah_cu_cp_prod.dockerfile .

            podman container rm $container_name
            
        fi
        #CUUP
        if [[ -z "$CU_TYPE" ]] || [[ "$CU_TYPE" == 'up' ]]; then
            echo "\t Building CU_UP"
            podman tag gbi-cu$DOCKER_TAG cu_up_dpdk_dev$DOCKER_TAG
            cd ${WORKSPACE}
            ls -ltr
            
            ## Using the above image and compiling with incredibuild
            container_name=cu_up_dpdk_dev_$RANDOM
            /opt/incredibuild/bin/ib_podman run --name $container_name --privileged -v $WORKSPACE/CU:/phoenix_mnt \
                -e TAR_OPTIONS="--no-same-owner" -e BUILD_VARIANT="variant01" -e VARIANT="cuup_dpdk" -e SEM_VERSION="$SEM_VERSION" -e DOCKER_TAG="$DOCKER_TAG" -e CU_FLAGS="-o -d" -e CU_VERSION=$CU_LATEST_TAG cu_up_dpdk_dev$DOCKER_TAG \
                bash -c  "/phoenix_mnt/compile_cups_ib_multistream.sh"

            #Copy RPM from container to VM agent
            podman cp $container_name:/root/rpmbuild/RPMS/x86_64/. $WORKSPACE
            podman cp $container_name:/root/rpmbuild/SPECS/cu_up_rpm.spec $WORKSPACE
            
            ls -ltR $WORKSPACE/CU/gNB_CU/build/
            cp $WORKSPACE/CU/gNB_CU/build/cuup_bin/config/{mem,sys}_config_cu_up.txt $WORKSPACE/
            ls -lah $WORKSPACE/
            buildah commit --format docker $container_name $CUUP_TARGET
            
            cd $WORKSPACE/CU/ && ls -ltr
            ## Build production images
            buildah build $CACHE_OPTION --format docker --build-arg SRC_IMG=$CUUP_TARGET --target gnb_cu_up -t $CUUP_TARGET_PROD \
                -f $WORKSPACE/CU/gNB_platform/containers/cu/buildah_cu_up_prod.dockerfile .

            podman container rm $container_name
            
        fi
    ;;

    "no_dpdk")
        echo "Building CU No-DPDK..."
        #CUCP
        if [[ -z "$CU_TYPE" ]] || [[ "$CU_TYPE" == 'cp' ]]; then
            echo "\t Building CU_CP"
            podman tag gbi-cu$DOCKER_TAG cu_cp_nodpdk_dev$DOCKER_TAG
            cd ${WORKSPACE}
            ls -ltr

            ## Using the above image and compiling with incredibuild
            container_name=cu_cp_nodpdk_dev_$RANDOM
            /opt/incredibuild/bin/ib_podman run --name $container_name --privileged -v $WORKSPACE/CU:/phoenix_mnt \
                -e TAR_OPTIONS="--no-same-owner" -e BUILD_VARIANT="variant02" -e VARIANT="cucp_nodpdk" -e SEM_VERSION="$SEM_VERSION" -e DOCKER_TAG="$DOCKER_TAG" -e CU_FLAGS="-o -l" -e CU_VERSION=$CU_LATEST_TAG cu_cp_nodpdk_dev$DOCKER_TAG \
                bash -c  "/phoenix_mnt/compile_cups_ib_multistream.sh"
            
            #Copy RPM from container to VM agent
            podman cp $container_name:/root/rpmbuild/RPMS/x86_64/. $WORKSPACE
            podman cp $container_name:/root/rpmbuild/SPECS/cu_cp_rpm.spec $WORKSPACE
            
            ls -lah $WORKSPACE/CU/
            buildah commit --format docker $container_name $CUCP_TARGET
            
            cd $WORKSPACE/CU/ && ls -ltr
            ## Build production images
            buildah build $CACHE_OPTION --format docker --build-arg SRC_IMG=$CUCP_TARGET --target gnb_cu_cp -t $CUCP_TARGET_PROD \
                -f $WORKSPACE/CU/gNB_platform/containers/cu/buildah_cu_cp_prod.dockerfile .

            
            podman container rm $container_name
            
        fi
        #CUUP
        if [[ -z "$CU_TYPE" ]] || [[ "$CU_TYPE" == 'up' ]]; then
            echo "\t Building CU_UP" 
            podman tag gbi-cu$DOCKER_TAG cu_up_nodpdk_dev$DOCKER_TAG
            cd ${WORKSPACE}
            ls -ltr

            ## Using the above image and compiling with incredibuild
            container_name=cu_up_nodpdk_dev_$RANDOM
            /opt/incredibuild/bin/ib_podman run --name $container_name --privileged -v $WORKSPACE/CU:/phoenix_mnt \
                -e TAR_OPTIONS="--no-same-owner" -e BUILD_VARIANT="variant02" -e SEM_VERSION="$SEM_VERSION" -e VARIANT="cuup_nodpdk" -e DOCKER_TAG="$DOCKER_TAG" -e CU_FLAGS="-o -l" -e CU_VERSION=$CU_LATEST_TAG cu_up_nodpdk_dev$DOCKER_TAG \
                bash -c  "/phoenix_mnt/compile_cups_ib_multistream.sh"

            #Copy RPM from container to VM agent
            podman cp $container_name:/root/rpmbuild/RPMS/x86_64/. $WORKSPACE
            podman cp $container_name:/root/rpmbuild/SPECS/cu_up_rpm.spec $WORKSPACE
            
            ls -ltr $WORKSPACE/CU/
            buildah commit --format docker $container_name $CUUP_TARGET
            
            cd $WORKSPACE/CU/ && ls -ltr
            ## Build production images
            buildah build $CACHE_OPTION --format docker --build-arg SRC_IMG=$CUUP_TARGET --target gnb_cu_up -t $CUUP_TARGET_PROD \
                -f $WORKSPACE/CU/gNB_platform/containers/cu/buildah_cu_up_prod.dockerfile .

            
            podman container rm $container_name

        fi

    ;;
    *)
        echo "Unknown variant: ${BUILD_VARIANT} ..."
        exit 1
	;;
esac
ls -ltr
