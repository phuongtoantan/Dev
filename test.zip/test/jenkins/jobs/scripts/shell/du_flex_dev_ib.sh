#!/bin/bash
## Copyright (c) 2017-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

set -x
echo -e $"\n\
[Artifactory]\n\
name=Artifactory\n\
baseurl=https://phm.artifactory.cec.lab.emc.com/artifactory/mobile-phoenix-rpm-candidate/\n\
enabled=1\n\
gpgcheck=0"\
    > /etc/yum.repos.d/Artifactory.repo
dnf install -y intel-oneapi-runtime-compilers
dnf clean all
PF_FC_RRU_INT=$PF_FC_RRU_INT
FLEXRAN_VERSION=$FLEXRAN_VERSION
VERSION=
export CC=/usr/local/bin/gcc
# Identify compile_du.sh script location
build_path=/phoenix/gNB_DU/build
[[ -f /phoenix/gNB_DU/compile_du.sh ]] && build_path=/phoenix/gNB_DU
set -eo pipefail && cd $build_path
PF_FC_RRU_INT=${PF_FC_RRU_INT} FLEXRAN_VERSION=${FLEXRAN_VERSION} ./compile_du.sh -t du-flexran ${MH_DPDK} | tee build.log
# Build crypto.so dynamic library for confd (to match openssl version)
unzip /phoenix/confd-basic-7.3.3.linux.x86_64.zip -d /phoenix
cd /phoenix/confd-basic-7.3.3.linux.x86_64
./confd-basic-7.3.3.linux.x86_64.installer.bin confd
tar xvfz confd-basic-7.3.3.libconfd.tar.gz --strip-components=1
cd libconfd
make crypto
\cp crypto/crypto.so /phoenix/confd-basic-7.3.3.linux.x86_64/confd/lib/confd/lib/core/crypto/priv/lib
# Copy RPM spec file
cd /platform/containers/du
cp du_flexran_rpm.spec /root/rpmbuild/SPECS
# Copy the startup script
cp start_du_flexran $build_path/intel/du_bin/bin/
# Copy service files 
cp start_du_flexran_service $build_path/intel/du_bin/bin/
cp stop_du_flexran_service $build_path/intel/du_bin/bin/
cp gNB_du_flexran.service /root/
# Prepare DU environment
PATH=/opt/gnb/du_flexran/bin:$PATH
# Copy the set_version script
cp /platform/containers/du/set_version.sh /root
# Run the set_version script to force version for the dependent RPMs
chmod +x /root/set_version.sh
/root/set_version.sh -f /root/rpmbuild/SPECS/du_flexran_rpm.spec
# Create RPM
cd /phoenix/gNB_DU
VERSION=${VERSION:-$(git tag --list "DU_2.1.0.0_*" | tail -n 1)}
RPM_VERSION=${VERSION:3:7} && RPM_RELEASE=$(echo ${VERSION:11} | sed "s/-/./g")
cd /root/rpmbuild
QA_RPATHS=$[ 0x0020 | 0x0002 ] rpmbuild -bb SPECS/du_flexran_rpm.spec --define "VERSION $RPM_VERSION" --define "RELEASE $RPM_RELEASE" --define "__strip /bin/true"
