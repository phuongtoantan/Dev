#!/bin/bash
#Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
set -x
helpFunction() {
    echo ""
    echo "Usage: $0 -t <Tag for TestSim> -c <TestSim container name>"    
    echo -e "\t-t Specify the tag for TestSim TCs"
    echo ""
    exit 1
}

# Get input parameters
while getopts "t:c:" opt; do
    case "$opt" in    
    t) TESTSIM_TAG="$OPTARG" ;;
    c) DU_TESTSIM_CONTAINER="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Variables
CONTAINER_WORKSPACE="/DU"

# Install extra dependencies
cd /usr/lib64
ln -s libcrypto.so.1.0.2o libcrypto.so.1.0.0
echo "export LD_LIBRARY_PATH=.:/usr/local/lib64:/usr/lib64" >> ~/.bashrc

# SSH
echo "Restart sshd"
systemctl restart sshd
systemctl status sshd | tee tmp_$(date +%s).txt

# Update some hardcoded parts from Test Sim config file
echo "########################## Update DU Test Sim Configuration ##########################"
TEST_SIM_CONFIG_FILE="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/configuration/Config.yaml"
# To support new VMs that have OAM network interface ens33 (not ens192) - refer to MP-76549, MP-79327
INT=$(ls /sys/class/net | grep ens)
echo -e "List of ens interface names: \n$INT"
if [[ $INT == *"ens33"* && $INT == *"ens192"* ]]; then
        echo "ERROR: This VM has both ens33 and ens192"
        exit 1
elif [[ $INT == *"ens33"* ]]; then
        echo "This VM has ens33. Need to change interface names in Config.yaml"
        FAPI_PORT_NAME="ens35"
        F1U_PORT_NAME="ens36"
        F1C_PORT_NAME="ens37"
        sed -i "s#fapi_port_name: .*#fapi_port_name: \"$FAPI_PORT_NAME\"#" $TEST_SIM_CONFIG_FILE
        sed -i "s#f1u_port_name: .*#f1u_port_name: \"$F1U_PORT_NAME\"#" $TEST_SIM_CONFIG_FILE
        sed -i "s#f1c_port_name: .*#f1c_port_name: \"$F1C_PORT_NAME\"#" $TEST_SIM_CONFIG_FILE
elif [[ $INT == *"ens192"* ]]; then
        echo "This VM has ens192. No need to change interface names in Config.yaml"
else
    echo "ERROR: This VM doesn't have interface ens33, neither ens192"
    exit 1
fi
HOST_IP="127.0.0.1"
USERNAME="jenkins"
PASSWORD="jenkins@#@!"
SYS_SCRIPTS="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/configuration"
DU_BIN="$CONTAINER_WORKSPACE/gNB_DU/build/mvl/du_bin/bin"
OAM_BIN="$CONTAINER_WORKSPACE/gNB_DU/build/mvl/du_bin/oam"
PCAP="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/pcap/"
DU_LOG="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/du_log/"
DU_CONSOLE_LOG="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/du_console_log/"
MPLANE_LOG="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/mplane_log/"
MPLANE_CONSOLE_LOG="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/mplane_console_log/"
DEBUG_LOG="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/debug_log/"
OAM_LOG="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/oam_log/"
OAM_CONSOLE_LOG="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/oam_console_log/"
XML_PATH="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/configuration/du"
ACM_LOG="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/acm_log/"
ACM_CONSOLE_LOG="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/Log/acm_console_log/"
CONTAINER="$DU_TESTSIM_CONTAINER"
# PCI_BUS="19"
DPDK_ENABLED="True"
# Update Config.yaml
sed -i "s#IP: .*#IP: \"$HOST_IP\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#USER: .*#USER: \"$USERNAME\"#" $TEST_SIM_CONFIG_FILE
sed -i "s/PASS: .*/PASS: \"$PASSWORD\"/g" $TEST_SIM_CONFIG_FILE
sed -i "s#SYS_SCRIPTS: .*#SYS_SCRIPTS: \"$SYS_SCRIPTS\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#DU_BIN: .*#DU_BIN: \"$DU_BIN\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#OAM_BIN: .*#OAM_BIN: \"$OAM_BIN\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#PCAP: .*#PCAP: \"$PCAP\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#DU_LOG: .*#DU_LOG: \"$DU_LOG\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#DU_CONSOLE_LOG: .*#DU_CONSOLE_LOG: \"$DU_CONSOLE_LOG\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#MPLANE_LOG: .*#MPLANE_LOG: \"$MPLANE_LOG\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#MPLANE_CONSOLE_LOG: .*#MPLANE_CONSOLE_LOG: \"$MPLANE_CONSOLE_LOG\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#DEBUG_LOG: .*#DEBUG_LOG: \"$DEBUG_LOG\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#OAM_LOG: .*#OAM_LOG: \"$OAM_LOG\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#OAM_CONSOLE_LOG: .*#OAM_CONSOLE_LOG: \"$OAM_CONSOLE_LOG\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#XML_PATH: .*#XML_PATH: \"$XML_PATH\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#ACM_LOG: .*#ACM_LOG: \"$ACM_LOG\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#ACM_CONSOLE_LOG: .*#ACM_CONSOLE_LOG: \"$ACM_CONSOLE_LOG\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#container: .*#container: \"$CONTAINER\"#" $TEST_SIM_CONFIG_FILE
sed -i "s#DPDK-ENABLED: .*#DPDK-ENABLED: \"$DPDK_ENABLED\"#" $TEST_SIM_CONFIG_FILE

echo "Check $TEST_SIM_CONFIG_FILE content:"
cat $TEST_SIM_CONFIG_FILE
# Update keywords/core.py
echo "########################## Update keywords/core.py ##########################"
KEYWORD_CORE_FILE="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/keywords/core.py"
#sed -i "s#prach_config_indx = int.*#prach_config_indx = 156#" $KEYWORD_CORE_FILE
echo "Check $KEYWORD_CORE_FILE content:"
cat $KEYWORD_CORE_FILE | grep "prach_config_indx"

# echo "########################## Update du_ip_config.sh ##########################"
# Update for podman container...
DU_CONFIG_IP_FILE="$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM/configuration/du/du_ip_config.sh"
echo "Check $DU_CONFIG_IP_FILE content:"
cat $DU_CONFIG_IP_FILE

echo "########################## Start running DU Test Sim ##########################"
cd "$CONTAINER_WORKSPACE/gNB_DU_TEST_SIM"
# Run test
sh tools/du_testsim_pipeline.sh $TESTSIM_TAG
echo "Test completed!"
