#!/usr/bin/bash
set -xe

helpFunc()
{
    echo ""
    echo "Usage: $0 -w <workspace_location> -n <tar_filename>"
    echo -e "\t-w Workpsace location where the tar files are present, ./deploy_cups_du_tl26.sh -w /home/jenkins/jenkins -n cucp_build.tar.gz"
    echo -e "\t-n tar file for cuup/cucp/du; ./deploy_cups_du_tl26.sh -w /home/jenkins/jenkins -n cucp_build.tar.gz"

    echo ""
    exit 1
}

while getopts "w: n: g: b:" opt
do
   case "$opt" in
      w ) workspace_path="$OPTARG" ;;
      n ) tar_filename="$OPTARG" ;;
      g ) golden_config="$OPTARG" ;;
      b ) golden_bin="$OPTARG" ;;
      ? ) helpFunc ;; # Print helpFunction in case parameter is non-existent
   esac
done

# Print helpFunction in case parameters are empty
if [ -z "$workspace_path" -o -z "$tar_filename" ]; then
    echo "Missing mandatory parameter workspace_path (or/and) tar_filename."
    helpFunc
fi
[ -z "$golden_bin" ]    && golden_bin=/data/golden_bin
[ -z "$golden_oam" ]    && golden_oam=/data/golden_oam
[ -z "$golden_config" ] && golden_config=/data/golden_config/

## Untar and update contents based on build_type
build_type=$(echo $tar_filename | cut -d_ -f1)
tar_file_path=/data/tl26_main
pwd; cd ${workspace_path}

## CUCP
if [ "$build_type" = "cucp" ]; then
    # Kill cucp process
    pkill -9 gnb_cu_cp || echo "Currently no process running for gnb_cu_cp"
    sleep 3
    ps -ef | grep gnb_cu_cp | grep -v grep || echo "Currently no process running for gnb_cu_cp"
    
    # Cleanup the directory
    cucp_deploy_dir=${tar_file_path}/cucp_deploy
    rm -rf ${tar_file_path}/*
    mkdir -p ${cucp_deploy_dir}
    
    # Copy tar files from worksapce to /data/tl26_main
    cp -f ${tar_filename} ${tar_file_path}
    tar -xvf ${tar_filename} -C ${cucp_deploy_dir}

    # Replacing the config folder with golden_config
    cp -pf ${golden_config}/* ${cucp_deploy_dir}/cucp_bin/config/

    # Replacing the oam file from golden_bin location
    cp -pf ${golden_bin}/oam_cu_cp.sh ${cucp_deploy_dir}/cucp_bin/bin/

## CUUP
elif [ "$build_type" = "cuup" ]; then
    # Kill cuup process
    pkill -9 gnb_cu_up || echo "Currently no process running for gnb_cu_up"
    sleep 3
    ps -ef | grep gnb_cu_up | grep -v grep || echo "Currently no process running for gnb_cu_up"

    # Cleanup the directory
    cuup_deploy_dir=${tar_file_path}/cuup_deploy
    rm -rf ${tar_file_path}/*
    mkdir -p ${cuup_deploy_dir}

    # Copy tar files from worksapce to /data/tl26_main    
    cp -f ${tar_filename} ${tar_file_path}
    tar -xvf ${tar_filename} -C ${cuup_deploy_dir}

    # Replacing the config folder with golden_config
    cp -pf ${golden_config}/* ${cuup_deploy_dir}/cuup_bin/config/

    # Replacing the oam file from golden_bin location
    cp -pf ${golden_bin}/oam_cu_up.sh ${cuup_deploy_dir}/cuup_bin/bin/

## DU

elif [ "$build_type" = "du" ]; then
    # Kill du process
    pkill -9 gnb_du || echo "Currently no process running for gnb_du"
    sleep 3
    ps -ef | grep gnb_du | grep -v grep || echo "Currently no process running for gnb_du"

    # Cleanup
    du_deploy_dir=${tar_file_path}/du_deploy
    rm -rf ${tar_file_path}/*
    mkdir -p ${du_deploy_dir}

    # Copy tar files from worksapce to /data/tl26_main
    cp -f ${tar_filename} ${tar_file_path}
    tar -xvf ${tar_filename} -C ${du_deploy_dir}

    # Replacing the config folder with golden_config
    cp -pf ${golden_config}/* ${du_deploy_dir}/du_bin/config

    # Replacing the oam file from golden_bin location
    cp -pf ${golden_bin}/oam_du.sh ${du_deploy_dir}/du_bin/bin/

fi

exit 0
