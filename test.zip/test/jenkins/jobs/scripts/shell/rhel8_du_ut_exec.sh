#!/bin/bash
set -ex

#Script to be executed inside the container to execute gtest test cases
#Run lcov and generate the coverage information
#Generate the html report based on the information

#Patch confd
#mv confd_patch.patch /phoenix/5gran/du/liboam/oam_du/cm/confd/config/ ;
#pushd /5gran/du/liboam/oam_du/cm/confd/config/ ;
#yum install patch -y ;
#patch < confd_patch.patch /phoenix/5gran/du/liboam/oam_du/cm/confd/config/confd.conf

#popd

#Updated commands
source $WORKSPACE/gNB_DU/5gran/du/build/confd/confdrc

#Build ngp
#cd /phoenix/ngp/build/;
#make clean; make all;
#echo $?
#echo "finished building ngp"

# Not checking the return code for build du
set +e

#Run build pal script
#cd /phoenix/gNB_DU/build/pal;
#./build_du.sh
#echo $?
#echo "finished build_du.sh"
set -ex

#cd /phoenix/gNB_DU/build/du_ut;
#./build_du_coverage.sh
#echo "finished build_du_coverage.sh"

# install net-tools package for net-stat cmd used by "make stop" below
# dnf install -y net-tools
export PATH=${PATH}:/usr/local/sbin:/usr/sbin:/bin
sudo sysctl -w kernel.sched_rt_runtime_us=-1
#Build confd
cd $WORKSPACE/gNB_DU/5gran/du/build/du_ut/du_bin/bin/../liboam/oam_du/cm/confd/run/;
make stop; make clean; make all; make start

cd $WORKSPACE/gNB_DU/5gran/du/build/du_ut/du_bin/bin
netconf-console --host=127.0.0.1 --port=2100 ../config/oam_3gpp_cell_cfg_mu1_6cell.xml

#Create coverage directory
cd $WORKSPACE/gNB_DU/5gran/du/build/du_ut/obj
mkdir coverage

#Run gtest cases
cd $WORKSPACE/gNB_DU/5gran/du/build/du_ut/du_bin/bin/
export LD_LIBRARY_PATH=.:/usr/local/lib:/usr/lib:/usr/local/lib64:/usr/lib64

#set +e;
./gnb_du --gtest_filter=CUt*Sch* --gtest_output=xml:xunitCUtSch.xml;
./gnb_du --gtest_filter=CUtRlc* --gtest_output=xml:xunitCUtRlc.xml;
./gnb_du --gtest_filter=CUtFapi* --gtest_output=xml:xunitCUtFapi.xml;
sudo su -c "export LD_LIBRARY_PATH=.:/usr/local/lib:/usr/local/lib64/:$LD_LIBRARY_PATH ; ./gnb_du --gtest_filter=CUtApp* --gtest_output=xml:xunitCUtApp.xml;"
set -ex

#Stop and restart confd
cd $WORKSPACE/gNB_DU/5gran/du/build/du_ut/du_bin/bin/../liboam/oam_du/cm/confd/run/;
make stop; make clean; make all; make start

cd $WORKSPACE/gNB_DU/5gran/du/build/du_ut/du_bin/bin
netconf-console --host=127.0.0.1 --port=2100 ../config/oam_3gpp_cell_cfg_mu1_1cell.xml

#Run gtest cases for single cell
cd $WORKSPACE/gNB_DU/5gran/du/build/du_ut/du_bin/bin/
export LD_LIBRARY_PATH=.:/usr/local/lib:/usr/lib:/usr/local/lib64:/usr/lib64

#set +e;
sudo su -c "export LD_LIBRARY_PATH=.:/usr/local/lib:/usr/local/lib64/:$LD_LIBRARY_PATH ;  ./gnb_du --gtest_filter=CUt*App*-*MCell* --gtest_output=xml:xunitCUtApp1Cell.xml;"
set -ex


# Move all xunit captures to the xunit folder
mkdir -p $WORKSPACE/xunit_dir
mv xunit*.xml $WORKSPACE/xunit_dir

#Collect DU log, DU binary and coredump (if exists)
mkdir $WORKSPACE/du_log
cp $WORKSPACE/gNB_DU/5gran/du/build/du_ut/du_bin/bin/du_stats_* $WORKSPACE/du_log
if sudo test -d "/var/log/gnb/O-RAN/O-DU/OT/L2/DU/Logs"; then
    sudo cp /var/log/gnb/O-RAN/O-DU/OT/L2/DU/Logs/DU_1_1/* $WORKSPACE/du_log
else 
    sudo cp /var/log/gnb/DU_1_1/* $WORKSPACE/du_log
fi
cp $WORKSPACE/gNB_DU/5gran/du/build/du_ut/du_bin/bin/gnb_du $WORKSPACE/du_log
if compgen -G "${WORKSPACE}/gNB_DU/5gran/du/build/du_ut/du_bin/bin/core*" > /dev/null; then
    cp ${WORKSPACE}/gNB_DU/5gran/du/build/du_ut/du_bin/bin/core* $WORKSPACE/du_log
else
    echo "There is NO coredump files"
fi
sudo zip -r -q $WORKSPACE/du_log.tar.gz $WORKSPACE/du_log
rm -rf $WORKSPACE/du_log
ls -lrt $WORKSPACE

#Copy gcda, gcda files to coverage folder
cd $WORKSPACE/gNB_DU/5gran/du/build/du_ut/obj
mv *.gcno *.gcda coverage/

#Create lcov directory and run lcov
mkdir $WORKSPACE/lcov_data

cd $WORKSPACE/gNB_DU/5gran/du/build/du_ut/
lcov --directory . --capture --output-file $WORKSPACE/lcov_data/gt_coverage.info
ls -ltr $WORKSPACE/lcov_data/gt_coverage.info
lcov --remove $WORKSPACE/lcov_data/gt_coverage.info '*/usr/*' -o $WORKSPACE/lcov_data/gt_coverage.info;
lcov --remove $WORKSPACE/lcov_data/gt_coverage.info '*/liboam/*' -o $WORKSPACE/lcov_data/gt_coverage.info;
lcov --remove $WORKSPACE/lcov_data/gt_coverage.info '*/mt/*' -o $WORKSPACE/lcov_data/gt_coverage.info;
lcov --remove $WORKSPACE/lcov_data/gt_coverage.info '*/gt_ut/*' -o $WORKSPACE/lcov_data/gt_coverage.info;
lcov --remove $WORKSPACE/lcov_data/gt_coverage.info '*/ngp/*' -o $WORKSPACE/lcov_data/gt_coverage.info;
lcov --remove $WORKSPACE/lcov_data/gt_coverage.info '*/5gnrclpal/*' -o $WORKSPACE/lcov_data/gt_coverage.info;
lcov --remove $WORKSPACE/lcov_data/gt_coverage.info '*/cm/*' -o $WORKSPACE/lcov_data/gt_coverage.info;
lcov --remove $WORKSPACE/lcov_data/gt_coverage.info '*/5gnr_cmn/*' -o $WORKSPACE/lcov_data/gt_coverage.info;
lcov --remove $WORKSPACE/lcov_data/gt_coverage.info '*/du_profiler/*' -o $WORKSPACE/lcov_data/gt_coverage.info;

#Run genhtml to generate report
cd $WORKSPACE/lcov_data
genhtml -o $WORKSPACE/result gt_coverage.info
ls -ltr

# Generate DU LCOV json report
pip3 install --user xmltodict beautifulsoup4
python3 /home/jenkins/files/python/parse-lcov.py -i $WORKSPACE/result/index.html -o $WORKSPACE/rhel-lcov-du.json -j ${BUILD_URL}

exit 0
