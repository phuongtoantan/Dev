#!/bin/bash
set -ex

helpFunction()
{
    echo ""
    echo "Usage: $0 -w <Jenkins Workspace> -b <DU branch> -t <DU_TEST branch> -a <DU build artifact path> -i <DU CT image name> -a <DU CT container name> -r <DU CT report>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-b Specify the DU branch. E.g: main"
    echo -e "\t-t Specify the DU_TEST branch. E.g: main/other"
    echo -e "\t-a Specify the DU artifact path"
    echo -e "\t-i Specify the DU CT docker image name"
    echo -e "\t-c Specify the DU CT docker container name"
    echo -e "\t-r Specify the DU CT report name"
    echo -e "\t-f Specify the tag for DU CT TCs"
    echo ""
    exit 1
}

CT_TESTCASE_TAG=""
# Get input parameters
while getopts "w: b: t: a: i: c: r: f:" opt
do
    case "$opt" in
        w ) WORKSPACE="$OPTARG" ;;
        b ) DU_BRANCH="$OPTARG" ;;
        t ) DU_CT_BRANCH="$OPTARG" ;;
        a ) DU_BUILD_ARTIFACT="$OPTARG" ;;
        i ) DU_CT_IMAGE="$OPTARG" ;;
        c ) DU_CT_CONTAINER="$OPTARG" ;;
        r ) DU_CT_REPORT="$OPTARG" ;;
        f ) CT_TESTCASE_TAG="$OPTARG" ;;
        ? ) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

DU_CT_REPORT_PRE=$DU_CT_REPORT
CURRENT_SCRIPT_PATH="$WORKSPACE/gNB_DU_TEST/src/pipeline_tools/scripts"

if [ -z "$WORKSPACE" ]; then
    helpFunction
    exit 0
fi

if [ -z "$DU_BRANCH" ]; then
    helpFunction
    exit 0
fi

if [ -z "$DU_CT_BRANCH" ]; then
    helpFunction
    exit 0
fi

if [ -z "$DU_BUILD_ARTIFACT" ]; then
    helpFunction
    exit 0
fi

if [ -z "$DU_CT_IMAGE" ]; then
    helpFunction
    exit 0
fi

if [ -z "$DU_CT_CONTAINER" ]; then
    helpFunction
    exit 0
fi

if [ -z "$DU_CT_REPORT" ]; then
    helpFunction
    exit 0
fi

# Prepare enviroment
PATH_TO_INSTALL='/liboam_confd'
PATH_TO_DU_CODE='/phoenix'
PATH_TO_DU_TEST_CODE='/du_test'
DU_CT_SCRIPT="/du_ct"
DU_CT_TC_FAILURE=0
DU_CT_TC_FAILURE_CONFIG=""
TC_Start_time=0
TC_End_time=0
TC_Duration=0
TC_Total_Time=0
TC_Total_Count=0
TC_Total_Failure_Count=0
TC_Xunit_Info=""
Xunit_Content=""
TC_File=""

# Condition for Testcases to pick Pre-CI TCs or full suite of TCs.

if [ "$CT_TESTCASE_TAG" == "PreCI" ]; then
    TC_File="pre_ci_tc.txt"
else
    TC_File="default_tc.txt"
fi

# Delete DU CT report file
rm -f $WORKSPACE/$DU_CT_REPORT*

cd $WORKSPACE/gNB_platform/containers/du
rm -f *.log
echo -n "$GIT_ACCOUNT" > gitsecret.txt

# Build DU CT environment
sudo buildah build --no-cache --format docker --build-arg USECACHE=$(date +%s) --secret id=gitsecret,src=gitsecret.txt --build-arg PATH_TO_INSTALL=$PATH_TO_INSTALL --build-arg DU_BRANCH=$DU_BRANCH --build-arg CT_BRANCH=$DU_CT_BRANCH --target=set_du_ct_env -t $DU_CT_IMAGE -f buildah_du_ct.dockerfile .

echo "Running Component Test..."
export PATH=${PATH}:/usr/local/sbin:/usr/sbin:/bin
sudo sysctl -w kernel.sched_rt_runtime_us=-1
# Check and enable SCTP on RHEL8
if ! (lsmod | grep sctp); then
    sudo dnf install -y kernel-rt-modules-extra
    sudo dnf install -y kernel-modules-extra
    sudo modprobe sctp
fi

# Run DU CT container
sudo podman run -d --network podman --privileged --ulimit core=-1 --security-opt label=disable --name $DU_CT_CONTAINER \
    -e PATH_TO_DU_CODE=$PATH_TO_DU_CODE \
    -e PATH_TO_INSTALL=$PATH_TO_INSTALL \
    -e PATH_TO_DU_TEST_CODE=$PATH_TO_DU_TEST_CODE \
    -e DU_CT_SCRIPT=$DU_CT_SCRIPT \
    -v $CURRENT_SCRIPT_PATH/du_ct:$DU_CT_SCRIPT \
    -v $DU_BUILD_ARTIFACT:/du_build_artifacts/du_build_pal.tar.gz \
    $DU_CT_IMAGE /usr/sbin/init
sudo podman ps

# For troubleshooting issue related to dependencies, see:
# https://confluence.cec.lab.emc.com/display/MP/Developer+DU+Tester+Systems+-+Booking
# https://eos2git.cec.lab.emc.com/Mobile-Phoenix/gNB_DU_TEST#building-uesimcu-on-rhel8-do-this
###can delete install_extra_dependencies.sh after MP-47948 merge & dockerfile is updated to common one. Its for libzlog linking.### 
sudo podman exec -t $DU_CT_CONTAINER $DU_CT_SCRIPT/install_extra_dependencies.sh

# Start test
#pre_execution_setup.sh configures for default setup using oam_3gpp_cell_cfg_mu1_1cell.xml

CONFIG_ARRAY=("../config/oam_3gpp_cell_cfg_mu1_1cell.xml")

## Pre-execution setup, once per container run, --privileged is required to change network interface
sudo podman exec -t --privileged $DU_CT_CONTAINER $DU_CT_SCRIPT/pre_execution_setup.sh

#TC_ARRAY format : testcase.py;folderpath<;arguments_to_testcase>

#Read specific test cases for main/Pre-CI from file default_tc.txt/pre_ci_tc.txt.
TC_ARRAY=()
echo "Reading $CURRENT_SCRIPT_PATH/du_ct/$TC_File for test cases"
while IFS= read -r line; do
   TC_ARRAY+=("$line")
   echo "Added $line to TC array"
done <$CURRENT_SCRIPT_PATH/du_ct/$TC_File

for config_element in "${CONFIG_ARRAY[@]}"
do
    echo "Config: $config_element"
    DU_CT_REPORT=$DU_CT_REPORT_PRE"_default.log"
    echo "Using default config for $config_element, CT report: $DU_CT_REPORT"

    for tc in "${TC_ARRAY[@]}"
    do
        echo "Setting up for $tc ."
        IFS=';' read -ra TESTARRAY <<< "$tc"
        echo "TC is ${TESTARRAY[0]} and Path is ${TESTARRAY[1]}"
    
        echo "Length of elements is ${#TESTARRAY[@]}"
        if [ ${#TESTARRAY[@]} -gt 2 ]
        then
            echo "Arguments to python script: ${TESTARRAY[2]}"
            TC_ARG="${TESTARRAY[0]} ${TESTARRAY[2]}"
        else
            TC_ARG="${TESTARRAY[0]}"
        fi
        ## Start 4 components for testing
        #Terminate existing binaries
        sudo podman exec $DU_CT_CONTAINER bash -c 'pkill -9 upper_stub; pkill -9 gnb_du; pkill -9 mplane; pkill -9 uesim' || true

        #Skip upper stub config ready polling
        CELL_ADMIN_TEST=false
        
        #For cell admin test case only
        case "${TESTARRAY[0]}" in
            "TestSuite-CLI0007-SA-SUB6-1C-1UE-UNLOCK-1C.py" | "TestSuite-CLI0008-SA-SUB6-1C-1UE-Cell-Oper-And-Cell-State-Verification-Test.py" | "cell-add-lock-delete-testcase.py" | "cell-addition-sequentially-testcase.py" | "mplane-du-heartbeat-detection.py")
                echo "Setting up cell administration test case for ${TESTARRAY[0]}"
                sudo podman exec -t $DU_CT_CONTAINER $DU_CT_SCRIPT/execution_setup_cell_admin.sh
                #Necessary for upper stub config to be ready before starting DU & load cell config for F1 setup
                CELL_ADMIN_TEST=true
                ;;
        esac

        #Capture start time
        TC_Start_time=`date '+%s'`
        TC_Total_Count=$((TC_Total_Count + 1))
        #Set Fail status to empty for every test case
        TC_Xunit_Info_Fail=""
        #Set Testcontroller log name
        TC_LOG=${TESTARRAY[0]}.log

        sudo podman exec -d -t $DU_CT_CONTAINER bash -c '/opt/gnb/mplane/bin/start_mplane -ru'
        sudo podman exec -d -t -e TC_EXEC=${TESTARRAY[0]} $DU_CT_CONTAINER bash -c 'echo "Starting upper_stub for $TC_EXEC ." >> $PATH_TO_DU_TEST_CODE/upper_stub_console_logs.txt'
        sudo podman exec -d -t $DU_CT_CONTAINER $DU_CT_SCRIPT/run_tcpdump.sh $PATH_TO_DU_TEST_CODE ${TESTARRAY[0]}
        sudo podman exec -d -t $DU_CT_CONTAINER $DU_CT_SCRIPT/run_upper_stub.sh $PATH_TO_DU_TEST_CODE
        
        #Poll for upper stub ready
        for count in {0..30}; do
            if sudo podman exec -t $DU_CT_CONTAINER bash -c 'tail -n50 $PATH_TO_DU_TEST_CODE/upper_stub_console_logs.txt | grep "DU TESTER UPPER STUB STARTED"'; then
                # Give enough time for upper stup to start all of its threads so it is ready to receive upper stup config from TC
                sleep 1
                break
            fi; sleep 1
        done

        sudo podman exec -t $DU_CT_CONTAINER $DU_CT_SCRIPT/run_test_controller.sh $PATH_TO_DU_TEST_CODE "$TC_ARG" ${TESTARRAY[1]} | tee $TC_LOG &
        pidForTC=$!
        
        if $CELL_ADMIN_TEST; then
            set +x
            #Poll for test controller to ssh into lower stub, configure upper stub
            for count in {0..30}; do
                echo "Polling for upper stub config ready..."
                if tail -n50 $TC_LOG | grep "TestCase: Calling Upper Stub Config Success"; then
                    break
                fi; sleep 1
            done
            set -x
        fi

        #Poll for mplane up
        for count in {0..30}; do
            if sudo podman exec -t $DU_CT_CONTAINER bash -c 'ps -A | grep -w mplane'; then
                echo 'MPlane UP'
                break
            fi; sleep 1
            if [ $count -eq 30 ]; then
                echo 'MPlane failed to initialze'
            fi
        done

        sudo podman exec -d -t -e TC_EXEC=${TESTARRAY[0]} $DU_CT_CONTAINER bash -c 'echo "Starting DU for $TC_EXEC ." >> $PATH_TO_DU_TEST_CODE/gnb_du_console_logs.txt'
        sudo podman exec -d -t $DU_CT_CONTAINER $DU_CT_SCRIPT/run_du.sh $PATH_TO_DU_CODE
        sleep 1
        ## Change the DU log storage size every time after bring up the DU
        sudo podman exec -d -t $DU_CT_CONTAINER $DU_CT_SCRIPT/change_du_log_storage_size.sh $PATH_TO_DU_CODE
        ## Check DU status
        if ! sudo podman exec -t $DU_CT_CONTAINER bash -c 'ps -A | grep gnb_du'; then
            echo 'DU failed to initialize'
        fi

        sudo podman exec -d -t -e TC_EXEC=${TESTARRAY[0]} $DU_CT_CONTAINER bash -c 'echo "Starting uesim for $TC_EXEC ." >> $PATH_TO_DU_TEST_CODE/uesim_console_logs.txt'
        sudo podman exec -d -t $DU_CT_CONTAINER $DU_CT_SCRIPT/run_lower_stub.sh $PATH_TO_DU_TEST_CODE
        sleep 1
        ## Check UESIM status
        if ! sudo podman exec -t $DU_CT_CONTAINER bash -c 'ps -A | grep uesim'; then
            echo 'UESIM failed to initialize'
        fi
        
        ## Wait for the test completed and check result
        wait $pidForTC
        TEST_RESULT=$(sudo podman exec $DU_CT_CONTAINER bash -c 'cat test_result.txt')
        echo "Test result: $TEST_RESULT"

        if [[ "$TEST_RESULT" != "PASSED" ]]; then
            echo 'Run test failed'
            #Increment count for failed test cases
            TC_Total_Failure_Count=$((TC_Total_Failure_Count + 1))
            TC_Xunit_Info_Fail="<failure message='FAILED' type='AssertionError'></failure> \n"
        fi

        echo "Change log name for ${TESTARRAY[0]}"
        sudo podman exec -d -t $DU_CT_CONTAINER $DU_CT_SCRIPT/change_logs_name.sh $PATH_TO_DU_CODE $PATH_TO_DU_TEST_CODE ${TESTARRAY[0]}
        echo "Stop tcpdump for ${TESTARRAY[0]}"
        sudo podman exec -t $DU_CT_CONTAINER $DU_CT_SCRIPT/terminate_tcpdump.sh

        #Capture end time
        TC_End_time=`date '+%s'`
        TC_Duration=$(($TC_End_time - $TC_Start_time))
        echo "TC duration is $TC_Duration"
        TC_Total_Time=$((TC_Total_Time + TC_Duration))
        
        #Format
        #<testcase classname="Sanity" name="Single_UE_Attach_Detach_MU1" time="136.959">
        #<failure message="IP address of 0.0.0.0 - Test Failed&#10;&#10;Also teardown failed:&#10;Validation of Capture : failed..." type="AssertionError"></failure>
        #</testcase>
        TC_Xunit_Info+="\n<testcase classname='Sanity' name='${TESTARRAY[0]}' time='$TC_Duration'>\n"
        TC_Xunit_Info+="$TC_Xunit_Info_Fail"
        TC_Xunit_Info+="</testcase>"

        #Write to DU CT report file
        echo "${TESTARRAY[0]} $TEST_RESULT" >> $WORKSPACE/$DU_CT_REPORT
    done
    #End of TC array

    #Check test result for config
    cd $WORKSPACE
    TC_ARR_LEN="${#TC_ARRAY[@]}"
    TC_EXEC=`grep -c ^ $DU_CT_REPORT`
    TC_FAILED=`grep -c FAILED $DU_CT_REPORT` || true
    #Dont fail, if 0 test cases failed.
    echo "Summary Total TC: $TC_ARR_LEN , Executed: $TC_EXEC , Failed: $TC_FAILED"

    cat $DU_CT_REPORT

    if [ $TC_ARR_LEN -ne $TC_EXEC ]
        then
            echo "FAIL: All Test cases are not executed"
            DU_CT_TC_FAILURE=1
            DU_CT_TC_FAILURE_CONFIG="$DU_CT_TC_FAILURE_CONFIG $config_element"
    fi

    if [ $TC_FAILED -gt 0 ]
        then
            echo "FAIL: There are failed test cases in the report"
            DU_CT_TC_FAILURE=1
            DU_CT_TC_FAILURE_CONFIG="$DU_CT_TC_FAILURE_CONFIG $config_element"
        else
            echo "All test cases are PASSED"
    fi

done 
#End of for loop of CONFIG_ARRAY
set -ex
#Generate x unit xml report
echo "Summary report TC total:$TC_Total_Count ; TC failed:$TC_Total_Failure_Count ;TC total time:$TC_Total_Time"
Xunit_Content="<?xml version='1.0' encoding='UTF-8'?>\n"
Xunit_Content+="<testsuite name='Sanity' tests='$TC_Total_Count' errors='0' failures='$TC_Total_Failure_Count' skipped='0' time='$TC_Total_Time'>"
Xunit_Content=$Xunit_Content$TC_Xunit_Info
Xunit_Content+="\n</testsuite>"

echo -e "$Xunit_Content" | tee $WORKSPACE/xunitreport.xml

if [ $DU_CT_TC_FAILURE -eq 1 ]
    then
        echo "FAIL: There are failed test cases in the report. Test cases failed in config $DU_CT_TC_FAILURE_CONFIG"
        exit 1
    else
        echo "All test cases are PASSED"
fi
