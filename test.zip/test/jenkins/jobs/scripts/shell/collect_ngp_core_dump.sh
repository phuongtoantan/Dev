## Copyright (c) 2017-2022 Dell Inc. or its subsidiaries. All Rights Reserved.

#!/bin/bash

helpFunction() {
    echo ""
    echo "Usage: $0 -c <Container ID>  -s <Start timestamp>"
    echo -e "\t-c Container ID"
    echo -e "\t-s Start timestamp"
    echo -e "\t-f Component Folder"
    echo ""
    exit 1
}

# Get input parameters
while getopts "c: s: f:" opt; do
    case "$opt" in
    c) CONTAINER_ID="$OPTARG" ;;
    s) START_TIME="$OPTARG" ;;
    f) FOLDER="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ -z "$CONTAINER_ID" ]; then
    echo "Container ID is manadatory"
    helpFunction
fi
if [ -z "$START_TIME" ]; then
    echo "Start time is manadatory"
    helpFunction
fi
if [ -z "$FOLDER" ]; then
    echo "Component Folder is mandatory"
    helpFunction
fi

# Get core dump list from starting time
coredumpctl list --since=@${START_TIME} > core_dump.txt
echo "Get core dump list from starting time"
cat core_dump.txt
dump_pids=()
dump_binaries=()
while read line; do
    line_list=($line)
    for index in ${!line_list[@]}; do
        if [[ "${line_list[$index]}" =~ ^([0-2][0-9]):([0-5][0-9]):([0-5][0-9])$ ]]; then
            dump_info=$(coredumpctl info ${line_list[$index+2]})
            # if echo $dump_info | grep -q "$CONTAINER_ID"; then
            if echo $dump_info | grep -q "/root/${FOLDER}/"; then
                dump_pids+=(${line_list[$index+2]})
                dump_binaries+=(${line_list[$index+7]})
            fi
        fi
    done
done < core_dump.txt


echo "Core dump PIDs: ${dump_pids[@]}"
echo "Core dump binaries: ${dump_binaries[@]}"

set -x
if [[ -n $dump_pids ]]; then
    echo "==================== CORE DUMP ANALYSIS ===================="
    mkdir core_dump_logs
    mkdir core_dump_binaries
    # Copy binarie files
    for binary in "${dump_binaries[@]}"; do
        sudo podman cp ${CONTAINER_ID}:${binary} core_dump_binaries
    done
    # Analyze
    for pid in "${dump_pids[@]}"; do
        sudo cp /var/lib/systemd/coredump/core.*.${pid}.*.lz4 core_dump_logs
        sudo coredumpctl info ${pid}
    done
    ls -lrt core_dump_logs/
    ls -lrt core_dump_binaries/
    if [ -n "$(ls -A core_dump_logs)" ]; then
        sudo tar -czvf core_dump_logs.tar.gz core_dump_logs
    fi
    if [ -n "$(ls -A core_dump_binaries)" ]; then
        sudo tar -czvf core_dump_binaries.tar.gz core_dump_binaries
    fi
    ls -lrt

    # Clean up
    rm -rf core_dump_logs
    rm -rf core_dump_binaries
fi

