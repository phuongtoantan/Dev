## Copyright (c) 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
#!/bin/bash
set -ex

helpFunction() {
    echo ""
    echo "Usage: $0 -w <Jenkins Workspacke/Git Repo Clone>  -v <Build Variants> -b <Branch> -t <Docker Tag>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-a Specify the ACM branch"
    echo -e "\t-A Specify the API branch"
    echo -e "\t-m Specify the Mplane branch"
    echo -e "\t-v Specify the build variants. Supported build variants are dpdk & nodpdk_crypto"
    echo -e "\t-b Specify the DU branch"
    echo -e "\t-e Specify any extra arguments"
    echo -e "\t-n Specify the NGP branch"
    echo -e "\t-g Specify the GBI image tag"
    echo -e "\t-o Specify the OAM branch"
    echo -e "\t-s Specify the DU-TEST-SIM branch"
    echo -e "\t-N Specify the Node Controller branch"
    echo -e "\t-p Specify the Platform branch"
    echo -e "\t-y Specify the Yang Model branch"
    echo -e "\t-t Specify the DU docker tag"
    echo ""
    exit 1
}

NGP_BRANCH="HEAD"
OAM_BRANCH="HEAD"
NODECONTROLLER_BRANCH="HEAD"
GBI_TAG="latest"

# Get input parameters
while getopts "w: a: A: m: v: b: r:: e:: n: o: s: t: N: p: y: g::" opt; do
    case "$opt" in
    w) WORKSPACE="$OPTARG" ;;
    a) ACM_BRANCH="$OPTARG" ;;
    A) API_BRANCH="$OPTARG" ;;
    m) MPLANE_BRANCH="$OPTARG" ;;
    v) BUILD_VARIANT="$OPTARG" ;;
    b) DU_BRANCH="$OPTARG" ;;
    e) EXTRA_ARGS="$OPTARG" ;;
    n) NGP_BRANCH="$OPTARG" ;;
    g) GBI_TAG="$OPTARG" ;;
    o) OAM_BRANCH="$OPTARG" ;;
    s) DU_TEST_SIM_BRANCH="$OPTARG" ;;
    N) NODECONTROLLER_BRANCH="$OPTARG" ;;
    p) PLATFORM_BRANCH="$OPTARG" ;;
    y) YANG_MODEL_BRANCH="$OPTARG" ;;
    t) TAG="$OPTARG" ;;
    r) BUILD_VERSION="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ ! -d "$WORKSPACE" ]; then
    echo "Error: No such file or directory $WORKSPACE"
    helpFunction
fi
if [ -z "$BUILD_VARIANT" ]; then
    echo "Build variant is manadatory"
    helpFunction
fi
if [ -z "$DU_BRANCH" ]; then
    echo "DU branch is manadatory"
    helpFunction
fi
if [ -z "$TAG" ]; then
    echo "DU tag is manadatory"
    helpFunction
fi

# Determine extra input build arguments
EXTRA_BUILD_ARGS="-e FH_DPDK=-f -e MH_DPDK=-m"
if [ -n "$EXTRA_ARGS" ]; then
    EXTRA_BUILD_ARGS="$EXTRA_ARGS"
fi
cd $WORKSPACE/containers/du
TIME_STAMP=$(date +%N)
CACHE_OPTION="--no-cache"
ls -ltr
pwd
echo -n "$GIT_ACCOUNT" >gitsecret.txt
case "$BUILD_VARIANT" in
"dpdk")
    # Build set_du_env image
    buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$DU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg GBI_TAG=$GBI_TAG \
        --build-arg OAM_BRANCH=$OAM_BRANCH --build-arg ACM_BRANCH=$ACM_BRANCH --build-arg NODECONTROLLER_BRANCH=$NODECONTROLLER_BRANCH --build-arg PLATFORM_BRANCH=$PLATFORM_BRANCH --build-arg YANG_MODEL_BRANCH=$YANG_MODEL_BRANCH --build-arg USECACHE=$TIME_STAMP --target set_du_env -t set_du_env:"$BUILD_VARIANT-$TAG" -f set_du_env.dockerfile .
    # Run build commands dpdk
    echo "Building dpdk...."
    package_variant="01_dpdk"
    # Complite DU build variant using Incredibuild
    container_name=du_dev_$RANDOM
    /opt/incredibuild/bin/ib_podman run -v /etc/localtime:/etc/localtime --privileged --name $container_name -v $WORKSPACE/build_scripts/$SCRIPT_PATH/du_dev_ib_multistream.sh:/scripts/du_dev_ib_multistream.sh \
        -v $WORKSPACE/containers/du:/platform/containers/du \
        -e DOCKER_TAG="$TAG" -e VERSION="$BUILD_VERSION" -e BUILD_VARIANT="$package_variant" -e FH_DPDK=-f -e MH_DPDK=-m set_du_env:"$BUILD_VARIANT-$TAG" bash -c "cd /scripts && chmod +x du_dev_ib_multistream.sh && ./du_dev_ib_multistream.sh"
    podman commit --format docker $container_name build_du_fpp:$TAG
    # Build DU production image
    buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg USECACHE=$TIME_STAMP --build-arg SRC_IMG=build_du_fpp:$TAG \
    --target gnb_du -t gnb_du_fpp:$TAG -f buildah_du_prod.dockerfile .
    # Extract DU build tarball & RPM from container image
    gnb_container_name=gnb_du_dpdk_$RANDOM
    podman create --name $gnb_container_name build_du_fpp:$TAG
    podman cp $gnb_container_name:/phoenix/gNB_DU/build/du_build_pal.tar.gz ../../
    podman cp $gnb_container_name:/root/rpmbuild/RPMS/x86_64/. ../../
    podman cp $gnb_container_name:/root/rpmbuild/SPECS/du_rpm.spec $WORKSPACE
    podman rm $gnb_container_name
    ;;
"no_dpdk")
    # Build set_du_env image
    buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$DU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH \
        --build-arg OAM_BRANCH=$OAM_BRANCH --build-arg NODECONTROLLER_BRANCH=$NODECONTROLLER_BRANCH --build-arg PLATFORM_BRANCH=$PLATFORM_BRANCH --build-arg YANG_MODEL_BRANCH=$YANG_MODEL_BRANCH --build-arg USECACHE=$TIME_STAMP --target set_du_env -t set_du_env:"$BUILD_VARIANT-$TAG" -f set_du_env.dockerfile .
    # Run build commands no dpdk
    echo "Building no dpdk...."
    package_variant="02_no_dpdk"
    # Complite DU build variant using Incredibuild
    container_name=du_dev_$RANDOM
    /opt/incredibuild/bin/ib_podman run -v /etc/localtime:/etc/localtime --privileged --name $container_name -v $WORKSPACE/build_scripts/$SCRIPT_PATH/du_dev_ib_multistream.sh:/scripts/du_dev_ib_multistream.sh \
        -v $WORKSPACE/containers/du:/platform/containers/du \
        -e DOCKER_TAG="$TAG" -e VERSION="$BUILD_VERSION" -e BUILD_VARIANT="$package_variant" -e FH_DPDK="" -e MH_DPDK="" set_du_env:"$BUILD_VARIANT-$TAG" bash -c "cd /scripts && chmod +x du_dev_ib_multistream.sh && ./du_dev_ib_multistream.sh"
    podman commit --format docker $container_name build_du_pal:$TAG
    # Build DU production image
    buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg USECACHE=$TIME_STAMP --build-arg SRC_IMG=build_du_pal:$TAG \
    --target gnb_du -t gnb_du_pal:$TAG -f buildah_du_prod.dockerfile .
    # Extract DU build tarball from container image
    gnb_container_name=gnb_du_nodpdk_$RANDOM
    podman create --name $gnb_container_name build_du_pal:$TAG
    podman cp $gnb_container_name:/phoenix/gNB_DU/build/du_build_pal.tar.gz ../../
    podman cp $gnb_container_name:/root/rpmbuild/SPECS/du_rpm.spec $WORKSPACE
    podman rm $gnb_container_name
    ;;
"mvl")
    # Build set_du_env image
    buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$DU_BRANCH --build-arg DU_TEST_SIM_BRANCH=$DU_TEST_SIM_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg GBI_TAG=$GBI_TAG \
        --build-arg OAM_BRANCH=$OAM_BRANCH --build-arg NODECONTROLLER_BRANCH=$NODECONTROLLER_BRANCH --build-arg PLATFORM_BRANCH=$PLATFORM_BRANCH --build-arg YANG_MODEL_BRANCH=$YANG_MODEL_BRANCH --build-arg USECACHE=$TIME_STAMP \
        --build-arg ACM_BRANCH=$ACM_BRANCH --build-arg API_BRANCH=$API_BRANCH --build-arg MPLANE_BRANCH=$MPLANE_BRANCH --target set_du_env -t set_du_env:"$BUILD_VARIANT-$TAG" -f set_du_env.dockerfile .
    # Run build commands marvell
    echo "Building Marvell...."
    # Complite DU build variant using Incredibuild
    container_name=du_dev_$RANDOM
    /opt/incredibuild/bin/ib_podman run -v /etc/localtime:/etc/localtime --privileged --name $container_name -v $WORKSPACE/build_scripts/$SCRIPT_PATH/du_mvl_dev_ib_multistream.sh:/scripts/du_mvl_dev_ib_multistream.sh \
        -v $WORKSPACE/containers/du:/platform/containers/du \
        -v $WORKSPACE/product_test_5g/framework/libraries/common/manage_config.py:/scripts/manage_config.py \
        -v $WORKSPACE/global-eula:/platform/global-eula \
        -e DOCKER_TAG="$TAG" -e VERSION="$BUILD_VERSION" $EXTRA_BUILD_ARGS set_du_env:"$BUILD_VARIANT-$TAG" bash -c "cd /scripts && chmod +x du_mvl_dev_ib_multistream.sh && ./du_mvl_dev_ib_multistream.sh"
    podman commit --format docker $container_name build_du_marvell:$TAG
    # Build DU production image
    buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg USECACHE=$TIME_STAMP --build-arg SRC_IMG=build_du_marvell:$TAG \
    --target gnb_du_marvell -t gnb_du_marvell:$TAG -f buildah_du_mvl_prod.dockerfile .
    # Extract DU build tarball & RPM from container image
    gnb_container_name=gnb_du_marvell_$RANDOM
    podman create --name $gnb_container_name build_du_marvell:$TAG
    podman cp $gnb_container_name:/phoenix/gNB_DU/build/du_build_mvl.tar.gz ../../
    podman cp $gnb_container_name:/root/rpmbuild/RPMS/x86_64/. ../../
    podman cp $gnb_container_name:/root/rpmbuild/SPECS/du_marvell_rpm.spec $WORKSPACE
    podman rm $gnb_container_name
    ;;
"ut")
    # Build set_du_env image    
    ls -ltr;pwd
    podman image tag du_ut_gbi:latest set_du_env:"$BUILD_VARIANT-$TAG"
    podman run -d --privileged --name set_du_env_temp$TIME_STAMP set_du_env:"$BUILD_VARIANT-$TAG" /usr/sbin/init
    podman exec set_du_env_temp$TIME_STAMP bash -c 'mkdir -p /phoenix'
    podman cp $WORKSPACE/DU/. set_du_env_temp$TIME_STAMP:/phoenix
    podman commit set_du_env_temp$TIME_STAMP du_ut_dev:$TAG
    cd ${WORKSPACE};ls -ltr
    container_name=du_ut_dev_$TAG
    # Complite DU build variant using Incredibuild
    /opt/incredibuild/bin/ib_podman run -v /etc/localtime:/etc/localtime --privileged --name $container_name \
        -v $WORKSPACE/product_test_5g/framework/libraries/common/manage_config.py:/scripts/manage_config.py \
        -v $WORKSPACE/build_scripts/$SCRIPT_PATH/du_ut_dev.sh:/scripts/du_ut_dev.sh \
        -v $WORKSPACE/containers/du:/platform/containers/du -e DOCKER_TAG=":$TAG" du_ut_dev:$TAG \
        bash -c "set -ex && cd /scripts && chmod +x du_ut_dev.sh && ./du_ut_dev.sh"
    podman commit --format docker $container_name build_du_ut:$TAG
    if ! podman images build_du_ut:$TAG ; then
        echo 'Build failed'
        exit 1
    fi
    # Tag prod image to upload to Artifactory
    podman tag build_du_ut:$TAG gnb_du_ut:$TAG
    ;;
*)
    echo "Unknown variant...."
    ls -ltr
    ;;
esac
