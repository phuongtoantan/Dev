#!/bin/bash
set -ex

#Prepare env for build and run build

if [ "$1" = "" ];then
        echo "Parameter 1: Workspace/repo path is manadatory"
        echo "./build_du.sh /home/jenkins/gNB_DU dpdk main"
        exit 0
fi

if [ "$2" = "" ];then
        echo "Parameter 2: dpdk or no_dpdk manadatory"
        echo "./build_du.sh /home/jenkins/gNB_DU dpdk main"
        exit 0
fi

if [ "$3" = "" ];then
        echo "Parameter 3: branch, mandatory"
        echo "./build_du.sh /home/jenkins/gNB_DU dpdk main"
        exit 0
fi

export DOCKER_BUILDKIT=1
eval "$(ssh-agent -s)"

#Add key for specific host
ssh-add

timeStamp=$(date +%s)

#Setup tag
DOCKER_TAG=""

if [ "$3" != "main" ]; then
	DOCKER_TAG=":$3"
	#Change to lower case and replace / with _ in the branch tag
        DOCKER_TAG=`echo $DOCKER_TAG | awk '{print tolower($0)}'| sed -e "s/\//_/g"`
	echo "Docker tag : $DOCKER_TAG"	
fi

cd $1/containers
pwd

#Get confd
wget -r -np -R 'index.html*' --no-check-certificate -nH --cut-dirs=4 \
     https://phm.artifactory.cec.lab.emc.com/artifactory/list/mobile-phoenix-ran-external/confd-basic-7.3.3/confd-basic-7.3.3.linux.x86_64.zip

ls -ltr;pwd

#Build GCC
docker build --target=gcc_5.4 -t gcc_5.4 -f build_du.dockerfile .

#Build du_tools
docker build --target=du_tools -t du_tools -f build_du.dockerfile .

case "$2" in
        "no_dpdk")
                #Run build commands no dpdk
                echo "Building no_dpdk...."

                docker build --ssh default --build-arg BRANCH=$3 --build-arg USECACHE=$timeStamp  --target=build_du -t build_du$DOCKER_TAG  -f build_du.dockerfile  .

                container_name="copy_gnb_build"
                docker ps -a --format "{{.Names}}" | grep -q $container_name && docker rm $container_name
                docker create --name $container_name  build_du$DOCKER_TAG
                docker cp ${container_name}:/phoenix/gNB_DU/build/du_build_pal.tar.gz .
                docker cp ${container_name}:/phoenix/gNB_DU/build/du_time.txt .
				if grep 'build_du.log' build_du.dockerfile; then
					docker cp ${container_name}:/phoenix/gNB_DU/build/build_du.log .
				fi
                docker rm $container_name

                ls -ltr
                ;;
        "foxconn")
                echo "Building foxconn.."

                docker build --ssh default --build-arg BRANCH=$3 --build-arg PF_FC_RRU_INT=YES --build-arg FLEXRAN_VERSION=21.03 --build-arg USECACHE=$timeStamp --target=build_du_flexran -t build_du_flexran${DOCKER_TAG}  -f build_du.dockerfile  .

                container_name="copy_du_flexran_build"
                docker ps -a --format "{{.Names}}" | grep -q $container_name && docker rm $container_name
                docker create --name $container_name  build_du_flexran${DOCKER_TAG}
                docker cp $container_name:/phoenix/gNB_DU/build/du_build_flexran_foxconn.tar.gz .
                docker rm $container_name

                ls -ltr
                ;;
        "flexran")
                echo "Building Flexran.."
                docker build --ssh default --build-arg BRANCH=$3 --build-arg USECACHE=$timeStamp  --target=build_du_flexran -t build_du_flexran${DOCKER_TAG}  -f build_du.dockerfile  .

                container_name="copy_du_flexran_build"
                docker ps -a --format "{{.Names}}" | grep -q $container_name && docker rm $container_name
                docker create --name ${container_name}  build_du_flexran${DOCKER_TAG}
                docker cp ${container_name}:/phoenix/gNB_DU/build/du_build_flexran.tar.gz .
                docker rm ${container_name}

                ls -ltr
                ;;

        "mvl")
                echo "Building mvl, Marvell.."
                docker build --ssh default --build-arg BRANCH=$3 --build-arg USECACHE=$timeStamp  --target=build_du_mvl -t build_du_mvl${DOCKER_TAG}  -f build_du.dockerfile  .

                container_name="copy_du_mvl_build"
                docker ps -a --format "{{.Names}}" | grep -q $container_name && docker rm $container_name
                docker create --name ${container_name}  build_du_mvl${DOCKER_TAG}
                docker cp ${container_name}:/phoenix/gNB_DU/build/du_build_mvl.tar.gz .
                docker rm ${container_name}

                ls -ltr
                ;;
        *)
                #Run build commands dpdk - default
                echo "Building dpdk...."

                #Updated commands
                docker build --ssh default --build-arg BRANCH=$3 --build-arg USECACHE=$timeStamp --build-arg DPDK_VER=19.11 --target=build_du_dpdk -t build_du_dpdk$DOCKER_TAG  -f build_du.dockerfile  .

                container_name="copy_gnb_build"
                docker ps -a --format "{{.Names}}" | grep -q $container_name && docker rm $container_name
                docker create --name $container_name  build_du_dpdk$DOCKER_TAG
                docker cp ${container_name}:/phoenix/gNB_DU/build/du_build_pal.tar.gz .
                docker cp ${container_name}:/phoenix/gNB_DU/build/du_time.txt .
				if grep 'build_du.log' build_du.dockerfile; then
					docker cp ${container_name}:/phoenix/gNB_DU/build/build_du.log .
				fi
                docker rm $container_name

		ls -ltr
		;;
esac