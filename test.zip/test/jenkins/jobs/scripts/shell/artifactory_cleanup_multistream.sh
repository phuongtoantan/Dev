#!/bin/bash
# File name: artifactory_cleanup_multistream.sh
#
# Authors:
#
# Copyright (c) 2024 Dell Inc. or its subsidiaries.
# All Rights Reserved.
#

usage() {
    echo ""
    echo "Usage: $0 -s <Artifactory Server ID> -d <Artifactory Scripts Path>"
    echo -e "\t-s Artifactory Server ID ( ID which is created using 'jf config' )"
    echo -e "\t-d Artifactory Search/Cleanup file path"
    echo -e "\t-m Stream name"
    echo ""
    exit 1
}

error_exit() {
    e_code=$1
    shift
    e_msg="$*"

    if [ $e_code -ne 0 ]; then
        echo "ERROR: $e_msg"
        usage
        exit $e_code
    fi
}

while getopts "s: d: m:" opt
do
    case "$opt" in
        s ) ART_SERVER_ID="$OPTARG" ;;
        d ) SCRIPT_BASE_PATH="$OPTARG" ;;
        m ) STREAM_NAME="$OPTARG" ;;
        ? ) usage ;;
    esac
done

# Main
##export CI="True" # Artifactory env variable to avoid prompt

[ -z "$ART_SERVER_ID" ]  && error_exit 1 "Artifactory Server ID doesn't exists"
[ -d "$SCRIPT_BASE_PATH" ] || error_exit 1 "Artifactory Search/Cleanup path doesn't exists"

jf config show | grep -w "$ART_SERVER_ID" >/dev/null 2>&1|| error_exit $? "JFrog Artifactory configuration for ${ART_SERVER_ID} is not available."

comp=(pr main)

for c in ${comp[@]}; do
        spec_file="${SCRIPT_BASE_PATH}/${STREAM_NAME}/search_spec_${c}.json"
        log_file="${SCRIPT_BASE_PATH}/search_spec_${c}_log.json"

        echo '#------------------------------------------------------------------------------#'
        echo -e "\t Artifactory Cleanup for Components: ${c}"
        echo '#------------------------------------------------------------------------------#'
        echo ''

        if [ ! -f "$spec_file" ]; then
                 echo "Artifactory Search Spec file $spec_file for Componenet $c, does not exists"
                 continue
        fi

        # Will enable remove artifacts when everything is ready.
        # Currently it just search RPMs/Images base on search spec files
        # jf rt del --spec $spec_file --server-id ${ART_SERVER_ID} | tee $log_file 2>&1
        jf rt s --spec $spec_file --server-id ${ART_SERVER_ID} | tee $log_file 2>&1 
done
