#! /bin/bash

while getopts "t: d:" opt
do 
    case "$opt" in
        t ) TARGET_FUNCTION_DIR="$OPTARG" ;;
        d ) TARGET_BRANCH="$OPTARG" ;;
    esac
done

files=$(git diff --name-only origin/$TARGET_BRANCH $TARGET_FUNCTION_DIR/*/*.groovy)

files_array=( $files )

printf "%s\n" "${files_array[@]}"

if [ "${#files_array[@]}" -eq 0 ]; then
    echo "No Groovy files found for linting."
else
#Linting
    npm-groovy-lint --failon error --loglevel error ${files_array[@]}
fi