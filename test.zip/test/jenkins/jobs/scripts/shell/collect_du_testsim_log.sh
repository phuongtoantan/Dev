#Copyright © 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.

#!/bin/bash
helpFunction() {
    echo ""
    echo "Usage: $0 -w <Jenkins Workspace>  -c <Container name>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-c Specify the container name"
    echo ""
    exit 1
}

# Get input parameters
while getopts "w: c:" opt; do
    case "$opt" in
    w) WORKSPACE="$OPTARG" ;;
    c) DU_TESTSIM_CONTAINER="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done
set +ex
#Collect DU log and coredump on running container
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'pwd;ls -l'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'mkdir -p /pcap /debug_log /du_console_log /du_log /mplane_console_log /mplane_log /oam_console_log /oam_log /acm_console_log /acm_log /dpdk_trace_log /pm_reports'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU/build/mvl/du_bin/bin/du_stats_*;cp /DU/gNB_DU/build/mvl/du_bin/bin/du_stats_* /du_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/du_console_log;cp -r /DU/gNB_DU_TEST_SIM/Log/du_console_log/* /du_console_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/du_log;cp -r /DU/gNB_DU_TEST_SIM/Log/du_log/* /du_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/mplane_console_log;cp -r /DU/gNB_DU_TEST_SIM/Log/mplane_console_log/* /mplane_console_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/mplane_log;cp -r /DU/gNB_DU_TEST_SIM/Log/mplane_log/* /mplane_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/oam_console_log;cp -r /DU/gNB_DU_TEST_SIM/Log/oam_console_log/* /oam_console_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/oam_log;cp -r /DU/gNB_DU_TEST_SIM/Log/oam_log/* /oam_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/acm_console_log;cp -r /DU/gNB_DU_TEST_SIM/Log/acm_console_log/* /acm_console_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/acm_log;cp -r /DU/gNB_DU_TEST_SIM/Log/acm_log/* /acm_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/debug_log;cp -r /DU/gNB_DU_TEST_SIM/Log/debug_log/* /debug_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/pcap;cp -r /DU/gNB_DU_TEST_SIM/Log/pcap/* /pcap'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/pm_reports;cp -r /DU/gNB_DU_TEST_SIM/Log/pm_reports/* /pm_reports'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/dpdk_trace_log;cp -r /DU/gNB_DU_TEST_SIM/Log/dpdk_trace_log/* /dpdk_trace_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /var/log/gnb/DU_1_1; \
                                                [ -d /var/log/gnb/O-RAN/O-DU/OT/L2/DU/Logs ] \
                                                    && cp /var/log/gnb/O-RAN/O-DU/OT/L2/DU/Logs/DU_1_1/* /du_log \
                                                    || cp /var/log/gnb/DU_1_1/* /du_log'

sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/du_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/mplane_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/oam_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/acm_log'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/pm_reports'
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'ls -l /DU/gNB_DU_TEST_SIM/Log/dpdk_trace_log'

mkdir $WORKSPACE/du_console_log
mkdir $WORKSPACE/du_log
mkdir $WORKSPACE/mplane_console_log
mkdir $WORKSPACE/mplane_log
mkdir $WORKSPACE/oam_console_log
mkdir $WORKSPACE/oam_log
mkdir $WORKSPACE/acm_console_log
mkdir $WORKSPACE/acm_log
mkdir $WORKSPACE/debug_log
mkdir $WORKSPACE/pcap
mkdir $WORKSPACE/pm_reports
mkdir $WORKSPACE/dpdk_trace_log

sudo podman cp $DU_TESTSIM_CONTAINER:/du_console_log/. $WORKSPACE/du_console_log
sudo podman cp $DU_TESTSIM_CONTAINER:/du_log/. $WORKSPACE/du_log
sudo podman cp $DU_TESTSIM_CONTAINER:/mplane_console_log/. $WORKSPACE/mplane_console_log
sudo podman cp $DU_TESTSIM_CONTAINER:/mplane_log/. $WORKSPACE/mplane_log
sudo podman cp $DU_TESTSIM_CONTAINER:/oam_console_log/. $WORKSPACE/oam_console_log
sudo podman cp $DU_TESTSIM_CONTAINER:/oam_log/. $WORKSPACE/oam_log
sudo podman cp $DU_TESTSIM_CONTAINER:/acm_console_log/. $WORKSPACE/acm_console_log
sudo podman cp $DU_TESTSIM_CONTAINER:/acm_log/. $WORKSPACE/acm_log
sudo podman cp $DU_TESTSIM_CONTAINER:/debug_log/. $WORKSPACE/debug_log
sudo podman cp $DU_TESTSIM_CONTAINER:/pcap/. $WORKSPACE/pcap
sudo podman cp $DU_TESTSIM_CONTAINER:/pm_reports/. $WORKSPACE/pm_reports
sudo podman cp $DU_TESTSIM_CONTAINER:/dpdk_trace_log/. $WORKSPACE/dpdk_trace_log

ls -lrt /var/lib/systemd/coredump/core*
if compgen -G "/var/lib/systemd/coredump/core*" > /dev/null; then
    cp /var/lib/systemd/coredump/core* $WORKSPACE/du_log
    rm -f /var/lib/systemd/coredump/core*
else
    echo "There is NO coredump files"
fi
sudo zip -r -q $WORKSPACE/du_console_log.tar.gz $WORKSPACE/du_console_log
sudo zip -r -q $WORKSPACE/du_trace_log.tar.gz $WORKSPACE/du_log
sudo zip -r -q $WORKSPACE/mplane_console_log.tar.gz $WORKSPACE/mplane_console_log
sudo zip -r -q $WORKSPACE/mplane_trace_log.tar.gz $WORKSPACE/mplane_log
sudo zip -r -q $WORKSPACE/oam_console_log.tar.gz $WORKSPACE/oam_console_log
sudo zip -r -q $WORKSPACE/oam_trace_log.tar.gz $WORKSPACE/oam_log
sudo zip -r -q $WORKSPACE/acm_console_log.tar.gz $WORKSPACE/acm_console_log
sudo zip -r -q $WORKSPACE/acm_trace_log.tar.gz $WORKSPACE/acm_log
sudo zip -r -q $WORKSPACE/debug_log.tar.gz $WORKSPACE/debug_log
sudo zip -r -q $WORKSPACE/pcap.tar.gz $WORKSPACE/pcap
sudo zip -r -q $WORKSPACE/pm_reports.tar.gz $WORKSPACE/pm_reports
sudo zip -r -q $WORKSPACE/dpdk_trace_log.tar.gz $WORKSPACE/dpdk_trace_log

rm -rf $WORKSPACE/du_console_log
rm -rf $WORKSPACE/du_log
rm -rf $WORKSPACE/mplane_console_log
rm -rf $WORKSPACE/mplane_log
rm -rf $WORKSPACE/oam_console_log
rm -rf $WORKSPACE/oam_log
rm -rf $WORKSPACE/acm_console_log
rm -rf $WORKSPACE/acm_log
rm -rf $WORKSPACE/debug_log
rm -rf $WORKSPACE/pcap
rm -rf $WORKSPACE/pm_reports
rm -rf $WORKSPACE/dpdk_trace_log
ls -lrt $WORKSPACE
