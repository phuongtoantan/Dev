#!/bin/bash

REPO_LAST_COMMIT=$(git log --name-status HEAD^..HEAD)

if git log --name-status HEAD^..HEAD | grep -qi 'test:logging'; then
   echo "logging"

elif git log --name-status HEAD^..HEAD | grep -qi 'test:memory'; then
   echo "memory"

else
    echo "all"
fi