// Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

#!/bin/bash
current_dir=.
export PYTHONPATH=$current_dir/framework/servers/services/generated/:$current_dir:$current_dir/framework/servers/services/default/
# echo "Applying System Configuration"
# ./$current_dir/configuration/du/du_ip_config.sh

function edit_sys_config {
    local key=$1
    local value=$2
    local file=$3

    if [[ -z "$value" ]]; then
        return 1
    else
        sed -i "s/^\($key\s*=\s*\).*$/\1$value/" "$file"
    fi  
}

echo "Editing oam_app_cfg.txt"
cd $pwd/DU/gNB_DU/build/mvl/du_bin/oam/du/config
edit_sys_config "OAM_CONFD_PORT" "11000" "oam_app_cfg.txt"
edit_sys_config "0MQ_CONSUMER_URI" "tcp:\/\/127.0.0.1:10051" "oam_app_cfg.txt"
edit_sys_config "0MQ_PRODUCER_URI" "tcp:\/\/127.0.0.1:10052" "oam_app_cfg.txt"
edit_sys_config "0MQ_PROXY_URI" "tcp:\/\/127.0.0.1:10053" "oam_app_cfg.txt"
edit_sys_config "NF_LIST" "du" "oam_app_cfg.txt"
edit_sys_config "OAMA_ENABLED" "TRUE" "oam_app_cfg.txt"

echo "Editing oam_du_confd_cfg.txt"
cd $pwd/DU/gNB_DU/build/mvl/du_bin/config/
edit_sys_config "OAM_CONFD_PORT" "11000" "oam_du_confd_cfg.txt"
edit_sys_config "0MQ_CONSUMER_URI" "tcp:\/\/127.0.0.1:10051" "oam_du_confd_cfg.txt"
edit_sys_config "0MQ_PRODUCER_URI" "tcp:\/\/127.0.0.1:10052" "oam_du_confd_cfg.txt"
edit_sys_config "0MQ_PROXY_URI" "tcp:\/\/127.0.0.1:10053" "oam_du_confd_cfg.txt"
edit_sys_config "OAMA_ENABLED" "TRUE" "oam_du_confd_cfg.txt"

echo "Finished - applying System Configuration for OAM"

echo "Copying DU Automated script"
cd $pwd/DU/gNB_DU_TEST_SIM
cp $current_dir/configuration/du/ConfD.sh $current_dir/../gNB_DU/build/mvl/du_bin/bin
cp $current_dir/configuration/du/start_confd_pwo.sh $current_dir/../gNB_DU/build/mvl/du_bin/bin
cp $current_dir/configuration/du/EditConfig.sh $current_dir/../gNB_DU/build/mvl/du_bin/bin
cp $current_dir/configuration/du/StartDU.sh $current_dir/../gNB_DU/build/mvl/du_bin/bin
cp $current_dir/configuration/du/StartOAM.sh $current_dir/../gNB_DU/build/mvl/du_bin/oam
cp $current_dir/../gNB_DU/build/mvl/du_bin/config/mem_config_TestSIM.txt $current_dir/../gNB_DU/build/mvl/du_bin/config/mem_config.txt
cp $current_dir/../gNB_DU/build/mvl/du_bin/config/sys_config_TestSIM.txt $current_dir/../gNB_DU/build/mvl/du_bin/config/sys_config.txt
chmod 777 /DU/gNB_DU/build/mvl/du_bin/config/
checksctp
#Validate the hugepage setting and correct it before running one_time_setup.sh script
# required_hugepages=20
# current_hugepages=$(dpdk-hugepages.py -s | awk 'FNR == 2 {print $2}')

# if [ "$current_hugepages" -ne "$required_hugepages" ]; then
#     echo "Current hugepages=$currentHugepages is not equal to $requiredHugepages, setting up new hugepages..."	
#     echo "$password" | dpdk-hugepages.py -p 1G --setup ${required_hugepages}G
# else
#     echo "Hugepages are already set to $required_hugepages."
# fi
echo "Run one_time_setup.sh"
sed -i '/read password/d' one_time_setup.sh
sed -i '/sudo chmod/d' one_time_setup.sh
source ./one_time_setup.sh
pwd; ls -lrth
chmod 777 $pwd/DU/gNB_DU/build/mvl/du_bin/oam/du/config
echo "Copy configure_Rsyslog.sh to DU/gNB_DU/build/mvl/du_bin/oam/du/config"
cp $current_dir/../gNB_DU/build/mvl/du_bin/oam/du/config/configure_Rsyslog.sh $current_dir/../gNB_DU/build/mvl/du_bin/oam/
if [[ -z "$1" ]]
then
    echo "Run Sanity Testcases"
    robot -x xunitreport -d $current_dir/Log -i Sanity -e Skip $current_dir/testcases/
else
    echo "Run $1 Testcases"
    robot -x xunitreport -d $current_dir/Log -i $1 -e Skip $current_dir/testcases/
fi
echo $? > failed_testcase_num
