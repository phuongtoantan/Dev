#!/bin/bash
retry=5

# Retry loop for uninstallation
while [ $retry -ge 1 ]
do
    dnf remove -y mplane
    retVal=$?
    if [[ $retVal -eq 0 ]]
    then
        echo 'dnf remove command is successful'
        break
    fi
    echo 'dnf remove command is failed. Re-trying...'
    sleep 60
    retry=$(( $retry - 1 ))
done

if [[ $retry -eq 0 ]]
then
    exit 1
fi

retry=5

# Retry loop for installation
while [ $retry -ge 1 ]
do
    dnf install -y /root/rpmbuild/RPMS/x86_64/mplane.rpm
    retVal=$?
    if [[ $retVal -eq 0 ]]
    then
        echo 'dnf install command is successful'
        break
    fi
    echo 'dnf install command is failed. Re-trying...'
    sleep 60
    retry=$(( $retry - 1 ))
done

if [[ $retry -eq 0 ]]
then
    exit 1
else
    exit 0
fi
