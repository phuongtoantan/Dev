#!/bin/bash
## Copyright (c) 2024 Dell Inc. or its subsidiaries. All Rights Reserved.

# Usage: capture_top_cpu.sh -NUM_PROCESS=5 -DURATION_MINUTE=240 -INTERVAL_SECOND=5
# Default values if not set via command line arguments
NUM_PROCESS=5 # Default number of process to capture
DURATION_MINUTE=240 # Default duration in minute
INTERVAL_SECOND=1  # Default interval in second

# Start this script in a new process group
setsid bash -c 'exec "$0" "$@"' bash "$@" &

# Parse command line options
for i in "$@"
do
case $i in
    -NUM_PROCESS=*)
    NUM_PROCESS="${i#*=}"
    shift
    ;;
    -DURATION_MINUTE=*)
    DURATION_MINUTE="${i#*=}"
    shift
    ;;
    -INTERVAL_SECOND=*)
    INTERVAL_SECOND="${i#*=}"
    shift
    ;;
    *)
    # unknown option
    ;;
esac
done

# Convert minutes to seconds
DURATION_SECOND=$((DURATION_MINUTE * 60))  

# Log file to store the output
LOG_FILE="$WORKSPACE/cpu_usage.log"

# Set up a trap to handle SIGTERM and exit cleanly
# trap 'echo "Received signal to stop."; kill 0; exit' SIGTERM

# Function to capture the column headers and top N highest CPU consuming processes
capture_top_cpu() {
    echo "$(date +'%Y-%m-%d %H:%M:%S %Z %:z')"  # Output the current timestamp
    top -b -n 1 | awk -v num="$NUM_PROCESS" 'NR==7 || (NR>=8 && NR<(8+num))'
}

# Capture the output at the specified interval for the duration in seconds
(
    for (( i = 0; i < DURATION_SECOND; i+=INTERVAL_SECOND )); do
        capture_top_cpu >> "$LOG_FILE"
        echo "----------------------------------------" >> "$LOG_FILE"
        sleep "$INTERVAL_SECOND" # Wait for the specified interval before the next capture
    done
) &

# Get the PID of the background process
SCRIPT_PID=$!

# Wait for the duration or until the script ends
wait $SCRIPT_PID
