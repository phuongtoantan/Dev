#!/usr/bin/bash
whoami

which $SHELL

set -x
#Kill cu and du process
pkill -9 gnb_du
sleep 5
pkill -9 gnb_cu
pkill -9 gnb_cuup
pkill -9 gnb_cucp

sleep 30

ps -ef | grep gnb_cu | grep -v grep
ps -ef | grep gnb_du | grep -v grep



#Set flags
set -xe

if [ "$1" = "" ];then
        echo "Parameter 1: workpsace location where the tar files are present"
        echo "Example: ./deploy_cu_du.sh /home/jenkins/jenkins cuup_build.tar.gz cucp_build.tar.gz  du_build.tar.gz"
        exit 0
fi

if [ "$2" = "" ];then
        echo "Parameter 2: tar file for cuup"
        echo "Example: ./deploy_cu_du.sh /home/jenkins/jenkins cuup_build.tar.gz cucp_build.tar.gz  du_build.tar.gz"
        exit 0
fi

if [ "$3" = "" ];then
        echo "Parameter 3: tar file for cucp"
        echo "Example: ./deploy_cu_du.sh /home/jenkins/jenkins cuup_build.tar.gz cucp_build.tar.gz  du_build.tar.gz"
        exit 0
fi

if [ "$4" = "" ];then
        echo "Parameter 3: tar file for du"
        echo "Example: ./deploy_cu_du.sh /home/jenkins/jenkins cuup_build.tar.gz cucp_build.tar.gz  du_build.tar.gz"
        exit 0
fi



#Untar the files
#Goto workspace
# pwd
# cd $1

# #CU
# #CUUP       
CUUP_DEPLOY_DIR=cuup_deploy
# rm -rf ${CUUP_DEPLOY_DIR}
# mkdir ${CUUP_DEPLOY_DIR}
# tar -xvf $2 -C ${CUUP_DEPLOY_DIR}
# #subdir cu_bin

# #CUCP       
CUCP_DEPLOY_DIR=cucp_deploy
# rm -rf ${CUCP_DEPLOY_DIR}
# mkdir ${CUCP_DEPLOY_DIR}
# tar -xvf $3 -C ${CUCP_DEPLOY_DIR}
# #subdir cu_bin

# #DU
# #Get the tar file into this directory
# #Seach for du tar file
# #DU_PATH=`find ../../../ -name gnb-du-dpdk-pal.tar.gz`
# #mv to this direcotry
# #cp -f $DU_PATH .

DU_DEPLOY_DIR=du_deploy
# rm -rf ${DU_DEPLOY_DIR}
# mkdir ${DU_DEPLOY_DIR}
# tar -xvf $4 -C ${DU_DEPLOY_DIR}



#Copy xml files for cu/du configuration
#CU-CP
cp -pf /home/test1/Q1_config/Q1_Working_Config/sys_config_cu_cp.txt ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/config/
#cp -pf /data/latest/1000674_2.3.0_01/01-Sub6_SA_CU-only/Binary/cu_bin/config/oam_3gpp_cu_sa_1du_1cell.xml ${1}/${CU_DEPLOY_DIR}/cu_bin/config/
# cp -pf /home/test1/Q1_config/Q1_Working_Config/oam_3gpp_cu_cp_sa_1du_1cell.xml ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/config/
cp -pf /home/test1/Q1_config/Q1_Working_Config/mem_config_cu_cp.txt ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/config/
cp -pf /home/test1/Q1_config/Q1_Working_Config/oam_cu_cp_confd_cfg.txt ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/config/
cp -pf /data/golden_configs/cu_cp/start_cu_cp ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/bin/
cp -pf ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/bin/gnb_cu_cp ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/bin/start_cu_cp1

#CU-UP
cp -pf /home/test1/Q1_config/Q1_Working_Config/sys_config_cu_up.txt ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/config/
#cp -pf /data/latest/1000674_2.3.0_01/01-Sub6_SA_CU-only/Binary/cu_bin/config/oam_3gpp_cu_sa_1du_1cell.xml ${1}/${CU_DEPLOY_DIR}/cu_bin/config/
# cp -pf /home/test1/Q1_config/Q1_Working_Config/oam_3gpp_cu_up_sa.xml ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/config/
cp -pf /home/test1/Q1_config/Q1_Working_Config/mem_config_cu_up.txt ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/config/
cp -pf /home/test1/Q1_config/Q1_Working_Config/oam_cu_up_confd_cfg.txt ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/config/
cp -pf /data/golden_configs/cu_up/start_cu_up ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/bin/
cp -pf ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/bin/gnb_cu_up ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/bin/start_cu_up1

#DU
cp -pf /data/latest/1000674_2.3.0_08/08-sub6-SA-DU-PAL-only/Binary/TRILLIUM_5GNR_GNB_DU_PAL_SUB6_WITH_DPDK_BIN_REL_2.3.0/pal/config/sys_config.txt ${1}/${DU_DEPLOY_DIR}/du_bin/config/
#cp -pf /data/latest/1000674_2.3.0_08/08-sub6-SA-DU-PAL-only/Binary/TRILLIUM_5GNR_GNB_DU_PAL_SUB6_WITH_DPDK_BIN_REL_2.3.0/pal/config/oam_3gpp_cell_cfg_mu1_1cell.xml ${1}/${DU_DEPLOY_DIR}/du_bin/config/
#cp -pf /home/test1/Q1_config/Q1_Working_Config/oam_3gpp_cell_cfg_mu1_1cell.xml ${1}/${DU_DEPLOY_DIR}/du_bin/config/
#cp -pf /home/jenkins/tar_file_2.4.0/config/oam_3gpp_cell_cfg_mu1_1cell.xml ${1}/${DU_DEPLOY_DIR}/du_bin/config/
# cp -pf /data/golden_configs/du/oam_3gpp_cell_cfg_mu1_1cell.xml ${1}/${DU_DEPLOY_DIR}/du_bin/config/
cp -pf /data/golden_configs/du/gnb_d ${1}/${DU_DEPLOY_DIR}/du_bin/bin/

#Add the write permission for raft scp of logs
chmod -R a+w ${1}

#Export command, added for DU liboamdu.so
export LD_LIBRARY_PATH=.:/usr/local/lib:/usr/lib:/usr/local/lib64:/usr/lib64:${1}/du_deploy/lib64
echo ${LD_LIBRARY_PATH}

#Create symbolic links for binaries
ln -sf  ${1}/${CUCP_DEPLOY_DIR} /data/latest/jenkins/cucp
ln -sf  ${1}/${CUUP_DEPLOY_DIR} /data/latest/jenkins/cuup
ln -sf ${1}/${DU_DEPLOY_DIR} /data/latest/jenkins/du

#Setup confd for cucp
pwd
cp /home/test1/Q1_config/Q1_Working_Config/cucp_confd.conf ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/liboam/oam_cucp/cm/confd/config/confd.conf
cd ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/liboam/oam_cucp/cm/confd/run
source /home/cu3/confd-basic-7.3.3.linux.x86_64/confd/confdrc
make stop
make clean
make all
make start

#Setup netconf-console
#CU-CP
pwd
cd ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/config/
cp /home/cu3/confd-basic-7.3.3.linux.x86_64/confd/bin/netconf-console .
netconf-console --host=127.0.0.1 --port=2102 oam_3gpp_cu_cp_sa_1du_1cell.xml

#Setup confd for cuup
pwd
cp /home/test1/Q1_config/Q1_Working_Config/cuup_confd.conf ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/liboam/oam_cuup/cm/confd/config/confd.conf
cd ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/liboam/oam_cuup/cm/confd/run
source /home/cu3/confd-basic-7.3.3.linux.x86_64/confd/confdrc
make stop
make clean
make all
make start

#Setup netconf-console
#CU-UP
pwd
cd ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/config/
cp /home/cu3/confd-basic-7.3.3.linux.x86_64/confd/bin/netconf-console .
netconf-console --host=127.0.0.1 --port=2101 oam_3gpp_cu_up_sa.xml


#Start gnb
pwd
cd ${1}/${CUCP_DEPLOY_DIR}/cucp_bin/bin/

#Temporary fix - Copy librestclient to bin folder
cp -p /home/jenkins/librestclient/* .

export LD_LIBRARY_PATH=.:/usr/local/lib:/usr/lib:/usr/local/lib64:/usr/lib64:${1}/du_deploy/lib64
#./gnb_cu_cp &
#./gnb_cu_cp > cu_cp_screen.log 2>&1 &
./gnb_cu_cp | tee cu_cp_screen.log &

sleep 30 
ps -ef | grep gnb_cu_cp | grep -v grep

pwd
cd ${1}/${CUUP_DEPLOY_DIR}/cuup_bin/bin/

#Temporary fix - Copy librestclient to bin folder
cp -p /home/jenkins/librestclient/* .
export LD_LIBRARY_PATH=.:/usr/local/lib:/usr/lib:/usr/local/lib64:/usr/lib64:${1}/du_deploy/lib64

#./gnb_cu_up &
#./gnb_cu_up > cu_up_screen.log 2>&1 &
./gnb_cu_up | tee cu_up_screen.log &



#Wait for cu to come up
sleep 30

#Check process
ps -ef | grep gnb_cu_up | grep -v grep

#Setup confd for du
pwd
cp /home/test1/Q1_config/Q1_Working_Config/du_confd.conf ${1}/${DU_DEPLOY_DIR}/du_bin/liboam/oam_du/cm/confd/config/confd.conf
cd ${1}/${DU_DEPLOY_DIR}/du_bin/liboam/oam_du/cm/confd/run
source /home/cu3/confd-basic-7.3.3.linux.x86_64/confd/confdrc
make stop
make clean
make all
make start

#Setup netconf-console
pwd
cd ${1}/${DU_DEPLOY_DIR}/du_bin/config/
cp /home/cu3/confd-basic-7.3.3.linux.x86_64/confd/bin/netconf-console .
netconf-console --host=127.0.0.1 --port=2100 oam_3gpp_cell_cfg_mu1_1cell.xml

#Start gnb_du
pwd
cd ${1}/${DU_DEPLOY_DIR}/du_bin/bin/
export LD_LIBRARY_PATH=.:/usr/local/lib:/usr/lib:/usr/local/lib64:/usr/lib64:${1}/du_deploy/lib64
#./gnb_du &
#./gnb_du > du_screen.log 2>&1 &
#./gnb_du > /dev/null 2>&1 &
./gnb_du --bg | tee du_screen.log &

#Wait for cell to come up
sleep 30

#Check process
ps -ef | grep gnb_du | grep -v grep

#echo "Checking if cell is UP, if not quits the script"
grep "is UP" du_screen.log

exit 0
