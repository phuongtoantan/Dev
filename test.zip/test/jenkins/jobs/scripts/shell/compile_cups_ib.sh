## Copyright (c) 2017-2023 Dell Inc. or its subsidiaries. All Rights Reserved.
#!/bin/bash
########################################################################################################
# Name     : compile_cups_incredibuild.sh
# Usage    : ./compile_cups_incredibuild.sh
# Example  : ./compile_cups_incredibuild.sh
########################################################################################################
set -ex
# Get CU_TYPE from VARIANT value, pattern should be: cucp_dpdk, cuup_dpdk, cucp_nodpdk, cuup_nodpdk
CU_TYPE=${VARIANT:2:2}
cp -r /phoenix_mnt /phoenix
ln -s /phoenix/gNB_platform /platform
cd /phoenix/gNB_CU/build/
chmod +x compile_cu_ib.sh
ib_console --avoid-shared --avoid-basedir=/phoneix -c ${VARIANT}${DOCKER_TAG} ./compile_cu_ib.sh -t $CU_TYPE $CU_FLAGS -j 200

# Copy RPM spec file for CU-PS
cp /platform/containers/cu/cu_${CU_TYPE}_rpm.spec /root/rpmbuild/SPECS

# Copy the startup script for CU-PS
cp /platform/containers/cu/start_cu_${CU_TYPE} /phoenix/gNB_CU/build/cu${CU_TYPE}_bin/bin/

# Copy service files for CU-PS
cp /platform/containers/cu/start_cu_${CU_TYPE}_service /phoenix/gNB_CU/build/cu${CU_TYPE}_bin/bin/
cp /platform/containers/cu/stop_cu_${CU_TYPE}_service /phoenix/gNB_CU/build/cu${CU_TYPE}_bin/bin/
cp /platform/containers/cu/gNB_cu_${CU_TYPE}.service /root/
# Copy the set_version script
cp /platform/containers/cu/set_version.sh /root

# Run the set_version script to force version for the dependent RPMs
chmod +x /root/set_version.sh
/root/set_version.sh -f /root/rpmbuild/SPECS/cu_${CU_TYPE}_rpm.spec -r "2.1.0.0"

# Update version/release in rpm spec and Create CU RPM
cd /phoenix

# Update container PATH to run start_cu_up
PATH=/opt/gnb/cu${CU_TYPE}/bin:$PATH

CU_VERSION=$CU_VERSION
VERSION=${CU_VERSION:3:7} && RELEASE_TAG=$(echo ${CU_VERSION:11} | sed "s/-/./g")
cd /root/rpmbuild
QA_RPATHS=$[ 0x0020 | 0x0002 ] rpmbuild -bb SPECS/cu_${CU_TYPE}_rpm.spec --define "CU_VERSION $VERSION" --define "RELEASE_TAG $RELEASE_TAG" --define "BUILD_VARIANT _$BUILD_VARIANT" --define "__strip /bin/true"

# Copy artifacts
cp -r /phoenix/gNB_CU/build/cu${CU_TYPE}_bin /phoenix_mnt/gNB_CU/build/cu${CU_TYPE}_bin
cp -r /phoenix/gNB_CU/build/gnb_cu-release /phoenix_mnt/gNB_CU/build/gnb_cu-release
mkdir -p /phoenix_mnt/gNB_ngp/thirdparty/dpdk/dpdk-*/x86_64-native-linuxapp-gcc/bin
cp -r /phoenix/gNB_ngp/thirdparty/dpdk/dpdk-*/x86_64-native-linuxapp-gcc/bin /phoenix_mnt/gNB_ngp/thirdparty/dpdk/dpdk-*/x86_64-native-linuxapp-gcc/bin
# Remove unnecessery folders
rm -rf /phoenix/gNB_CU_Test && ls -lah /phoenix
