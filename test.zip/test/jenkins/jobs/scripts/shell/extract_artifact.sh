#!/usr/bin/bash

#Untar the files
# Usage:
# extract_artifact.sh $WORKSPACE cucp_build.tar.gz cu_deploy
WORKING_DIR=$1
ARTIFACT="$2"
DEPLOY_DIR="$3"

cd ${WORKING_DIR}

rm -rf ${DEPLOY_DIR}
mkdir ${DEPLOY_DIR}
tar -xvf ${ARTIFACT} -C ${DEPLOY_DIR}
