#!/bin/bash
set -x

image=$1

# Extract rpm files
build_cid=$(buildah from $image)
build_mnt=$(buildah mount $build_cid)
ls $build_mnt/root/rpmbuild/RPMS/x86_64/
cp $build_mnt/root/rpmbuild/RPMS/x86_64/* .
buildah unmount $build_cid
buildah rm $build_cid
