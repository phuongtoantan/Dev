## Copyright (c) 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
#!/bin/bash
set -ex

helpFunction()
{
    echo ""
    echo "Usage: $0 -w <Jenkins Workspacke/Git Repo Clone>  -v <Build Variants> -b <Branch>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-v Specify the build variants. Supported build variants are dpdk & nodpdk_crypto"
    echo -e "\t-b Specify the CU branch"
    echo -e "\t-t Specify the CU type, must be 'cp' or 'up'"
    echo ""
    exit 1
}

NGP_BRANCH="HEAD"
GBI_TAG="latest"

# Get input parameters
while getopts "w: v: b: n: t: g::" opt
do
    case "$opt" in
        w ) WORKSPACE="$OPTARG" ;;
        v ) BUILD_VARIANT="$OPTARG" ;;
        b ) CU_BRANCH="$OPTARG" ;;
        g ) GBI_TAG="$OPTARG" ;;
        n ) NGP_BRANCH="$OPTARG" ;;
        t ) CU_TYPE="$OPTARG" ;;
        ? ) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ ! -d "$WORKSPACE" ]; then
    echo "Error: No such file or directory $WORKSPACE"
    helpFunction
fi
if [ -z "$BUILD_VARIANT" ]; then
    echo "Build variant is manadatory"
    helpFunction
fi

if [ -z "$CU_BRANCH" ]; then
    echo "CU branch is manadatory"
    helpFunction
fi

# Prepare extra parameters
DOCKER_TAG=":latest"
if [ "$CU_BRANCH" != "main" ];then
    DOCKER_TAG=":$CU_BRANCH"
    # Change to lower case and replace / with _ in the branch tag
    DOCKER_TAG=`echo $DOCKER_TAG | awk '{print tolower($0)}'| sed -e "s/\//_/g"`
    echo "Docker tag : $DOCKER_TAG"
fi

if [[ "$NGP_BRANCH" != "HEAD" ]] && [[ "$NGP_BRANCH" != "main" ]];then
    DOCKER_TAG=":$NGP_BRANCH"
    # Change to lower case and replace / with _ in the branch tag
    DOCKER_TAG=`echo $DOCKER_TAG | awk '{print tolower($0)}'| sed -e "s/\//_/g"`
    echo "Docker tag : $DOCKER_TAG"
fi

TIME_STAMP=$(date +%s)
CACHE_OPTION="--layers"

# Prepare confd, SSH setup for building
## Get confd
cd $WORKSPACE
wget -rq -np -R 'index.html*' --no-check-certificate -nH --cut-dirs=4 \
https://phm.artifactory.cec.lab.emc.com/artifactory/list/mobile-phoenix-ran-external/confd-basic-7.3.3/confd-basic-7.3.3.linux.x86_64.zip
## Add key for specific host
# eval "$(ssh-agent -s)"
# ssh-add

# Using build steps from: https://eos2git.cec.lab.emc.com/Mobile-Phoenix/gNB_platform/blob/main/containers/cu/README.md
cd $WORKSPACE/CU/gNB_platform/containers/cu
echo -n "$GIT_ACCOUNT" > gitsecret.txt

# Build gNB Base Image
# buildah build --layers --format docker --secret id=gitsecret,src=gitsecret.txt --target gbi -t gbi -f buildah_cu.dockerfile .
podman pull $GBI_IMAGE
# Create set_du_env stage
# buildah build --no-cache --format docker --secret id=gitsecret,src=gitsecret.txt --target set_cu_env -t set_cu_env -f buildah_cu.dockerfile .

case "$BUILD_VARIANT" in
    "dpdk")
        echo "Building CU DPDK..."
        package_variant="variant01"
        #CUCP
        if [[ -z "$CU_TYPE" ]] || [[ "$CU_TYPE" == 'cp' ]]; then
            echo "\t Building CU_CP"
            buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$CU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg CU_FLAGS="-o -d" --build-arg USECACHE=$TIME_STAMP --build-arg BUILD_VARIANT=$package_variant --target=build_cu_cp -t $CUCP_TARGET -f buildah_cu_cp.dockerfile .
            buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$CU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg CU_FLAGS="-o -d" --build-arg USECACHE=$TIME_STAMP --build-arg BUILD_VARIANT=$package_variant --target gnb_cu_cp -t $CUCP_TARGET_PROD -f buildah_cu_cp.dockerfile .
            podman create --name cu_cp_dev$TIME_STAMP $CUCP_TARGET
            podman cp cu_cp_dev$TIME_STAMP:/phoenix/gNB_CU/build/cucp_bin/config/mem_config_cu_cp.txt $WORKSPACE
            podman cp cu_cp_dev$TIME_STAMP:/phoenix/gNB_CU/build/cucp_bin/config/sys_config_cu_cp.txt $WORKSPACE
            podman cp cu_cp_dev$TIME_STAMP:/root/rpmbuild/SPECS/cu_cp_rpm.spec $WORKSPACE
            podman rm cu_cp_dev$TIME_STAMP
        fi
        #CUUP
        if [[ -z "$CU_TYPE" ]] || [[ "$CU_TYPE" == 'up' ]]; then
            echo "\t Building CU_UP"
            buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$CU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg CU_FLAGS="-o -d" --build-arg USECACHE=$TIME_STAMP --build-arg BUILD_VARIANT=$package_variant --target=build_cu_up -t $CUUP_TARGET -f buildah_cu_up.dockerfile .
            buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$CU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg CU_FLAGS="-o -d" --build-arg USECACHE=$TIME_STAMP --build-arg BUILD_VARIANT=$package_variant --target gnb_cu_up -t $CUUP_TARGET_PROD -f buildah_cu_up.dockerfile .
            podman create --name cu_up_dev$TIME_STAMP $CUUP_TARGET
            podman cp cu_up_dev$TIME_STAMP:/phoenix/gNB_CU/build/cuup_bin/config/mem_config_cu_up.txt $WORKSPACE
            podman cp cu_up_dev$TIME_STAMP:/phoenix/gNB_CU/build/cuup_bin/config/sys_config_cu_up.txt $WORKSPACE
            podman cp cu_up_dev$TIME_STAMP:/root/rpmbuild/SPECS/cu_up_rpm.spec $WORKSPACE
            podman rm cu_up_dev$TIME_STAMP
        fi
    ;;
    "no_dpdk")
        echo "Building CU No-DPDK..."
        package_variant="variant02"
        #CUCP
        if [[ -z "$CU_TYPE" ]] || [[ "$CU_TYPE" == 'cp' ]]; then
            echo "\t Building CU_CP"
            buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$CU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg CU_FLAGS="-o -l" --build-arg USECACHE=$TIME_STAMP --build-arg BUILD_VARIANT=$package_variant --target=build_cu_cp -t $CUCP_TARGET -f buildah_cu_cp.dockerfile .
            buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$CU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg CU_FLAGS="-o -l" --build-arg USECACHE=$TIME_STAMP --build-arg BUILD_VARIANT=$package_variant --target gnb_cu_cp -t $CUCP_TARGET_PROD -f buildah_cu_cp.dockerfile .
            #Extract tar file
            podman create --name cu_cp_prod$TIME_STAMP $CUCP_TARGET
            podman cp cu_cp_prod$TIME_STAMP:/phoenix/gNB_CU/build/cucp_build.tar.gz $WORKSPACE
            podman cp cu_cp_prod$TIME_STAMP:/root/rpmbuild/SPECS/cu_cp_rpm.spec $WORKSPACE
            podman rm cu_cp_prod$TIME_STAMP
        fi
        #CUUP
        if [[ -z "$CU_TYPE" ]] || [[ "$CU_TYPE" == 'up' ]]; then
            echo "\t Building CU_UP"
            buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$CU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg CU_FLAGS="-o -l" --build-arg USECACHE=$TIME_STAMP --build-arg BUILD_VARIANT=$package_variant --target=build_cu_up -t $CUUP_TARGET -f buildah_cu_up.dockerfile .
            buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BRANCH=$CU_BRANCH --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg CU_FLAGS="-o -l" --build-arg USECACHE=$TIME_STAMP --build-arg BUILD_VARIANT=$package_variant --target gnb_cu_up -t $CUUP_TARGET_PROD -f buildah_cu_up.dockerfile .
            podman create --name cu_up_prod$TIME_STAMP $CUUP_TARGET
            podman cp cu_up_prod$TIME_STAMP:/phoenix/gNB_CU/build/cuup_build.tar.gz $WORKSPACE
            podman cp cu_up_prod$TIME_STAMP:/root/rpmbuild/SPECS/cu_up_rpm.spec $WORKSPACE
            podman rm cu_up_prod$TIME_STAMP
        fi

    ;;
    *)
        echo "Unknown variant: ${BUILD_VARIANT} ..."
        exit 1
	;;
esac

ls -ltr
