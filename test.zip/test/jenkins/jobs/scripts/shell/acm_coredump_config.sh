#!/bin/bash
## Copyright (c) 2023-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

# Ensure the real sudo is available
if ! command -v sudo &> /dev/null; then
  echo "sudo could not be found, please ensure it is installed and available in PATH."
  exit 1
fi

# Update /etc/systemd/coredump.conf
COREDUMP_CONF="/etc/systemd/coredump.conf"
sed -i 's/^#\?ProcessSizeMax=.*/ProcessSizeMax=10G/' $COREDUMP_CONF
sed -i 's/^#\?ExternalSizeMax=.*/ExternalSizeMax=10G/' $COREDUMP_CONF

# Update /etc/systemd/system.conf
SYSTEM_CONF="/etc/systemd/system.conf"
sed -i 's/^#\?DumpCore=.*/DumpCore=yes/' $SYSTEM_CONF
sed -i 's/^#\?DefaultLimitCORE=.*/DefaultLimitCORE=infinity/' $SYSTEM_CONF

# Update kernel core dump pattern
SYSCTL_CONF="/etc/sysctl.conf"
echo 'kernel.core_pattern=core_%e_%p' | tee -a $SYSCTL_CONF

# Apply kernel parameter changes
sysctl -p

# Set user limits for core dumps
ulimit -c unlimited

# Apply systemd changes
systemctl daemon-reexec

echo "Coredump config changes have been applied successfully."