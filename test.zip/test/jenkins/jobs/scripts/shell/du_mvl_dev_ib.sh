#!/bin/bash
## Copyright (c) 2017-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

set -x
# Identify compile_du.sh script location
build_path=/phoenix/gNB_DU/build
[[ -f /phoenix/gNB_DU/compile_du.sh ]] && build_path=/phoenix/gNB_DU
export CC=/usr/local/bin/gcc
set -eo pipefail && cd $build_path
#current time on container
date
# Start DU compilation
ib_console --avoid-shared --avoid-basedir=/phoenix -c du_mvl${DOCKER_TAG} ./compile_du.sh -t du-mvl ${FH_DPDK} ${MH_DPDK} -j 200 | tee build.log
##make crypto
# Copy RPM spec file
cd /platform/containers/du
cp du_marvell_rpm.spec /root/rpmbuild/SPECS
# Copy the startup script
cp start_du_marvell /phoenix/gNB_DU/build/mvl/du_bin/bin/
# Copy service files
cp pre_start_du_marvell_service /phoenix/gNB_DU/build/mvl/du_bin/bin/
cp start_du_marvell_service /phoenix/gNB_DU/build/mvl/du_bin/bin/
# WA below step needs for main_2 only
[[ -f start_du_marvell_aio ]] && cp start_du_marvell_aio /phoenix/gNB_DU/build/mvl/du_bin/bin/
#end WA
cp stop_du_marvell_service /phoenix/gNB_DU/build/mvl/du_bin/bin/
cp gNB_du_marvell.service /root/
# Prepare DU environment
PATH=/opt/gnb/du_marvell/bin:$PATH
ls -l /platform || true; ls -l /platform/global-eula || true
cp -r /platform/global-eula /phoenix/; ls -l /phoenix; ls -l /phoenix/global-eula || true
# Copy the set_version script
cp /platform/containers/du/set_version.sh /root
chmod +x /root/set_version.sh
# Get current mainstream build version for dependencies
if [ -n "$VERSION" ]; then
  # Retrieve DU tmp tag
  DU_TMP_TAG="${VERSION:0:2}_TMP${VERSION:2}"
  SEM_RELEASE_VERSION="${VERSION:3:7}"
  if [ -n "$DU_TMP_TAG" ]; then
    cd /phoenix/transport
    git checkout $DU_TMP_TAG
    git pull || true
    SHA=$(git rev-list -n 1 $DU_TMP_TAG)
    SUB_TMP_VERSION=$(git tag --contains $SHA --list "Transport_TMP_"$SEM_RELEASE_VERSION"_*" | tail -n 1)
    SUB_VERSION=$(git tag --contains $SHA --list "Transport_"$SEM_RELEASE_VERSION"_*" | tail -n 1)
    OPTION=" -t "
    SUB_RELEASE=""
    if [ -z "$SUB_TMP_VERSION" ]; then
      #assume mainstream build for dependence finished
      if ! [ -z "$SUB_VERSION" ]; then
        SUB_RELEASE=${SUB_VERSION: -4}
      fi
    else
      if [ -z "$SUB_VERSION" ]; then
        #assume mainstream build for dependence haven't finished yet
        SUB_RELEASE=${SUB_TMP_VERSION: -4}
      else
        #multiple tags linked to the same commit --> get latest one
        SUB_RELEASE=${SUB_VERSION: -4}
        SUB_TMP_RELEASE=${SUB_TMP_VERSION: -4}
        if [[ "$SUB_TMP_RELEASE" > "$SUB_RELEASE" ]]; then
          SUB_RELEASE=$SUB_TMP_RELEASE
        fi
      fi
    fi
    if [ -n "$SUB_RELEASE" ]; then
      PACKAGE_VERSION_LIST=" -t "$SUB_RELEASE
    fi
  fi
fi

# Create RPM
cd /phoenix/gNB_DU
VERSION=${VERSION:-$(echo "DU_2.1.0.0_v001")}
RPM_VERSION=${VERSION:3:7} && RPM_RELEASE=$(echo ${VERSION:11} | sed "s/-/./g")
# Run the set_version script to force version for the dependent RPMs
set +ex #If set_version.sh is failed somehow, expect the pipeline still continue to use with the latest version of dependencies instead of failing whole pipeline
/root/set_version.sh -f /root/rpmbuild/SPECS/du_marvell_rpm.spec -r "$RPM_VERSION" $PACKAGE_VERSION_LIST
set -ex
# Content of du_marvell_rpm.spec file after running set_version.sh script
cat /root/rpmbuild/SPECS/du_marvell_rpm.spec
cd /root/rpmbuild
QA_RPATHS=$[ 0x0020 | 0x0002 ] rpmbuild -bb SPECS/du_marvell_rpm.spec --define "VERSION $RPM_VERSION" --define "RELEASE $RPM_RELEASE" --define "__strip /bin/true"
