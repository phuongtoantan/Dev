#!/bin/bash
## Copyright (c) 2023-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

echo "Preparing to perform UT and CT"
ut_cmd='./run_tests.sh --gtest_filter="*UnitTest*"'
ct_cmd='./run_tests.sh --gtest_filter="*ComponentTest*"'

cd /DU/gNB_ACM/scripts
chmod +x run_tests.sh
echo "Running Unit tests"
echo "Command used: ${ut_cmd}"
## executing the Unit test command
$ut_cmd
ut_exit_status=$?

if [ $ut_exit_status -eq 0 ]; then
    mv /DU/gNB_ACM/build/bin/test_detail.xml output/unit_test_results.xml
else
    echo "UT failed"
fi

echo "Running component tests"
echo "Command used: ${ct_cmd}"
## executing the Component test command
$ct_cmd
ct_exit_status=$?

if [ $ct_exit_status -eq 0 ]; then
    mv /DU/gNB_ACM/build/bin/test_detail.xml output/component_test_results.xml
    cp -avr lcov_results /output
else
    echo "Component tests failed"
fi
