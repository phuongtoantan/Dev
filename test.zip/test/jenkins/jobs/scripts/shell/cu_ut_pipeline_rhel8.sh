#!/bin/bash
## Copyright (c) 2017-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
set -ex

CU_BRANCH=$1
UT_BRANCH=$2
WORKSPACE=$3
JOB_NAME=$4
BUILD_ID=$5
ROBOT_CMD="$6"
LCOV="${7:-false}"
MEMCHECK="${8:-false}"
MEMCHECK_NAME="${9:-Undefined}"
IS_NIGHTLY="${10:-false}"

USAGE="$0 main main /home/jenkins/jenkins/workspace/CU_UT_PR-52 CU-UT/main 1 Sanity"

### Prepare env for testing
# Check imput params
if [ -z "$CU_BRANCH" ]; then
        echo "Parameter 1: CU branch is mandatory"
        echo "$USAGE"
        exit 0
fi

if [ -z "$UT_BRANCH" ]; then
        echo "Parameter 2: UT branch is mandatory"
        echo "$USAGE"
        exit 0
fi

if [ -z "$WORKSPACE" ]; then
        echo "Parameter 3: WORKSPACE is mandatory"
        echo "$USAGE"
        exit 0
fi

if [ -z "$JOB_NAME" ]; then
        echo "Parameter 4: JOB_NAME is mandatory"
        echo "$USAGE"
        exit 0
fi

if [ -z "$BUILD_ID" ]; then
        echo "Parameter 5: BUILD_ID is mandatory"
        echo "$USAGE"
        exit 0
fi

# Define image name in case non-existence
if [ -z "$RUN_TESTS_IMAGE" ]; then
        RUN_TESTS_IMAGE="run_tests_${JOB_NAME}:${BUILD_ID}"
fi

if [ -z "$RUN_TESTS_CONTAINER" ]; then
        RUN_TESTS_CONTAINER="run_tests_${JOB_NAME}_${BUILD_ID}"
fi

##### Starting #####
echo "##### Starting #####"
whoami

# gNB_platform repo will be checked out from Jenkins pipeline before running this script
BUILDAH_CU_DOCKER_FILE="${WORKSPACE}/gNB_platform/containers/cu/buildah_cu.dockerfile"
TEST_CU_RHEL8_DOCKER_FILE="${WORKSPACE}/gNB_platform/containers/cu/test_cu_rhel8.dockerfile"
TIME_STAMP=$(date +%s)

# Check rt kernel is active
if [[ ! $(uname -r | grep rt) ]]; then
  echo "RT kernel is not running."
  exit 1
fi

# Check and enable SCTP on RHEL agents
if ! (lsmod | grep sctp); then
        subscription-manager repos --enable rhel-8-for-x86_64-rt-rpms
        dnf install -y kernel-rt-modules-extra-$(uname -r)
        modprobe sctp
fi

# Set sched_rt_runtime_us=-1 to avoid to avoid EPERM issue, also mentioned in:
# https://jira.cec.lab.emc.com/browse/MP-3191?focusedCommentId=6771986&page=com.atlassian.jira.plugin.system.issuetabpanels%3Acomment-tabpanel#comment-6771986
sysctl -w kernel.sched_rt_runtime_us=-1

# Set container_manage_cgroup to on in SELinux configuration so that containerse can write to the cgroup file system
if [[ $(getenforce | grep Enforcing) ]] || [[ $(genenforce | grep Permissive) ]]; then
    if [[ ! $(getsebool -a | grep container_manage_cgroup | grep on$) ]]; then
        setsebool -P container_manage_cgroup true
    fi
fi

# Prepare neccessary files for building
# cd $WORKSPACE/gNB_platform/containers/cu
# for loop in {0..3}; do
#     wget -r -np -R 'index.html*' --no-check-certificate -nH --cut-dirs=4 \
#         https://phm.artifactory.cec.lab.emc.com/artifactory/list/mobile-phoenix-ran-external/confd-basic-7.3.3/confd-basic-7.3.3.linux.x86_64.zip && break || exit_code=$?
#     if [ $loop -eq 3 ]; then exit $exit_code; fi
#     sleep 30
# done

cd $WORKSPACE/gNB_platform/containers/cu

### Reuse the CU built images: $GNB_CU_CP_IMAGE and $GNB_CU_UP_IMAGE
# Copy CU builds over to unit test podman container
GNB_CU_CP_CONTAINER="cu_cp_prod_${JOB_NAME}_${BUILD_ID}"
GNB_CU_UP_CONTAINER="cu_up_prod_${JOB_NAME}_${BUILD_ID}"
podman create --name ${GNB_CU_CP_CONTAINER} ${GNB_CU_CP_IMAGE}
podman create --name ${GNB_CU_UP_CONTAINER} ${GNB_CU_UP_IMAGE}
mkdir -p gNB_CU_CP
mkdir -p gNB_CU_UP
podman cp ${GNB_CU_CP_CONTAINER}:/phoenix/. gNB_CU_CP
podman cp ${GNB_CU_UP_CONTAINER}:/phoenix/. gNB_CU_UP
podman cp ${GNB_CU_CP_CONTAINER}:/root/confd-basic-7.3.3.linux.x86_64/ .
# Cleanup after copy CUCP/CUUP artifacts
podman rm ${GNB_CU_CP_CONTAINER}
podman rm ${GNB_CU_UP_CONTAINER}
rm -rf gNB_CU_{CP,UP}/gNB_CU_TEST || true
cp -r gNB_CU_TEST gNB_CU_CP/
cp -r gNB_CU_TEST gNB_CU_UP/
du -hd 1 gNB_CU_{CP,UP}

####################################################################
### Build unit test podman image with buildah
echo "################## Start building CU test image ##################"
cd $WORKSPACE/gNB_platform/containers/cu
# buildah build --network=host --layers --format docker --target cu_test_env -t cu_test_env -f ${TEST_CU_RHEL8_DOCKER_FILE} .
podman pull phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker/artifactory/mobile-phoenix-platform-docker/cu-images/cuut/cu_test_gbi:latest
buildah build --network=host --no-cache --format docker --build-arg USECACHE=$TIME_STAMP --build-arg BRANCH=${UT_BRANCH} --target=run_tests -t ${RUN_TESTS_IMAGE} -f ${TEST_CU_RHEL8_DOCKER_FILE} .
podman images || true
mv $WORKSPACE/gNB_platform/containers/cu/gNB_CU_CP $WORKSPACE/gNB_CU_CP
mv $WORKSPACE/gNB_platform/containers/cu/gNB_CU_UP $WORKSPACE/gNB_CU_UP
### Start running tests in podman container
echo "################## Start running robot test ##################"
ROBOT_CMD=$(echo $ROBOT_CMD | sed 's/\"/\\\"/g') # cover space charaters
CUCP_BUILD_DIR="/phoenix_cp"
CUUP_BUILD_DIR="/phoenix_up"
START_TEST_CMD="/start_tests_docker.sh -c $CUCP_BUILD_DIR -u $CUUP_BUILD_DIR -r \"${ROBOT_CMD}\" -l $LCOV -m $MEMCHECK -j $MEMCHECK_NAME"
ps -ef

echo "Clean up /etc/rsyslog.d folder before mounting to container"
rm -f /etc/rsyslog.d/*

podman run -d --privileged --pids-limit=-1 \
        --security-opt seccomp=unconfined \
        -v /dev/hugepages:/dev/hugepages \
        -v /etc/rsyslog.d:/etc/rsyslog.d \
        -v /var/log:/var/log \
        -v /var/run/rsyslogd.pid:/var/run/rsyslogd.pid \
        -v /etc/localtime:/etc/localtime:ro \
        --name ${RUN_TESTS_CONTAINER} \
        ${RUN_TESTS_IMAGE} /usr/sbin/init
podman ps
echo "NUMBER OF RUNNING PROCESSES in ${RUN_TESTS_CONTAINER}:"
podman exec -t ${RUN_TESTS_CONTAINER} sh -c "ps -ef"

echo "Check /etc/rsyslog.d folder inside container before start testing"
podman exec -t ${RUN_TESTS_CONTAINER} sh -c "ls -ltr /etc/rsyslog.d"

# DEBUGGING - Starting monitoring CPU script
if [ "$IS_NIGHTLY" == "true" ]; then
        echo "Starting monitoring CPU script"
        DEBUG_TOP_SCRIPT_PATH="$WORKSPACE/build_scripts/jenkins/jobs/scripts/shell/capture_top_cpu.sh"
        DEBUG_TOP_PID_FILE="$WORKSPACE/top_pid.txt"
        DEBUG_TOP_OUTPUT="$WORKSPACE/cpu_usage.log"
        chmod +x $DEBUG_TOP_SCRIPT_PATH
        # Start the monitoring script in the background
        $DEBUG_TOP_SCRIPT_PATH -NUM_PROCESS=5 -DURATION_MINUTE=240 -INTERVAL_SECOND=5 &
        # Save the PID of the process group
        echo $! > $DEBUG_TOP_PID_FILE
fi
# DEBUGGING - Starting monitoring CPU script

echo "Start running Tests"
podman exec -t ${RUN_TESTS_CONTAINER} sh -c "$START_TEST_CMD"
podman exec ${RUN_TESTS_CONTAINER} sh -c "systemctl status; du -hd 2 /phoenix_cp; du -hd 2 /phoenix_up; cp -r /tmp /home/automation/cu_log_tmp"

# DEBUGGING - Stopping monitoring CPU script
if [ "$IS_NIGHTLY" == "true" ]; then
        echo "Stopping monitoring CPU script"
        # Retrieve and kill the monitoring script process
        if [ -f "$DEBUG_TOP_PID_FILE" ]; then
                DEBUG_TOP_CPU_PID=$(cat "$DEBUG_TOP_PID_FILE")
                echo "Terminating monitoring script with PID: $DEBUG_TOP_CPU_PID"
                kill -- $DEBUG_TOP_CPU_PID || true # Send SIGTERM to the entire process group
                rm "$DEBUG_TOP_PID_FILE"  # Cleanup PID file after killing the process
        else
                echo "PID file not found. Unable to terminate monitoring script."
        fi
fi
# DEBUGGING - Stopping monitoring CPU script

### Collect Robot test results
[[ -d "${WORKSPACE}/ROBOT-Report" ]] && (echo 'ROBOT-Report EXISTED!'; ls -lah ${WORKSPACE}/ROBOT-Report) || mkdir -p ${WORKSPACE}/ROBOT-Report
podman cp ${RUN_TESTS_CONTAINER}:/home/automation/test/cu_e1_test/automation/robotframework/ ${WORKSPACE}/ROBOT-Report
# For RHEL8, rename xunitreport.xml file to avoid duplicated results
mv ${WORKSPACE}/ROBOT-Report/robotframework/xunitreport.xml ${WORKSPACE}/ROBOT-Report/robotframework/rhel8-xunitreport.xml

# Collect messages & secure in /var/log for this Nightly run
if [ "$IS_NIGHTLY" == "true" ]; then
        echo "################## Collecting messages & secure in /var/log for this Nightly run ##################"
        SYSLOG_PATH='/home/automation/cu_log_tmp/syslog'
        CONTAINER_ID=$(podman ps -aq)
        podman exec ${RUN_TESTS_CONTAINER} sh -c "mkdir -p $SYSLOG_PATH"
        podman exec ${RUN_TESTS_CONTAINER} sh -c "grep $CONTAINER_ID /var/log/messages > /tmp/messages; cd $SYSLOG_PATH; tar -I lz4 -cf messages_${RUN_TESTS_CONTAINER}.tar.lz4 /tmp/messages; rm -f /tmp/messages"
        podman exec ${RUN_TESTS_CONTAINER} sh -c "grep $CONTAINER_ID /var/log/secure > /tmp/secure; cd $SYSLOG_PATH; tar -I lz4 -cf secure_${RUN_TESTS_CONTAINER}.tar.lz4 /tmp/secure; rm -f /tmp/secure"
        podman exec ${RUN_TESTS_CONTAINER} sh -c "cp -R /var/log/audit /tmp/audit; cd $SYSLOG_PATH; tar -I lz4 -cf audit_${RUN_TESTS_CONTAINER}.tar.lz4 /tmp/audit; rm -rf /tmp/audit"
fi

# Collect tmp files from podman container
mkdir ${WORKSPACE}/rhel8_cuut_tmp
podman cp ${RUN_TESTS_CONTAINER}:/home/automation/cu_log_tmp/. ${WORKSPACE}/rhel8_cuut_tmp
ls -lahR ${WORKSPACE}/rhel8_cuut_tmp
# DEBUGGING - Collect cpu_usage.log for this Nightly run
if [ "$IS_NIGHTLY" == "true" ]; then
        cp ${DEBUG_TOP_OUTPUT} ${WORKSPACE}/rhel8_cuut_tmp
fi
# DEBUGGING - Collect cpu_usage.log for this Nightly run
find ${WORKSPACE}/rhel8_cuut_tmp/ \( -type f -o -type l -o -type d \) -printf "%P\n" | tar -czf ${WORKSPACE}/rhel8_cuut_tmp.tar.gz --no-recursion -C ${WORKSPACE}/rhel8_cuut_tmp/ -T -
rm -rf ${WORKSPACE}/rhel8_cuut_tmp


if [ "$LCOV" == "true" ]; then
        echo "################## Start generating LCOV report ##################"
        # rm -rf ${WORKSPACE}/gNB_CU_{C,U}P/gNB_CU/*
        podman cp ${RUN_TESTS_CONTAINER}:$CUCP_BUILD_DIR/gNB_CU/. ${WORKSPACE}/gNB_CU_CP/gNB_CU
        podman cp ${RUN_TESTS_CONTAINER}:$CUUP_BUILD_DIR/gNB_CU/. ${WORKSPACE}/gNB_CU_UP/gNB_CU
        du -hd 2 ${WORKSPACE}/gNB_CU_CP || true
        # Generate CUCP and CUUP LCOV in parallel
        (
                # CUCP LCOV
                CUCP_BUILD_PATH="/phoenix/gNB_CU/build"
                podman run --rm --privileged --pids-limit=-1 \
                        --network=host \
                        --security-opt seccomp=unconfined \
                        -v ${WORKSPACE}/gNB_CU_CP:/phoenix \
                        -e CUCP_BUILD_PATH=$CUCP_BUILD_PATH \
                        ${RUN_TESTS_IMAGE} sh -c "set -eo pipefail;cd $CUCP_BUILD_PATH; ./compile_cu.sh -t cp -r -o; \
                                                  lcov --remove $CUCP_BUILD_PATH/lcov_report/full_report.info \"/opt/\" -o $CUCP_BUILD_PATH/lcov_report/full_report.info; \
                                                  genhtml $CUCP_BUILD_PATH/lcov_report/full_report.info -o $CUCP_BUILD_PATH/lcov_report | tee /phoenix/lcov_cucp_log.txt"
        ) &
        pidForCUCP=$!

        (
                # CUUP LCOV
                CUUP_BUILD_PATH="/phoenix/gNB_CU/build"
                podman run --rm --privileged --pids-limit=-1 \
                        --network=host \
                        --security-opt seccomp=unconfined \
                        -v ${WORKSPACE}/gNB_CU_UP:/phoenix \
                        -e CUUP_BUILD_PATH=$CUUP_BUILD_PATH \
                        ${RUN_TESTS_IMAGE} sh -c "set -eo pipefail;cd $CUUP_BUILD_PATH;./compile_cu.sh -t up -r -o; \
                                                  lcov --remove $CUUP_BUILD_PATH/lcov_report/full_report.info \"/opt/\" -o $CUUP_BUILD_PATH/lcov_report/full_report.info; \
                                                  genhtml $CUUP_BUILD_PATH/lcov_report/full_report.info -o $CUUP_BUILD_PATH/lcov_report | tee /phoenix/lcov_cuup_log.txt"
        ) &
        pidForCUUP=$!
        wait $pidForCUCP $pidForCUUP

        # Collect results
        mkdir ${WORKSPACE}/CUCP-Report
        mkdir ${WORKSPACE}/CUUP-Report
        [ -f ${WORKSPACE}/gNB_CU_CP/lcov_cucp_log.txt ] && cp ${WORKSPACE}/gNB_CU_CP/lcov_cucp_log.txt ${WORKSPACE}/CUCP-Report
        [ -f ${WORKSPACE}/gNB_CU_UP/lcov_cuup_log.txt ] && cp ${WORKSPACE}/gNB_CU_UP/lcov_cuup_log.txt ${WORKSPACE}/CUUP-Report
        cp -r ${WORKSPACE}/gNB_CU_CP/gNB_CU/build/lcov_report/* ${WORKSPACE}/CUCP-Report || true
        cp -r ${WORKSPACE}/gNB_CU_UP/gNB_CU/build/lcov_report/* ${WORKSPACE}/CUUP-Report || true
fi

# Clean up disk space
rm -rf ${WORKSPACE}/gNB_CU_{CP,UP}

chown -R jenkins:jenkins ${WORKSPACE}

ROBOT_OUTPUT_XML="${WORKSPACE}/ROBOT-Report/robotframework/output.xml"
if [ -f "${ROBOT_OUTPUT_XML}" ]; then
        echo "Output.xml file exists."
else
        echo "FAIL: Result output ${ROBOT_OUTPUT_XML} file does not exist."
        exit 1
fi

# Checking for pass, fail, skip results in output.xml
fail=$(grep "All Tests" ${ROBOT_OUTPUT_XML} | sed -e 's/.*fail=\"//g' | sed -e 's/\".*//g')
pass=$(grep "All Tests" ${ROBOT_OUTPUT_XML} | sed -e 's/.*pass=\"//g' | sed -e 's/\".*//g')
skip=$(grep "All Tests" ${ROBOT_OUTPUT_XML} | sed -e 's/.*skip=\"//g' | sed -e 's/\".*//g')

echo "----- Robot results -----"
echo "Pass: $pass"
echo "Fail: $fail"
echo "Skip: $skip"

# If any test cases were executed
if [ $pass -eq 0 ]; then
        echo "FAIL: No test cases executed; pass: $pass, fail: $fail , skip: $skip"
        exit 1
fi

# Checking for 100% result
if [ $pass -gt 0 ] && ([ $fail -ne 0 ] || [ $skip -ne 0 ]); then
        echo "FAIL: All tests have not passed; pass: $pass, fail: $fail , skip: $skip"
        exit 1
else
        echo "All tests have passed; pass: $pass, fail: $fail , skip: $skip"
fi
