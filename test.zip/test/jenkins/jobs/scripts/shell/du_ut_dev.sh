## Copyright (c) 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.
#!/bin/bash
set -ex
# Identify compile_du.sh script location
build_path=/phoenix/gNB_DU/build
[[ -f /phoenix/gNB_DU/compile_du.sh ]] && build_path=/phoenix/gNB_DU
cd $build_path
# Current time on container
date
# Get input parameters
while getopts "a: " opt; do
    case "$opt" in
    a) ADDRESS_SANITIZER="$OPTARG" ;;
    esac
done
# Refresh key after dnf install
rm /etc/yum.repos.d/redhat.repo && microdnf makecache 
# Install some dependent packages of sanitizer libraries
dnf install libasan gcc-toolset-10-libasan-devel liblsan gcc-toolset-10-liblsan-devel -y
# Start DU compilation
if [ "$ADDRESS_SANITIZER" = true ]; then
    ib_console --avoid-shared --avoid-basedir=/phoenix -c du_ut${DOCKER_TAG} ./compile_du.sh -t du-ut -j 200 -s address
    echo "Start DU compilation with address sanitizer !"
else
    ib_console --avoid-shared --avoid-basedir=/phoenix -c du_ut${DOCKER_TAG} ./compile_du.sh -t du-ut -j 200
    echo "Start DU compilation !"
fi 
# Identify DU UT build path
du_ut_path=/phoenix/gNB_DU/build/du_ut
[[ -d /phoenix/gNB_DU/build/ut ]] && du_ut_path=/phoenix/gNB_DU/build/ut
# Copy the startup script
cp /platform/containers/du/start_du_ut $du_ut_path/du_bin/bin/
# Copy service files
cp /platform/containers/du/start_du_ut_service $du_ut_path/du_bin/bin/
cp /platform/containers/du/stop_du_ut_service $du_ut_path/du_bin/bin/
cp /platform/containers/du/gNB_du_ut.service /root/
# Prepare DU environment
PATH=/opt/gnb/du_ut/bin:$PATH
ln -s /usr/bin/python3 /usr/bin/python