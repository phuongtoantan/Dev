#!/bin/bash
#Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

set -ex


DEFAULT_BASE_IMAGE="du_testsim_gbi:latest"

helpFunction() {
    echo ""
    echo "Usage: $0 -w <Jenkins Workspace>  -i <DU docker Image> -d <DU Test Sim directory> -c <Container name> -t <Tag for TestSim>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-i Specify the DU docker image. Only support DU MVL build variant now"
    echo -e "\t-d Specify the DU Test Sim directory"
    echo -e "\t-c Specify the container name"
    echo -e "\t-t Specify the tag for TestSim TCs"
    echo -e "\t-b Specify the base image"
    echo ""
    exit 1
}
# Get input parameters
while getopts "w: i: d: c: t: b:" opt; do
    case "$opt" in
    w) WORKSPACE="$OPTARG" ;;
    i) DU_IMAGE_NAME="$OPTARG" ;;
    d) DU_TEST_SIM_DIR="$OPTARG" ;;
    c) DU_TESTSIM_CONTAINER="$OPTARG" ;;
    t) TESTSIM_TAG="$OPTARG" ;;
    b) BASE_IMAGE="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Set a default value if BASE_IMAGE is not provided
BASE_IMAGE=${BASE_IMAGE:-$DEFAULT_BASE_IMAGE}

# Check parameters
if [ ! -d "$WORKSPACE" ]; then
    echo "Error: No such file or directory $WORKSPACE"
    helpFunction
fi
if [ -z "$DU_IMAGE_NAME" ]; then
    echo "DU docker image name is manadatory"
    helpFunction
fi
if [ -z "$DU_TEST_SIM_DIR" ]; then
    echo "DU Test Sim directory is manadatory"
    helpFunction
fi
if [ -z "$DU_TESTSIM_CONTAINER" ]; then
    echo "DU Test Sim container name is manadatory"
    helpFunction
fi
if [ -z "$(sudo podman images -q ${DU_IMAGE_NAME} 2>/dev/null)" ]; then
    echo "Unable to find image: ${DU_IMAGE_NAME}"
    exit 1
fi

CURRENT_SCRIPT_PATH="$(dirname -- "$(readlink -f "${BASH_SOURCE}")")"
time_stamp=$(date +%s)

#TODO parmatrize
DU_CONTAINER_NAME="du_build_ctn_$time_stamp"
# Downloading evans and goJson library
cd $WORKSPACE
wget https://phm.artifactory.cec.lab.emc.com/artifactory/mobile-phoenix-ran-external/evans
chmod +x evans
wget https://phm.artifactory.cec.lab.emc.com/artifactory/mobile-phoenix-ran-external/goJson
chmod +x goJson
echo "########################## Prepare DU build artifacts ##########################"
cd $WORKSPACE
echo "Get DU build artifacts from docker image: $DU_IMAGE_NAME"
sudo podman create --name $DU_CONTAINER_NAME $DU_IMAGE_NAME
sudo podman cp $DU_CONTAINER_NAME:/phoenix .
# DU folder will be created under $WORKSPACE
sudo mv phoenix DU
sudo rm -rf DU/gNB_DU_TEST_SIM
sudo cp -r gNB_DU_TEST_SIM DU/
echo "Update CONFD_DIR to align with DU path in podman container"
sudo sed -i "s#CONFD_DIR=/phoenix/gNB_DU/build/confd#CONFD_DIR=/DU/gNB_DU/build/confd#" "$WORKSPACE/DU/gNB_DU/build/confd/confdrc"
sudo podman rm $DU_CONTAINER_NAME
# Enable SCTP on the agent machine
echo "Enable sctp in RHEL8"
sudo modprobe sctp
cd $WORKSPACE



echo "########################## Start Test Sim Within Container ##########################"
# Mount necessary items, including the custom image optionaly and run test sim within container

sudo podman run -d --network=host --privileged --ulimit core=-1 --security-opt label=disable --name $DU_TESTSIM_CONTAINER \
   	-v /run/systemd/system:/run/systemd/system \
	-v /var/run/dbus/system_bus_socket:/var/run/dbus/system_bus_socket \
	-v /etc/rsyslog.d/:/etc/rsyslog.d/ \
	-v /dev:/dev \
    -v /lib/modules:/lib/modules \
    -v $WORKSPACE/DU:/DU \
    -v /home/jenkins/.ssh:/root/.ssh \
    -v $CURRENT_SCRIPT_PATH/start_du_testsim.sh:/scripts/start_du_testsim.sh \
    $BASE_IMAGE /usr/sbin/init


sudo podman ps
# Synchronize redhat.repo certificates by removing the gbi image certificates and creating new certificates
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'rm /etc/yum.repos.d/redhat.repo; microdnf makecache'
# Install latest MPLANE rpm from Artifactory
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'dnf install -y mplane'
# Copy evans and goJson to container
sudo podman cp $WORKSPACE/evans $DU_TESTSIM_CONTAINER:/usr/local/bin/
sudo podman cp $WORKSPACE/goJson $DU_TESTSIM_CONTAINER:/usr/local/bin/
# Install latest ACM rpm from Artifactory
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'dnf install -y acm'
# Check the existence of python packages on the TestSim container
sudo podman exec $DU_TESTSIM_CONTAINER bash -c 'pip3.8 list'
# Use du_testsim_pipeline.sh from shared-lib repo instead of pipeline.sh from gNB_DU_TEST_SIM repo
sudo podman cp $CURRENT_SCRIPT_PATH/du_testsim_pipeline.sh $DU_TESTSIM_CONTAINER:/DU/gNB_DU_TEST_SIM/tools
if [ -z "$TESTSIM_TAG" ]; then
    sudo podman exec -t $DU_TESTSIM_CONTAINER /scripts/start_du_testsim.sh -c $DU_TESTSIM_CONTAINER
else
    sudo podman exec -t $DU_TESTSIM_CONTAINER /scripts/start_du_testsim.sh -t $TESTSIM_TAG -c $DU_TESTSIM_CONTAINER
fi
echo "Test completed!"
# Check if any TC failed
FAIL_TC_NUM=$(cat $DU_TEST_SIM_DIR/failed_testcase_num)
if [ $FAIL_TC_NUM -gt 0 ]
        then
                echo "FAIL: $FAIL_TC_NUM failed test case(s)"
                exit 1
        else
                echo "All test cases are PASSED"
fi
