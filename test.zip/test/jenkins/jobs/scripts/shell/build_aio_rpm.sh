## Copyright (c) 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
#!/bin/bash
set -ex

helpFunction()
{
    echo ""
    echo "Usage: $0 -v <RPM_VERSION> -r <RPM_RELEASE> -c <CUCP_BUILD_VARIANT> -u <CUUP_BUILD_VARIANT> -d <DU_BUILD_VARIANT> -o <OAMA_BUILD_VARIANT> -n <NODED_BUILD_VARIANT> -e <AIO_RPM_EXPORT_PATH>"
    echo -e "\t-v Specify the RPM_VERSION"
    echo -e "\t-r Specify the RPM_RELEASE"
    echo -e "\t-c Specify the CUCP_BUILD_VARIANT"
    echo -e "\t-u Specify the CUUP_BUILD_VARIANT"
    echo -e "\t-d Specify the DU_BUILD_VARIANT"
    echo -e "\t-o Specify the OAMA_BUILD_VARIANT"
    echo -e "\t-n Specify the NODED_BUILD_VARIANT"
    echo -e "\t-e Specify the AIO_RPM_EXPORT_PATH"
    echo ""
    exit 1
}

# Get input parameters
while getopts "v: r: c: u: d: o: n: e:" opt
do
    case "$opt" in
        v ) RPM_VERSION="$OPTARG" ;;
        r ) RPM_RELEASE="$OPTARG" ;;
        c ) CUCP_BUILD_VARIANT="$OPTARG" ;;
        u ) CUUP_BUILD_VARIANT="$OPTARG" ;;
        d ) DU_BUILD_VARIANT="$OPTARG" ;;
        o ) OAMA_BUILD_VARIANT="$OPTARG" ;;
        n ) NODED_BUILD_VARIANT="$OPTARG" ;;
        e ) AIO_RPM_EXPORT_PATH="$OPTARG" ;;
        ? ) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ -z "$RPM_VERSION" ]; then
    echo "Error: $RPM_VERSION is manadatory"
    helpFunction
fi
if [ -z "$RPM_RELEASE" ]; then
    echo "Error: $RPM_RELEASE is manadatory"
    helpFunction
fi
if [ -z "$CUCP_BUILD_VARIANT" ]; then
    echo "Error: $CUCP_BUILD_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$CUUP_BUILD_VARIANT" ]; then
    echo "Error: $CUUP_BUILD_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$DU_BUILD_VARIANT" ]; then
    echo "Error: $DU_BUILD_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$OAMA_BUILD_VARIANT" ]; then
    echo "Error: $OAMA_BUILD_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$NODED_BUILD_VARIANT" ]; then
    echo "Error: $NODED_BUILD_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$AIO_RPM_EXPORT_PATH" ]; then
    echo "Error: $AIO_RPM_EXPORT_PATH is manadatory"
    helpFunction
fi

# Pull latest GBI image 
GBI_IMAGE=${GBI_IMAGE:='phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker/artifactory/platform/gbi:latest'}
podman pull $GBI_IMAGE

RHEL_RELEASE=8.6
# Create output directory to save aio rpm package
mkdir -p "$AIO_RPM_EXPORT_PATH"

# Run container to build aio rpm package
podman run --rm --privileged  \
    -v "$(pwd)/gNB_platform/containers/aio:/root/rpmbuild/SPECS"  \
    -v "$AIO_RPM_EXPORT_PATH:/output" \
    -e "RPM_VERSION=$RPM_VERSION" \
    -e "RPM_RELEASE=$RPM_RELEASE" \
    -e "CUCP_BUILD_VARIANT=$CUCP_BUILD_VARIANT" \
    -e "CUUP_BUILD_VARIANT=$CUUP_BUILD_VARIANT" \
    -e "DU_BUILD_VARIANT=$DU_BUILD_VARIANT" \
    -e "OAMA_BUILD_VARIANT=$OAMA_BUILD_VARIANT" \
    -e "NODED_BUILD_VARIANT=$NODED_BUILD_VARIANT" \
    $GBI_IMAGE \
    /bin/bash -c ' echo "Install tools and dependencies" && \
        rm /etc/yum.repos.d/redhat.repo && \
        microdnf --releasever=$RHEL_RELEASE makecache
        cd /root/rpmbuild && \
        chmod +x /root/rpmbuild/SPECS/set_version.sh
        /root/rpmbuild/SPECS/set_version.sh -f /root/rpmbuild/SPECS/aio_rpm.spec -o $OAMA_BUILD_VARIANT -n $NODED_BUILD_VARIANT -c $CUCP_BUILD_VARIANT -u $CUUP_BUILD_VARIANT && \
        rpmbuild -bb SPECS/aio_rpm.spec --define "VERSION $RPM_VERSION" \
                                        --define "RELEASE $RPM_RELEASE" \
                                        --define "CUCP_BUILD_VARIANT $CUCP_BUILD_VARIANT" \
                                        --define "CUUP_BUILD_VARIANT $CUUP_BUILD_VARIANT" \
                                        --define "DU_BUILD_VARIANT $DU_BUILD_VARIANT" \
                                        --define "OAMA_BUILD_VARIANT $OAMA_BUILD_VARIANT" \
                                        --define "NODED_BUILD_VARIANT $NODED_BUILD_VARIANT" && \
        ls -lrt /root/rpmbuild/SPECS && \
        ls -lrt /root/rpmbuild/RPMS/x86_64 && \
        cp -r /root/rpmbuild/RPMS/x86_64/aio*.rpm /output
        cp /root/rpmbuild/SPECS/aio_rpm.spec /output
    '