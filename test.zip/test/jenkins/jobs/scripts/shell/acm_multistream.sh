#!/bin/bash
## Copyright (c) 2023-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
# Default values
DU_BRANCH="main_2"
NGP_BRANCH="main_2"
OAM_BRANCH="main_2"
MPLANE_BRANCH="main_2"
ACM_BRANCH="main_2"
YANG_MODEL_BRANCH="main_2"


IMAGE_TAG="latest"
IMAGE_NAME="acm_prod_image"
CONTAINER_NAME="acm_staging_test"

# Default Dockerfile path
DOCKERFILE_PATH="acm_prod.dockerfile"

# Default build target
BUILD_TARGET="acm_build"

# Default cache option
CACHE_OPTION="--layers"
ENABLE_TESTING=false
PACKAGE_NAME="acm"
PACKAGE_VERSION="2.0.0.0"
PACKAGE_RELEASE="1000"

# Function to show usage
show_usage() {
    echo "Usage: $0 [options]"
    echo "Options:"
    echo "  -d, --du-branch BRANCH     Set DU branch (default: main_2)"
    echo "  -n, --ngp-branch BRANCH    Set NGP branch (default: main_2)"
    echo "  -o, --oam-branch BRANCH    Set OAM branch (default: main_2)"
    echo "  -m, --mplane-branch BRANCH Set MPLANE branch (default: main_2)"
    echo "  -a, --acm-branch BRANCH    Set ACM branch (default: main_2)"
    echo "  -y, --yang-model-branch BRANCH    Set yang model branch (default: main_2)"
    echo "  -t, --tag TAG              Set Docker image tag (default: latest)"
    echo "  -f, --dockerfile FILE      Set path to Dockerfile (default: acm_dependencies.dockerfile)"
    echo "  -i, --image-name NAME      Set Docker image name (default: acm_dependencies_image)"
    echo "  -e, --enable-testing       Enable testing during build (default: false)"
    echo "  -h, --help                 Show this help message"
    echo "  -p, --package-name NAME    Set RPM package name (default: default_name)"
    echo "  -v, --package-version VER  Set RPM package version (default: default_version)"
    echo "  -r, --package-release REL  Set RPM package release (default: default_release)"
    echo "  -w, --workspace            Specify workspace (default: Jenkins Workspace)"
    echo "  -c, --container-name       Specify ACM Staging container name (default: acm_staging_test)"
    exit 1
}
# Function to display variables
display_variables() {
    echo "Variables set:"
    echo "  - DU_BRANCH: $DU_BRANCH"
    echo "  - NGP_BRANCH: $NGP_BRANCH"
    echo "  - OAM_BRANCH: $OAM_BRANCH"
    echo "  - MPLANE_BRANCH: $MPLANE_BRANCH"
    echo "  - ACM_BRANCH: $ACM_BRANCH"
    echo "  - YANG_MODEL_BRANCH: $YANG_MODEL_BRANCH"
    echo "  - IMAGE_TAG: $IMAGE_TAG"
    echo "  - DOCKERFILE_PATH: $DOCKERFILE_PATH"
    echo "  - IMAGE_NAME: $IMAGE_NAME"
    echo "  - ENABLE_TESTING: $ENABLE_TESTING"
    echo "  - PACKAGE_NAME: $PACKAGE_NAME"
    echo "  - PACKAGE_VERSION: $PACKAGE_VERSION"
    echo "  - PACKAGE_RELEASE: $PACKAGE_RELEASE"
    echo "  - WORKSPACE: $WORKSPACE"
    echo "  - CONTAINER_NAME: $CONTAINER_NAME"
    echo ""
}
# Parse command line options
while [[ $# -gt 0 ]]; do
    case "$1" in
        -d|--du-branch)
            DU_BRANCH="$2"
            shift 2
            ;;
        -n|--ngp-branch)
            NGP_BRANCH="$2"
            shift 2
            ;;
        -o|--oam-branch)
            OAM_BRANCH="$2"
            shift 2
            ;;
        -m|--mplane-branch)
            MPLANE_BRANCH="$2"
            shift 2
            ;;
        -a|--acm-branch)
            ACM_BRANCH="$2"
            shift 2
            ;;
        -y|--yang-model-branch)
            YANG_MODEL_BRANCH="$2"
            shift 2
            ;;
        -t|--tag)
            IMAGE_TAG="$2"
            shift 2
            ;;
        -f|--dockerfile)
            DOCKERFILE_PATH="$2"
            shift 2
            ;;
        -i|--image-name)
            IMAGE_NAME="$2"
            shift 2
            ;;
        -e|--enable-testing)
            ENABLE_TESTING=true
            shift
            ;;
        -h|--help)
            show_usage
            ;;
        -p|--package-name)
            PACKAGE_NAME="$2"
            shift 2
            ;;
        -v|--package-version)
            PACKAGE_VERSION="$2"
            shift 2
            ;;
        -r|--package-release)
            PACKAGE_RELEASE="$2"
            shift 2
            ;;
        -nc|--no-cache)
            NO_CACHE=true
            shift
            ;;
        -w|--workspace)
            WORKSPACE="$2"
            shift 2
            ;;
        -c|--container-name)
            CONTAINER_NAME="$2"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            show_usage
            ;;
    esac
done

SCRIPT_PATH="${WORKSPACE}/build_scripts/jenkins/jobs/scripts/shell"
echo "script path is : ${SCRIPT_PATH}"

if [ "$NO_CACHE" = "true" ]; then
    CACHE_OPTION="--no-cache"
fi
# Conditionally set the Dockerfile path based on testing
if [ "$ENABLE_TESTING" = "true" ]; then
    DOCKERFILE_PATH="acm_staging.dockerfile"
    IMAGE_NAME="acm_staging_image"
    container=$(podman ps -a --format "{{.ID}} {{.Image}}" | grep "${CONTAINER_NAME}" | awk '{print $1}')
    for id in $container; do
        echo "Stopping container: $id"
        podman stop $id
        echo "Removing container: $id"
        podman rm $id
    done 
fi
# Display passed options and set variables
echo "Passed options:"
for arg in "$@"; do
    echo "  - $arg"
done
echo ""
display_variables


# Get a list of container IDs running the specified image
container_ids=$(podman ps -a --format "{{.ID}} {{.Image}}" | grep "${IMAGE_NAME}:${IMAGE_TAG}" | awk '{print $1}')

# Stop and remove the containers
for id in $container_ids; do
    echo "Stopping container: $id"
    podman stop $id
    echo "Removing container: $id"
    podman rm $id
done

# Get a list of image IDs with the specified tag and name
image_ids=$(podman images --format "{{.ID}} {{.Repository}}:{{.Tag}}" | grep "${IMAGE_NAME}:${IMAGE_TAG}" | awk '{print $1}')

# Iterate through the image IDs and remove them
for id in $image_ids; do
    echo "Removing image: $id"
    podman rmi $id
done

echo "Image and container cleanup completed."

# Build the image using buildah
cmd="buildah bud -t $IMAGE_NAME:$IMAGE_TAG \
    $CACHE_OPTION \
    --build-arg DU_BRANCH=$DU_BRANCH \
    --build-arg NGP_BRANCH=$NGP_BRANCH \
    --build-arg OAM_BRANCH=$OAM_BRANCH \
    --build-arg MPLANE_BRANCH=$MPLANE_BRANCH \
    --build-arg ACM_BRANCH=$ACM_BRANCH \
    --build-arg YANG_MODEL_BRANCH=$YANG_MODEL_BRANCH \
    --build-arg ENABLE_TESTING=$ENABLE_TESTING \
    --target $BUILD_TARGET \
    -f $DOCKERFILE_PATH ."

echo "Running command:"
echo "$cmd"
echo

# Execute the build command
$cmd

if [ $? -eq 0 ]; then
    echo "Build completed: $IMAGE_NAME:$IMAGE_TAG"

    # If testing is enabled, run tests and perform additional operations
    if [ "$ENABLE_TESTING" = "true" ]; then
        host_results_dir="$(pwd)/test_results"
        # Create the local directory if it doesn't exist
        mkdir -p "$host_results_dir"
        ulimit -c unlimited        
        # Run the container with a bind mount to copy the file
        chmod +x "${SCRIPT_PATH}/run_acm_tests.sh"
        podman run -d --network host --privileged --name $CONTAINER_NAME --ulimit core=-1 --security-opt label=disable \
            -v "$host_results_dir:/output" \
            -v /lib/modules:/lib/modules \
            -v /dev:/dev \
            -v /run/systemd/system:/run/systemd/system \
            -v /var/run/dbus/system_bus_socket:/var/run/dbus/system_bus_socket \
            -v /etc/rsyslog.d/:/etc/rsyslog.d/ \
            -v /var/log:/var/log \
            -v "${SCRIPT_PATH}:/scripts" \
            -v /var/lib/systemd/coredump:/var/lib/systemd/coredump \
            $IMAGE_NAME:$IMAGE_TAG \
            sleep infinity
        podman ps -a
        # Configuring coredumps
        # podman exec $CONTAINER_NAME /bin/bash -c 'chmod +x /scripts/acm_coredump_config.sh; sh /scripts/acm_coredump_config.sh'
        # Running the unit tests
        podman exec $CONTAINER_NAME /bin/bash -c 'cd /DU/gNB_ACM/build/bin/;/DU/gNB_ACM/scripts/run_tests.sh -- --gtest_filter="*UnitTest*"; cp test_detail.xml /output/unit_test_results.xml'
        # Running the component tests
        podman exec $CONTAINER_NAME /bin/bash -c 'cd /DU/gNB_ACM/build/bin/;/DU/gNB_ACM/scripts/run_tests.sh -- --gtest_filter="*ComponentTest*"; cp test_detail.xml /output/component_test_results.xml; cp -avr lcov_results /output'
        sudo chmod 777 -R "$host_results_dir"
        echo "unit_test_results.xml component_test_results.xml copied to $host_results_dir"

    else
        # Run the container to generate RPMs and save them in a host directory
        echo "Running container to generate RPMs"
        host_rpm_dir="$(pwd)/rpm_output_$IMAGE_TAG"
        mkdir -p "$host_rpm_dir"
        podman run -v "$host_rpm_dir:/output" $IMAGE_NAME:$IMAGE_TAG \
            /bin/bash -c "
                rm /etc/yum.repos.d/redhat.repo && \
                microdnf makecache
                chmod +x /root/set_version.sh
                /root/set_version.sh -f /root/rpmbuild/SPECS/acm_rpm.spec
                cd /DU/gNB_ACM && \
                cd /root/rpmbuild && \
                QA_RPATHS=$[ 0x0002 ] rpmbuild -bb SPECS/acm_rpm.spec --define 'PACKAGE_NAME $PACKAGE_NAME' --define 'PACKAGE_VERSION $PACKAGE_VERSION' --define 'PACKAGE_RELEASE $PACKAGE_RELEASE' && \
                cp -r /root/rpmbuild/RPMS/x86_64 /output
                cp /root/rpmbuild/SPECS/acm_rpm.spec /output
            "
        sudo chmod 777 -R "$host_rpm_dir"    
    fi

else
    echo "Image build failed."
fi