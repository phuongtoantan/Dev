#!/bin/bash
# Copyright © 2024 Dell Inc. or its subsidiaries. All Rights Reserved.
set -ex

helpFunction() {
    echo ""
    echo "Usage: $0 -w <Jenkins Workspacke/Git Repo Clone> -n <NGP branch> -o <OAM branch> -m <MPLANE branch> -i <API_BRANCH> -d <DU_BRANCH> -c <NODED_BRANCH> -y <YANG_MODEL_BRANCH> -t <MPLANE TAG>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-n Specify the NGP branch"
    echo -e "\t-o Specify the OAM branch"
    echo -e "\t-m Specify the MPLANE branch"
    echo -e "\t-i Specify the API branch"
    echo -e "\t-d Specify the DU branch"
    echo -e "\t-c Specify the Node Controller branch"
    echo -e "\t-y Specify the Yang Model branch"
    echo -e "\t-t Specify the MPLANE tag"
    echo ""
    exit 1
}

NGP_BRANCH="HEAD"
OAM_BRANCH="HEAD"
MPLANE_BRANCH="HEAD"
API_BRANCH="HEAD"
DU_BRANCH="HEAD"
NODED_BRANCH="HEAD"

# Get input parameters
while getopts "w: n: o: m: i: d: c: y: t:" opt; do
    case "$opt" in
    w) WORKSPACE="$OPTARG" ;;
    n) NGP_BRANCH="$OPTARG" ;;
    o) OAM_BRANCH="$OPTARG" ;;
    m) MPLANE_BRANCH="$OPTARG" ;;
    i) API_BRANCH="$OPTARG" ;;
    d) DU_BRANCH="$OPTARG" ;;
    c) NODED_BRANCH="$OPTARG" ;;
    y) YANG_MODEL_BRANCH="$OPTARG" ;;
    t) MPLANE_TAG="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ ! -d "$WORKSPACE" ]; then
    echo "Error: No such file or directory $WORKSPACE"
    helpFunction
fi

cd $WORKSPACE/containers/mplane
TIME_STAMP=$(date +%N)
CACHE_OPTION="--no-cache"
ls -ltr
pwd
echo -n "$GIT_ACCOUNT" >gitsecret.txt

buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --target mplane_tools -t mplane_tools:$MPLANE_TAG -f buildah_mplane_ib.dockerfile .

echo "Building set_mplane_env stage..."
buildah images
buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg NGP_BRANCH=$NGP_BRANCH --build-arg OAM_BRANCH=$OAM_BRANCH --build-arg MPLANE_BRANCH=$MPLANE_BRANCH --build-arg API_BRANCH=$API_BRANCH --build-arg DU_BRANCH=$DU_BRANCH --build-arg NODED_BRANCH=$NODED_BRANCH --build-arg YANG_MODEL_BRANCH=$YANG_MODEL_BRANCH --target set_mplane_env -t set_mplane_env:$MPLANE_TAG -f buildah_mplane_ib.dockerfile .
buildah images | egrep "set_mplane_env +$MPLANE_TAG"
echo "set_mplane_env stage built successfully."

echo "Building ib compuilation stage..."
buildah containers
buildah images
/opt/incredibuild/bin/ib_podman run --privileged --name mplane_dev_$MPLANE_TAG set_mplane_env:$MPLANE_TAG bash -c "find /opt/grpc/ -type f -exec touch {} + && cd /DU/gNB_FH_MPLANE/build && ib_console --avoid-shared --avoid-basedir=/phoenix  ./compile_mplane.sh && ls -la /DU/gNB_FH_MPLANE/build && ls -la /DU/gNB_FH_MPLANE/opt/gnb/mplane"

echo "ib container running supposed"
podman container list

podman commit --format docker mplane_dev_$MPLANE_TAG mplane_rpm:$MPLANE_TAG
podman run --rm --entrypoint ls mplane_rpm:$MPLANE_TAG /DU/gNB_FH_MPLANE/opt/gnb/mplane
echo "ib compuilation stage built successfully."

echo "commiting the ib container stage..."
buildah images | egrep "mplane_rpm +$MPLANE_TAG"
podman images | egrep "mplane_rpm +$MPLANE_TAG"
echo "ib commitment successfully."

echo "final mplane build container stage..."
buildah build $CACHE_OPTION --format docker --secret id=gitsecret,src=gitsecret.txt --build-arg BASE_IMAGE="mplane_rpm:$MPLANE_TAG" \
    -t mplane_final:$MPLANE_TAG -f buildah_source_mplane_ib.dockerfile .
ls -la
cd $WORKSPACE/build_scripts/jenkins/jobs/scripts/shell
ls -la
buildah unshare ./buildah_get_rpm.sh mplane_final:$MPLANE_TAG
echo "final mplane done..."

#generic pattern matching for the copying 
cp gRPC-*.x86_64.rpm ../../../../../
cp mplane-*.x86_64.rpm ../../../../../ 

cd $WORKSPACE/containers/mplane

# Extract MPLANE binary from mplane dev container
podman cp mplane_dev_$MPLANE_TAG:/DU/gNB_FH_MPLANE/build/bin/mplane ../../

echo "conatiner and Imgaes clean up..."
podman rm mplane_dev_$MPLANE_TAG
buildah rmi mplane_final:$MPLANE_TAG
buildah rmi mplane_rpm:$MPLANE_TAG
buildah rmi set_mplane_env:$MPLANE_TAG
buildah rmi mplane_tools:$MPLANE_TAG