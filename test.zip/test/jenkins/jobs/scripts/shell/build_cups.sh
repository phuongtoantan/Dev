#!/bin/bash
set -ex

#Prepare env for build and run build

if [ "$1" = "" ];then
        echo "Parameter 1: Workspace/repo path is manadatory"
        echo "./build_cups.sh /home/jenkins/gNB_CU dpdk master"
        exit 0
fi

if [ "$2" = "" ];then
        echo "Parameter 2: dpdk or no_dpdk manadatory"
        echo "./build_cups.sh /home/jenkins/gNB_CU dpdk master"
        exit 0
fi

if [ "$3" = "" ];then
        echo "Parameter 3: branch, mandatory"
        echo "./build_cups.sh /home/jenkins/gNB_CU dpdk master"
        exit 0
fi

timeStamp=$(date +%s)

export DOCKER_BUILDKIT=1
eval "$(ssh-agent -s)"

#Add key for specific host
ssh-add

#Setup tag
DOCKER_TAG=""

if [ "$3" != "main" ];then
        DOCKER_TAG=":$3"
	#Change to lower case and replace / with _ in the branch tag
        DOCKER_TAG=`echo $DOCKER_TAG | awk '{print tolower($0)}'| sed -e "s/\//_/g"`
        echo "Docker tag : $DOCKER_TAG"
fi


cd $1/containers
pwd

#Get confd
wget -r -np -R 'index.html*' --no-check-certificate -nH --cut-dirs=4 \
     https://phm.artifactory.cec.lab.emc.com/artifactory/list/mobile-phoenix-ran-external/confd-basic-7.3.3/confd-basic-7.3.3.linux.x86_64.zip

ls -ltr;pwd

#Build GCC
docker build --target=gcc_5.4 -t gcc_5.4 -f build_cu_dpdk.dockerfile .

if [ "no_dpdk" = "$2" ]; then
	DOCKER_CU_CP_IMAGE_NAME="${4:-gnb_cu_cp_prod}"
	DOCKER_CU_UP_IMAGE_NAME="${5:-gnb_cu_up_prod}"

	#Run build commands no dpdk
        echo "Building no_dpdk...."

	#Build cu_tools
        docker build --target=cu_tools -t cu_tools -f build_cu.dockerfile .

	docker build --ssh default --build-arg BRANCH=$3 --build-arg USECACHE=$(date +%s) --build-arg CU_FLAGS="-o -l" --target=build_cu_cp -t $DOCKER_CU_CP_IMAGE_NAME$DOCKER_TAG -f build_cu.dockerfile .
	docker build --ssh default --build-arg BRANCH=$3 --build-arg USECACHE=$(date +%s) --build-arg CU_FLAGS="-o -l" --target=build_cu_up -t $DOCKER_CU_UP_IMAGE_NAME$DOCKER_TAG -f build_cu.dockerfile .
	docker create --name cu_cp_prod$timeStamp $DOCKER_CU_CP_IMAGE_NAME$DOCKER_TAG
	docker create --name cu_up_prod$timeStamp $DOCKER_CU_UP_IMAGE_NAME$DOCKER_TAG
	docker cp cu_cp_prod$timeStamp:/phoenix/5gran/cu/build/cucp_build.tar.gz $1
	docker cp cu_up_prod$timeStamp:/phoenix/5gran/cu/build/cuup_build.tar.gz $1
	docker cp cu_cp_prod$timeStamp:/phoenix/5gran/cu/build/cucp_time.txt $1
	docker cp cu_up_prod$timeStamp:/phoenix/5gran/cu/build/cuup_time.txt $1

	docker rm cu_cp_prod$timeStamp
	docker rm cu_up_prod$timeStamp
	ls -ltr
else
	#Run build commands dpdk - default      
	echo "Building dpdk...."

	#Build cu_tools_dpdk
        docker build --target=cu_tools_dpdk -t cu_tools_dpdk -f build_cu_dpdk.dockerfile .

	docker build --ssh default --build-arg BRANCH=$3 --build-arg USECACHE=$(date +%s) --target=build_cu_cp_dpdk -t gnb_cu_cp_crypto_dpdk$DOCKER_TAG -f build_cu_dpdk.dockerfile .
	docker build --ssh default --build-arg BRANCH=$3 --build-arg USECACHE=$(date +%s) --target=build_cu_up_dpdk -t gnb_cu_up_crypto_dpdk$DOCKER_TAG -f build_cu_dpdk.dockerfile .
	docker create --name cu_cp_dpdk_prod gnb_cu_cp_crypto_dpdk$DOCKER_TAG
	docker create --name cu_up_dpdk_prod gnb_cu_up_crypto_dpdk$DOCKER_TAG
	docker cp cu_cp_dpdk_prod:/phoenix/5gran/cu/build/cucp_build.tar.gz $1
	docker cp cu_up_dpdk_prod:/phoenix/5gran/cu/build/cuup_build.tar.gz $1
	docker cp cu_cp_dpdk_prod:/phoenix/5gran/cu/build/cucp_time.txt $1
	docker cp cu_up_dpdk_prod:/phoenix/5gran/cu/build/cuup_time.txt $1
	docker rm cu_cp_dpdk_prod
	docker rm cu_up_dpdk_prod
	ls -ltr
fi
