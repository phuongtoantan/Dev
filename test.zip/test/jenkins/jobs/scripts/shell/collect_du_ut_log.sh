## Copyright (c) 2021-2023 Dell Inc. or its subsidiaries. All Rights Reserved.

#!/bin/bash
helpFunction() {
    echo ""
    echo "Usage: $0 -w <Jenkins Workspace>  -c <Container name>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-c Specify the container name"
    echo ""
    exit 1
}

# Get input parameters
while getopts "w: c:" opt; do
    case "$opt" in
    w) WORKSPACE="$OPTARG" ;;
    c) DU_UT_CONTAINER="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done
# Identify DU UT build path
du_ut_path=/phoenix/gNB_DU/build/du_ut
sudo podman exec $DU_UT_CONTAINER bash -c "[[ -d /phoenix/gNB_DU/build/ut ]]" && du_ut_path=/phoenix/gNB_DU/build/ut

# Identify DU log path
du_log_path=/var/log/gnb/
sudo podman exec $DU_UT_CONTAINER bash -c '[[ -d /var/log/gnb/O-RAN/O-DU/OT/L2/DU/Logs ]]' && du_log_path=/var/log/gnb/O-RAN/O-DU/OT/L2/DU/Logs

#Collect DU log and coredump
sudo podman exec $DU_UT_CONTAINER bash -c 'pwd;ls -l'
sudo podman exec $DU_UT_CONTAINER bash -c "mkdir -p /du_log;ls -l $du_ut_path/du_bin/bin/;ls -l $du_log_path/DU_*"
if sudo podman exec $DU_UT_CONTAINER bash -c "compgen -G $du_ut_path/du_bin/bin/du_stats_*" > /dev/null; then
    sudo podman exec $DU_UT_CONTAINER bash -c "cp $du_ut_path/du_bin/bin/du_stats_* /du_log"
else
    echo "There is NO du_stats_* files"
fi
if sudo podman exec $DU_UT_CONTAINER bash -c "compgen -G $du_log_path/DU_*" > /dev/null; then
    sudo podman exec $DU_UT_CONTAINER bash -c "cp -r $du_log_path/DU_* /du_log"
else
    echo "There is NO $du_log_path/DU_* files"
fi
if sudo podman exec $DU_UT_CONTAINER bash -c "compgen -G $du_ut_path/du_bin/bin/gnb_du*" > /dev/null; then
    sudo podman exec $DU_UT_CONTAINER bash -c "cp $du_ut_path/du_bin/bin/gnb_du /du_log"
else
    echo "There is NO gnb_du files"
fi
if sudo podman exec $DU_UT_CONTAINER bash -c "compgen -G $du_ut_path/du_bin/bin/liboamdu.so*" > /dev/null; then
    sudo podman exec $DU_UT_CONTAINER bash -c "cp $du_ut_path/du_bin/bin/liboamdu.so /du_log"
else
    echo "There is NO liboamdu.so files"
fi
if sudo podman exec $DU_UT_CONTAINER bash -c "compgen -G $du_ut_path/du_bin/bin/core.*" > /dev/null; then
    sudo podman exec $DU_UT_CONTAINER bash -c "mv $du_ut_path/du_bin/bin/core.* $du_ut_path/du_bin/bin/coredump"
else
    echo "There is NO $du_ut_path/du_bin/bin/core.* files"
fi
echo "Coredump directory on container:"
sudo podman exec $DU_UT_CONTAINER bash -c "ls -lrth $du_ut_path/du_bin/bin/coredump || true"
sudo podman exec $DU_UT_CONTAINER bash -c "cd $du_ut_path/du_bin/bin; tar -I lz4 -cf coredump.tar.lz4 coredump && rm -rf coredump || true"
sudo podman exec $DU_UT_CONTAINER bash -c "cp $du_ut_path/du_bin/bin/coredump.tar.lz4 /du_log"
sudo podman exec $DU_UT_CONTAINER bash -c 'ls -lrth /du_log'
mkdir -p $WORKSPACE/du_log
ls -lrth $WORKSPACE
sudo podman cp $DU_UT_CONTAINER:/du_log/. $WORKSPACE/du_log
sudo zip -r -q $WORKSPACE/du_ut_log.tar.gz $WORKSPACE/du_log
pwd
ls -lrth $WORKSPACE
rm -rf $WORKSPACE/du_log
ls -lrth $WORKSPACE