# Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

#!/bin/bash
helpFunction() {
    echo ""
    echo "Usage: $0 -i <Agent IP>  -u <Agent SSH username> -p <Agent SSH password> -t <Target Label> -a <Artifactory Username> -b <Artifactory Password>"
    echo -e "\t-i Specify the target agent IP"
    echo -e "\t-u Specify the target agent SSH username"
    echo -e "\t-p Specify the target agent SSH password"
    echo -e "\t-t Specify the target label"
    echo -e "\t-a Specify the Artifactory username"
    echo -e "\t-b Specify the Artifactory password"
    echo ""
    exit 1
}

# Get input parameters
while getopts "i: u: p: t: a: b:" opt; do
    case "$opt" in
    i) IP_ADDRESS="$OPTARG" ;;
    u) USER_NAME="$OPTARG" ;;
    p) PASSWORD="$OPTARG" ;;
    t) TARGET_LABEL="$OPTARG" ;;
    a) ARTIFACTORY_USERNAME="$OPTARG" ;;
    b) ARTIFACTORY_PASSWORD="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

checkAgentStatusAfterRebootViaSSH() {
    local userName=$1 passWord=$2 ipAddress=$3 retries=0 maxRetries=20
    # Wait for agent turn off...
    while [ $retries -lt $maxRetries ]; do
        sshpass -p "$passWord" ssh -o StrictHostKeyChecking=no -q -o ConnectTimeout=3 "$userName@$ipAddress" exit
        if [ $? -ne 0 ]; then
            echo "The agent turn off now !"
            break
        else
            echo "Wait for agent turn off !"
            sleep 7
            retries=$((retries + 1))
        fi
    done
    if [ $retries -eq $maxRetries ]; then
        echo "The agent does not turn off ! "
        exit 1
    fi

    # Wait for agent turn on...
    retries=0
    sleep 60
    while [ $retries -lt $maxRetries ]; do
        sshpass -p "$passWord" ssh -o StrictHostKeyChecking=no -q -o ConnectTimeout=3 "$userName@$ipAddress" exit
        if [ $? -eq 0 ]; then
            echo "The agent turn on now !"
            break
        else
            echo "Wait for agent turn on !"
            sleep 10
            retries=$((retries + 1))
        fi
    done
    if [ $retries -eq $maxRetries ]; then
        echo "The agent does not turn on ! "
        exit 1
    fi
}

if ! type sshpass >/dev/null; then
    sudo dnf install -y sshpass
fi

echo "Execute cleanup commands on remote agent: $IP_ADDRESS"
# We will use difference cleanup strategy for each type of labels
case "$TARGET_LABEL" in
"initiator_incredibuild1" | "oam_sim_test")
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date
echo "Disk space before cleanup:"; df -h
echo "##### Cleanup workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; ls -la; sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
docker system prune -a -f; docker ps -a; docker images
buildah rm -a
podman rmi -f \$(podman images -aq)
podman system prune -a -f
podman login -u $ARTIFACTORY_USERNAME -p $ARTIFACTORY_PASSWORD $ARTIFACTORY_SERVER
echo "Pulling latest gbi image..."
podman pull -q $GBI_IMAGE
podman ps -a; podman images
echo "Disk space after cleanup:"; df -h
sudo reboot
exit
EOF
checkAgentStatusAfterRebootViaSSH $USER_NAME $PASSWORD $IP_ADDRESS
    ;;
"du-test-sim" | "du-test-sim_mainstream" | "rh8-du-ut" | "initiator_incredibuild2")
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date
echo "Disk space before cleanup:"; df -h
echo "##### Cleanup workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; ls -la; sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
buildah rm -a
podman rmi -f \$(podman images -aq)
podman system prune -a -f
podman login -u $ARTIFACTORY_USERNAME -p $ARTIFACTORY_PASSWORD $ARTIFACTORY_SERVER
echo "Pulling latest gbi image..."
podman pull -q $GBI_IMAGE
podman ps -a; podman images
sudo podman rmi -f \$(sudo podman images -aq)
sudo podman system prune -a -f
echo "Pulling latest gbi image..."
sudo podman pull -q $GBI_IMAGE
sudo podman ps -a; sudo podman images
echo "##### Cleanup /var/temp files #####"
echo "Before cleanup /var/tmp: "; sudo du -hsx /var/tmp/ | awk '{print \$1}'
sudo find /var/tmp -mindepth 1 -maxdepth 1 -mtime +1 -exec rm -rf {} \;
echo "After cleanup /var/tmp: "; sudo du -hsx /var/tmp/ | awk '{print \$1}'
echo "Disk space after cleanup:"; df -h
sudo reboot
exit
EOF
checkAgentStatusAfterRebootViaSSH $USER_NAME $PASSWORD $IP_ADDRESS
    ;;
"cu_build_rhel8" | "rhel8-du-build" | "du_cov_rhel8" | "coverity-rhel8")
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date
echo "Disk space before cleanup:"; df -h
echo "##### Cleanup workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; ls -la; sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
buildah rm -a
podman rmi -f \$(podman images -aq)
podman system prune -a -f
podman login -u $ARTIFACTORY_USERNAME -p $ARTIFACTORY_PASSWORD $ARTIFACTORY_SERVER
echo "Pulling latest gbi image..."
podman pull -q $GBI_IMAGE
podman ps -a; podman images
echo "Disk space after cleanup:"; df -h
sudo reboot
exit
EOF
checkAgentStatusAfterRebootViaSSH $USER_NAME $PASSWORD $IP_ADDRESS
    ;;
"MANUAL-CU-UT-RHEL8" | "CU-UT-RHEL8" | "CU-MEM-CHECK" | "oam_sim_test_rhel8" | "coverity-rhel8" | "rhel8-oam" | "oam_sim_test_cron_rhel8") # Cleanup buildah/podman using with root
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date
echo "Disk space before cleanup:"; df -h
echo "##### Cleanup workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; ls -la; sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;

echo "##### Remove all non running containers (root) #####"
sudo podman container prune -f

echo "##### Deep cleanup podman/podman used by sudo #####"
sudo buildah rm -a
sudo podman rmi -f \$(sudo podman images -aq)
sudo podman system prune -a -f

echo "##### Pulling latest gbi image #####"
sudo podman login -u $ARTIFACTORY_USERNAME -p $ARTIFACTORY_PASSWORD $ARTIFACTORY_SERVER
sudo podman pull -q $GBI_IMAGE
sudo podman ps -a; sudo podman images
echo "Disk space after cleanup:"; df -h
sudo reboot
exit
EOF
checkAgentStatusAfterRebootViaSSH $USER_NAME $PASSWORD $IP_ADDRESS
    ;;
"Banned-Function-Check-host" | "platform" | "component-testing") # Cleanup workspace
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date
echo "Disk space before cleanup:"; df -h
echo "##### Cleanup Jenkins workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; ls -la; sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;

echo "Disk space after cleanup:"; df -h
exit
EOF
    ;;
"ru-docker" | "ru-albus-docker") # Cleanup workspace
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date
echo "Disk space before cleanup:"; df -h
echo "##### Cleanup Jenkins workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; ls -la; sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
sudo docker system prune -a -f; docker ps -a; docker images

echo "Disk space after cleanup:"; df -h
exit
EOF
    ;;
*) # Invalid option
    echo -e "Error: Not support label: '$TARGET_LABEL'"
    exit 1
    ;;
esac
