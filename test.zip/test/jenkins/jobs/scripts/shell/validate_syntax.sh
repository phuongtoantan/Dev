# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.
#! /bin/bash
set -o pipefail

while getopts "f: u: p: l: t: s: d:" opt
do
    case "$opt" in
        f ) FOLDER_VALIDATE="$OPTARG" ;;
        u ) JENKINS_USERNAME="$OPTARG" ;;
        p ) JENKINS_PASSWORD="$OPTARG" ;;
        l ) JENKINS_VALIDATE_TOOL_URL="$OPTARG" ;;
        t ) TARGET_FOLDER="$OPTARG" ;;
        s ) SCRIPT_BRANCH="$OPTARG" ;;
        d ) TARGET_BRANCH="$OPTARG" ;;
    esac
done
set -e
cd ${FOLDER_VALIDATE}
git checkout $SCRIPT_BRANCH || echo "Branch already on $SCRIPT_BRANCH"
set +e
# Create an empty array to store the file names
files=()
# Loop through each file in the folder and add it to the array
# git diff --name-only main
for file in "$TARGET_FOLDER"/*
    do
    if [ -f "$file" ]; then
            files+=("$file")
    fi
done
set -e
files=$(git diff --name-only origin/$TARGET_BRANCH $TARGET_FOLDER/*.groovy)
echo $files
files_array=( $files )

# loop through the array and print each file
for file in "${files_array[@]}"
do
    echo "Validating pipeline: $file"
    output=$(curl -s -u "$JENKINS_USERNAME:$JENKINS_PASSWORD" -k -X POST -F "jenkinsfile=<${file}" ${JENKINS_VALIDATE_TOOL_URL})
    if echo "$output" | grep -q "Jenkinsfile successfully validated."; then
        echo "[$file] Validation successful!"
    elif echo "$output" | grep -q "did not contain the 'pipeline' step"; then
        echo "[WARNING] [$file] Skip error as it seems like a function!"
    else
        echo "[$file] Validation failed! Please check the log for more details."
        echo "$output"
        exit 1
    fi
    echo "============================="
done