#!/bin/bash
# File name: artifactory_cleanup.sh
#
# Authors:
#
# Copyright (c) 2024 Dell Inc. or its subsidiaries.
# All Rights Reserved.
#

usage() {
    echo ""
    echo "Usage: $0 -s <Artifactory Server ID> -d <Artifactory Scripts Path>"
    echo -e "\t-s Artifactory Server ID ( ID which is created using 'jf config' )"
    echo -e "\t-d Artifactory Search/Cleanup file path"
    echo ""
    exit 1
}

error_exit() {
    e_code=$1
    shift
    e_msg="$*"

    if [ $e_code -ne 0 ]; then
        echo "ERROR: $e_msg"
        usage
        exit $e_code
    fi
}

while getopts "s: d:" opt
do
    case "$opt" in
        s ) ART_SERVER_ID="$OPTARG" ;;
        d ) SCRIPT_BASE_PATH="$OPTARG" ;;
        ? ) usage ;;
    esac
done

# Main
##export CI="True" # Artifactory env variable to avoid prompt

[ -z "$ART_SERVER_ID" ]  && error_exit 1 "Artifactory Server ID doesn't exists"
[ -d "$SCRIPT_BASE_PATH" ] || error_exit 1 "Artifactory Search/Cleanup path doesn't exists"

jf config show | grep -w "$ART_SERVER_ID" >/dev/null 2>&1|| error_exit $? "JFrog Artifactory configuration for ${ART_SERVER_ID} is not available."

comp=(cu du L1 oam platform radio mplane other other_r1 noded rdc transport)

for c in ${comp[@]}; do
        spec_file="${SCRIPT_BASE_PATH}/search_spec_${c}.json"
        log_file="${SCRIPT_BASE_PATH}/search_spec_${c}.log"

        echo '#------------------------------------------------------------------------------#'
        echo -e "\t Artifactory Cleanup for Components: ${c}"
        echo '#------------------------------------------------------------------------------#'
        echo ''

        if [ ! -f "$spec_file" ]; then
                 echo "Artifactory Search Spec file $spec_file for Componenet $c, does not exists"
                 continue
        fi

        jf rt del --spec $spec_file --server-id ${ART_SERVER_ID} | tee $log_file 2>&1
done