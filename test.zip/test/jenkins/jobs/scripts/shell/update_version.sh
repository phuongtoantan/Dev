#!/bin/bash
#This Script Require 3 Inputs:
# $1 > Tag Name
# $2 > Release File
# $3 > The Main Branch
# $4 > Update Versio in Another File For Python Repos
 
REPO_NAME=$(git remote -v | head -n1 | awk '{print $2}' | sed -e 's,.*:\(.*/\)\?,,' -e 's/\.git$//')
REPO_CURRENT_VERSION=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2)
REPO_LAST_COMMIT=$(git log --name-status HEAD^..HEAD)
 
echo "Git Repo Name Is $REPO_NAME"
echo "Git Repo Current Version Is $REPO_CURRENT_VERSION"
echo "Git Last Commit Is $REPO_LAST_COMMIT"
 
if git log --name-status HEAD^..HEAD | grep -qi 'major';
then
   echo "Git Commit Change Major Version"
   major_version=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2 | cut -d '.' -f 1)
   minor_version=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2 | cut -d '.' -f 2)
   patch_version=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2 | cut -d '.' -f 3)
   echo "Current Major Version Is $major_version"
   major_new_version=`expr $major_version + 1`
   minor_new_version=0
   patch_new_version=0
   echo "Major New Version Is $major_new_version"
   REPO_NEW_VERSION=$major_new_version.$minor_new_version.$patch_new_version
   echo "New Version Is $REPO_NEW_VERSION"
   sed -i "s/$REPO_CURRENT_VERSION/$REPO_NEW_VERSION/g" $2 $4
 
 
elif git log --name-status HEAD^..HEAD | grep -qi 'minor';
then
   echo "Git Commit Change Minor Version"
   major_version=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2 | cut -d '.' -f 1)
   minor_version=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2 | cut -d '.' -f 2)
   patch_version=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2 | cut -d '.' -f 3)
   echo "Current Minor Version Is $minor_version"
   minor_new_version=`expr $minor_version + 1`
   patch_new_version=0
   echo "Minor New Version Is $minor_new_version"
   REPO_NEW_VERSION=$major_version.$minor_new_version.$patch_new_version
   echo "New Version Is $REPO_NEW_VERSION"
   sed -i "s/$REPO_CURRENT_VERSION/$REPO_NEW_VERSION/g" $2 $4
 
else
   echo "Git Commit Change patch Version"
   major_version=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2 | cut -d '.' -f 1)
   minor_version=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2 | cut -d '.' -f 2)
   patch_version=$(sed -n -e "/^$1/p" $2 | sed "s/\'//g" | cut -d " " -f 2 | cut -d '.' -f 3)
   echo "Current Patch Version Is $patch_version"
   patch_new_version=`expr $patch_version + 1`
   echo "Patch New Version Is $patch_new_version"
   REPO_NEW_VERSION=$major_version.$minor_version.$patch_new_version
   echo "New Version Is $REPO_NEW_VERSION"
   sed -i "s/$REPO_CURRENT_VERSION/$REPO_NEW_VERSION/g" $2 $4
fi
 
 
git add $2 $4
git config user.email svc_npmpgithub@dell.com
git config user.name svc_npmpgithub
git commit -m "Update Version From v$REPO_CURRENT_VERSION to v$REPO_NEW_VERSION"
git push origin $3
