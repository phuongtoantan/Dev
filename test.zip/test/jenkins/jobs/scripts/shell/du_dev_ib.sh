#!/bin/bash

## Copyright (c) 2017-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
set -x
export CC=/usr/local/bin/gcc
# Identify compile_du.sh script location
build_path=/phoenix/gNB_DU/build
[[ -f /phoenix/gNB_DU/compile_du.sh ]] && build_path=/phoenix/gNB_DU
set -eo pipefail && du -h -d 3 /phoenix && cd $build_path
#current time on container
date
ib_console --avoid-shared --avoid-basedir=/phoenix -c du_pal${DOCKER_TAG} ./compile_du.sh -t du-pal ${FH_DPDK} ${MH_DPDK} -j 200 | tee build.log
# Copy RPM spec file
cd /platform/containers/du
cp du_rpm.spec /root/rpmbuild/SPECS
# Copy the startup script
cp start_du /phoenix/gNB_DU/build/pal/du_bin/bin/
# Copy service files
cp start_du_service /phoenix/gNB_DU/build/pal/du_bin/bin/
cp stop_du_service /phoenix/gNB_DU/build/pal/du_bin/bin/
cp gNB_du.service /root/
# Prepare DU environment
PATH=/opt/gnb/du/bin:$PATH
# Copy the set_version script
cp /platform/containers/du/set_version.sh /root
# Run the set_version script to force version for the dependent RPMs
chmod +x /root/set_version.sh
/root/set_version.sh -f /root/rpmbuild/SPECS/du_rpm.spec
# Create RPM
cd /phoenix/gNB_DU
VERSION=${VERSION:-$(echo "DU_2.1.0.0_v001")}
RPM_VERSION=${VERSION:3:7} && RPM_RELEASE=$(echo ${VERSION:11} | sed "s/-/./g")
cd /root/rpmbuild
QA_RPATHS=$[ 0x0020 | 0x0002 ] rpmbuild -bb SPECS/du_rpm.spec --define "VERSION $RPM_VERSION" --define "RELEASE $RPM_RELEASE" --define "BUILD_VARIANT $BUILD_VARIANT" --define "__strip /bin/true"
