#!/bin/bash
## Copyright (c) 2023-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

helpFunction() {
    echo ""
    echo "Usage: $0 -w <Jenkins Workspace>  -c <Container name>"
    echo -e "\t-w Specify the workspace"
    echo -e "\t-c Specify the container name"
    echo ""
    exit 1
}

# Get input parameters
while getopts "w: c:" opt; do
    case "$opt" in
    w) WORKSPACE="$OPTARG" ;;
    c) ACM_STAGING_CONTAINER="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done
set +ex

sudo podman exec $ACM_STAGING_CONTAINER bash -c 'pwd;ls -l'
sudo podman exec $ACM_STAGING_CONTAINER bash -c 'mkdir -p /acm_log '
sudo podman exec $ACM_STAGING_CONTAINER bash -c 'ls -l /var/log/gnb/O-RAN/Common;cp -r /var/log/gnb/O-RAN/Common/ACM*.* /acm_log'
sudo podman exec $ACM_STAGING_CONTAINER bash -c 'ls -l /acm_log'

mkdir $WORKSPACE/acm_log

if [ -n "$(ls -A /var/lib/systemd/coredump/)" ]; then  
        mkdir -p $WORKSPACE/acm_log/acm_coredumps && ls -A /var/lib/systemd/coredump/ && cp /var/lib/systemd/coredump/core.gnb_acm* $WORKSPACE/acm_log/acm_coredumps
        podman exec -it $ACM_STAGING_CONTAINER sh -c 'mkdir -p /acm_binary && cp -r /DU/gNB_ACM/build/bin/gnb_acm_test /acm_binary/gnb_acm_test && cp -r /acm_binary /acm_log/ '
        echo "Core dump and binary are copied"
else
        echo "No Coredumps available"
fi

sudo podman cp $ACM_STAGING_CONTAINER:/acm_log/. $WORKSPACE/acm_log
sudo zip -r -q $WORKSPACE/acm_log.tar.gz $WORKSPACE/acm_log
rm -rf $WORKSPACE/acm_log
sudo rm -rf /var/lib/systemd/coredump/*
ls -ltr $WORKSPACE
