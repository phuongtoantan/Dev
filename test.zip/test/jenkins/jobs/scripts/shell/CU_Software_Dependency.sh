#!/bin/bash
cd /usr/bin

if [ -e evans ]; then
    echo "Evans present"
else
    echo "Evans not present"
    curl -k -O https://phm.artifactory.cec.lab.emc.com/artifactory/mobile-phoenix-ran-external/evans
    chmod +x evans
fi

if [ -e goJson ]; then
    echo "goJson present"
else
    echo "goJson not present"
    curl -k -O https://phm.artifactory.cec.lab.emc.com/artifactory/mobile-phoenix-ran-external/goJson
    chmod +x goJson
fi
