# Copyright © 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

#!/bin/bash
helpFunction() {
    echo ""
    echo "Usage: $0 -i <Agent IP>  -u <Agent SSH username> -p <Agent SSH password> -t <Target Label>"
    echo -e "\t-i Specify the target agent IP"
    echo -e "\t-u Specify the target agent SSH username"
    echo -e "\t-p Specify the target agent SSH password"
    echo -e "\t-t Specify the target label"
    echo ""
    exit 1
}

# Get input parameters
while getopts "i: u: p: t: a: b:" opt; do
    case "$opt" in
    i) IP_ADDRESS="$OPTARG" ;;
    u) USER_NAME="$OPTARG" ;;
    p) PASSWORD="$OPTARG" ;;
    t) TARGET_LABEL="$OPTARG" ;;
    ?) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

if ! type sshpass >/dev/null; then
    sudo dnf install -y sshpass
fi

echo "Execute cleanup commands on remote agent: $IP_ADDRESS"
# We will use difference cleanup strategy for each type of labels
# For docker: Stop old run_tests containers running for more than 24 hours, so "docker system prune -f" can also remove these docker containers
# For podman: remove old localhost/ + none images (without latest tag) created more than 12 hours ago
# For buildah: remove old localhost/ + none images (without latest tag) craeted more than 24 hours ago
case "$TARGET_LABEL" in
"du-test-sim" | "du-test-sim_mainstream" | "rh8-du-ut" | "oam_sim_test_rhel8" | "oam_sim_test_cron_rhel8" | "product_test_5G") # Cleanup docker, podman, podman(with sudo)
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date; echo "Disk space before cleanup:"; df -h
echo "##### Before cleaning up workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup workspace #####"
sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
echo "##### After cleaning up workspace #####"
pwd; sudo du -h --max-depth=1 | sort -hr

echo "##### Cleanup docker #####"
old_docker_containers=\$(docker ps -a --filter "name=run_tests"| grep -E " ((months|weeks|days)+ ago)|(((\d)?\d\d\d|[2-9][4-9]|[3-9]\d)+ hours ago)" | awk 'NR != 0 {print \$1}')
if [ -n "\$old_docker_containers" ]; then
    docker stop \$old_docker_containers
fi
docker images; docker ps -a
docker system prune -f -a
docker images; docker ps -a

echo "##### Cleanup podman #####"
podman images; podman ps -a
podman rm -a -f
podman system prune -f -a
podman images; podman ps -a
old_local_images=\$(podman images --filter "until=12h" | grep "localhost/\|<none>" | grep -v "latest"  | awk 'NR != 0 {print \$3}')
if [ -n "\$old_local_images" ]; then
    podman rmi -f \$old_local_images
fi

echo "##### Cleanup podman used by sudo #####"
sudo podman images; sudo podman ps -a
sudo podman rm -a -f
sudo podman system prune -f -a
sudo podman images; sudo podman ps -a
old_sudo_local_images=\$(sudo podman images --filter "until=12h" | grep "localhost/\|<none>\|/gnb_oam" | grep -v "latest" | awk 'NR != 0 {print \$3}')
if [ -n "\$old_sudo_local_images" ]; then
    sudo podman rmi -f \$old_sudo_local_images
fi

echo "##### Cleanup buildah #####"
buildah images; buildah ps -a
old_buildah_images=\$(buildah images -a --filter "until=24h" | grep "localhost/\|<none>" | grep -v "latest" | awk 'NR !=0 {print \$3}')
if [ -n "\$old_buildah_images" ]; then
    buildah rmi -f \$old_buildah_images
fi
buildah images; buildah ps -a

echo "##### Cleanup buildah used by sudo #####"
sudo buildah images; sudo buildah ps -a
old_sudo_buildah_images=\$(sudo buildah images -a --filter "until=24h" | grep "localhost/\|<none>" | grep -v "latest" | awk 'NR !=0 {print \$3}')
if [ -n "\$old_sudo_buildah_images" ]; then
    sudo buildah rmi -f \$old_sudo_buildah_images
fi
sudo buildah images; sudo buildah ps -a

echo "##### Cleanup buildah temp files #####"
echo "Before cleanup /var/tmp: "; sudo du -hsx /var/tmp/ | awk '{print \$1}'
sudo find /var/tmp -maxdepth 1 \( -name "buildah*" -o -name "storage*" \) -mtime +1 -exec rm -rf {} \;
echo "After cleanup /var/tmp: "; sudo du -hsx /var/tmp/ | awk '{print \$1}'

echo "Disk space after cleanup:"; df -h
exit
EOF
    ;;
"cu_build_memcheck" | "rhel8-du-build" | "du_cov_rhel8" | "coverity-rhel8" | "ngp-rhel8" | "ngp_cov_rhel8" | "initiator_incredibuild1" | "initiator_incredibuild2" | "L1_transport" | "oam_sim_test_rhel8" | "rhel8-oam" | "component-testing" | "oam_sim_test_cron_rhel8") # Cleanup podman, podman(with sudo)
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date; echo "Disk space before cleanup:"; df -h
echo "##### Before cleaning up workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup workspace #####"
sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
echo "##### After cleaning up workspace #####"
pwd; sudo du -h --max-depth=1 | sort -hr

echo "##### Cleanup podman #####"
podman system prune -f -a
podman images; podman ps -a
old_local_images=\$(podman images --filter "until=12h" | grep "localhost/\|<none>" | grep -v "gbi.*latest" | awk 'NR != 0 {print \$3}')
if [ -n "\$old_local_images" ]; then
    podman rmi -f \$old_local_images
fi
podman system prune -f -a
podman rm -a -f
podman images; podman ps -a

echo "##### Cleanup podman used by sudo #####"
sudo podman system prune -f -a
sudo podman images; sudo podman ps -a
old_sudo_local_images=\$(sudo podman images --filter "until=12h" | grep "localhost/\|<none>" | grep -v "gbi.*latest" | awk 'NR != 0 {print \$3}')
if [ -n "\$old_sudo_local_images" ]; then
    sudo podman rmi -f \$old_sudo_local_images
fi
sudo podman system prune -f -a
sudo podman rm -a -f
sudo podman images; sudo podman ps -a

echo "##### Cleanup /tmp/du_build_image #####"
ls -lrth /tmp/du_build_image || true
sudo find /tmp/du_build_image -type f -mmin +360 -exec rm -rf {} \; || true
ls -lrth /tmp/du_build_image || true

echo "##### Cleanup /var/temp files #####"
echo "Before cleanup /var/tmp: "; sudo du -hsx /var/tmp/ | awk '{print \$1}'
sudo find /var/tmp -mindepth 1 -maxdepth 1 -mtime +1 -exec rm -rf {} \;
echo "After cleanup /var/tmp: "; sudo du -hsx /var/tmp/ | awk '{print \$1}'

echo "Disk space after cleanup:"; df -h
exit
EOF
    ;;
"cov-agent-1" | "agent-1" | "agent-2" | "oam_sim_test" | "l1_lightweight_pool" | "ru-albus-docker") # Cleanup docker
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date; echo "Disk space before cleanup:"; df -h
echo "##### Before cleaning up workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup workspace #####"
sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
echo "##### After cleaning up workspace #####"
pwd; sudo du -h --max-depth=1 | sort -hr

echo "##### Cleanup docker #####"
docker images; docker ps -a
docker system prune -f -a
docker images; docker ps -a
echo "Disk space after cleanup:"; df -h
exit
EOF
    ;;
"MANUAL-CU-UT-RHEL8" | "CU-UT-RHEL8"| "NIGHTLY-CU-UT-RHEL8" | "CU-MEM-CHECK" | "CU-CT-RHEL8" | "mplane-ms" | "platform") # Cleanup podman/buildah for root user
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date; echo "Disk space before cleanup:"; df -h
echo "##### Before cleaning up workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup workspace #####"
sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
echo "##### After cleaning up workspace #####"
pwd; sudo du -h --max-depth=1 | sort -hr

echo "##### Remove all non running containers (root) #####"
sudo podman ps -a
sudo podman container prune -f

echo "##### Cleanup buildah used by sudo #####"
sudo buildah images; sudo buildah ps -a
old_sudo_buildah_images=\$(sudo buildah images -a --filter "until=24h" | grep "localhost/\|<none>" | grep -v "latest" | awk 'NR !=0 {print \$3}')
if [ -n "\$old_sudo_buildah_images" ]; then
    sudo buildah rmi -f \$old_sudo_buildah_images
fi
sudo buildah images; sudo buildah ps -a

echo "##### Cleanup podman used by sudo #####"
sudo podman images; sudo podman ps -a
sudo podman system prune -f -a
sudo podman images; sudo podman ps -a
old_sudo_local_images=\$(sudo podman images --filter "until=12h" | grep "localhost/\|<none>" | grep -v "latest" | awk 'NR != 0 {print \$3}')
if [ -n "\$old_sudo_local_images" ]; then
    sudo podman rmi -f \$old_sudo_local_images
fi
sudo podman system prune -f -a
sudo podman images; sudo podman ps -a

echo "##### Cleanup buildah temp files #####"
echo "Before cleanup /var/tmp: "; sudo du -hsx /var/tmp/ | awk '{print \$1}'
sudo find /var/tmp -maxdepth 1 \( -name "buildah*" -o -name "storage*" \) -mtime +1 -exec rm -rf {} \;
echo "After cleanup /var/tmp: "; sudo du -hsx /var/tmp/ | awk '{print \$1}'

echo "Disk space after cleanup:"; df -h
exit
EOF
    ;;
"Banned-Function-Check-host" | "l1_agent" | "L1-Queensview-Agent-1" | "rsw_yocto_build" | "rsw_root_build" | "rsw_albus_pack" | "radio-sw-cov" | "component-testing") # Cleanup workspace
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date; echo "Disk space before cleanup:"; df -h
echo "##### Before cleaning up workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup workspace #####"
sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
echo "##### After cleaning up workspace #####"
pwd; sudo du -h --max-depth=1 | sort -hr

echo "Disk space after cleanup:"; df -h
exit
EOF
    ;;
"e2e-test" | "AIO-TL17") # Cleanup workspace
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date; echo "Disk space before cleanup:"; df -h
echo "##### Before cleaning up workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup workspace #####"
sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
echo "##### After cleaning up workspace #####"
pwd; sudo du -h --max-depth=1 | sort -hr

echo "##### Stop hanging containers which impact network namespace #####"
podman images; podman ps -a
podman stop \$(podman ps 2>&1 | grep -oE 'for container [a-f0-9]+' | awk '\$0=\$NF')
echo "##### Stop hanging container more than 1 days #####"
podman stop \$(podman ps -q --filter "until=\$(date +'%Y-%m-%dT%H:%M:%S' --date='-1 days')")
echo "##### Podman prune and check again #####"
podman system prune -f -a
podman images; podman ps -a
echo "Disk space after cleanup:"; df -h
exit
EOF
    ;;
"jira-generic" | "rhel8")
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date; echo "Disk space before cleanup:"; df -h
echo "##### Before cleaning up workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup workspace #####"
sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
echo "##### After cleaning up workspace #####"
pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup old files ( > 2 days) #####"
sudo find . -mindepth 1 -maxdepth 1 -mtime +2 -exec rm -rf {} \;
echo "##### After cleaning up #####"
pwd; sudo du -h --max-depth=1 | sort -hr
exit
EOF
    ;;
"podman")
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date; echo "Disk space before cleanup:"; df -h
echo "##### Before cleaning up workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; sudo du -h --max-depth=1 | sort -hr

echo "##### Cleanup podman #####"
podman images; podman ps -a
podman system prune -f
podman images; podman ps -a

sudo podman images; sudo podman ps -a
sudo podman system prune -f
sudo podman images; sudo podman ps -a

echo "##### After cleaning up #####"
pwd; sudo du -h --max-depth=1 | sort -hr
exit
EOF
    ;;
"rdc" | "rdc_test")
    timeout 2h sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no -tt "$USER_NAME@$IP_ADDRESS" <<EOF
date; echo "Disk space before cleanup:"; df -h
echo "##### Before cleaning up workspace #####"
cd /home/jenkins/jenkins/workspace; pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup workspace #####"
sudo find . -type d -name '*_ws-cleanup_*' -prune -exec rm -rf {} \;
echo "##### After cleaning up workspace #####"
pwd; sudo du -h --max-depth=1 | sort -hr
echo "##### Cleanup old files ( > 2 days) #####"
sudo find . -mindepth 1 -maxdepth 1 -mtime +2 -exec rm -rf {} \;
echo "##### After cleaning up old files #####"
pwd; sudo du -h --max-depth=1 | sort -hr

echo "##### Cleanup podman #####"
podman images; podman ps -a
podman system prune -f
podman images; podman ps -a

sudo podman images; sudo podman ps -a
sudo podman system prune -f
sudo podman images; sudo podman ps -a

echo "##### After cleaning up #####"
pwd; sudo du -h --max-depth=1 | sort -hr
exit
EOF
    ;;
*) # Invalid option
    echo -e "Error: Not support label: '$TARGET_LABEL'"
    exit 1
    ;;
esac
