## Copyright (c) 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.
#!/bin/bash
set -ex

helpFunction()
{
    echo ""
    echo "Usage: $0 -v <RPM_VERSION> -r <RPM_RELEASE> -a <ACM_BUILD_VARIANT> -m <MPLANE_BUILD_VARIANT> -d <DU_BUILD_VARIANT> -h <MINERVA_HOST_DRIVER> -f <MINERVA_FIRMWARE> -e <DU_METAPACKAGE_RPM_EXPORT_PATH>"
    echo -e "\t-v Specify the RPM_VERSION"
    echo -e "\t-r Specify the RPM_RELEASE"
    echo -e "\t-a Specify the ACM_BUILD_VARIANT"
    echo -e "\t-m Specify the MPLANE_BUILD_VARIANT"
    echo -e "\t-d Specify the DU_BUILD_VARIANT"
    echo -e "\t-h Specify the MINERVA_HOST_DRIVER"
    echo -e "\t-f Specify the MINERVA_FIRMWARE"
    echo -e "\t-e Specify the DU_METAPACKAGE_RPM_EXPORT_PATH"
    echo -e "\t-s Specify the KEA_SERVER_VARIANT"
    echo -e "\t-k Specify the KEA_DHCP_VARIANT"
    echo -e "\t-t Specify the TRANSPORT_FH_VARIANT"
    echo ""
    exit 1
}

# Get input parameters
while getopts "v: r: a: m: d: h: f: e: s: k: t:" opt
do
    case "$opt" in
        v ) RPM_VERSION="$OPTARG" ;;
        r ) RPM_RELEASE="$OPTARG" ;;
        a ) ACM_BUILD_VARIANT="$OPTARG" ;;
        m ) MPLANE_BUILD_VARIANT="$OPTARG" ;;
        d ) DU_BUILD_VARIANT="$OPTARG" ;;
        h ) MINERVA_HOST_DRIVER="$OPTARG" ;;
        f ) MINERVA_FIRMWARE="$OPTARG" ;;
        e ) DU_METAPACKAGE_RPM_EXPORT_PATH="$OPTARG" ;;
        s ) KEA_SERVER_VARIANT="$OPTARG" ;;
        k ) KEA_DHCP_VARIANT="$OPTARG" ;;
        t ) TRANSPORT_FH_VARIANT="$OPTARG" ;;
        ? ) helpFunction ;; # Print helpFunction in case parameter is non-existent
    esac
done

# Check parameters
if [ -z "$RPM_VERSION" ]; then
    echo "Error: $RPM_VERSION is manadatory"
    helpFunction
fi
if [ -z "$RPM_RELEASE" ]; then
    echo "Error: $RPM_RELEASE is manadatory"
    helpFunction
fi
if [ -z "$ACM_BUILD_VARIANT" ]; then
    echo "Error: $ACM_BUILD_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$MPLANE_BUILD_VARIANT" ]; then
    echo "Error: $MPLANE_BUILD_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$DU_BUILD_VARIANT" ]; then
    echo "Error: $DU_BUILD_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$MINERVA_HOST_DRIVER" ]; then
    echo "Error: $MINERVA_HOST_DRIVER is manadatory"
    helpFunction
fi
if [ -z "$MINERVA_FIRMWARE" ]; then
    echo "Error: $MINERVA_FIRMWARE is manadatory"
    helpFunction
fi
if [ -z "$DU_METAPACKAGE_RPM_EXPORT_PATH" ]; then
    echo "Error: $DU_METAPACKAGE_RPM_EXPORT_PATH is manadatory"
    helpFunction
fi
if [ -z "$KEA_SERVER_VARIANT" ]; then
    echo "Error: $KEA_SERVER_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$KEA_DHCP_VARIANT" ]; then
    echo "Error: $KEA_DHCP_VARIANT is manadatory"
    helpFunction
fi
if [ -z "$TRANSPORT_FH_VARIANT" ]; then
    echo "Error: $TRANSPORT_FH_VARIANT is manadatory"
    helpFunction
fi
echo $acm_release
# Pull latest GBI image 
GBI_IMAGE=${GBI_IMAGE:='phm.artifactory.cec.lab.emc.com/mobile-phoenix-platform-docker/artifactory/platform/gbi:latest'}
podman pull $GBI_IMAGE

RHEL_RELEASE=8.6
# Create output directory to save du rpm package
mkdir -p "$DU_METAPACKAGE_RPM_EXPORT_PATH"

# Run container to build du rpm package
podman run --rm --privileged  \
    -v "$(pwd)/gNB_platform/containers/du:/root/rpmbuild/SPECS"  \
    -v "$DU_METAPACKAGE_RPM_EXPORT_PATH:/output" \
    -e "RPM_VERSION=$RPM_VERSION" \
    -e "RPM_RELEASE=$RPM_RELEASE" \
    -e "ACM_BUILD_VARIANT=$ACM_BUILD_VARIANT" \
    -e "MPLANE_BUILD_VARIANT=$MPLANE_BUILD_VARIANT" \
    -e "DU_BUILD_VARIANT=$DU_BUILD_VARIANT" \
    -e "MINERVA_HOST_DRIVER=$MINERVA_HOST_DRIVER" \
    -e "MINERVA_FIRMWARE=$MINERVA_FIRMWARE" \
    -e "KEA_SERVER_VARIANT=$KEA_SERVER_VARIANT" \
    -e "KEA_DHCP_VARIANT=$KEA_DHCP_VARIANT" \
    -e "TRANSPORT_FH_VARIANT=$TRANSPORT_FH_VARIANT" \
    $GBI_IMAGE \
    /bin/bash -c ' echo "Install tools and dependencies" && \
        rm /etc/yum.repos.d/redhat.repo && \
        microdnf --releasever=$RHEL_RELEASE makecache
        cd /root/rpmbuild && \
        chmod +x /root/rpmbuild/SPECS/set_version_du_marvell_metapkg.sh
        /root/rpmbuild/SPECS/set_version_du_marvell_metapkg.sh -f /root/rpmbuild/SPECS/du_marvell_metapackage_rpm.spec -a $ACM_BUILD_VARIANT -d $DU_BUILD_VARIANT -w $MINERVA_FIRMWARE -h $MINERVA_HOST_DRIVER -m $MPLANE_BUILD_VARIANT -s $KEA_SERVER_VARIANT -k $KEA_DHCP_VARIANT -t $TRANSPORT_FH_VARIANT && \
        rpmbuild -bb SPECS/du_marvell_metapackage_rpm.spec --define "VERSION $RPM_VERSION" \
                                        --define "RELEASE $RPM_RELEASE" \
                                        --define "ACM_BUILD_VARIANT $ACM_BUILD_VARIANT" \
                                        --define "MPLANE_BUILD_VARIANT $MPLANE_BUILD_VARIANT" \
                                        --define "DU_BUILD_VARIANT $DU_BUILD_VARIANT" \
                                        --define "MINERVA_FIRMWARE $MINERVA_FIRMWARE" \
                                        --define "MINERVA_HOST_DRIVER $MINERVA_HOST_DRIVER" \
                                        --define "KEA_SERVER_VARIANT $KEA_SERVER_VARIANT" \
                                        --define "KEA_DHCP_VARIANT $KEA_DHCP_VARIANT" \
                                        --define "TRANSPORT_FH_VARIANT $TRANSPORT_FH_VARIANT" && \
        ls -lrt /root/rpmbuild/SPECS && \
        ls -lrt /root/rpmbuild/RPMS/x86_64 && \
        cp -r /root/rpmbuild/RPMS/x86_64/du_marvell_metapackage*.rpm /output
        cp /root/rpmbuild/SPECS/du_marvell_metapackage_rpm.spec /output
    '