# Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import plotly
from tabulate import tabulate
import io
import sys
from base64 import b64encode

df = pd.read_csv(sys.argv[1], index_col=False)
df.reset_index(drop=True, inplace=True)

filters = ["CU","DU","ngp","[N|n]earRT","AIO","OAM","Cleanup","deployer","L1","[M|m]ainstream","RDC","Radio","Transport","[N|n]oded","TL","Others"]
nav_filters = ["CU","DU","ngp","NearRT","AIO","OAM","Cleanup","deployer","L1","Mainstream","RDC","Radio","Transport","Noded","TL","Others"]

dfs = {}

for filter in filters:
  tmp_df = df[df['name'].str.contains(filter)]
  tmp_zeros = tmp_df[tmp_df['build_count'] == 0] # TODO add & branch follow regex of non main
  tmp_df = tmp_df[tmp_df['build_count'] != 0]
  dfs[filter] = (tmp_df,tmp_zeros)

tl_df = df[df['name'].str.contains("TL") &  ~df['name'].str.contains("AIO")]
tl_zeros = tl_df[tl_df['build_count'] == 0]
tl_df = tl_df[tl_df['build_count'] != 0]
dfs["TL"]=(tl_df,tl_zeros)

other_df= df[~df['name'].str.contains("CU") &  ~df['name'].str.contains("DU") & ~df['name'].str.contains("ngp") &  ~df['name'].str.contains("[N|n]earRT") & ~df['name'].str.contains("OAM") &  ~df['name'].str.contains("Cleanup") & ~df['name'].str.contains("deployer") &  ~df['name'].str.contains("L1") & ~df['name'].str.contains("[M|m]ainstream") &  ~df['name'].str.contains("RDC") & ~df['name'].str.contains("TL") & ~df['name'].str.contains("AIO") & ~df['name'].str.contains("Radio") & ~df['name'].str.contains("Transport") & ~df['name'].str.contains("[N|n]oded")]
other_zeros = other_df[other_df['build_count'] == 0]
other_df = other_df[other_df['build_count'] != 0]
dfs["Others"] = (other_df,other_zeros)

template = """
<!DOCTYPE html>
<html>
<head>
    <title> Report </title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <style>

    li {{
      display: inline;
    }}

    .topnav {{
      background-color: #333;
      overflow: hidden;
      display: flex;
      flex: 1;
      justify-content: space-evenly;
    }}

    .topnav a {{
      float: left;
      color: #f2f2f2;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 17px;
    }}

    .topnav a:hover {{
      background-color: #ddd;
      color: black;
    }}

    .topnav a.active {{
      background-color: #04AA6D;
      color: white;
    }}

    table, td, th {{
      border: 1px solid;
    }}

    table {{
      width: 100%;
      border-collapse: collapse;
    }}
    </style>

</head>
<body>
    <nav class="topnav">
        <ul>
            {nav_items}
        </ul>
    </nav>
    {fig}
    {table}
</body>
</html>
"""


nav_items = ""
for i in range(len(nav_filters)):
    nav_items += f"<li><a href='./{filters[i]}.html'>{nav_filters[i]}</a></li>\n"

import os

path = "./"+"report" # enter path to directory for file creationtry:
try:
    os.mkdir(path)
except OSError as error:
    pass

for name , dataframes in dfs.items():
    file_name = path + "/" +  name + ".html"
    with open(file_name, "w") as file:

        fig = px.bar(dataframes[0], x='name', y='build_count', color="status", text='build_count', hover_data="branch", color_discrete_map={
            "red": "disabled",
            "green": "active",
        })
        file_content = plotly.offline.plot(fig, include_plotlyjs=False, output_type='div')

        tab = tabulate(dataframes[1], headers=list(dataframes[1]), tablefmt='html')

        html = template.format(nav_items=nav_items , fig=file_content , table=tab)

        file.write(html)