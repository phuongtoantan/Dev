#!/usr/bin/python3

from bs4 import BeautifulSoup
import codecs
import sys
import json
import getopt
import argparse


parser = argparse.ArgumentParser()

parser.add_argument(
    "-i", "--input-file",
    help="Require Robot Report File In Json Format",
    required=True,
)
parser.add_argument(
    "-o", "--output-file",
    help="where to store json (e.g: ${WORKSPACE}/lcov-cucp.json)",
    required=True,
)
parser.add_argument(
    "-j", "--jenkins-url",
    help="jenkins job url (e.g: https://osj-phm-02-prd.cec.delllabs.net/job/CU_UT/job/main/17)",
    required=True,
)

args = parser.parse_args()

html_doc = codecs.open(args.input-file, "r")

soup = BeautifulSoup(html_doc, 'html.parser')

print("\n")

job_data = {}


job_data["job"] = args.jenkins-url

# Iterate over BeautifulSoup object to find required items
for link in soup.find_all("td", class_="headerItem"):

    link_type = link.get_text()
    
    # Retrieve data for lines and functions
    if(link_type in ('Lines:', 'Functions:')):
        job_data[link_type] = {}

        # Find next td type in document
        link = link.find_next("td")
        hit = link.get_text()
        job_data[link_type]['hit'] = hit

        # Find next td type in document
        link = link.find_next("td")
        total = link.get_text()
        job_data[link_type]['total'] = total

        # Find next td type in document
        link = link.find_next("td")
        coverage = link.get_text()
        job_data[link_type]['coverage'] = coverage

dir = ""

for link in soup.find_all("td", class_="tableHead"):
    dir = link

job_data['Directories'] = {}

# Retrieve directory statistics from document
while (dir.find_next(class_="coverFile")):

    dir = dir.find_next(class_="coverFile")
    dir_name = dir.get_text()
    job_data['Directories'] [dir_name]= {}
    
    # Statistic type and their original name to be obtained for directory
    covers = {"lines %": "coverPerLo","line stats": "coverNumLo","function %": "coverPerLo","function_stats": "coverNumLo"}

    for stat_type in covers:
      data = dir.find_next(class_=covers[stat_type])
      if data is not None:
        stat_value = data.get_text()
        # Store value of statistic type for directory
        job_data['Directories'] [dir_name][stat_type]= stat_value

# Write the data extracted to JSON file      


with open(output_json_file, 'w') as fp:
    json.dump(job_data, fp,indent=4)


return output_json_file
