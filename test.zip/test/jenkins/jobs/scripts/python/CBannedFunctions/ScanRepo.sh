#!/bin/bash

# Exit immediately if any command fails
set -e

# Print each command before executing (for debugging)
set -x
ls -ltr

printenv > env_vars.txt

echo $REPO

SSH_URL="git@eos2git.cec.lab.emc.com:Mobile-Phoenix/"

GIT_URL="https://eos2git.cec.lab.emc.com/Mobile-Phoenix/"

REPO_URL=$GIT_URL$REPO/

echo $REPO_URL

echo "cloning ($REPO) in workspace"

git clone --recursive $SSH_URL$REPO.git

ls -ltr $WORKSPACE

cd $WORKSPACE/build_scripts/jenkins/jobs/scripts/python/CBannedFunctions

python3 FunctionCheckerRepo.py -dir $WORKSPACE/$REPO/ -repo $REPO_URL -b main
