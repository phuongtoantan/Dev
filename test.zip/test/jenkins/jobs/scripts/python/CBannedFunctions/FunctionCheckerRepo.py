#!/usr/bin/python3
# Copyright (c) 2024 Dell Inc. or its subsidiaries. All rights reserved.

import codecs
import sys
import json
import getopt
import argparse
from tabulate import tabulate
import glob
import os
import re
import numpy as np

HTML_REPORT_NAME= "BannedFunctionReport.html"

HEADERS = ["Filename","Line Number","Banned function","Suggested Function",]

MACRO_PATTERN_REGEX = r'^#define\s+(\w+)((?:.*\\\r?\n)*.*)$'

filepath = ""

parser = argparse.ArgumentParser()

parser.add_argument(
    "-dir",
    help="Please pass the path to the directory for checking the banned functions",
    required=True,)

parser.add_argument(
    "-repo",
    help="Please pass the github URL for the repository name",
    required=True,)

parser.add_argument(
    "-b",
    help="Please pass the branch name",
    required=True,)

parser.add_argument('-pr', action='store_true', help="pass it when using github project check")

parser.add_argument(
    "-diff",
    help="Please pass the text file containing the change list with the raised pull request",
    required=False,)

args = parser.parse_args()

dirpath = args.dir
REPO = args.repo
BRANCH = args.b
PRCHECK = args.pr
DIFF_LIST = args.diff
repo_name = REPO.rsplit('/')[-2]

extensions = [".c", ".cpp", ".hpp", ".h"]
allfiles = []
filtered_list = []

#remove non-existing/external files and return new list
def filter_filelist():
    for filename in allfiles:
        skipped = False
        with open('ExternalCode.json', 'r') as c:
            codefile = json.load(c)      
            for c in codefile:
                files = codefile[c]
                filepath = filename.split(repo_name+'/')[-1]
                if filepath in files:
                    skipped = True
                    break
            if skipped:
                continue
        if not os.path.exists(filename):
            continue
        filtered_list.append(filename)

if PRCHECK is False:

    for extension in extensions:
        path = dirpath + "**/*" + extension
        print(path)

        # Get list of files recursively in directory
        allfiles.extend(glob.glob(path, recursive = True))
else:
    # Open the file and count the lines
    with open(DIFF_LIST, 'r') as file:
        lines = file.readlines()
        number_of_lines = len(lines)
     #load the change list from the pull request
    if number_of_lines == 1:
        data = np.loadtxt(DIFF_LIST, dtype='str', ndmin=1)
    else:
        data = np.genfromtxt(DIFF_LIST, delimiter="\t", dtype=str)
    print(data)
    datafiles = data.tolist()
    
    for d in datafiles:
        path = dirpath + d
        print(path)
        
        allfiles.extend(glob.glob(path, recursive = True))

filter_filelist()
print(filtered_list)

#html code for the banned function report    
htmlStartString = """<html>
    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> 
    </head>
            <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.2/css/jquery.dataTables.css">
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.2/js/jquery.dataTables.js"></script>
        <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>
        <script>
            $(document)
                .ready(function () {
                    $('#table_id')
                        .DataTable( {

                        dom: 'lBfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
                        
                        }
                        
                        );
                });
        </script>
    <title>
        Report Results
    </title>
    <body>
        <table id="table_id" class="display">
            <thead>
                <tr style="text-align:left"> 
                    <th>
                        Filename
                    </th>
                    <th>
                        Line Number
                    </th>
                    <th>
                        Banned Function/Macro
                    </th>
                    <th>
                        Suggested Solution
                    </th>
                </tr>
            </thead>
            <tbody> """
htmlTableHeaderDataStartString = ""
htmlTableHeaderDataEndString = ""
htmlTableBodyDataStartString = ""
htmlTableDataEndString = ""
htmlEndString ="""           </tbody>
        </table>
                <footer>
    <p><a href="https://confluence.cec.lab.emc.com/pages/viewpage.action?spaceKey=MP&title=Security+Guidance+on+Banned+Functions" target="_blank">For more information about CRT Banned Functions</a></p>
</footer>
    </body>
</html>\n</body></html>"""

table_data = []

#function to create the whole HTML report
def create_html_report(html_report_name,htmlTableHeaderDataStartString):
    print(htmlTableHeaderDataStartString, htmlTableBodyDataStartString)
    with open(html_report_name,'w') as f:
        f.write(htmlStartString)
        f.write(htmlTableHeaderDataStartString)
        f.write(htmlTableHeaderDataEndString)
        f.write(htmlTableBodyDataStartString)
        f.write(htmlEndString)
        f.close()

"""Function to check the files in the repository."""
def banned_function_checker(htmlTableBodyDataStartString, repoName):
    #Update banned list with macro name linking to banned function
    #applied for assert() only at the moment
    data = ExtendCustomBannedListWithMacro('dictionary.json', 'assert')
    if repoName == "gNB_ngp":
        del data['malloc']
        del data['free']
    for filename in filtered_list:
        print('Processing for file: %s' % filename)
        htmlTableFileData = ""

        for i in data:
            bannedfunc = i
            suggestedfunc = ",".join(data[i])
            
            # print("calling change in file")
            htmlTableFileData += function_change(filename, bannedfunc, suggestedfunc)
        htmlTableBodyDataStartString += htmlTableFileData

        if not len(htmlTableFileData):            
            #htmlTableBodyDataStartString += htmlTableFileData
            print("there are no banned functions")
    return htmlTableBodyDataStartString

index=0

#function to scan each file line by line for banned function and generate the result 
def function_change(filename, bannedfunc, suggestedfunc):
    
    # Safely read the input filename using 'with'
    input_file = open(filename, 'rb')

    multi_line = False
    
    table_body_row = ""
    
    for line_number, line_str in enumerate(input_file, 1):
        cont = False
      
        line_str = line_str.decode("ISO-8859-1")   
        line = line_str   
      
        com_start = '/*'
        com_single = '//'
        if com_start in line_str:
            line = line_str.split(com_start,1)[0]
            multi_line = True
            if line.isspace():
                cont = True
      
        if(multi_line):
            com_close = '*/'
            if com_close in line_str:
                line += line_str.split(com_close,1)[1]
                multi_line = False
                if line.isspace():
                    cont = True
                else:
                    cont = False

              
        elif  com_single in line_str:
            line = line_str.split(com_single,1)[0]
            if line.isspace():
                cont = True
          
        if cont:
            continue    
      
        if bannedfunc in line:
            # Exclude C-banned checker for the assert() inside NGP_DEBUG_ENABLE macro in ngp_data_pool MP-82188
            ngp_data_pool_file_list = [dirpath + "include/ngp_data_pool.h", dirpath + "mem/src/ngp_data_pool.cpp"]
            if bannedfunc == "assert" and filename in ngp_data_pool_file_list:             
                if is_inside_macro_block(filename, line_number, "NGP_DEBUG_ENABLE"):
                    continue
        
            #linefunc = re.findall(r'^' + str(bannedfunc) + '\( | \s*' + str(bannedfunc) + '\( | \s*' + str(bannedfunc) + '\s*\(',line)
            linefunc = re.findall(r"^"+str(bannedfunc)+'\s*\(|\s+'+str(bannedfunc)+'\s*\(|'+'\:\:'+str(bannedfunc)+'\s*\(|\:\:'+str(bannedfunc)+'\s+|'+'\:\:'+str(bannedfunc)+'\s*[\<\,\&\;\:]'+'|\(\s*'+str(bannedfunc)+'\s*\(',line)
            filepath = filename.split(repo_name+'/')[-1]
        
            if linefunc:
                print('Change "{bannedfunc}()" to "{suggestedfunc}" in {filename}'.format(**locals()))       

                table_body_row += f"""  <tr>    
                    <!-- Individual fields are kept here -->
                    <!--First field i.e. first <td> is file name-->
                    <td style="padding-left:20px;width:35%">
                        <a href="{REPO}blob/{BRANCH}/{filepath}#L{line_number}" target="_blank" rel="noopener noreferrer">{filepath}</a>
                    </td>
                    <!--Second field should consist of line number-->
                    <td style="padding-left:20px;width:10%">
                        {line_number}
                    </td>
                    <!--Third field is banned function-->
                    <td style="padding-left:20px;width:20%">
                        {bannedfunc}
                    </td>
                    <!--Final field is suggested function-->
                    <td style="padding-left:20px;width:35%">
                        {suggestedfunc}
                    </td>
                </tr>"""
              
    
    input_file.close()
    
    return table_body_row

#function check inside macro block
def is_inside_macro_block(filename, banned_line_number, macro_pattern):
    with open(filename, 'r') as file:
        lines = file.readlines()

    inside_macro_block = False
    macro_pattern_regex = re.compile(r'\s*#(?:ifdef\s+|if defined\()(?<!\!)' + re.escape(macro_pattern) + r'\b')

    for i, line in enumerate(lines, start=1):
        # Check start line of macro with macro_pattern
        if macro_pattern_regex.match(line):
            inside_macro_block = True
        # End of macro block at #endif
        elif re.match(r'\s*#endif\b', line):
            inside_macro_block = False
        # Check whether banned_line_number belongs in macro block
        if inside_macro_block and banned_line_number == i:
            return True
        
    return False

#make custom banned function list
#append macro name which is linking to banned function into current banned list
def ExtendCustomBannedListWithMacro(dictionary='dictionary.json', banned_func=None):
    banned_list = open(dictionary)
    custom_dictionary = json.load(banned_list)
    for filename in filtered_list:
        macros = findMacroLinktoBannedFunc(filename, banned_func)
        if macros:
            custom_dictionary.update(dict.fromkeys(macros, [f'Calling to banned function {banned_func}. Justify to use alternate function in the macro']))
    return custom_dictionary

#find macro name linking to banned function
def findMacroLinktoBannedFunc(filename=None, banned_func=None, exclude_macrolist=['NGP_DEBUG_ENABLE']):
    list_macro = []
    banned_func_regx = r'[^\w+]' + banned_func + r'\('
    if not filename or not banned_func:
        print("The code file or banned function is not specific. Returning...")
        return None
    #read file
    with open(filename, 'r', errors='ignore') as file:
        content = file.read()
    #perform regex to find macro definition
    matchs = re.findall(MACRO_PATTERN_REGEX, content, re.MULTILINE)
    for match in matchs:
        if match[0] in exclude_macrolist:
            print('Macro name: %s is in exclusion list' % match[0])
            continue
        if match[1] and re.search(banned_func_regx, match[1]):
            print('Found macro name: %s calling to banned func: %s' % (match[0], banned_func))
            list_macro.append(match[0])
    return list_macro

#function call
htmlTableBodyDataStartString = banned_function_checker(htmlTableBodyDataStartString, repo_name)


if htmlTableBodyDataStartString == "":
    print("There are no violations, HTML report not generated")
    sys.exit(0)

#if not a githubpullrequest checker
if PRCHECK is False:
    create_html_report(HTML_REPORT_NAME,htmlTableHeaderDataStartString)
    print("please check the HTML report linked to build number for the list of banned functions")
    sys.exit(2)
    
else:
    create_html_report(HTML_REPORT_NAME,htmlTableHeaderDataStartString)
    print("please check the HTML report linked to build number for the list of banned functions, ending unsuccessfully")
    sys.exit(1)
