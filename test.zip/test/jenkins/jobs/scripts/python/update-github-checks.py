import os
import requests
from github import Github

if "PR_NUM" in os.environ:
    github_pr_num = os.environ["PR_NUM"]
if "REPO_NAME" in os.environ:
    github_repo = os.environ["REPO_NAME"]
if "PR_COMMIT" in os.environ:
    github_pr_commit = os.environ["PR_COMMIT"]
if "MESSAGE" in os.environ:
    github_message = os.environ["MESSAGE"]
if "STATUS" in os.environ:
    build_result = os.environ["STATUS"]
if "GITHUB_TOKEN" in os.environ:
    token = os.environ["GITHUB_TOKEN"]
if "CHECK_NAME" in os.environ:
    check_name = os.environ["CHECK_NAME"]
if "REPORT_LINK" in os.environ:
    report_link = os.environ["REPORT_LINK"]


def send_comment(repo_name, pr_num, message):
    g = Github(base_url = "https://eos2git.cec.lab.emc.com/api/v3", login_or_token = token, verify = False)

    repo = g.get_repo(repo_name)
    pr = repo.get_pull(int(pr_num))
    print("Send comment to github pull request #{}".format(pr_num))
    pr.create_issue_comment(message) 


def send_checkrun(repo_name, commit, jenkins_url, build_result):
    github_api = "https://eos2git.cec.lab.emc.com/api/v3/repos/{}/statuses/{}".format(repo_name, commit)
    if build_result == "SUCCESS":
        state = "success"
    else:
        state = "failure"

    data = {
        "state": "{}".format(state),
        "context": "{}".format(check_name),
        "description": "Check result: {}".format(build_result),
        "target_url": "{}".format(report_link),
    }
    headers = {"Authorization": "Bearer {}".format(token)}
    print("Posting check run result to pull request #{}".format(github_pr_num))
    r = requests.post(github_api, headers=headers, json=data, verify=False)
    if r.status_code != 201:
        raise "Failed to post check run to pull request #{}".format(github_pr_num)

send_checkrun(github_repo, github_pr_commit, report_link, build_result)
if build_result == "SUCCESS":
    github_messages = "{} is {}\n".format(check_name, build_result)
else:
    github_messages = "{} is {}\n".format(check_name, build_result) + github_message

send_comment(github_repo, github_pr_num, github_messages)
