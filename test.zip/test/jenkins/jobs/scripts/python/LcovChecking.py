#!/usr/bin/python3

import argparse
from lxml import html

class HTMLParser():
    """Parse html."""
    def __init__(self, file_path):
        with open(file_path, "r") as f:
            self.data = f.read()
        self.tree = html.fromstring(self.data)

    def get_table(self):
        """Get table list. Return list of table object."""
        return self.tree.xpath("//table")
        
    def get_tr(self, table_index=2):
        """Get tr list inside a table. Return list of tr object."""
        tables = self.get_table()
        return tables[table_index].xpath(".//tr")
    

class HTMLBuilder():
    """Build basic htm report."""
    def add_table(self, success_dict, failure_dict, skipped_dict, threshold_dict):
        """Add table tag."""
        summary_table = ("""
            <div style="width:10%; margin:0 auto; border: 1px outset red; background-color: lightblue; text-align: center;">
                <p><b><ins>SUMMARY</ins></b></p>
                <p>Checked Files: {}</p>
                <p>Passed: {}</p>
                <p>Failed: {}</p>
                <p>Skipped: {}</p>
            </div> 
        """.format(len(threshold_dict), len(success_dict), len(failure_dict), len(skipped_dict)))
        failure_table = self.add_tr("File", "Status", 'Threshold (%)', 'Reported Value (%)', 'color:blue; background-color: yellow')
        skipped_table = self.add_tr("File", "Status", 'Threshold (%)', 'Reported Value (%)', 'color:blue; background-color: yellow')
        success_table = self.add_tr("File", "Status", 'Threshold (%)', 'Reported Value (%)', 'color:blue; background-color: yellow')
        for key, value in failure_dict.items():
            failure_table += self.add_tr(key, "FAILED",threshold_dict[key], value)
            
        for key, value in skipped_dict.items():
            skipped_table += self.add_tr(key, "SKIPPED",threshold_dict[key], value)
            
        for key, value in success_dict.items():
            success_table += self.add_tr(key, "PASSED",threshold_dict[key], value)
            
        table_format = (
            '<h2 style="color:red">FAILED</h2>\n'
            '<table style="width:45%">\n'
            "{}\n"
            "</table>\n"
            '<h2 style="color:red">SKIPPED</h2>\n'
            '<table style="width:45%">\n'
            "{}\n"
            "</table>\n"
            '<h2 style="color:green">PASSED</h2>\n'
            '<table style="width:45%">\n'
            "{}\n"
            "</table>\n"
        ).format(failure_table, skipped_table, success_table)
        return table_format, summary_table
        
    def add_tr(self, file, status, threshold, reported, style=""):
        """Add tr tag."""
        tr_format = (
            '<tr style="{}">\n'
                "<th>{}</th>\n"
                "<th>{}</th>\n"
                "<th>{}</th>\n"
                "<th>{}</th>\n"
            "</tr>\n"
        ).format(style, file, status, threshold, reported)
        return tr_format
        
    def build_html(self, success_dict, failure_dict, skipped_dict, threshold_dict, output_file_name):
        """Build html report."""
        table, summary = self.add_table(success_dict, failure_dict, skipped_dict, threshold_dict)
        html_format = (
            '<!DOCTYPE html>\n'
            '<html>\n'
            '<h1 style="font-size:200%;color:blue;text-align:center" >LCOV - CHECKING RESULT</h1>'
            "{}"
            '<style> table, th, td {{ border:1px solid black; border-color: #92a8d1;}} </style>\n'
            '<body>\n'
            "{}"
            '</body>\n'
            '</html>'
        ).format(summary, table)
        
        with open(output_file_name, 'w') as f:
            f.write(html_format)            


class LCOVParser():
    """Parse the lcov html report and represent its data as a dictionary."""
    def __init__(self, file_path):
        self.file_path = file_path
        self.dict = { }
        self.parser = HTMLParser(file_path)
        
    def parse_summary(self):
        """Parse lcov summary report."""
        self.dict["Summary"] = {}
        for index, table in enumerate(self.parser.get_table()):
            if index == 0:
                rows = table.xpath(".//tr//td")
                for i, row in enumerate(rows):
                    if "Test:" in row.text_content():
                        self.dict["Summary"]["Test"] = rows[i+1].text_content().strip()
                    if "Test Date:" in row.text_content():
                        self.dict["Summary"]["Test Date"] = rows[i+1].text_content().strip()
                    if "Legend:" in row.text_content():
                        self.dict["Summary"]["Legend"] = rows[i+1].text_content().strip()
                    if "Lines:" in row.text_content():
                        self.dict["Summary"]["Lines"] = rows[i+1].text_content().strip()
                    if "Functions:" in row.text_content():
                        self.dict["Summary"]["Functions"] = rows[i+1].text_content().strip()
                    if "Branches:" in row.text_content():
                        self.dict["Summary"]["Branches"] = rows[i+1].text_content().strip()
        return self.dict

    def get_row_data(self):
        """Get data in tr tag inside a table."""
        tr_list = self.parser.get_tr(2)
        # Remove empty elmt
        tr_list.pop(0)
        
        for tr in tr_list:
            # Number of rows in tr
            if len(tr) > 9:
                self.dict[tr[0].text_content().strip()] = ({
                        'Line Coverage': {
                            "coverage": tr[2].text_content().strip(),
                            "Total": tr[3].text_content().strip(),
                            "Hit": tr[4].text_content().strip()
                        }, 
                        'Branch Coverage': {
                            "coverage": tr[5].text_content().strip(),
                            "Total": tr[6].text_content().strip(),
                            "Hit": tr[7].text_content().strip()
                        },
                        'Function Coverage': {
                            "coverage": tr[8].text_content().strip(),
                            "Total": tr[9].text_content().strip(),
                            "Hit": tr[10].text_content().strip()
                        }
                    })
        return self.dict
    
def parse_multiple_index(file_path_list: list):
    """Parse multiple index.html to one dictionary."""
    lcov_report = {}
    for file in file_path_list:
        parser = LCOVParser(file)
        lcov_report.update(parser.get_row_data())
    
    return lcov_report
    
def check_lcov_threshold(lcov_report_files: list, threshold_config_file):
    """Compare lcov threshold with lcov report."""
    conf_data = {}
    threshold_config_list = []
    success_dict = {}
    failure_dict = {}
    skipped_dict = {}
    lcov_report_dict = parse_multiple_index(lcov_report_files)
    with open(threshold_config_file, 'r') as file:
        lines = file.readlines()
        threshold_config_list = [line.strip() for line in lines]
        
    for item in threshold_config_list:
        conf_data[item.split(":")[0].strip()] = item.split(":")[1].strip()
    print("Checking {} files in lcov configuration file.".format(len(conf_data)))
        
    for file in conf_data:
        conf_threhold_value = float(conf_data[file].split("%")[0].strip())
        report_value = 0
        if file in lcov_report_dict:
            if (len(lcov_report_dict[file]["Branch Coverage"]["coverage"]) > 1):
                report_value = float(lcov_report_dict[file]["Branch Coverage"]["coverage"].split("%")[0].strip())
            print("===== Checking LCOV report for \"{}\" =====".format(file))
            print("LCOV report value is {}%. Threshold configuration value is {}%.".format(report_value, conf_threhold_value))
            if report_value < conf_threhold_value:
                print("[FAILED] Code coverage (branch) is lower than defined threshold.")
                failure_dict[file] = report_value
            else:
                success_dict[file] = report_value
        else:
            if conf_threhold_value == 0:
                success_dict[file] = conf_threhold_value
            else:    
                print("There is no LCOV report for {}".format(file))
                skipped_dict[file] = ""
    
    print("\r\nLIST OF SUCCESS: \r\n{}".format(success_dict))
    print("\r\nLIST OF FAILURES: \r\n{}".format(failure_dict))
    print("\r\nLIST OF SKIPPED: \r\n{}".format(skipped_dict))
    
    HTMLBuilder().build_html(success_dict, failure_dict, skipped_dict, conf_data, "lcov_checking_report.html")
    
    if (len(success_dict) < len(conf_data)):
        print("Only {}/{} files succeed.".format(len(success_dict), len(conf_data)))
        return False
    
    return True

def parse_args():
    """Parse all arguments."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-t", "--threshold-file",
        required=True,
        help="Path to threshold configuration file",
    )
    parser.add_argument(
        "-i", "--input-html-file",
        nargs="+",
        required=True,
        help="Path to index.html files",
    )
    args = parser.parse_args()
    return args

if __name__ == "__main__":
    args = parse_args()
    if args.input_html_file and args.threshold_file:
        if check_lcov_threshold(args.input_html_file, args.threshold_file):
            print("LCOV CHECKING: PASSED")
        else:
            print("LCOV CHECKING: FAILED")
