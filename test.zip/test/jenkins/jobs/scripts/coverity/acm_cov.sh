#!/bin/bash
set -ex

#Script to run coverity for ACM
#Arguments:
#1 Coverity bin directory
#2 Coverity intermediate directory

helpFunc()
{
    echo ""
    echo "Usage: $0 -c <cov_bin_dir> -i <intermediate_dir>"
    echo -e "\t-c Path to coverity bin directory"
    echo -e "\t-i Path to coverity intermediate directory"
    echo -e "\t-d build using cov-run-desktop, -d "
    echo ""
    exit 1
}

while getopts "c: i: d s: o: f:" opt
		
do
   case "$opt" in
      c ) cov_path="$OPTARG" ;;
      i ) inter_dir_path="$OPTARG" ;;
      d ) cov_run_d="true" ;;
      s ) stream="$OPTARG" ;;
      o ) output_filename="$OPTARG" ;;
      f ) change_list="$OPTARG" ;;
      ? ) helpFunc ;; # Print helpFunction in case parameter is non-existent
   esac
done

# Print helpFunction in case parameters are empty
if [ -z "$cov_path" ] 
then
   echo "Coverity path must be provided";
   helpFunc
fi

if [ -z "$inter_dir_path" ] 
then
   echo "Intermediate directory must be provided";
   helpFunc
fi

url="https://isg-coverity3.cec.lab.emc.com"
#Component map filter for ignoring third party libs; only applicable for cov-run-desktop
cov_run_desktop_options=" --ignore-uncapturable-inputs true --present-in-reference false --set-new-defect-owner false --exit1-if-defects false --verbose 2 "


cd /DU/gNB_ACM
chmod +x compile_acm.sh

if [ "$cov_run_d" == "true" ]; then
    echo -e "\n\n##### Coverity scan for PR #####"
	if [ -z "$stream" ]; then
		echo "For cov-run-desktop, stream must be provided"; helpFunc
	fi

	if [ -z "$output_filename" ]; then
        echo "For cov-run-desktop, Coverity output filename must be provided"; helpFunc
	fi

	if [ -z "$change_list" ]; then
		echo "For cov-run-desktop, change list must be provided"; helpFunc
	fi

   # Build
   echo -e "\n\n##### start cov-run-desktop build #####"
	$cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream $stream --user committer --password commit  --build --record-with-source ./compile_acm.sh

   # Analyze
   echo -e "\n\n##### start cov-run-desktop analyze #####"
   $cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream $stream --user committer --password commit $cov_run_desktop_options --text-output $inter_dir_path/$output_filename @@/$change_list
else
   # Build
   echo -e "\n\n##### start cov-build build #####"
   $cov_path/cov-build --dir $inter_dir_path ./compile_acm.sh 
fi

exit 0
