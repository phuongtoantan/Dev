#!/bin/bash
set -ex

pwd

helpFunc()
{
    echo ""
    echo "Usage: $0 -n -o -c change_file"
    echo -e "\t-c <Change list file name path>"
    echo -e "\t-n ngp get submodules for ngp"
    echo -e "\t-o oam get submodules for oam"
    echo -e "\t-m mplane get submodules for FH_MPlane"
    echo ""
    exit 1
}

while getopts "c: n o m" opt
do
   case "$opt" in
      c ) change_list_filepath="$OPTARG" ;;
      n ) ngp="true" ;;
      o ) oam="true" ;;
      m ) mplane="true" ;;
      ? ) helpFunc ;; # Print helpFunction in case parameter is non-existent
   esac
done

if [ -z "$change_list_filepath" ] 
then
   echo "Change file path must be provided";
   helpFunc
fi

getChange(){
    # $1 is submodule
    # $2 is change_list path
    prev_commit=`git ls-tree HEAD~ $1 | awk '{print $3}'`
    curr_commit=`git ls-tree HEAD  $1 | awk '{print $3}'`
    if [ "$prev_commit" = "$curr_commit" ]; then
        echo "No changes in $1"
    else
        cd $1
        git diff --name-only $prev_commit $curr_commit >> $2$1
        sed -i "s/^/\/phoenix\/$1\//g" $2$1
        cat $2$1 >> $2
        rm $2$1
        cd ..
    fi
}

if [ "$ngp" == "true" ]; then
    getChange ngp $change_list_filepath
fi 

if [ "$oam" == "true" ]; then
    getChange gNB_OAM $change_list_filepath
fi

if [ "$mplane" == "true" ]; then
    getChange gNB_FH_MPLANE $change_list_filepath
fi

cat $change_list_filepath
