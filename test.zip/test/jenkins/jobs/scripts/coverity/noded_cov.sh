#!/bin/bash
set -ex

#Script to run coverity for Transport
#Arguments:
#1 Coverity bin directory
#2 Coverity intermediate directory
# Copyright (c) 2023 Dell Inc. or its subsidiaries. All rights reserved.


helpFunc() {
    echo ""
    echo "Usage: $0 -c <cov_bin_dir> -i <intermediate_dir> -b <cu compile options>"
    echo -e "\t-c Path to coverity bin directory"
    echo -e "\t-i Path to coverity intermediate directory"
    echo ""
    exit 1
}

while getopts "c: i: d s: u: p: o: f:" opt; do
    case "$opt" in
        c ) cov_path="$OPTARG" ;;
        i ) inter_dir_path="$OPTARG" ;;
        d ) cov_run_d="true" ;;
        s ) stream="$OPTARG" ;;
        u ) user="$OPTARG" ;;
        p ) password="$OPTARG" ;;
        o ) output_filename="$OPTARG" ;;
        f ) change_list="$OPTARG" ;;
        ? ) helpFunc ;;
    esac
done

#Defaults
COV_URL='https://isg-coverity3.cec.lab.emc.com'
COV_RUN_DESKTOP_OPTIONS=" --ignore-uncapturable-inputs true --present-in-reference false --set-new-defect-owner false --exit1-if-defects false --verbose 2 "

# Print helpFunction in case parameters are empty
if [ -z "$cov_path" ] ; then
   echo "Coverity path must be provided";
   helpFunc
fi

if [ -z "$inter_dir_path" ]; then
   echo "Intermediate directory must be provided";
   helpFunc
fi

cd /DU/gNB_node_controller
ls -ltr

#configure compiler
$cov_path/cov-configure --compiler cc --comptype gcc --template
$cov_path/cov-configure --compiler c++ --comptype gcc --template

if [ "$cov_run_d" == "true" ]; then
    if [ -z "$stream" ]; then
        echo "For cov_run_desktop, stream must be provided";
        helpFunc
    fi

    if [ -z "$user" ]; then
        echo "For cov_run_desktop, user must be provided";
        helpFunc
    fi

    if [ -z "$password" ]; then
        echo "For cov_run_desktop, password must be provided";
        helpFunc
    fi

    if [ -z "$output_filename" ]; then
        echo "For cov_run_desktop, Coverity output filename must be provided";
        helpFunc
    fi

    if [ -z "$change_list" ]; then
        echo "For cov_run_desktop, change list must be provided";
        helpFunc
    fi

    #Build
    $cov_path/cov-run-desktop \
        --dir $inter_dir_path \
        --url $COV_URL \
        --stream $stream \
        --user $user --password $password \
        --record-with-source \
        --build /DU/gNB_node_controller/build-noded.sh

    echo -e "\n\n##### cov-run-desktop build completed #####"
    echo "############################## starting debugging ######################################"
    echo $change_list
    cat $change_list
    #find . -type f -iname glib.c
    #for i in `cat $change_list`; do ls $i; done
    
    echo "############################## end debugging ######################################"
    #Analyze
    $cov_path/cov-run-desktop \
        --dir $inter_dir_path \
        --url $COV_URL \
        --stream $stream $COV_RUN_DESKTOP_OPTIONS \
        --user $user --password $password \
        --text-output $inter_dir_path/$output_filename @@/$change_list

    echo -e "\n\n##### cov-run-desktop analyze completed #####"

else
    #Build
    $cov_path/cov-build --dir $inter_dir_path /DU/gNB_node_controller/build-noded.sh
    echo -e "\n\n##### cov-build build completed #####"
fi

exit 0
