#!/bin/bash
set -ex

#Script to run coverity for OAM
#Arguments:
#1 Coverity bin directory
#2 Coverity intermediate directory

helpFunc()
{
    echo ""
    echo "Usage: $0 -c <cov_bin_dir> -i <intermediate_dir> -b <cu compile options>"
    echo -e "\t-c Path to coverity bin directory"
    echo -e "\t-i Path to coverity intermediate directory"
    echo ""
    exit 1
}

while getopts "c: i: d s: a: o: f:" opt
do
   case "$opt" in
      c ) cov_path="$OPTARG" ;;
      i ) inter_dir_path="$OPTARG" ;;
      d ) cov_run_d="true" ;;
      s ) stream="$OPTARG" ;;
      a ) auth_key="$OPTARG" ;;
      o ) output_filename="$OPTARG" ;;
      f ) change_list="$OPTARG" ;;
      ? ) helpFunc ;; # Print helpFunction in case parameter is non-existent
   esac
done

#Defaults
url="https://isg-coverity3.cec.lab.emc.com"
cov_run_desktop_options=" --ignore-uncapturable-inputs true --present-in-reference false --set-new-defect-owner false --exit1-if-defects false --verbose 2 "

# Print helpFunction in case parameters are empty
if [ -z "$cov_path" ] 
then
   echo "Coverity path must be provided";
   helpFunc
fi

if [ -z "$inter_dir_path" ] 
then
   echo "Intermediate directory must be provided";
   helpFunc
fi

cd /phoenix
ls -ltr

#configure compiler
$cov_path/cov-configure --compiler /usr/local/bin/gcc --comptype gcc

if [ "$cov_run_d" == "true" ]; then
	if [ -z "$stream" ] 
	then
		echo "For cov_run_desktop, stream must be provided";
		helpFunc
	fi

	if [ -z "$output_filename" ] 
	then
		echo "For cov_run_desktop, Coverity output filename must be provided";
		helpFunc
	fi

	if [ -z "$change_list" ] 
	then
		echo "For cov_run_desktop, change list must be provided";
		helpFunc
	fi
    
        #Build
	$cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream $stream --user committer --password commit --record-with-source --build /phoenix/build.sh

	echo -e "\n\n##### cov-run-desktop build  completed #####"

	#Analyze
	$cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream $stream --user committer --password commit $cov_run_desktop_options --text-output $inter_dir_path/$output_filename @@/$change_list

	echo -e "\n\n##### cov-run-desktop analyze  completed #####"
	#echo "Content of $output_filename"
	#cat $inter_dir_path/$output_filename
    
else
    	#coverity build
   	$cov_path/cov-build --dir $inter_dir_path /phoenix/build.sh
fi

exit 0
