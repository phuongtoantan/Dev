#!/bin/bash
set -ex
export CC=/usr/local/bin/gcc
#Script to run coverity for DU
#Arguments:
#1 Coverity bin directory
#2 Coverity intermediate directory
#3 Compilation option, DU "-t cp -o" ....

helpFunc()
{
    echo ""
    echo "Usage: $0 -c <cov_bin_dir> -i <intermediate_dir> -b <du compile options>"
    echo -e "\t-c Path to coverity bin directory"
    echo -e "\t-i Path to coverity intermediate directory"
    echo -e "\t-b DU compile options , example '-t cp -o'"
    echo -e "\t-d build using cov-run-desktop, -d -s 'MP-DU-dpdk-main' -a '/aut-key.txt' -o 'coverity_error_nodpdk.txt' -f '/change_list.txt'"
    echo -e "\t-d Options require stream, authentication key file path, coverity error output file name, change list file path."
    echo -e "\t-p Run on OS, -p rhel"
    echo ""
    exit 1
}

while getopts "c: i: b: d s: a: o: f: p:" opt
do
   case "$opt" in
      c ) cov_path="$OPTARG" ;;
      i ) inter_dir_path="$OPTARG" ;;
      b ) build_options="$OPTARG" ;;
      d ) cov_run_d="true" ;;
      s ) stream="$OPTARG" ;;
      a ) auth_key="$OPTARG" ;;
      o ) output_filename="$OPTARG" ;;
      f ) change_list="$OPTARG" ;;
	  p ) os="$OPTARG" ;;
      ? ) helpFunc ;; # Print helpFunction in case parameter is non-existent
   esac
done

#Defaults
url="https://isg-coverity3.cec.lab.emc.com"

#Component map filter for ignoring third party libs; only applicable for cov-run-desktop
component_not_regex=" --component-not-regex MP-DU-usr "

cov_run_desktop_options=" --ignore-uncapturable-inputs true --present-in-reference false --set-new-defect-owner false --exit1-if-defects false --verbose 2 $component_not_regex"

# Print helpFunction in case parameters are empty
if [ -z "$cov_path" ] 
then
   echo "Coverity path must be provided";
   helpFunc
fi

if [ -z "$inter_dir_path" ] 
then
   echo "Intermediate directory must be provided";
   helpFunc
fi

if [ -z "$build_options" ] 
then
   echo "Build options must be provided";
   helpFunc
fi

# Identify compile_du.sh script location
build_path="/phoenix/gNB_DU/build"
[[ -f /phoenix/gNB_DU/compile_du.sh ]] && build_path=/phoenix/gNB_DU
cd $build_path

if [ "$cov_run_d" == "true" ]; then
	if [ -z "$stream" ] 
	then
		echo "For cov_run_desktop, stream must be provided";
		helpFunc
	fi


	if [ -z "$output_filename" ] 
	then
		echo "For cov_run_desktop, Coverity output filename must be provided";
		helpFunc
	fi

	if [ -z "$change_list" ] 
	then
		echo "For cov_run_desktop, change list must be provided";
		helpFunc
	fi
	
	#Build
   $cov_path/cov-build --dir $inter_dir_path --desktop --emit-complementary-info --record-with-source ./compile_du.sh $build_options

	echo -e "\n\n##### cov-run-desktop build  completed #####"

	#Analyze
   if [ -s $change_list ]
   then
      $cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream $stream --user committer --password commit  $cov_run_desktop_options --text-output $inter_dir_path/$output_filename @@/$change_list
   else
      echo -e "\n\n##### cov-run-desktop analyze -- no any change file is detected #####"
   fi
   
	echo -e "\n\n##### cov-run-desktop analyze  completed #####"
	#echo "Content of $output_filename"
	#cat $inter_dir_path/$output_filename
else
	$cov_path/cov-build --emit-complementary-info --dir $inter_dir_path ./compile_du.sh $build_options
fi

exit 0
