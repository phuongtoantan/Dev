#!/bin/bash
set -ex

#Script to run coverity for CU
#Arguments:
#1 Coverity bin directory
#2 Coverity intermediate directory
#3 Compilation option, CU UP, CU CP, "-t cp -o" ....

helpFunc()
{
    echo ""
    echo "Usage: $0 -c <cov_bin_dir> -i <intermediate_dir> -b <cu compile options>"
    echo -e "\t-c Path to coverity bin directory"
    echo -e "\t-i Path to coverity intermediate directory"
    echo -e "\t-b CU compile options , example '-t cp -o'"
    echo -e "\t-d build using cov-run-desktop, -d -s 'MP-CUCP-dpdk-main' "
    echo -e "\t-s Stream for cov-run-desktop, -d  -s 'MP-CUCP-dpdk-main' "
    echo -e "\t-p Run on OS, -p rhel"
    echo ""
    exit 1
}

while getopts "c: i: b: d s: a: o: f: p:" opt
		
do
   case "$opt" in
      c ) cov_path="$OPTARG" ;;
      i ) inter_dir_path="$OPTARG" ;;
      b ) build_options="$OPTARG" ;;
      d ) cov_run_d="true" ;;
      s ) stream="$OPTARG" ;;
      a ) auth_key="$OPTARG" ;;
      o ) output_filename="$OPTARG" ;;
      f ) change_list="$OPTARG" ;;
      p ) os="$OPTARG" ;;

      ? ) helpFunc ;; # Print helpFunction in case parameter is non-existent
   esac
done

# Print helpFunction in case parameters are empty
if [ -z "$cov_path" ] 
then
   echo "Coverity path must be provided";
   helpFunc
fi

if [ -z "$inter_dir_path" ] 
then
   echo "Intermediate directory must be provided";
   helpFunc
fi

if [ -z "$build_options" ] 
then
   echo "Build options must be provided";
   helpFunc
fi

url="https://isg-coverity3.cec.lab.emc.com"
#Component map filter for ignoring third party libs; only applicable for cov-run-desktop
component_not_regex=" --component-not-regex MP-CU-3rdParty "

cd /phoenix/gNB_CU/build

if [ "$cov_run_d" == "true" ]; then
	if [ -z "$stream" ] 
	then
		echo "Build options must be provided";
		helpFunc
	fi
	
	cov_run_desktop_options=" --ignore-uncapturable-inputs true --present-in-reference false --set-new-defect-owner false --exit1-if-defects false --verbose 2 $component_not_regex"
	
	$cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream $stream  --user committer --password commit --build --record-with-source ./compile_cu.sh $build_options
	echo -e "\n\n##### cov-run-desktop build  completed #####"

    $cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream $stream --user committer --password commit $cov_run_desktop_options --text-output $inter_dir_path/$output_filename @@/$change_list
	
    #$cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream MP-CUCP-nodpdk-main --user committer --password commit --reference-snapshot latest --present-in-reference false --ignore-uncapturable-inputs false --exit1-if-defects false $(git --no-pager diff origin/main origin/MP-1072 --name-only | grep -e .cpp$ -e .h$ -e .c$ | sed 's/^5gran/\/phoenix\/5gran/' )
	echo -e "\n\n##### cov-run-desktop analyze  completed #####"
	#echo "Content of $output_filename"
	#cat $inter_dir_path/$output_filename

else
	#/data/cov-analysis-linux64-2020.12-3/bin/cov-build --dir /data/cov_inter_dir/CUCP_nodpdk ./compile_cu.sh -t cp -o
	$cov_path/cov-build --dir $inter_dir_path ./compile_cu.sh $build_options
fi

exit 0
