#!/bin/bash
set -ex

#Script to run coverity for MPLANE
#Arguments:
#1 Coverity bin directory
#2 Coverity intermediate directory
#3 Coverity stream
## Copyright (c) 2021-2024 Dell Inc. or its subsidiaries. All Rights Reserved.

helpFunc()
{
    echo ""
    echo "Usage: $0 -c <cov_bin_dir> -i <intermediate_dir> -s <Coverity stream>"
    echo -e "\t-c Path to coverity bin directory"
    echo -e "\t-i Path to coverity intermediate directory"
    echo -e "\t-b MPLANE compile options , example '-t cp -o'"
    echo -e "\t-d build using cov-run-desktop, -d "
    echo -e "\t-s Stream for cov-run-desktop, -s 'MP-MPLane-main' "
    echo -e "\t-p Run on OS, -p rhel"
    echo ""
    exit 1
}

while getopts "c: i: b: d s: a: o: f: p:" opt
        
do
   case "$opt" in
      c ) cov_path="$OPTARG" ;;
      i ) inter_dir_path="$OPTARG" ;;
      b ) build_options="$OPTARG" ;;
      d ) cov_run_d="true" ;;
      s ) stream="$OPTARG" ;;
      a ) auth_key="$OPTARG" ;;
      o ) output_filename="$OPTARG" ;;
      f ) change_list="$OPTARG" ;;
      p ) os="$OPTARG" ;;

      ? ) helpFunc ;; # Print helpFunction in case parameter is non-existent
   esac
done

# Print helpFunction in case parameters are empty
if [ -z "$cov_path" ] 
then
    echo "Coverity path must be provided";
    helpFunc
fi

if [ -z "$inter_dir_path" ] 
then
    echo "Intermediate directory must be provided";
    helpFunc
fi

if [ -z "$build_options" ] 
then
    echo "Build options must be provided";
    helpFunc
fi

url="https://isg-coverity3.cec.lab.emc.com"
#Component map filter for ignoring third party libs; only applicable for cov-run-desktop
cov_run_desktop_options=" --ignore-uncapturable-inputs true --present-in-reference false --set-new-defect-owner false --exit1-if-defects false --verbose 2 "

cd /DU/gNB_FH_MPLANE/build

if [ "$cov_run_d" == "true" ]; then
    echo -e "\n\n##### Coverity scan for PR #####"
	if [ -z "$stream" ]; then
		echo "For cov-run-desktop, stream must be provided"; helpFunc
	fi

	if [ -z "$output_filename" ]; then
        echo "For cov-run-desktop, Coverity output filename must be provided"; helpFunc
	fi

	if [ -z "$change_list" ]; then
		echo "For cov-run-desktop, change list must be provided"; helpFunc
	fi

    # Build
    echo -e "\n\n##### start cov-run-desktop build #####"
	$cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream $stream --user committer --password commit  --build --record-with-source ./compile_mplane.sh $build_options

    # Analyze
    echo -e "\n\n##### start cov-run-desktop analyze #####"
    $cov_path/cov-run-desktop --dir $inter_dir_path --url $url --stream $stream --user committer --password commit $cov_run_desktop_options --text-output $inter_dir_path/$output_filename @@/$change_list
else
    # Build
    echo -e "\n\n##### start cov-build build #####"
    $cov_path/cov-build --dir $inter_dir_path ./compile_mplane.sh $build_options
fi

exit 0
