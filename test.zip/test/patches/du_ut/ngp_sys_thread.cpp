/****************************************************************************************************************************
 *
 *          (c) Copyright 2012 by RadiSys Corporation. All rights reserved.
 *
 *   This software is confidential and proprietary to RadiSys Corporation.
 *   No part of this software may be reproduced, stored, transmitted,
 *   disclosed or used in any form or by any means other than as expressly
 *   provided by the written Software License Agreement between Radisys
 *   and its licensee.
 *
 *   Radisys warrants that for a period, as provided by the written
 *   Software License Agreement between Radisys and its licensee, this
 *   software will perform substantially to Radisys specifications as
 *   published at the time of shipment, exclusive of any updates or
 *   upgrades, and the media used for delivery of this software will be
 *   free from defects in materials and workmanship.  Radisys also warrants
 *   that has the corporate authority to enter into and perform under the
 *   Software License Agreement and it is the copyright owner of the software
 *   as originally delivered to its licensee.
 *
 *   RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
 *   WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
 *   A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
 *   MATERIALS.
 *
 *   IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
 *   CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
 *   OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
 *   ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
 *   LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
 *   OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *                     Restricted Rights Legend:
 *
 *   This software and all related materials licensed hereby are
 *   classified as "restricted computer software" as defined in clause
 *   52.227-19 of the Federal Acquisition Regulation ("FAR") and were
 *   developed entirely at private expense for nongovernmental purposes,
 *   are commercial in nature and have been regularly used for
 *   nongovernmental purposes, and, to the extent not published and
 *   copyrighted, are trade secrets and confidential and are provided
 *   with all rights reserved under the copyright laws of the United
 *   States.  The government's rights to the software and related
 *   materials are limited and restricted as provided in clause
 *   52.227-19 of the FAR.
 *
 *                  IMPORTANT LIMITATION(S) ON USE
 *
 *   The use of this software is limited to the use set
 *   forth in the written Software License Agreement between Radisys and
 *   its Licensee. Among other things, the use of this software
 *   may be limited to a particular type of Designated Equipment, as
 *   defined in such Software License Agreement.
 *   Before any installation, use or transfer of this software, please
 *   consult the written Software License Agreement or contact Radisys at
 *   the location set forth below in order to confirm that you are
 *   engaging in a permissible use of the software.
 *
 *                  RadiSys Corporation
 *                  Tel: +1 (858) 882 8800
 *                  Fax: +1 (858) 777 3388
 *                  Email: support@trillium.com
 *                  Web: http://www.radisys.com
 *
 ***************************************************************************************************************************/

/****************************************************************************************************************************
 *
 *  Name:
 *
 *  Type:   C++
 *
 *  Desc:
 *
 *  File:   ngp_sys_thread.cpp
 *
 *  Sid:
 *
 *  Prg:
 *
 ***************************************************************************************************************************/

/*!**************************************************************************************************************************
    \file        ngp_sys_thread.cpp

    \brief       This source file contains the implementation of sys thread
 ***************************************************************************************************************************/
#include "ngp_sys_thread.h"
#include "ngp_modules.h"
#include "ngp_logging_macros.h"
#ifdef LICENSE_ENABLED
#include "ngp_license.h"
#endif

/*!
    \namespace   ngp
    \brief       This namespace is used for implementing the Next Gen. Platform services
*/
namespace ngp
{
    /*!
        \fn          thread_entry_function
        \brief       This function is used for entering into the operations assigned to the thread
        \param       param   Contains the pointer to param of scheduling
        \return      Returns the void pointer
    */
    void* thread_entry_function(void* param)
    {
        ((sys_thread*)param)->on_init();
        ((sys_thread*)param)->run();
        ((sys_thread*)param)->on_exit();
        return 0;
    }

    /*!
        \fn          thread_start
        \brief       This function is used for staring the operation assigned to the thread.
        \param       param   Contains the pointer to param of scheduling
        \return      Returns the void pointer
    */
    extern "C" void* thread_start(void* param)
    {
        return ngp::thread_entry_function(param);
    }

    sys_thread::sys_thread(): thread_id(0), is_thread_running(false)
    {
#ifdef LICENSE_ENABLED
        ngp::license lic_obj = ngp::license::get_instance();
        bool ret = lic_obj.validate_license();

        if (ret)
        {
            std::cout << "License Successfully verified\n";
        }

#endif
        ngp::checked_memset(&thread_attr, 0, sizeof(thread_attr));
    }

    sys_thread::~sys_thread()
    {
        if ((thread_id) && (get_current_thread_id() != thread_id))
        {
            pthread_join(thread_id, NULL);
        }

        is_thread_running = false;
        pthread_attr_destroy(&thread_attr);
    }

    void sys_thread::cancel()
    {
        pthread_cancel(thread_id);
        is_thread_running = false;
    }

    ngp::ret_t sys_thread::create()
    {
        int result = pthread_attr_init(&thread_attr);

        if (0 != result)
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Insufficient memory exists to initialise the thread attributes object");
        }

        result = pthread_attr_setstacksize(&thread_attr, (size_t)(1024 * 1024));

        if (0 != result)
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Failed to set stack size to the thread");
        }

        result = pthread_attr_getschedparam(&thread_attr, &scheduling_params);

        if (0 != result)
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Failed to get scheduling parameter to the thread");
        }

        result = pthread_create(&thread_id, &thread_attr, thread_start, this);

        if (0 != result)
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Failed to create the thread");
            return ngp::ret_t::FAILURE;
        }

        //sys_thread is running, set flag to true
        is_thread_running = true;
        return ngp::ret_t::SUCCESS;
    }

    ngp::ret_t sys_thread::create(int priority, int32_t policy, std::list<int> core_list, std::string _thread_name)
    {
        thread_name = _thread_name;

        if (0 != pthread_attr_init(&thread_attr))
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Insufficient memory exists to initialise the thread attributes object");
        }

        ngp::checked_memset(&scheduling_params, 0, sizeof(scheduling_params));
        scheduling_params.sched_priority = priority;//Adding the core
        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);

        for (std::list<int>::iterator iterator = core_list.begin(); iterator != core_list.end(); iterator++)
        {
            CPU_SET(*iterator, &cpuset);
        }
/*++UT FIX changes start*/  
       if (cpuset.__bits[0] > 127)
        cpuset.__bits[0] = 1;
/*++UT FIX changes end*/ 
        if (0 != pthread_attr_setinheritsched(&thread_attr, PTHREAD_EXPLICIT_SCHED))
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Failed to set PTHREAD_EXPLICIT_SCHED");
        }

        if (0 != pthread_attr_setstacksize(&thread_attr, (size_t)(1024 * 1024)))
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Failed to set stack size to the thread");
        }

        if (0 != pthread_attr_setscope(&thread_attr, PTHREAD_SCOPE_SYSTEM))
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Failed to set scope to the thread");
        }

        if (0 != pthread_attr_setschedpolicy(&thread_attr, policy))
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Failed to set policy of the thread");
        }

        if (core_list.size() > 0)
        {
            if (0 != pthread_attr_setaffinity_np(&thread_attr, sizeof(cpu_set_t), &cpuset))
            {
                LOG_ERROR_VSTR(ngp::STHREAD, "Failed to set core affinity of the thread");
            }
        }

        if (0 != pthread_attr_setschedparam(&thread_attr, &scheduling_params))
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Failed to set scheduling parameter to the thread");
        }

        if (0 != pthread_create(&thread_id, &thread_attr, thread_start, this))
        {
            LOG_ERROR_VSTR(ngp::STHREAD, "Failed to create the thread");
            return ngp::ret_t::FAILURE;
        }

        //Adding the name to thread
        if (thread_name != "")
        {
            if (thread_name.size() > 15)
            {
                LOG_ERROR_VSTR(ngp::STHREAD, "Allowed size of thread name <= 15, Passed size of thread name:",
                               thread_name.size());
                thread_name.resize(15);
                LOG_INFO_VSTR(ngp::STHREAD, "After resize thread name : ", thread_name);
            }

            if (0 != pthread_setname_np(thread_id, thread_name.c_str()))
            {
                LOG_ERROR_VSTR(ngp::STHREAD, "Failed to set name to the thread");
            }
        }

        int32_t assigned_policy;

        if (0 == pthread_getschedparam(thread_id, &assigned_policy, &scheduling_params))
        {
            if (assigned_policy == SCHED_FIFO)
            {
                LOG_INFO_VSTR(ngp::STHREAD, "Policy : SCHED_FIFO");
            }
            else if (assigned_policy == SCHED_RR)
            {
                LOG_INFO_VSTR(ngp::STHREAD, "Policy : SCHED_RR");
            }
            else if (assigned_policy == SCHED_OTHER)
            {
                LOG_INFO_VSTR(ngp::STHREAD, "Policy : SCHED_OTHER");
            }
            else
            {
                LOG_INFO_VSTR(ngp::STHREAD, "Policy : INVALID");
            }
        }

        //sys_thread is running, set flag to true
        is_thread_running = true;
        return ngp::ret_t::SUCCESS;
    }

    void sys_thread::exit_thread(int exitcode)
    {
        if (thread_id)
        {
            if (get_current_thread_id() ==  thread_id)
            {
                pthread_exit((void*)(&exitcode));
            }
            else
            {
                pthread_cancel(thread_id);
            }

            is_thread_running = false;
        }
    }

    void sys_thread::join()
    {
        if ((thread_id) && (get_current_thread_id() != thread_id))
        {
            pthread_join(thread_id, NULL);
            thread_id = 0;
        }
    }

    void sys_thread::detach()
    {
        if (thread_id)
        {
            pthread_detach(thread_id);
        }
    }

    bool sys_thread::is_running()
    {
        return is_thread_running;
    }

    void sys_thread::kill_thread(int exitcode)
    {
        exit(exitcode);
    }

} // namespace ngp

/***************************************************************************************************************************
 *  End of file:
 ***************************************************************************************************************************/

/***************************************************************************************************************************
 *  Notes:
 ***************************************************************************************************************************/

/***************************************************************************************************************************
 *  Revision history:
 ***************************************************************************************************************************/
 
/***************************************************************************************************************************
 *  Version     Description
 *  ----------- ----------------------------------------------
 *  1.0         Initial release
 *  1.6         Release 2019-Q1
 *  1.7         Release 2019-Q2
 ***************************************************************************************************************************/
