# MP DevOps pipeline documentation

## How to use Jenkins Job Builder?

- Visit: [**jenkins_job_builder**](../jenkins_job_builder/README.md)

# How to apply the multi-stream pipeline approach?

- Visit: [**apply-multi-stream-pipeline-approach**](./apply-multi-stream-pipeline-approach.md)

# Releases metadata

- Visit: [**resources/releases**](../resources/releases/)
