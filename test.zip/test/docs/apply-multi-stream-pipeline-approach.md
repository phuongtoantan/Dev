# How to apply the multi-stream pipeline approach?

Read this Confluence page: https://confluence.cec.lab.emc.com/x/sc8cXw
